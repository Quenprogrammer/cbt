# Firestore list/permission fix

Fixed the evaluation errors reported for admin collection lists.

## Root cause
The previous rules used Map.get() on optional fields such as:
- request.auth.token.get('role', '')
- resource.data.get('authUid', '')
- resource.data.get('studentId', '')

Those expressions were throwing rule evaluation errors during collection list requests in the emulator.

## Changes
- Role checks now guard custom claim existence with `'role' in request.auth.token` before direct access.
- Student/assignment/draft rules guard optional fields with `'field' in resource.data` before direct access.
- Activity log create rule guards actorId the same way.
- AngularFire `user()` calls in ExamAttemptService are created inside `runInInjectionContext`.
- InvigilationService auth stream and direct Firestore writes are also wrapped in `runInInjectionContext`.

## Required after replacing project
Stop all running emulators and start them again so firestore.rules is reloaded:

npm run functions:build
npm run emulators

If the current emulator data was seeded before custom claims were created, run the seed once and then sign in again:

npm run seed

Admin login from the seed:
user1@example.com / password123
