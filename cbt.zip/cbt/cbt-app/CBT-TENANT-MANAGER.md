# CBT Multi-Tenant Platform + Tenant Manager

This project has been upgraded from a single-tenant CBT application into a multi-tenant CBT SaaS platform.

## Applications

- **CBT application**: existing Angular application on port `4200`.
- **Tenant Manager**: new Angular application in `projects/tenant-manager`, development port `4300`.
- **Firebase Emulator UI**: port `4000`.

## Tenant model

Each institution / CBT centre is one tenant.

```text
tenants/{tenantId}
  users/{uid}
  student/{studentId}
  staffs/{staffId}
  subjects/{subjectId}
    exams/{examId}
  examAssignments/{id}
  examDrafts/{id}
  examAttempts/{id}
  results/{id}
  examRegistrations/{id}
  notifications/{id}
  invigilationSchedules/{id}
  activityLogs/{id}
  exports/{id}
  settings/{id}
```

Platform-level collections are separate:

```text
platformAdmins/{uid}
platformPlans/{planId}
platformInvoices/{invoiceId}
platformPayments/{paymentId}
platformAuditLogs/{logId}
userTenancies/{uid}/tenants/{tenantId}
```

`resultChecks/{pin}` stays global because it is queried by opaque result PIN, but each record carries a `tenantId` and public access is only allowed while that tenant is active and the Public Results module is enabled.

## Tenant Manager features

The new Tenant Manager includes:

- Platform dashboard and aggregated tenant usage.
- Tenant / institution directory.
- Create a new institution and its first administrator.
- Active, trial, suspended, cancelled and deleted tenant states.
- Enable / disable access and lock / unlock a tenant.
- Mandatory reason when a tenant is locked, disabled, suspended or cancelled.
- Dedicated restricted-tenant detail page.
- Starter, Professional and Enterprise subscription plans.
- Per-tenant limits for students, staff, users, subjects and monthly exam attempts.
- Module entitlements for Students, Staff, Subjects, Exams, Invigilation, Results, Notifications, Exports and Public Results.
- Platform invoices and payment recording.
- Platform administrator list and platform audit logs.
- Loading and disabled states for platform operations.
- Futuristic responsive UI with persistent Dark / Light mode.
- Styled thin scrollbars.

## Restricted tenant login behaviour

The main CBT application checks the tenant immediately after authentication.

If the tenant is:

- locked,
- disabled,
- suspended,
- cancelled, or
- deleted,

then the user is routed to:

```text
/tenant-access
```

The page displays:

- institution name,
- tenant code,
- current tenant status,
- access status,
- lock status,
- the exact restriction reason entered in Tenant Manager,
- restriction/change date,
- **Check access again**, and
- **Sign out**.

The same restriction is also enforced by Cloud Functions and Firestore rules; changing the client route cannot bypass it.

## Student registration

Student registration now requires a tenant code. The registration page loads subjects for that institution and creates the student inside the selected tenant.

Examples from the emulator seed:

```text
DEMO-CBT
GREENFIELD-CBT
```

## Firebase Emulator Suite

Configured ports:

```text
Auth          9099
Functions     5001
Firestore     8980
Storage       9199
Emulator UI   4000
```

### Install

From the project root:

```bash
npm install
npm run tenant:install
```

### Start emulators

```bash
npm run emulators:fresh
```

After the emulators are running, use another terminal:

```bash
npm run seed:reset
```

### Start CBT app

```bash
npm start
```

Open:

```text
http://127.0.0.1:4200
```

### Start Tenant Manager

```bash
npm run start:tenant
```

Open:

```text
http://127.0.0.1:4300
```

## Emulator test accounts

### Platform / Tenant Manager

```text
Email:    platform@cbt.test
Password: Password123!
```

### Existing CBT tenant

```text
Tenant code: DEMO-CBT
Admin:       user1@example.com / password123
Student:     khaleel@example.com / 123456
Exam user:   user3@example.com / password123
```

The existing emulator dataset is migrated into `tenants/demo-cbt/...` by the seed.

### Second test tenant

```text
Tenant code: GREENFIELD-CBT
Admin:       greenfield.admin@cbt.test
Password:    Password123!
```

This gives a second tenant for data-isolation and suspension/locking tests.

## Recommended acceptance test

1. Start emulators and run the seed.
2. Sign into Tenant Manager as `platform@cbt.test`.
3. Confirm `DEMO-CBT` and `GREENFIELD-CBT` are listed separately.
4. Sign into CBT as the existing `DEMO-CBT` admin and confirm legacy data is available.
5. Sign into `GREENFIELD-CBT` and verify Demo CBT records are not visible.
6. Create another tenant from Tenant Manager.
7. Sign in with its first administrator account.
8. Add students / staff / subjects and confirm they are stored only below that tenant.
9. Lock the tenant in Tenant Manager and enter a reason.
10. Attempt login in the CBT app and confirm `/tenant-access` displays that reason.
11. Unlock the tenant and use **Check access again**.
12. Suspend and cancel the tenant and repeat the test.
13. Test the Student, Staff and Subject limits.
14. Disable the Exams / Results / Public Results modules and verify the corresponding operations are denied.

## Deployment

The Tenant Manager is configured as a separate Firebase App Hosting backend:

```text
Backend ID: cbt-tenant-manager
App root:   projects/tenant-manager
Node:       22
```

The root CBT application can continue using its current deployment configuration.

For a production rollout, migrate existing live single-tenant records and existing Auth users into a tenant before enabling the tenant-scoped Firestore rules. The emulator seed performs this migration only for emulator/test data.

## Security design

- Platform administrators are not normal CBT tenant administrators.
- Tenant Manager cross-tenant operations are performed through verified callable Functions.
- The browser is not granted direct access to platform collections.
- Tenant membership is enforced with the Firebase Auth `tenantId` custom claim.
- Tenant state is checked in both Cloud Functions and Firestore rules.
- Plan limits are checked in callable registration/exam flows and Firestore creation rules for direct admin writes.
- Legacy root CBT collections are closed by Firestore rules after migration.
