# CBT Tenant Manager

Platform-owner portal for the multi-tenant CBT SaaS application.

## Development

From the repository root:

```bash
npm run tenant:install
npm run start:tenant
```

Development URL: `http://127.0.0.1:4300`

The development Firebase client automatically uses the emulator suite:

- Auth `127.0.0.1:9099`
- Functions `127.0.0.1:5001`
- Firestore `127.0.0.1:8980`
- Storage `127.0.0.1:9199`

After running the root emulator seed, sign in with:

```text
platform@cbt.test
Password123!
```

## App Hosting

Backend ID: `cbt-tenant-manager`

App root directory: `projects/tenant-manager`

Runtime: Node 22
