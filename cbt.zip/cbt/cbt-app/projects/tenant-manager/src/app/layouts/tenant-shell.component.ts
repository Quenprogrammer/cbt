import { Component, OnInit, signal } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { PlatformAuthService } from '../core/auth/platform-auth.service';
import { TenantThemeService } from '../core/services/tenant-theme.service';
import { TenantDirectoryService } from '../core/services/tenant-directory.service';
import { DiscardChangesService } from '../core/services/discard-changes.service';

interface RefreshablePage { refresh?(): Promise<void>; ngOnInit?(): void | Promise<void>; hasUnsavedChanges?(): boolean; }
@Component({
  selector: 'tenant-shell', standalone: true, imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
  <a class="skip-link" href="#main-content">Skip to content</a>
  <div class="app-shell">
    <aside class="sidebar" aria-label="Platform navigation">
      <a class="brand" routerLink="/tenants"><span class="brand-mark">C</span><span><strong>CBT Platform</strong><small>Tenant management</small></span></a>
      <a class="primary-button full" routerLink="/tenants/new" (click)="menuOpen.set(false)">+ New institution</a>
      <button class="mobile-menu secondary-button" (click)="menuOpen.set(!menuOpen())" [attr.aria-expanded]="menuOpen()" aria-controls="platform-navigation">Institutions & navigation <i class="bi bi-list"></i></button>
      <div id="platform-navigation" class="sidebar-navigation" [class.mobile-open]="menuOpen()">
        <nav aria-label="Main navigation">
          <a routerLink="/tenants" routerLinkActive="active" [routerLinkActiveOptions]="{exact:true}" ariaCurrentWhenActive="page" (click)="menuOpen.set(false)">All institutions</a>
          <a routerLink="/plans" routerLinkActive="active" ariaCurrentWhenActive="page" (click)="menuOpen.set(false)">Pricing plans</a>
        </nav>
        <p class="nav-label">Institutions</p>
        <nav class="institution-nav" aria-label="Institutions">
          @for(t of directory.tenants(); track t.id) {
            <a [routerLink]="['/tenants',t.id]" routerLinkActive="active" ariaCurrentWhenActive="page" (click)="menuOpen.set(false)">
              <strong>{{t.name}}</strong><small>{{t.tenantCode}}</small><span class="sidebar-badge">{{t.locked ? 'Locked' : t.accessStatus === 'disabled' ? 'Restricted' : t.status}}</span>
            </a>
          } @empty { <p class="sidebar-empty">{{directory.loading() ? 'Loading institutions…' : directory.error() ? 'Institutions unavailable. Try Refresh.' : 'No institutions yet.'}}</p> }
        </nav>
        <p class="nav-label">Platform</p>
        <nav aria-label="Platform tools">
          <a routerLink="/dashboard" routerLinkActive="active" ariaCurrentWhenActive="page" (click)="menuOpen.set(false)">Dashboard</a>
          <a routerLink="/billing" routerLinkActive="active" ariaCurrentWhenActive="page" (click)="menuOpen.set(false)">All billing</a>
          @if(auth.session()?.role === 'platform-owner' || auth.session()?.role === 'platform-admin') {
            <a routerLink="/platform-users" routerLinkActive="active" ariaCurrentWhenActive="page" (click)="menuOpen.set(false)">Platform administrators</a>
          }
          @if(auth.session()?.role !== 'billing-admin') { <a routerLink="/audit" routerLinkActive="active" ariaCurrentWhenActive="page" (click)="menuOpen.set(false)">Audit logs</a> }
        </nav>
      </div>
      <div class="sidebar-footer"><small>{{auth.session()?.displayName}} · {{auth.session()?.role}}</small></div>
    </aside>
    <main class="main" id="main-content">
      <header class="topbar"><span class="eyebrow">Platform administration</span><div class="topbar-actions">
        <button class="secondary-button theme-toggle" (click)="theme.toggle()" [attr.aria-label]="theme.isDark() ? 'Switch to light mode' : 'Switch to dark mode'"><i class="bi" [class.bi-sun]="theme.isDark()" [class.bi-moon]="!theme.isDark()"></i></button>
        <button class="secondary-button" [disabled]="refreshing()" (click)="refresh()">{{refreshing() ? 'Refreshing…' : 'Refresh'}}</button>
        <button class="secondary-button outline-button" [disabled]="loggingOut()" (click)="logout()">{{loggingOut() ? 'Signing out…' : 'Sign out'}}</button>
      </div></header>
      @if(error()) { <div class="page shell-error" role="alert">{{error()}}</div> }
      <router-outlet (activate)="activePage = $event" />
    </main>
  </div>
  @if(discard.prompt(); as prompt) {
    <div class="dialog-backdrop"><section class="discard-dialog" role="dialog" aria-modal="true" aria-labelledby="discard-title" (keydown.escape)="discard.answer(false)">
      <h2 id="discard-title">Unsaved changes</h2><p>{{prompt}}</p><div class="form-actions">
        <button id="keep-editing" class="secondary-button" (click)="discard.answer(false)" (keydown.shift.tab)="$event.preventDefault(); discardButton.focus()">Keep editing</button>
        <button #discardButton class="primary-button" (click)="discard.answer(true)" (keydown.tab)="trapTab($event)">Discard changes</button>
      </div>
    </section></div>
  }`
})
export class TenantShellComponent implements OnInit {
  readonly loggingOut = signal(false);
  readonly refreshing = signal(false);
  readonly menuOpen = signal(false);
  readonly error = signal<string | null>(null);
  activePage?: RefreshablePage;
  constructor(readonly auth: PlatformAuthService, readonly theme: TenantThemeService,
    readonly directory: TenantDirectoryService, readonly discard:DiscardChangesService, private readonly router: Router) {}
  ngOnInit(): void { void this.directory.reload(); }
  async refresh(): Promise<void> {
    if (this.refreshing()) return;
    if (this.activePage?.hasUnsavedChanges?.() && !await this.discard.confirm('Discard your unsaved changes and refresh?')) return;
    this.refreshing.set(true); this.error.set(null);
    try {
      await this.directory.reload();
      if (this.activePage?.refresh) await this.activePage.refresh();
      else await this.activePage?.ngOnInit?.();
    } catch (error) { this.error.set(error instanceof Error ? error.message : 'Unable to refresh.'); }
    finally { this.refreshing.set(false); }
  }
  async logout(): Promise<void> {
    if (this.loggingOut()) return;
    this.loggingOut.set(true);
    try { if(await this.router.navigateByUrl('/login')) await this.auth.logout(); }
    finally { this.loggingOut.set(false); }
  }
  trapTab(event:Event):void { if(!(event as KeyboardEvent).shiftKey){event.preventDefault();document.getElementById('keep-editing')?.focus();} }
}
