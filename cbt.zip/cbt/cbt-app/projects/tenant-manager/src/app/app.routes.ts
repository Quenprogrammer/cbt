import { Routes } from '@angular/router';
import { authGuard } from './core/auth/auth.guard';
import { LoginPage } from './features/auth/login.page';
import { TenantShellComponent } from './layouts/tenant-shell.component';
import { DashboardPage } from './features/dashboard/dashboard.page';
import { TenantsPage } from './features/tenants/tenants.page';
import { CreateTenantPage } from './features/tenants/create-tenant.page';
import { TenantDetailsPage } from './features/tenants/tenant-details.page';
import { TenantStatusPage } from './features/tenants/tenant-status.page';
import { PlansPage } from './features/plans/plans.page';
import { BillingPage } from './features/billing/billing.page';
import { AuditPage } from './features/audit/audit.page';
import { PlatformUsersPage } from './features/platform-users/platform-users.page';
import { TenantOverviewPage } from './features/tenants/tenant-overview.page';
import { TenantAccessPage } from './features/tenants/tenant-access.page';
import { TenantSubscriptionPage } from './features/tenants/tenant-subscription.page';
import { TenantFinancePage } from './features/tenants/tenant-finance.page';
import { unsavedChangesGuard } from './core/auth/unsaved-changes.guard';

export const routes: Routes = [
  { path: 'login', component: LoginPage },
  { path: '', component: TenantShellComponent, canActivate: [authGuard], children: [
    { path: 'dashboard', component: DashboardPage },
    { path: 'tenants', component: TenantsPage },
    { path: 'tenants/new', component: CreateTenantPage, canDeactivate: [unsavedChangesGuard] },
    { path: 'tenants/:tenantId/status', component: TenantStatusPage },
    { path: 'tenants/:tenantId', component: TenantDetailsPage, children: [
      { path: 'overview', component: TenantOverviewPage },
      { path: 'access', component: TenantAccessPage, canDeactivate: [unsavedChangesGuard] },
      { path: 'billing', component: TenantSubscriptionPage, canDeactivate: [unsavedChangesGuard] },
      { path: 'invoices', component: TenantFinancePage, data: {mode:'invoices'}, canDeactivate: [unsavedChangesGuard] },
      { path: 'payments', component: TenantFinancePage, data: {mode:'payments'}, canDeactivate: [unsavedChangesGuard] },
      { path: '', pathMatch: 'full', redirectTo: 'overview' }
    ] },
    { path: 'plans', component: PlansPage, canDeactivate: [unsavedChangesGuard] },
    { path: 'billing', component: BillingPage, canDeactivate: [unsavedChangesGuard] },
    { path: 'platform-users', component: PlatformUsersPage },
    { path: 'audit', component: AuditPage },
    { path: '', pathMatch: 'full', redirectTo: 'tenants' }
  ]},
  { path: '**', redirectTo: 'tenants' }
];
