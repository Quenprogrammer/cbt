import { Injectable, computed, signal } from '@angular/core';
import { User, onAuthStateChanged, signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { firebaseAuth } from '../firebase/firebase.client';
import { PlatformApiService } from '../services/platform-api.service';
import { PlatformSession } from '../models/platform.models';

@Injectable({ providedIn: 'root' })
export class PlatformAuthService {
  readonly firebaseUser = signal<User | null>(null);
  readonly session = signal<PlatformSession | null>(null);
  readonly initialized = signal(false);
  readonly loading = signal(false);
  readonly error = signal<string | null>(null);
  readonly authenticated = computed(() => !!this.firebaseUser() && !!this.session());

  constructor(private readonly api: PlatformApiService) {
    onAuthStateChanged(firebaseAuth, async user => {
      this.firebaseUser.set(user);
      if (!user) { this.session.set(null); this.initialized.set(true); return; }
      try { this.session.set(await this.api.session()); }
      catch { this.session.set(null); await signOut(firebaseAuth); }
      finally { this.initialized.set(true); }
    });
  }
  async login(email: string, password: string) {
    this.loading.set(true); this.error.set(null);
    try {
      await signInWithEmailAndPassword(firebaseAuth, email.trim(), password);
      this.session.set(await this.api.session());
    } catch (error) {
      this.error.set(error instanceof Error ? error.message : 'Unable to sign in.');
      throw error;
    } finally { this.loading.set(false); }
  }
  async logout() { await signOut(firebaseAuth); this.session.set(null); }
}
