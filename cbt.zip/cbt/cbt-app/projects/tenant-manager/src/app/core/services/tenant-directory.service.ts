import { Injectable, signal } from '@angular/core';
import { PlatformApiService } from './platform-api.service';
import { TenantInstitution } from '../models/platform.models';

@Injectable({ providedIn: 'root' })
export class TenantDirectoryService {
  readonly tenants = signal<TenantInstitution[]>([]);
  readonly loading = signal(false);
  readonly error = signal<string | null>(null);
  private pending?: Promise<void>;
  constructor(private readonly api: PlatformApiService) {}
  reload(): Promise<void> {
    if (this.pending) return this.pending;
    this.loading.set(true); this.error.set(null);
    this.pending = this.api.tenants().then(result => { this.tenants.set(result.tenants); })
      .catch(error => { this.error.set(error instanceof Error ? error.message : 'Unable to load institutions.'); })
      .finally(() => { this.loading.set(false); this.pending = undefined; });
    return this.pending;
  }
  update(tenant: TenantInstitution): void {
    this.tenants.update(items => items.some(item => item.id === tenant.id)
      ? items.map(item => item.id === tenant.id ? tenant : item) : [tenant, ...items]);
  }
}
