export type PlatformRole = 'platform-owner' | 'platform-admin' | 'billing-admin' | 'support';
export type TenantStatus = 'trial' | 'active' | 'suspended' | 'cancelled' | 'deleted';
export type SubscriptionStatus = 'trial' | 'active' | 'grace-period' | 'past-due' | 'suspended' | 'cancelled';

export interface PlatformSession { uid:string; email:string; displayName:string; role:PlatformRole; }
export interface TenantLimits { students:number; staff:number; users:number; subjects:number; monthlyAttempts:number; }
export interface TenantModules { students:boolean; staff:boolean; subjects:boolean; exams:boolean; invigilation:boolean; results:boolean; notifications:boolean; exports:boolean; publicResults:boolean; }
export interface TenantInstitution {
  id:string; name:string; shortName:string; tenantCode:string; email:string; phone:string; address:string;
  timezone:string; currency:string; status:TenantStatus; accessStatus:'enabled'|'disabled'; locked:boolean;
  statusReason?:string; statusChangedAt?:string|null; statusChangedBy?:string; planId:string;
  subscriptionStatus:SubscriptionStatus; limits:TenantLimits; modules:TenantModules;
  usage?:Partial<TenantLimits>; createdAt?:string|null; updatedAt?:string|null;
}
export interface PlatformPlan { id:string; name:string; description:string; priceMonthly:number; currency:string; status:'active'|'inactive'; limits:TenantLimits; modules:TenantModules; }
export interface PlatformDashboard { totalTenants:number; activeTenants:number; trialTenants:number; suspendedTenants:number; totalStudents:number; totalStaff:number; totalUsers:number; totalSubjects:number; recentTenants:TenantInstitution[]; }
export interface PlatformInvoice { id:string; invoiceNo:string; tenantId:string; tenantName:string; planId:string; description:string; amount:number; amountPaid:number; balance:number; currency:string; status:'unpaid'|'part-paid'|'paid'|'void'; dueDate:string; createdAt?:string|null; }
export interface PlatformPayment { id:string; invoiceId:string; invoiceNo:string; tenantId:string; tenantName:string; amount:number; currency:string; method:string; reference:string; paidAt:string; createdAt?:string|null; }
export interface PlatformAuditLog { id:string; actorId:string; actorName:string; actorRole:string; action:string; tenantId:string|null; details?:Record<string,unknown>; createdAt?:string|null; }
export interface PlatformAdmin { id:string; uid:string; email:string; displayName:string; role:PlatformRole; status:string; createdAt?:string|null; updatedAt?:string|null; }
