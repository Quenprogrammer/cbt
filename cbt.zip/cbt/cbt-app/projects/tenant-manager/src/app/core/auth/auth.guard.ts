import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { PlatformAuthService } from './platform-auth.service';

export const authGuard: CanActivateFn = async () => {
  const auth = inject(PlatformAuthService); const router = inject(Router);
  if (!auth.initialized()) await new Promise<void>(resolve => {
    const timer = setInterval(() => { if (auth.initialized()) { clearInterval(timer); resolve(); } }, 25);
  });
  return auth.authenticated() ? true : router.parseUrl('/login');
};
