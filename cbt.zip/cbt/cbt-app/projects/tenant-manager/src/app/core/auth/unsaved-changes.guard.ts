import { CanDeactivateFn } from '@angular/router';
import { inject } from '@angular/core';
import { DiscardChangesService } from '../services/discard-changes.service';
export interface EditablePage { hasUnsavedChanges(): boolean; }
export const unsavedChangesGuard: CanDeactivateFn<EditablePage> = page =>
  !page.hasUnsavedChanges() || inject(DiscardChangesService).confirm();
