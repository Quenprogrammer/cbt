import { DOCUMENT } from '@angular/common';
import { computed, inject, Injectable, signal } from '@angular/core';

export type TenantThemeMode = 'light' | 'dark';

@Injectable({ providedIn: 'root' })
export class TenantThemeService {
  private readonly document = inject(DOCUMENT);
  private readonly storageKey = 'tenant-platform.tenant-manager.theme';
  readonly mode = signal<TenantThemeMode>(this.readInitialMode());
  readonly isDark = computed(() => this.mode() === 'dark');

  constructor() { this.apply(this.mode(), false); }

  toggle(): void { this.set(this.isDark() ? 'light' : 'dark'); }
  set(mode: TenantThemeMode): void { this.apply(mode, true); }

  private readInitialMode(): TenantThemeMode {
    try {
      const stored = this.document.defaultView?.localStorage.getItem(this.storageKey);
      if (stored === 'light' || stored === 'dark') return stored;
    } catch { /* localStorage can be unavailable */ }
    return 'light';
  }

  private apply(mode: TenantThemeMode, persist: boolean): void {
    this.mode.set(mode);
    this.document.documentElement.dataset['tenantTheme'] = mode;
    this.document.documentElement.style.colorScheme = mode;
    const meta = this.document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');
    meta?.setAttribute('content', mode === 'dark' ? '#07101f' : '#f4f7fb');
    if (persist) {
      try { this.document.defaultView?.localStorage.setItem(this.storageKey, mode); } catch { /* ignored */ }
    }
  }
}
