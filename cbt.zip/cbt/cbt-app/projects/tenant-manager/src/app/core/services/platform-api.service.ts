import {Injectable} from '@angular/core';
import {httpsCallable} from 'firebase/functions';
import {cloudFunctions} from '../firebase/firebase.client';
import {
  PlatformAdmin,
  PlatformAuditLog,
  PlatformDashboard,
  PlatformInvoice,
  PlatformPayment,
  PlatformPlan,
  PlatformSession,
  TenantInstitution, TenantModules, TenantLimits
} from '../models/platform.models';

@Injectable({providedIn: 'root'})
export class PlatformApiService {
  private async call<TReq extends object, TRes>(name: string, data: TReq = {} as TReq): Promise<TRes> {
    const fn = httpsCallable<TReq, TRes>(cloudFunctions, name);
    return (await fn(data)).data;
  }

  session() {
    return this.call<Record<string, never>, PlatformSession>('tenant_platform-getPlatformSession');
  }

  dashboard() {
    return this.call<Record<string, never>, PlatformDashboard>('tenant_platform-getPlatformDashboard');
  }

  tenants() {
    return this.call<Record<string, never>, { tenants: TenantInstitution[] }>('tenant_platform-listTenantInstitutions');
  }

  tenant(tenantId: string) {
    return this.call<{ tenantId: string }, TenantInstitution>('tenant_platform-getTenantInstitution', {tenantId});
  }

  plans() {
    return this.call<Record<string, never>, { plans: PlatformPlan[] }>('tenant_platform-listPlatformPlans');
  }

  createInstitution(payload: Record<string, unknown>) {
    return this.call<Record<string, unknown>, { tenantId: string }>('tenant_platform-createTenantInstitution', payload);
  }

  setStatus(tenantId: string, status: string, accessStatus: string, locked: boolean, statusReason = '') {
    return this.call('tenant_platform-setTenantInstitutionStatus', {
      tenantId,
      status,
      accessStatus,
      locked,
      statusReason
    });
  }

  setLimits(tenantId: string, limits: TenantLimits) {
    return this.call('tenant_platform-setTenantInstitutionLimits', {tenantId, limits});
  }

  setModules(
    tenantId: string,
    modules: TenantModules
  ) {
    return this.call('tenant_platform-setTenantInstitutionModules', {
      tenantId,
      modules
    });
  }

  savePlan(plan: PlatformPlan) {
    return this.call('tenant_platform-savePlatformPlan', {plan});
  }

  setPlan(tenantId: string, planId: string, subscriptionStatus: string, applyPlanDefaults = false) {
    return this.call('tenant_platform-setTenantInstitutionPlan', {
      tenantId,
      planId,
      subscriptionStatus,
      applyPlanDefaults
    });
  }

  invoices(tenantId?: string) {
    return this.call<{tenantId?: string}, { invoices: PlatformInvoice[] }>('tenant_platform-listPlatformInvoices', tenantId ? {tenantId} : {});
  }

  createInvoice(payload: Record<string, unknown>) {
    return this.call<Record<string, unknown>, {
      invoiceId: string;
      invoiceNo: string
    }>('tenant_platform-createPlatformInvoice', payload);
  }

  recordPayment(payload: Record<string, unknown>) {
    return this.call<Record<string, unknown>, { paymentId: string }>('tenant_platform-recordPlatformPayment', payload);
  }

  payments(tenantId?: string) {
    return this.call<{tenantId?: string}, { payments: PlatformPayment[] }>('tenant_platform-listPlatformPayments', tenantId ? {tenantId} : {});
  }

  auditLogs() {
    return this.call<Record<string, never>, { logs: PlatformAuditLog[] }>('tenant_platform-listPlatformAuditLogs');
  }

  admins() {
    return this.call<Record<string, never>, { admins: PlatformAdmin[] }>('tenant_platform-listPlatformAdmins');
  }
}
