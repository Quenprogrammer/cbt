import { initializeApp } from 'firebase/app';
import { connectAuthEmulator, getAuth } from 'firebase/auth';
import { connectFirestoreEmulator, getFirestore } from 'firebase/firestore';
import { connectFunctionsEmulator, getFunctions } from 'firebase/functions';
import { connectStorageEmulator, getStorage } from 'firebase/storage';
import { environment } from '../../../environments/environment';

export const firebaseApp=initializeApp(environment.firebase,'cbt-tenant-manager');
export const firebaseAuth=getAuth(firebaseApp);
export const firestore=getFirestore(firebaseApp);
export const cloudFunctions=getFunctions(firebaseApp);
export const firebaseStorage=getStorage(firebaseApp);
const marker='__cbtTenantManagerEmulatorsConnected';
const state=globalThis as typeof globalThis & Record<string,unknown>;
if(environment.useEmulators&&!state[marker]){
  connectAuthEmulator(firebaseAuth,'http://127.0.0.1:9099',{disableWarnings:true});
  connectFirestoreEmulator(firestore,'127.0.0.1',8980);
  connectFunctionsEmulator(cloudFunctions,'127.0.0.1',5001);
  connectStorageEmulator(firebaseStorage,'127.0.0.1',9199);
  state[marker]=true;
}
