import { Injectable, signal } from '@angular/core';

@Injectable({providedIn:'root'})
export class DiscardChangesService {
  readonly prompt=signal<string|null>(null);
  private resolve?: (discard:boolean)=>void;
  private previousFocus:HTMLElement|null=null;
  confirm(prompt='Discard your unsaved changes?'):Promise<boolean> {
    if(this.resolve) return Promise.resolve(false);
    this.previousFocus=document.activeElement as HTMLElement|null;
    this.prompt.set(prompt);
    setTimeout(()=>document.getElementById('keep-editing')?.focus());
    return new Promise<boolean>(resolve=>{this.resolve=resolve;});
  }
  answer(discard:boolean):void {
    const resolve=this.resolve; this.resolve=undefined; this.prompt.set(null);
    this.previousFocus?.focus(); resolve?.(discard);
  }
}
