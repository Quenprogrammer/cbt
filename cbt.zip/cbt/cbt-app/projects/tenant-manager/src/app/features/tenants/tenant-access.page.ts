import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TenantWorkspaceService, limitKeys, limitLabels, moduleKeys, moduleLabels } from './tenant-workspace.service';
import { TenantLimits, TenantModules } from '../../core/models/platform.models';

@Component({standalone:true,imports:[FormsModule],template:`
<div class="detail-grid">
  <section class="panel"><span class="panel-kicker">Capacity</span><h2>Usage limits</h2>
    <form #limitsForm="ngForm" (ngSubmit)="saveLimits()"><div class="form-grid">@for(key of keys; track key) { <label>{{labels[key]}}<input type="number" min="1" step="1" required [name]="key" [(ngModel)]="limits[key]" [disabled]="workspace.busy() || !workspace.canManage()"></label> }</div><div class="form-actions"><button class="primary-button" [disabled]="limitsForm.invalid || workspace.busy() || !workspace.canManage()">Save limits</button></div></form>
  </section>
  <section class="panel"><span class="panel-kicker">Availability</span><h2>Institution access</h2><p>Changes apply to CBT login and server access checks.</p>
    <form (ngSubmit)="saveAccess()"><div class="form-grid"><label>Status<select name="status" [(ngModel)]="status" [disabled]="workspace.busy() || !workspace.canAccess()"><option value="trial">Trial</option><option value="active">Active</option><option value="suspended">Suspended</option><option value="cancelled">Cancelled</option>@if(status==='deleted'){<option value="deleted">Deleted</option>}</select></label><label>Application access<select name="accessStatus" [(ngModel)]="accessStatus" [disabled]="workspace.busy() || !workspace.canAccess()"><option value="enabled">Enabled</option><option value="disabled">Disabled</option></select></label></div>
      <div class="form-actions"><button class="primary-button" [disabled]="workspace.busy() || !workspace.canAccess()">Save access</button></div>
      <hr><span class="panel-kicker">Emergency control</span><h2>Institution lock</h2>
      <label class="check-card"><input name="locked" type="checkbox" [(ngModel)]="locked" [disabled]="workspace.busy() || !workspace.canAccess()">Block all operational access</label>
      <label>Restriction reason<textarea name="reason" rows="3" [(ngModel)]="reason" [disabled]="workspace.busy() || !workspace.canAccess()" placeholder="Explain the restriction to institution users"></textarea></label><p class="hint">A reason is required when access is locked, disabled, suspended or cancelled.</p>
      <div class="form-actions"><button class="primary-button danger-button" [disabled]="workspace.busy() || !workspace.canAccess()">Save lock state</button></div>
    </form>
  </section>
</div>
<section class="panel"><span class="panel-kicker">Permissions</span><h2>CBT modules</h2><p>Choose which features this institution can access.</p>
  <div class="module-grid">@for(key of modulesKeys; track key) { <label class="check-card module-card"><input type="checkbox" [(ngModel)]="modules[key]" [disabled]="workspace.busy() || !workspace.canManage()"><span>{{moduleNames[key]}}</span></label> }</div>
  <div class="form-actions"><button class="primary-button" [disabled]="workspace.busy() || !workspace.canManage()" (click)="saveModules()">Save modules</button></div>
</section>
`})
export class TenantAccessPage {
  readonly keys=limitKeys; readonly labels=limitLabels; readonly modulesKeys=moduleKeys; readonly moduleNames=moduleLabels;
  limits:TenantLimits; modules:TenantModules;
  status:string; accessStatus:string; locked:boolean; reason:string;
  private limitsBaseline:string; private modulesBaseline:string; private accessBaseline:string;
  constructor(readonly workspace:TenantWorkspaceService) {
    const t=workspace.tenant()!;
    this.limits={...t.limits}; this.modules={...t.modules}; this.status=t.status; this.accessStatus=t.accessStatus; this.locked=t.locked; this.reason=t.statusReason ?? '';
    this.limitsBaseline=JSON.stringify(this.limits); this.modulesBaseline=JSON.stringify(this.modules); this.accessBaseline=this.accessSnapshot();
  }
  private accessSnapshot():string { return JSON.stringify([this.status,this.accessStatus,this.locked,this.reason]); }
  hasUnsavedChanges():boolean { return this.workspace.busy() || this.limitsBaseline!==JSON.stringify(this.limits) || this.modulesBaseline!==JSON.stringify(this.modules) || this.accessBaseline!==this.accessSnapshot(); }
  async saveLimits():Promise<void> {
    if(Object.values(this.limits).some(v=>!Number.isInteger(v)||v<1)) { this.workspace.error.set('Limits must be whole numbers of at least 1.'); return; }
    if(await this.workspace.run(()=>this.workspace.api.setLimits(this.workspace.tenantId,this.limits),'Usage limits updated.')) this.limitsBaseline=JSON.stringify(this.limits);
  }
  async saveModules():Promise<void> { if(await this.workspace.run(()=>this.workspace.api.setModules(this.workspace.tenantId,this.modules),'Module permissions updated.')) this.modulesBaseline=JSON.stringify(this.modules); }
  async saveAccess():Promise<void> {
    if((this.locked || this.accessStatus==='disabled' || ['suspended','cancelled','deleted'].includes(this.status)) && !this.reason.trim()) { this.workspace.error.set('Enter a reason before restricting institution access.'); return; }
    if(await this.workspace.run(()=>this.workspace.api.setStatus(this.workspace.tenantId,this.status,this.accessStatus,this.locked,this.reason),'Institution access updated.')) {
      const t=this.workspace.tenant()!; this.accessStatus=t.accessStatus; this.reason=t.statusReason ?? ''; this.accessBaseline=this.accessSnapshot();
    }
  }
}
