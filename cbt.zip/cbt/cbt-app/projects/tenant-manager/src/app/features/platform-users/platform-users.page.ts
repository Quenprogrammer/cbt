import { Component, OnInit, signal } from '@angular/core';
import { PlatformAdmin } from '../../core/models/platform.models';
import { PlatformApiService } from '../../core/services/platform-api.service';

@Component({standalone:true,template:`
<div class="page"><header class="page-header"><div><span class="eyebrow">PLATFORM ACCESS LAYER</span><h1>Platform Users</h1><p>Administrators authorized to access the Tenant Manager.</p></div></header>
<section class="panel network-panel">
@if(loading()){
  <div class="loading-state"><span class="spinner"></span><div><strong>Loading access directory</strong><small>Verifying platform administrator records…</small></div></div>
}@else if(error()){
  <div class="alert error">{{error()}}</div>
}@else{
<div class="table-wrap"><table><thead><tr><th>User</th><th>Role</th><th>Status</th><th>Created</th></tr></thead><tbody>@for(a of admins();track a.id){<tr><td><div class="tenant-cell"><span class="tenant-orb admin-orb">{{initials(a.displayName)}}</span><span><strong>{{a.displayName}}</strong><span class="muted">{{a.email}}</span></span></div></td><td><span class="pill">{{a.role}}</span></td><td><span class="status">{{a.status}}</span></td><td>{{a.createdAt||'—'}}</td></tr>}@empty{<tr><td colspan="4" class="empty">No platform administrators found.</td></tr>}</tbody></table></div>
}
</section></div>`})
export class PlatformUsersPage implements OnInit{
  readonly admins=signal<PlatformAdmin[]>([]);readonly loading=signal(true);readonly error=signal<string|null>(null);
  constructor(private readonly api:PlatformApiService){}
  initials(name:string){return name.split(' ').map(v=>v[0]).join('').slice(0,2).toUpperCase()||'PA';}
  async ngOnInit(){try{this.admins.set((await this.api.admins()).admins);}catch(e){this.error.set(e instanceof Error?e.message:'Unable to load platform users.');}finally{this.loading.set(false);}}
}
