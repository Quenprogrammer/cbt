import { Component, OnDestroy, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { PlatformInvoice, PlatformPayment } from '../../core/models/platform.models';
import { TenantWorkspaceService } from './tenant-workspace.service';

function localDateTime():string { const date=new Date(); return new Date(date.getTime()-date.getTimezoneOffset()*60000).toISOString().slice(0,16); }
@Component({standalone:true,imports:[FormsModule],template:`
@if(loading()) { <div class="loading-state" role="status"><span class="spinner"></span>Loading {{mode}}…</div> }
@else {
  <section class="panel"><span class="panel-kicker">{{mode==='invoices' ? 'Receivables' : 'Collections'}}</span><h2>{{mode==='invoices' ? 'Create invoice' : 'Record payment'}}</h2>
    @if(mode==='invoices') {
      <form #invoiceForm="ngForm" (ngSubmit)="createInvoice()"><div class="form-grid"><label>Invoice number<input value="Generated automatically" readonly></label><label>Amount<input type="number" name="amount" min="0.01" step="0.01" required [(ngModel)]="invoice.amount" [disabled]="busy() || !workspace.canBill()"></label>
      <label>Currency<input name="currency" maxlength="3" minlength="3" required [(ngModel)]="invoice.currency" [disabled]="busy() || !workspace.canBill()"></label><label>Plan<input [value]="workspace.tenant()!.planId" readonly></label><label>Due date<input type="date" name="dueDate" required [(ngModel)]="invoice.dueDate" [disabled]="busy() || !workspace.canBill()"></label><label>Description<input name="description" [(ngModel)]="invoice.description" required maxlength="250" [disabled]="busy() || !workspace.canBill()"></label></div>
      <div class="form-actions"><button class="primary-button" [disabled]="invoiceForm.invalid || busy() || !workspace.canBill()">{{busy() ? 'Creating…' : 'Create invoice'}}</button></div></form>
    } @else {
      <form #paymentForm="ngForm" (ngSubmit)="recordPayment()"><div class="form-grid"><label>Invoice<select name="invoiceId" required [(ngModel)]="payment.invoiceId" [disabled]="busy() || !workspace.canBill()"><option value="">Select invoice</option>@for(i of openInvoices();track i.id){<option [value]="i.id">{{i.invoiceNo}} · {{i.currency}} {{i.balance.toLocaleString()}} outstanding</option>}</select></label><label>Amount<input name="amount" type="number" min="0.01" step="0.01" required [(ngModel)]="payment.amount" [disabled]="busy() || !workspace.canBill()"></label><label>Method<select name="method" [(ngModel)]="payment.method" [disabled]="busy() || !workspace.canBill()"><option>Bank transfer</option><option>Cash</option><option>Card</option><option>Other</option></select></label><label>Reference<input name="reference" [(ngModel)]="payment.reference" maxlength="100" [disabled]="busy() || !workspace.canBill()"></label><label>Paid at<input type="datetime-local" name="paidAt" required [(ngModel)]="payment.paidAt" [disabled]="busy() || !workspace.canBill()"></label></div>
      @if(!openInvoices().length){<p class="hint">There are no outstanding invoices for this institution.</p>}
      <div class="form-actions"><button class="primary-button" [disabled]="paymentForm.invalid || !openInvoices().length || busy() || !workspace.canBill()">{{busy() ? 'Recording…' : 'Record payment'}}</button></div></form>
    }
  </section>
  @if(error()){<div class="alert error" role="alert">{{error()}}</div>}@if(message()){<div class="alert success" role="status">{{message()}}</div>}
  <section class="panel"><h2>{{mode==='invoices' ? 'Institution invoices' : 'Payment history'}}</h2><div class="table-wrap">
  @if(mode==='invoices') {
    <table><thead><tr><th>Invoice</th><th>Status</th><th>Amount</th><th>Balance</th><th>Due</th></tr></thead><tbody>@for(i of invoices();track i.id){<tr><td><strong>{{i.invoiceNo}}</strong><small class="muted">{{i.description}}</small></td><td><span class="status" [class.warning]="i.status!=='paid'">{{i.status}}</span></td><td>{{i.currency}} {{i.amount.toLocaleString()}}</td><td>{{i.currency}} {{i.balance.toLocaleString()}}</td><td>{{i.dueDate}}</td></tr>}@empty{<tr><td colspan="5" class="empty">No invoices yet.</td></tr>}</tbody></table>
  } @else {
    <table><thead><tr><th>Invoice</th><th>Amount</th><th>Method</th><th>Reference</th><th>Paid at</th></tr></thead><tbody>@for(p of payments();track p.id){<tr><td>{{p.invoiceNo}}</td><td>{{p.currency}} {{p.amount.toLocaleString()}}</td><td>{{p.method}}</td><td>{{p.reference || '—'}}</td><td>{{p.paidAt}}</td></tr>}@empty{<tr><td colspan="5" class="empty">No payments recorded.</td></tr>}</tbody></table>
  }</div></section>
}
`})
export class TenantFinancePage implements OnInit, OnDestroy {
  readonly mode:'invoices'|'payments';
  readonly invoices=signal<PlatformInvoice[]>([]); readonly payments=signal<PlatformPayment[]>([]);
  readonly loading=signal(true); readonly busy=signal(false); readonly error=signal<string|null>(null); readonly message=signal<string|null>(null);
  invoice={amount:null as number|null,currency:'NGN',dueDate:'',description:'CBT platform subscription'};
  payment={invoiceId:'',amount:null as number|null,method:'Bank transfer',reference:'',paidAt:localDateTime()};
  private baseline=''; private disposed=false;
  constructor(readonly workspace:TenantWorkspaceService, route:ActivatedRoute) {
    this.mode=route.snapshot.data['mode']; this.invoice.currency=workspace.tenant()!.currency;
    this.payment.invoiceId=route.snapshot.queryParamMap.get('invoice') ?? '';
    this.baseline=this.snapshot();
  }
  ngOnDestroy():void { this.disposed=true; }
  async ngOnInit():Promise<void> { await this.reload(); }
  private snapshot():string { return JSON.stringify(this.mode==='invoices' ? this.invoice : this.payment); }
  hasUnsavedChanges():boolean { return this.busy() || this.snapshot()!==this.baseline; }
  openInvoices():PlatformInvoice[] { return this.invoices().filter(i=>i.balance>0 && i.status!=='void'); }
  private async reload():Promise<void> {
    this.loading.set(true);
    try {
      const id=this.workspace.tenantId;
      const [invoices,payments]=await Promise.all([this.workspace.api.invoices(id),this.workspace.api.payments(id)]);
      if(this.disposed) return;
      this.invoices.set(invoices.invoices.filter(i=>i.tenantId===id)); this.payments.set(payments.payments.filter(p=>p.tenantId===id));
    } catch(error) { if(!this.disposed) this.error.set(error instanceof Error ? error.message : 'Unable to load billing records.'); }
    finally { if(!this.disposed) this.loading.set(false); }
  }
  async createInvoice():Promise<void> {
    if(this.busy() || !this.workspace.canBill()) return;
    if(!this.invoice.amount || this.invoice.amount<=0 || !this.invoice.dueDate || !/^[A-Za-z]{3}$/.test(this.invoice.currency)) { this.error.set('Enter a positive amount, due date and three-letter currency.'); return; }
    this.busy.set(true); this.error.set(null); this.message.set(null);
    try {
      await this.workspace.api.createInvoice({...this.invoice,currency:this.invoice.currency.toUpperCase(),tenantId:this.workspace.tenantId,planId:this.workspace.tenant()!.planId});
      this.invoice.amount=null; this.invoice.dueDate=''; this.baseline=this.snapshot(); this.message.set('Invoice created.'); await this.reload();
    } catch(error) { this.error.set(error instanceof Error ? error.message : 'Unable to create invoice.'); }
    finally { this.busy.set(false); }
  }
  async recordPayment():Promise<void> {
    if(this.busy() || !this.workspace.canBill()) return;
    const invoice=this.openInvoices().find(i=>i.id===this.payment.invoiceId);
    const amount=this.payment.amount;
    if(!invoice || !amount || amount<=0 || amount>invoice.balance || !this.payment.paidAt || !Number.isFinite(new Date(this.payment.paidAt).getTime())) { this.error.set('Select an outstanding invoice, enter a valid date, and an amount within its balance.'); return; }
    this.busy.set(true); this.error.set(null); this.message.set(null);
    try {
      await this.workspace.api.recordPayment({...this.payment,tenantId:this.workspace.tenantId,paidAt:new Date(this.payment.paidAt).toISOString()});
      this.payment={invoiceId:'',amount:null,method:'Bank transfer',reference:'',paidAt:localDateTime()}; this.baseline=this.snapshot(); this.message.set('Payment recorded.'); await this.reload();
    } catch(error) { this.error.set(error instanceof Error ? error.message : 'Unable to record payment.'); }
    finally { this.busy.set(false); }
  }
}
