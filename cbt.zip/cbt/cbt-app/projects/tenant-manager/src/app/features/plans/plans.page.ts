import { Component, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { PlatformApiService } from '../../core/services/platform-api.service';
import { PlatformAuthService } from '../../core/auth/platform-auth.service';
import { DiscardChangesService } from '../../core/services/discard-changes.service';
import { PlatformPlan } from '../../core/models/platform.models';
import { limitKeys, limitLabels, moduleKeys, moduleLabels } from '../tenants/tenant-workspace.service';

@Component({standalone:true,imports:[FormsModule],template:`
<div class="page">
  <header class="page-header"><div><h1>Pricing plans</h1><p>Packages, billing prices and CBT access limits for every institution.</p></div></header>
  @if(loading()) { <div class="loading-state" role="status"><span class="spinner"></span>Loading pricing plans…</div> }
  @else {
    @if(error()){<div class="alert error" role="alert">{{error()}}</div>}@if(message()){<div class="alert success" role="status">{{message()}}</div>}
    <div class="plan-grid">@for(p of plans();track p.id) {
      <section class="panel plan-card"><span class="panel-kicker">Monthly package</span><h2>{{p.name}}</h2><span class="pill" style="align-self:start">{{p.status}}</span>
        <strong class="price">{{p.currency}} {{p.priceMonthly.toLocaleString()}}<small>per month · billed monthly</small></strong><p style="margin-top:18px">{{p.description}}</p>
        <div class="usage-list">@for(key of keys;track key){<div><span>{{labels[key]}}</span><strong>{{p.limits[key].toLocaleString()}}</strong></div>}</div>
        <div class="module-tags">@for(key of modulesKeys;track key){@if(p.modules[key]){<span>{{moduleNames[key]}}</span>}}</div>
        @if(canEdit()){<button class="secondary-button" [disabled]="saving()" (click)="edit(p)">Edit {{p.name}}</button>}
      </section>
    }</div>
    <p class="hint">Institution limits are stored separately. Plan edits do not change existing invoices or automatically replace institution limits.</p>
    @if(draft; as p) {
      <section class="panel" id="plan-editor"><h2>Edit {{p.name}}</h2><p>Save the plan's defaults. Apply those defaults to an institution from its Billing tab.</p>
      <form #form="ngForm" (ngSubmit)="save()"><div class="form-grid">
        <label>Plan name<input name="name" [(ngModel)]="p.name" required maxlength="80" [disabled]="saving()"></label>
        <label>Monthly price<input name="price" type="number" min="0" step="0.01" [(ngModel)]="p.priceMonthly" required [disabled]="saving()"></label>
        <label>Currency<input name="currency" minlength="3" maxlength="3" [(ngModel)]="p.currency" required [disabled]="saving()"></label>
        <label>Status<select name="status" [(ngModel)]="p.status" [disabled]="saving()"><option value="active">Active</option><option value="inactive">Inactive</option></select></label>
        <label class="wide">Description<input name="description" [(ngModel)]="p.description" maxlength="300" [disabled]="saving()"></label>
        @for(key of keys;track key){<label>{{labels[key]}} limit<input [name]="key" type="number" min="1" step="1" [(ngModel)]="p.limits[key]" required [disabled]="saving()"></label>}
      </div><h3>Enabled modules</h3><div class="module-grid">@for(key of modulesKeys;track key){<label class="check-card module-card"><input [name]="'module-'+key" type="checkbox" [(ngModel)]="p.modules[key]" [disabled]="saving()"><span>{{moduleNames[key]}}</span></label>}</div>
      <div class="form-actions"><button class="primary-button" [disabled]="form.invalid || saving()">{{saving() ? 'Saving…' : 'Save global plan'}}</button><button type="button" class="secondary-button" [disabled]="saving()" (click)="cancel()">Cancel</button></div></form></section>
    }
  }
</div>`})
export class PlansPage implements OnInit {
  readonly plans=signal<PlatformPlan[]>([]); readonly loading=signal(true); readonly saving=signal(false);
  readonly error=signal<string|null>(null); readonly message=signal<string|null>(null);
  readonly keys=limitKeys; readonly labels=limitLabels; readonly modulesKeys=moduleKeys; readonly moduleNames=moduleLabels;
  draft:PlatformPlan|null=null; private baseline='';
  constructor(private readonly api:PlatformApiService,private readonly auth:PlatformAuthService,private readonly discard:DiscardChangesService) {}
  canEdit():boolean { return ['platform-owner','platform-admin'].includes(this.auth.session()?.role ?? ''); }
  async ngOnInit():Promise<void> { await this.refresh(); }
  async refresh():Promise<void> { this.draft=null; this.loading.set(true); this.error.set(null); try{this.plans.set((await this.api.plans()).plans);}catch(e){this.error.set(e instanceof Error?e.message:'Unable to load plans.');}finally{this.loading.set(false);} }
  hasUnsavedChanges():boolean { return this.saving() || (!!this.draft && JSON.stringify(this.draft)!==this.baseline); }
  async edit(plan:PlatformPlan):Promise<void> {
    if(this.hasUnsavedChanges() && !await this.discard.confirm('Discard your unsaved plan changes?')) return;
    this.draft={...plan,limits:{...plan.limits},modules:{...plan.modules}}; this.baseline=JSON.stringify(this.draft); this.message.set(null);
    setTimeout(()=>document.getElementById('plan-editor')?.scrollIntoView({block:'start',behavior:'smooth'}));
  }
  async cancel():Promise<void> { if(!this.hasUnsavedChanges() || await this.discard.confirm('Discard your unsaved plan changes?')) this.draft=null; }
  async save():Promise<void> {
    const p=this.draft; if(!p || this.saving() || !this.canEdit()) return;
    if(!p.name.trim() || !Number.isFinite(p.priceMonthly) || p.priceMonthly<0 || !/^[A-Za-z]{3}$/.test(p.currency) || Object.values(p.limits).some(v=>!Number.isInteger(v)||v<1)){this.error.set('Enter a name, valid price/currency and positive whole-number limits.');return;}
    this.saving.set(true); this.error.set(null); this.message.set(null);
    try { await this.api.savePlan({...p,currency:p.currency.toUpperCase()}); this.baseline=JSON.stringify(p); this.draft=null; this.plans.set((await this.api.plans()).plans); this.message.set('Global plan saved.'); }
    catch(e){this.error.set(e instanceof Error?e.message:'Unable to save plan.');}
    finally{this.saving.set(false);}
  }
}
