import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TenantWorkspaceService, limitKeys, limitLabels } from './tenant-workspace.service';

@Component({standalone:true,imports:[FormsModule],template:`
<section class="panel"><span class="panel-kicker">Subscription</span><h2>Plan settings</h2><p>Choose a package and subscription state. Existing invoices and payments remain unchanged.</p>
  <form #form="ngForm" (ngSubmit)="save()"><div class="form-grid"><label>Plan<select name="plan" [(ngModel)]="planId" required [disabled]="workspace.busy() || !workspace.canBill()">@for(p of workspace.plans();track p.id){<option [value]="p.id">{{p.name}}{{p.status==='inactive' ? ' (inactive)' : ''}}</option>}</select></label><label>Subscription status<select name="subscription" [(ngModel)]="subscriptionStatus" [disabled]="workspace.busy() || !workspace.canBill()"><option value="trial">Trial</option><option value="active">Active</option><option value="grace-period">Grace period</option><option value="past-due">Past due</option><option value="suspended">Suspended</option><option value="cancelled">Cancelled</option></select></label>
    <label>Monthly plan price<input [value]="price()" readonly></label><label>Billing cycle<input value="Monthly" readonly></label>
  </div><label class="check-card" style="margin-top:24px"><input name="defaults" type="checkbox" [(ngModel)]="applyPlanDefaults" [disabled]="workspace.busy() || !workspace.canBill()">Apply this plan's limits and module permissions</label>
  <p class="hint">Without this option, the institution keeps its current limits and module permissions. Subscription status does not replace the access controls.</p>
  <div class="limit-grid">@for(key of keys;track key){<label>{{labels[key]}}<input [value]="selectedLimits(key)" readonly></label>}</div>
  <div class="form-actions"><button class="primary-button" [disabled]="form.invalid || workspace.busy() || !workspace.canBill()">{{workspace.busy() ? 'Saving…' : 'Save plan'}}</button></div></form>
</section>
`})
export class TenantSubscriptionPage {
  readonly keys=limitKeys; readonly labels=limitLabels;
  planId:string; subscriptionStatus:string; applyPlanDefaults=false; private baseline:string;
  constructor(readonly workspace:TenantWorkspaceService) { const t=workspace.tenant()!; this.planId=t.planId; this.subscriptionStatus=t.subscriptionStatus; this.baseline=this.snapshot(); }
  private snapshot():string { return JSON.stringify([this.planId,this.subscriptionStatus,this.applyPlanDefaults]); }
  hasUnsavedChanges():boolean { return this.workspace.busy() || this.snapshot()!==this.baseline; }
  price():string { const p=this.workspace.plans().find(p=>p.id===this.planId); return p ? p.currency+' '+p.priceMonthly.toLocaleString() : 'Not configured'; }
  selectedLimits(key: typeof limitKeys[number]):number { return this.applyPlanDefaults ? this.workspace.plans().find(p=>p.id===this.planId)?.limits[key] ?? 0 : this.workspace.tenant()!.limits[key]; }
  async save():Promise<void> { if(await this.workspace.run(()=>this.workspace.api.setPlan(this.workspace.tenantId,this.planId,this.subscriptionStatus,this.applyPlanDefaults),'Subscription updated.')) { this.applyPlanDefaults=false; this.baseline=this.snapshot(); } }
}
