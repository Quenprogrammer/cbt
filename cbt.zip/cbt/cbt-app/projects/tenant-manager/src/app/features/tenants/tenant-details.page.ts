import { Component, DestroyRef, OnInit, inject } from '@angular/core';
import { ActivatedRoute, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TenantWorkspaceService } from './tenant-workspace.service';

@Component({
  standalone:true, imports:[RouterLink,RouterLinkActive,RouterOutlet], providers:[TenantWorkspaceService],
  template: `
  <div class="page">
    <a class="back-link" routerLink="/tenants">← All institutions</a>
    @if(workspace.loading()) { <div class="loading-state large" role="status"><span class="spinner"></span>Loading institution…</div> }
    @else { @if(workspace.tenant(); as t) {
      <header class="page-header"><div><h1>{{t.name}}</h1><p>{{t.tenantCode}} · {{t.email}}</p></div><span class="status" [class.danger]="workspace.restricted()" [class.warning]="t.status==='trial'">{{t.locked ? 'Locked' : t.accessStatus==='disabled' ? 'Restricted access' : t.status}}</span></header>
      <nav class="page-tabs" aria-label="Institution sections">
        @for(tab of tabs; track tab.path) { <a [routerLink]="tab.path" routerLinkActive="active" [routerLinkActiveOptions]="{exact:true}" ariaCurrentWhenActive="page">{{tab.label}}</a> }
      </nav>
      @if(workspace.restricted()) { <a class="restriction-strip" [routerLink]="['/tenants',t.id,'status']"><span><strong>Institution access is restricted</strong><small>{{t.statusReason || 'Open restriction details to review access.'}}</small></span><i class="bi bi-arrow-right"></i></a> }
      @if(workspace.error()) { <div class="alert error" role="alert">{{workspace.error()}}</div> }
      @if(workspace.message()) { <div class="alert success" role="status">{{workspace.message()}}</div> }
      <div class="workspace-content"><router-outlet (activate)="activePage = $event" /></div>
    } @else { <section class="panel"><h2>Institution unavailable</h2><p role="alert">{{workspace.error()}}</p><button class="primary-button" (click)="refresh()">Try again</button></section> } }
  </div>`
})
export class TenantDetailsPage implements OnInit {
  readonly tabs=[{path:'overview',label:'Overview'},{path:'access',label:'Access & limits'},{path:'billing',label:'Billing'},{path:'invoices',label:'Invoices'},{path:'payments',label:'Payments'}];
  activePage?: {hasUnsavedChanges?():boolean};
  private readonly destroyRef=inject(DestroyRef);
  constructor(readonly workspace:TenantWorkspaceService,private readonly route:ActivatedRoute) {}
  ngOnInit(): void { this.route.paramMap.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(params => { void this.workspace.load(params.get('tenantId') ?? ''); }); }
  hasUnsavedChanges(): boolean { return !!this.activePage?.hasUnsavedChanges?.(); }
  refresh(): Promise<void> { return this.workspace.load(this.workspace.tenantId); }
}
