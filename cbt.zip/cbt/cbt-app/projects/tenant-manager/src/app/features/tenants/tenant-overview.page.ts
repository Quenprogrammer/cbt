import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { TenantWorkspaceService, limitKeys, limitLabels } from './tenant-workspace.service';

@Component({standalone:true,imports:[RouterLink],template:`
@if(workspace.tenant(); as t) {
  <header class="panel-head"><div><h2>Institution overview</h2><p>Usage and access at a glance.</p></div></header>
  <div class="metric-grid">
    <section class="metric-card"><span>Students</span><strong>{{t.usage?.students ?? 0}}</strong><small>Limit {{t.limits.students.toLocaleString()}}</small></section>
    <section class="metric-card"><span>Staff</span><strong>{{t.usage?.staff ?? 0}}</strong><small>Limit {{t.limits.staff.toLocaleString()}}</small></section>
    <section class="metric-card"><span>User accounts</span><strong>{{t.usage?.users ?? 0}}</strong><small>Limit {{t.limits.users.toLocaleString()}}</small></section>
    <section class="metric-card"><span>Application access</span><strong style="font-size:20px">{{workspace.restricted() ? 'Restricted' : 'Enabled'}}</strong><small>{{t.subscriptionStatus}} subscription</small></section>
  </div>
  <div class="detail-grid">
    <section class="panel"><h2>Institution details</h2><div class="info-list">
      <div><span>Plan</span><strong>{{planName()}}</strong></div><div><span>Tenant code</span><strong>{{t.tenantCode}}</strong></div>
      <div><span>Contact email</span><strong>{{t.email}}</strong></div><div><span>Phone</span><strong>{{t.phone || 'Not set'}}</strong></div>
      <div><span>Address</span><strong>{{t.address || 'Not set'}}</strong></div><div><span>Timezone</span><strong>{{t.timezone}}</strong></div>
    </div></section>
    <section class="panel"><h2>Manage institution</h2>
      <a class="manage-link" routerLink="../access"><strong>Access & limits</strong><small>Set capacity, module permissions and access →</small></a>
      <a class="manage-link" routerLink="../billing"><strong>Billing</strong><small>Manage the subscription plan →</small></a>
      <a class="manage-link" routerLink="../invoices"><strong>Invoices</strong><small>Review invoices and outstanding balances →</small></a>
      <a class="manage-link" routerLink="../payments"><strong>Payments</strong><small>Record and review payments →</small></a>
    </section>
  </div>
  <section class="panel"><h2>CBT capacity</h2><div class="usage-list">@for(key of keys; track key) { <div><span>{{labels[key]}}</span><strong>{{t.usage?.[key] ?? 0}} / {{t.limits[key].toLocaleString()}}</strong></div> }</div></section>
}`})
export class TenantOverviewPage {
  readonly keys=limitKeys; readonly labels=limitLabels;
  constructor(readonly workspace:TenantWorkspaceService) {}
  planName(): string { const id=this.workspace.tenant()?.planId; return this.workspace.plans().find(p=>p.id===id)?.name ?? id ?? 'Not assigned'; }
}
