import { Component, OnInit, signal } from '@angular/core';
import { PlatformAuditLog } from '../../core/models/platform.models';
import { PlatformApiService } from '../../core/services/platform-api.service';

@Component({standalone:true,template:`
<div class="page"><header class="page-header"><div><span class="eyebrow">SECURITY EVENT STREAM</span><h1>Platform Audit</h1><p>Administrative actions performed across CBT tenants.</p></div></header>
<section class="panel network-panel">
@if(loading()){
  <div class="loading-state"><span class="spinner"></span><div><strong>Loading event stream</strong><small>Retrieving platform administrative activity…</small></div></div>
}@else if(error()){
  <div class="alert error">{{error()}}</div>
}@else{
<div class="table-wrap"><table><thead><tr><th>Time</th><th>Administrator</th><th>Action</th><th>Institution</th><th>Details</th></tr></thead><tbody>@for(row of rows();track row.id){<tr><td>{{row.createdAt||'—'}}</td><td><strong>{{row.actorName}}</strong><span class="muted">{{row.actorRole}}</span></td><td><span class="audit-action">{{row.action}}</span></td><td>{{row.tenantId||'Platform'}}</td><td><code>{{summary(row)}}</code></td></tr>}@empty{<tr><td colspan="5" class="empty">No platform audit events yet.</td></tr>}</tbody></table></div>
}
</section></div>`})
export class AuditPage implements OnInit{
  readonly rows=signal<PlatformAuditLog[]>([]);readonly loading=signal(true);readonly error=signal<string|null>(null);
  constructor(private readonly api:PlatformApiService){}
  async ngOnInit(){try{this.rows.set((await this.api.auditLogs()).logs);}catch(e){this.error.set(e instanceof Error?e.message:'Unable to load audit events.');}finally{this.loading.set(false);}}
  summary(row:PlatformAuditLog){const value=JSON.stringify(row.details??{});return value.length>110?value.slice(0,107)+'…':value;}
}
