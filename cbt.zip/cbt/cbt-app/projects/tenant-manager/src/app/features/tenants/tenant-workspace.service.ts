import { Injectable, signal } from '@angular/core';
import { PlatformApiService } from '../../core/services/platform-api.service';
import { TenantDirectoryService } from '../../core/services/tenant-directory.service';
import { PlatformAuthService } from '../../core/auth/platform-auth.service';
import { PlatformPlan, TenantInstitution, TenantLimits, TenantModules } from '../../core/models/platform.models';

export const limitLabels: Record<keyof TenantLimits,string> = {students:'Students',staff:'Staff',users:'User accounts',subjects:'Subjects',monthlyAttempts:'Monthly exam attempts'};
export const moduleLabels: Record<keyof TenantModules,string> = {students:'Students',staff:'Staff',subjects:'Subjects',exams:'Exams & questions',invigilation:'Invigilation',results:'Results',notifications:'Notifications',exports:'Exports',publicResults:'Public result checker'};
export const limitKeys = Object.keys(limitLabels) as (keyof TenantLimits)[];
export const moduleKeys = Object.keys(moduleLabels) as (keyof TenantModules)[];

@Injectable()
export class TenantWorkspaceService {
  readonly tenant = signal<TenantInstitution | null>(null);
  readonly plans = signal<PlatformPlan[]>([]);
  readonly loading = signal(true);
  readonly error = signal<string | null>(null);
  readonly message = signal<string | null>(null);
  readonly busy = signal(false);
  tenantId = '';
  private generation = 0;
  constructor(readonly api: PlatformApiService, readonly auth: PlatformAuthService, private readonly directory: TenantDirectoryService) {}
  canManage(): boolean { return ['platform-owner','platform-admin'].includes(this.auth.session()?.role ?? ''); }
  canAccess(): boolean { return this.canManage() || this.auth.session()?.role === 'support'; }
  canBill(): boolean { return this.canManage() || this.auth.session()?.role === 'billing-admin'; }
  restricted(): boolean { const t=this.tenant(); return !!t && (t.locked || t.accessStatus==='disabled' || ['suspended','cancelled','deleted'].includes(t.status)); }
  async load(id: string): Promise<void> {
    const generation = ++this.generation;
    this.tenantId=id; this.loading.set(true); this.tenant.set(null); this.error.set(null); this.message.set(null);
    try {
      const [tenant,plans] = await Promise.all([this.api.tenant(id),this.api.plans()]);
      if (generation!==this.generation) return;
      this.tenant.set(tenant); this.plans.set(plans.plans); this.directory.update(tenant);
    } catch(error) { if(generation===this.generation) this.error.set(error instanceof Error ? error.message : 'Unable to load institution.'); }
    finally { if(generation===this.generation) this.loading.set(false); }
  }
  async run(action: () => Promise<unknown>, success: string): Promise<boolean> {
    if(this.busy()) return false;
    const id=this.tenantId;
    this.busy.set(true); this.error.set(null); this.message.set(null);
    try {
      await action();
      const tenant=await this.api.tenant(id);
      if(id===this.tenantId) { this.tenant.set(tenant); this.directory.update(tenant); this.message.set(success); }
      return true;
    } catch(error) { this.error.set(error instanceof Error ? error.message : 'Unable to save changes.'); return false; }
    finally { this.busy.set(false); }
  }
}
