import {Component} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {Router} from '@angular/router';
import {PlatformAuthService} from '../../core/auth/platform-auth.service';
import {environment} from '../../../environments/environment';
import {TenantThemeService} from '../../core/services/tenant-theme.service';

@Component({
  standalone: true, imports: [FormsModule],
  template: `
    <div class="login-page futuristic-login">
      <button type="button" class="floating-theme-toggle" (click)="theme.toggle()"><i class="bi"
                                                                                      [class.bi-sun-fill]="theme.isDark()"
                                                                                      [class.bi-moon-stars-fill]="!theme.isDark()"></i><span>{{ theme.isDark() ? 'Light mode' : 'Dark mode' }}</span>
      </button>
      <section class="login-hero">
        <div class="hero-mesh"></div>
        <div class="hero-orbit orbit-a"></div>
        <div class="hero-orbit orbit-b"></div>
        <div class="hero-copy">
          <div class="brand login-brand">
            <div class="brand-mark"><i class="bi bi-grid-3x3-gap-fill"></i></div>
            <div><strong>CBT Platform</strong><span>Tenant Manager</span></div>
          </div>
          <span class="eyebrow">MULTI-TENANT CBT SAAS</span>
          <h1>Operate every tenant from one intelligent control layer.</h1>
          <p>Create tenants, govern access, monitor capacity and control subscriptions without crossing tenant data
            boundaries.</p>
          <div class="hero-points"><span><i class="bi bi-shield-check"></i> Platform-admin only</span><span><i
            class="bi bi-buildings"></i> Multi-tenant control</span><span><i class="bi bi-hdd-network"></i> Emulator ready</span>
          </div>
          <div class="hero-signal"><span class="pulse-dot"></span> Secure platform channel ready</div>
        </div>
      </section>
      <section class="login-panel">
        <form class="login-card glass-login" (ngSubmit)="submit()"><span class="login-node"><i
          class="bi bi-shield-lock-fill"></i></span><span class="eyebrow">SECURE ACCESS</span>
          <h2>Platform sign in</h2>
          <p>Authenticate with a platform administrator account.</p>
          @if (environment.useEmulators) {
            <div class="demo-box"><span class="pulse-dot"></span>
              <div><strong>Emulator credentials</strong><span>platform{{ '@' }}cbt.test</span><span>Password123!</span></div>
            </div>
          }
          <label>Email<input name="email" type="email" [(ngModel)]="email" autocomplete="email" required
                             [disabled]="auth.loading()"></label><label>Password<input name="password" type="password"
                                                                                       [(ngModel)]="password"
                                                                                       autocomplete="current-password"
                                                                                       required
                                                                                       [disabled]="auth.loading()"></label>
          @if (auth.error()) {
            <div class="alert error">{{ auth.error() }}</div>
          }
          <button class="primary-button glow-button full" [disabled]="auth.loading()">@if (auth.loading()) {
            <span class="spinner sm"></span> Authenticating…
          } @else {
            <i class="bi bi-arrow-right-circle"></i> Sign in
          }</button>
        </form>
      </section>
    </div>`
})
export class LoginPage {
  email = environment.useEmulators ? 'platform@cbt.test' : '';
  password = environment.useEmulators ? 'Password123!' : '';
  readonly environment = environment;

  constructor(readonly auth: PlatformAuthService, readonly theme: TenantThemeService, private readonly router: Router) {
  }

  async submit() {
    try {
      await this.auth.login(this.email, this.password);
      await this.router.navigateByUrl('/tenants');
    } catch {
    }
  }
}
