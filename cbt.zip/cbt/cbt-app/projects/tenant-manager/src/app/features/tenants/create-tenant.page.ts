import { Component, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { PlatformApiService } from '../../core/services/platform-api.service';
import { PlatformAuthService } from '../../core/auth/platform-auth.service';
import { TenantDirectoryService } from '../../core/services/tenant-directory.service';
import { PlatformPlan } from '../../core/models/platform.models';
import { limitKeys, limitLabels, moduleKeys, moduleLabels } from './tenant-workspace.service';

@Component({standalone:true,imports:[FormsModule,RouterLink],template:`
<div class="page">
  <header class="page-header"><div><h1>New institution</h1><p>Set up a CBT institution and create its first administrator.</p></div><a class="secondary-button" routerLink="/tenants">Cancel</a></header>
  @if(loadingPlans()) { <div class="loading-state" role="status"><span class="spinner"></span>Loading plans…</div> }
  @else {
    @if(error()){<div class="alert error" role="alert">{{error()}}</div>}
    <section class="panel"><h2>Institution details</h2>
    <form #form="ngForm" (ngSubmit)="submit()"><fieldset [disabled]="saving() || !canCreate()" class="plain-fieldset">
    <div class="form-grid" style="margin-top:24px">
      <label>Institution name<input name="name" [(ngModel)]="model.name" required maxlength="150"></label><label>Short name<input name="shortName" [(ngModel)]="model.shortName" required maxlength="40"></label>
      <label>Tenant code<input name="tenantCode" [(ngModel)]="model.tenantCode" required maxlength="40" placeholder="SCHOOL-CBT"></label><label>Contact email<input name="email" type="email" [(ngModel)]="model.email" required></label>
      <label>Administrator name<input name="adminName" [(ngModel)]="model.adminName" required></label><label>Administrator email<input name="adminEmail" type="email" [(ngModel)]="model.adminEmail" required></label>
      <label>Temporary password<input name="adminPassword" type="password" [(ngModel)]="model.adminPassword" required minlength="8" autocomplete="new-password"></label><label>Phone<input name="phone" [(ngModel)]="model.phone"></label>
      <label>Address<input name="address" [(ngModel)]="model.address"></label><label>Timezone<input name="timezone" [(ngModel)]="model.timezone" required></label>
      <label>Plan<select name="planId" [(ngModel)]="model.planId" (ngModelChange)="applyPlan($event)" required>@for(p of plans();track p.id){@if(p.status==='active'){<option [value]="p.id">{{p.name}}</option>}}</select></label><label>Initial status<select name="status" [(ngModel)]="model.status"><option value="trial">Trial</option><option value="active">Active</option></select></label>
      <label>Currency<input name="currency" [(ngModel)]="model.currency" minlength="3" maxlength="3" required></label><label>Monthly plan price<input [value]="planPrice()" readonly></label>
    </div><p class="hint">Students use the tenant code to register with the correct institution. Plan selection fills the CBT limits and permissions below.</p>
    <h3 style="margin-top:30px">CBT limits</h3><div class="form-grid">@for(key of keys;track key){<label>{{labels[key]}}<input [name]="key" type="number" min="1" step="1" required [(ngModel)]="model.limits[key]"></label>}</div>
    <h3 style="margin-top:30px">Enabled modules</h3><div class="module-grid">@for(key of modulesKeys;track key){<label class="check-card module-card"><input [name]="'module-'+key" type="checkbox" [(ngModel)]="model.modules[key]"><span>{{moduleNames[key]}}</span></label>}</div>
    </fieldset><div class="form-actions"><button class="primary-button" [disabled]="form.invalid || saving() || !canCreate() || !plans().length">{{saving() ? 'Creating institution…' : 'Create institution'}}</button></div></form>
    @if(!canCreate()){<p class="hint">Only platform owners and administrators can create institutions.</p>}
    </section>
  }
</div>`})
export class CreateTenantPage implements OnInit {
  readonly plans=signal<PlatformPlan[]>([]); readonly loadingPlans=signal(true); readonly saving=signal(false); readonly error=signal<string|null>(null);
  readonly keys=limitKeys; readonly labels=limitLabels; readonly modulesKeys=moduleKeys; readonly moduleNames=moduleLabels;
  model={name:'',shortName:'',tenantCode:'',email:'',phone:'',address:'',timezone:'Africa/Lagos',currency:'NGN',planId:'starter',status:'trial',adminName:'',adminEmail:'',adminPassword:'',limits:{students:500,staff:30,users:30,subjects:20,monthlyAttempts:2000},modules:{students:true,staff:true,subjects:true,exams:true,invigilation:false,results:true,notifications:true,exports:false,publicResults:true}};
  private readonly initial=JSON.stringify(this.model);
  private baseline=JSON.stringify(this.model); private created=false;
  constructor(private readonly api:PlatformApiService,private readonly auth:PlatformAuthService,private readonly directory:TenantDirectoryService,private readonly router:Router) {}
  canCreate():boolean { return ['platform-owner','platform-admin'].includes(this.auth.session()?.role ?? ''); }
  hasUnsavedChanges():boolean { return !this.created && (this.saving() || JSON.stringify(this.model)!==this.baseline); }
  async ngOnInit():Promise<void> { this.loadingPlans.set(true); try{this.plans.set((await this.api.plans()).plans);const first=this.plans().find(p=>p.status==='active');if(first)this.applyPlan(first.id);this.baseline=JSON.stringify(this.model);}catch(e){this.error.set(e instanceof Error?e.message:'Unable to load plans.');}finally{this.loadingPlans.set(false);} }
  async refresh():Promise<void> { this.model=JSON.parse(this.initial);this.created=false;this.error.set(null);await this.ngOnInit(); }
  applyPlan(id:string):void { const p=this.plans().find(p=>p.id===id);if(!p)return;this.model.planId=id;this.model.limits={...p.limits};this.model.modules={...p.modules}; }
  planPrice():string { const p=this.plans().find(p=>p.id===this.model.planId);return p ? p.currency+' '+p.priceMonthly.toLocaleString() : 'Not configured'; }
  async submit():Promise<void> {
    if(this.saving() || !this.canCreate())return;
    this.saving.set(true);this.error.set(null);
    try { const result=await this.api.createInstitution(this.model); this.created=true; await this.directory.reload(); await this.router.navigate(['/tenants',result.tenantId]); }
    catch(e){this.error.set(e instanceof Error?e.message:'Unable to create institution.');}
    finally{this.saving.set(false);}
  }
}
