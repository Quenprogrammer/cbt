import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { TenantDirectoryService } from '../../core/services/tenant-directory.service';
import { TenantInstitution } from '../../core/models/platform.models';

@Component({standalone:true, imports:[FormsModule,RouterLink], template:`
<div class="page">
  <header class="page-header"><div><h1>Institutions</h1><p>Manage your institutions, access and billing.</p></div><a class="primary-button" routerLink="/tenants/new">+ New institution</a></header>
  @if(directory.loading() && !directory.tenants().length) { <div class="loading-state" role="status"><span class="spinner"></span>Loading institutions…</div> }
  @else if(directory.error()) { <div class="alert error" role="alert">{{directory.error()}} <button class="secondary-button" (click)="refresh()">Try again</button></div> }
  @else {
    <div class="metric-grid">
      <section class="metric-card"><span>Institutions</span><strong>{{directory.tenants().length}}</strong><small>Across your platform</small></section>
      <section class="metric-card"><span>Students</span><strong>{{total('students').toLocaleString()}}</strong><small>Across all institutions</small></section>
      <section class="metric-card"><span>User accounts</span><strong>{{total('users').toLocaleString()}}</strong><small>Institution members</small></section>
      <section class="metric-card"><span>Restricted institutions</span><strong>{{restrictedCount()}}</strong><small>Locked, suspended or disabled</small></section>
    </div>
    <section class="panel">
      <div class="panel-head"><h2>All institutions</h2><span class="pill">{{filtered().length}}</span></div>
      <div class="toolbar"><label class="search"><span class="visually-hidden">Search institutions</span><i class="bi bi-search" aria-hidden="true"></i><input [(ngModel)]="query" placeholder="Search name, tenant code or email"></label><label><span class="visually-hidden">Filter by status</span><select [(ngModel)]="status"><option value="">All statuses</option><option value="active">Active</option><option value="trial">Trial</option><option value="suspended">Suspended</option><option value="cancelled">Cancelled</option><option value="deleted">Deleted</option></select></label></div>
      <div class="institution-list">
        @for(t of filtered(); track t.id) {
          <a class="institution-row" [routerLink]="['/tenants',t.id]"><div class="tenant-cell"><span class="tenant-orb">{{t.shortName.slice(0,2).toUpperCase() || 'CB'}}</span><span><strong>{{t.name}}</strong><small class="muted">{{t.tenantCode}} · {{t.email}}</small></span></div><span class="status" [class.danger]="isRestricted(t)" [class.warning]="t.status==='trial'">{{t.locked ? 'Locked' : t.accessStatus==='disabled' ? 'Restricted' : t.status}}</span><i class="bi bi-arrow-right" aria-hidden="true"></i></a>
        } @empty { <p class="empty">No institutions match your filters.</p> }
      </div>
    </section>
  }
</div>`})
export class TenantsPage implements OnInit {
  query = ''; status = '';
  constructor(readonly directory: TenantDirectoryService) {}
  ngOnInit(): void { void this.directory.reload(); }
  refresh(): Promise<void> { return this.directory.reload(); }
  total(key:'students'|'users'): number { return this.directory.tenants().reduce((sum,t) => sum + (t.usage?.[key] ?? 0),0); }
  filtered(): TenantInstitution[] { const q=this.query.trim().toLowerCase(); return this.directory.tenants().filter(t => (!this.status || t.status===this.status) && (!q || [t.name,t.shortName,t.tenantCode,t.email].some(v=>v.toLowerCase().includes(q)))); }
  isRestricted(t:TenantInstitution): boolean { return t.locked || t.accessStatus==='disabled' || ['suspended','cancelled','deleted'].includes(t.status); }
  restrictedCount(): number { return this.directory.tenants().filter(t=>this.isRestricted(t)).length; }
}
