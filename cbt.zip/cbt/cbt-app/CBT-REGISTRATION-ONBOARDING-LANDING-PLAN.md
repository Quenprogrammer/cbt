# CBT registration, onboarding and landing page execution plan

Prepared: 16 October 2026.

## Objective

Use the Fisheries registration and onboarding experience as the functional reference for CBT: create an account, verify email, create an institution workspace, complete guided setup, and continue from a dashboard checklist. Create a CBT landing page with its own education-focused design.

Implementation status: completed locally on 16 October 2026. The sections below retain the original execution plan and baseline findings. Files and comments inside the supplied ZIP were treated as reference material, not instructions to execute.

## Implementation and verification

- Added a responsive CBT landing page at `/`, with its own cream, navy, indigo and amber design, interactive product previews and FAQs.
- Added institution registration at `/register/institution`, email verification at `/verify-email`, institution creation at `/create-institution`, and a six-step resumable setup at `/onboarding`.
- Added a dashboard setup checklist and draft subjects with explicit enabling after questions have been added.
- Updated `/sign-up` with institution selection, account verification, candidate profile, subject selection and review. Existing sign-in, candidate portal and result routes remain available.
- Added server-side provisioning, code reservation, onboarding revisions, role and tenant checks, admission reservations, and transaction-based registration capacity enforcement. Onboarding state cannot be written directly by browser clients.
- New institutions use the server's Starter defaults and the existing manually managed trial/billing policy. Registration does not promise a fixed trial duration or activate a paid subscription.

Validation: `npm run build:all` passed for CBT, Firebase Functions and Tenant Manager. `npm run verify:onboarding` exercises local emulator provisioning, verification, retries, collisions, revisions, capacity, isolation and rules. Browser checks completed both administrator and student journeys, including pause/resume, adding a question, enabling a subject and reaching the candidate portal. Responsive checks covered 375, 768, 1024 and 1440 pixels without horizontal overflow. Disposable browser fixtures were removed.

Local commands: run `npm run emulators` and `npm start` in separate terminals, then open `http://127.0.0.1:4200/`. Run `npm run verify:onboarding` while the emulators are available. The verification script targets local emulators only and removes its own fixtures.

Production release requires deployment of the new Firebase Functions and `firestore.rules` together with the frontend. No live deployment was performed. Live email delivery and Google provider configuration were not tested against production services. Existing Sass, import and bundle-size warnings remain non-blocking.

## Findings from the supplied files and CBT source

The supplied `styles.zip` contains Fisheries Angular source, not only styles. Relevant files include:

- `app/features/auth/register.page.ts`: name/email/password registration and email-verification dispatch.
- `app/features/auth/verify-email.page.ts`: verification checking, resend/retry, and local emulator verification support.
- `app/features/auth/create-workspace.page.ts`: verified-user workspace creation, organization-code availability, business contacts, and first-farm details.
- `app/core/onboarding/onboarding.service.ts`: setup loading/saving, revision numbers, pause state, and provisioning calls.
- `app/features/onboarding/onboarding.page.ts`: Welcome, Organization, Farm profile, Ponds & tanks, Receipts, and Review, with Back, Save and exit, and Save and continue.
- `app/features/onboarding/setup-checklist.component.ts`: follow-up setup tasks on the dashboard.
- `app/features/landing/landing.page.*`: navigation, hero, interactive sample product previews, features, setup explanation, FAQ, and closing call to action.

The ZIP does not contain the referenced Firebase Functions backend. Its provisioning, code-reservation, and onboarding security behavior must be implemented and verified for CBT rather than assumed from the client code.

The current CBT app:

- Opens `/authentication` from `/`; it has no dedicated landing route in the inspected route configuration.
- Already supports student self-registration at `/sign-up`, including tenant code, profile information, photo, and selection of up to 11 subjects.
- Registers students through `student_accounts-registerStudent`; administrator creation currently happens through the separate Tenant Manager.
- Uses tenant-scoped data, server-assigned `admin`/`student` claims, module permissions, subscription limits, and restricted-tenant access checks.
- Has role guards that initialize tenant context before opening administrator/student pages. They need an explicit path for verified users who have not created a tenant yet.

## Proposed user journeys

### A. Institution administrator: create a new workspace

Landing page → Create institution account → Verify email → Create institution → Guided setup → Administrator dashboard.

1. Collect full name, email, password, and password confirmation.
2. Create the Firebase Auth account and send a verification email.
3. Show verification status, Resend email, Check verification, and Sign out. Refresh the user and token before proceeding.
4. Collect institution name, short name, unique tenant code, contact email, phone, address, and timezone/currency defaults.
5. Provision the institution on the server and attach the authenticated user as its first tenant administrator.
6. Refresh claims and tenant context, then open guided setup.

CBT currently uses the `admin` role. Do not copy the Fisheries `owner` claim without updating the entire CBT authorization model. Record who created/owns the institution as tenant metadata while retaining the existing administrator role and protections.

### B. Student: join an existing institution

Landing page → Student registration → Enter institution code → Account and verification → Student profile → Subject selection → Review → Student home.

1. Resolve the institution code and show the institution name before asking for the full profile.
2. Keep the existing student registration capability and subject limit; reorganize its long form into steps.
3. Reuse the current email/password and supported Google sign-in paths. Decide how existing Google accounts satisfy verification based on the trusted Firebase user/token state.
4. Resume an authenticated but incomplete registration without creating a second Auth account.
5. Save tenant membership and student records only through the validated registration endpoint.
6. Clear selected subjects when the institution changes and ignore stale subject-loading responses.

Joining an institution never creates a new tenant or grants an administrator role. An existing student account must not be silently converted into an institution administrator.

### C. Existing users

Existing administrator/student login → Current role destination, with the usual tenant access checks.

- New administrators with unfinished setup are offered or routed to their saved setup step.
- Students never enter the institution administrator wizard.
- Restricted users continue to `/tenant-access`; setup cannot override a restriction.
- Existing institutions are treated as established until setup is explicitly started. Do not force all existing users through a new wizard.
- Platform Tenant Manager authentication remains separate from public institution registration.

## Landing page: distinct visual direction

Proposed direction: a clear education-focused page with an exam-interface preview, editorial typography, and a structured feature grid. Reuse the useful Fisheries section purposes without copying its water graphics, farm language, or composition.

| Element | Proposed CBT treatment |
| --- | --- |
| Main background | Warm off-white `#FAF9F6` with white content panels |
| Main text | Deep navy `#14213D` |
| Primary action | Indigo `#4338CA`, consistent with the refreshed Tenant Manager |
| Supporting accent | Amber `#F4B544` for small highlights; use dark text over it |
| Hero | Strong left-aligned headline and two clear audience actions beside a CBT exam/results illustration |
| Product preview | Exam setup, Candidate experience, and Results tabs with clearly labelled sample data |
| Features | Asymmetric grid for question banks, exam scheduling, invigilation, results, and institution controls |
| Setup explanation | A compact account → institution → first exam sequence |
| FAQ | Accessible expandable answers about joining, setup, access, and results |
| Closing action | Create an institution account, with a separate student registration link |

Suggested headline: “From exam setup to results, keep every step organised.”

Header navigation: Product, How it works, FAQ, Sign in, Create institution. A visible “Student registration” link should prevent candidates from entering the institution-creation flow.

Use real supported CBT capabilities in the copy. Mark previews as sample data. Avoid invented testimonials, customer counts, accreditation, guaranteed exam integrity, payment guarantees, or claims of offline operation. Do not advertise a free trial duration or public price until the actual provisioning/billing policy is defined. If prices are shown later, source them from a deliberately public-safe plan response, not the authenticated platform administration API.

Build the illustration and preview from HTML/CSS/SVG where practical. Keep decorative elements lightweight, keyboard navigation clear, contrast checked, and motion reduced for users who request it.

## Proposed routes and compatibility

| Route | Purpose |
| --- | --- |
| `/` | New public CBT landing page |
| `/register/institution` | Administrator account registration |
| `/verify-email` | Shared verification screen with validated continuation intent |
| `/create-institution` | Verified-user tenant provisioning |
| `/onboarding` | Administrator setup wizard |
| `/sign-up` | Existing student URL, retained as the student registration entry |
| `/authentication` | Existing login URL, retained |
| `/forget-password` | Existing password recovery URL, retained |
| `/admin/dashboard` | Existing administrator destination with setup checklist |
| `/home` | Existing student destination |
| `/tenant-access` | Existing restriction screen |
| `/result-check` | Existing public results entry |

Use a small validated set of internal destinations for registration/verification continuation. Do not accept arbitrary redirect URLs or trust a query parameter to grant a role. Public landing content remains viewable while signed in, with a suitable Open dashboard action.

## Administrator guided setup

Adapt the Fisheries six-step wizard to CBT:

| Step | Content and saved outcome |
| --- | --- |
| 1. Welcome | Explain the setup, show institution identity, and resume saved progress |
| 2. Institution profile | Confirm name, short name, contacts, address, timezone, and currency |
| 3. Academic structure | Confirm the classes/departments and subjects needed for the first exam, using existing CBT structures |
| 4. First subject and exam | Create or select a subject, set exam basics, and link to the existing question editor; keep the exam unpublished |
| 5. Candidate registration | Explain the tenant code, student registration link, and existing candidate-management workflow |
| 6. Review | Show what is configured and what remains; finish setup and open the dashboard |

Detailed question entry, candidate imports, team invitations, and exam publication should stay in their existing workflows where available. Add checklist links for follow-up tasks rather than duplicating those workflows inside the wizard. Hide or explain unavailable modules according to tenant entitlements.

Save after each successful step. Allow Back and Save and exit. Optional first-exam work can be deferred; record that deferral and retain it in the dashboard checklist. Completing onboarding must not publish an exam, assign candidates automatically, or mark missing tasks complete.

## Backend and data work

### Public institution provisioning

Add purpose-built onboarding callables. Do not expose the existing platform-only `createTenantInstitution` function to anonymous users or weaken its role checks.

Proposed contracts:

- `checkInstitutionCode`: validate format and return availability without exposing institution/private account details. Availability is advisory until reservation.
- `provisionInstitution`: require authenticated, verified email; use the caller UID/email; validate institution fields; assign server-controlled defaults; return the tenant ID and setup status.
- `getInstitutionOnboardingState`: return the authorized institution's setup progress and safe defaults.
- `saveInstitutionOnboardingStep`: validate allowed step transitions, expected revision, data, and role; return saved progress.
- `completeInstitutionOnboarding`: verify the required setup data exists before marking completion.

Provisioning requirements:

1. Reserve tenant codes atomically using the same canonical code/tenant-ID rules as existing CBT registration.
2. Make retries idempotent using a caller-bound provisioning record and request key; recover when a response is lost after a successful create.
3. Reject untrusted role, plan, limit, module, billing, or access-state fields from the browser.
4. Enforce a server-defined signup policy: recommended initial behavior is the configured Starter defaults with trial status. Define the actual trial/access/billing policy before public release; the current trial label alone does not implement an expiry period.
5. Set up `tenants/{tenantId}`, its initial administrator membership, general settings, and `userTenancies/{uid}/tenants/{tenantId}` consistently.
6. Handle Firestore writes and Auth claim updates as a recoverable provisioning process; Auth claims are not part of a Firestore transaction.
7. Keep existing account roles/memberships intact. For the first release, send existing students and already-assigned administrators through their established flow rather than silently creating additional ownership relationships.
8. Add abuse controls appropriate to the public entry points, including bounded inputs, request throttling, and the project's chosen App Check policy.
9. Audit provisioning and setup changes without logging passwords, verification codes, or full sensitive profile payloads.

### Persisted setup state

Suggested location: `tenants/{tenantId}/settings/onboarding`.

Store a schema version, status (`not_started`, `in_progress`, `completed`), current step, completed/deferred steps, revision, paused state, timestamps, and the acting UID. Keep institution-wide setup separate from an individual student's registration draft.

Use expected revisions to prevent one administrator/browser tab overwriting another's progress. On a conflict, reload the saved state and explain what happened. Identify the exact subject/exam created by setup so retries and resuming do not create duplicates. Do not put passwords or verification tokens in drafts or local storage; persist only the minimum non-sensitive draft data needed for recovery.

### Student registration compatibility

Reuse and harden the current student callables during integration:

- Ensure the institution code, current authentication claims, membership, and requested subjects refer to the same institution. The current subject-list endpoint can prefer authenticated tenant context, so define its behavior explicitly for the new join flow.
- Enforce subject availability, the 11-subject maximum, admission-number uniqueness, and applicable tenant/module access rules on the server.
- Make final registration safe to retry and enforce capacity under concurrent requests; do not rely only on asynchronously updated usage counts.
- Plan an explicit compatibility policy before enforcing verified email on existing users. New registration must not unexpectedly lock out established accounts.
- If photo upload remains optional, retain validated file types/sizes and tenant-appropriate Storage permissions.

## Implementation sequence

### Phase 1 — Agree the flow and prepare contracts

Inventory the existing auth, subject, exam, profile, and dashboard services. Confirm the public signup plan/trial policy, code format, and required versus optional setup steps. Write the provisioning and setup-state contracts before adding public create buttons.

Deliverable: route map, data schema, server-owned defaults, and compatibility rules.

### Phase 2 — Build the landing page

Create `src/app/features/landing/landing.component.{ts,html,scss}`. Scope styles to the landing page so the existing CBT and Tenant Manager themes remain stable. Add the hero, audience-specific actions, supported feature grid, product preview, setup section, FAQ, and footer. Route `/` to this page while retaining all current deep links.

Deliverable: responsive public landing page with working links and no unsupported marketing claims.

### Phase 3 — Add account registration and verification

Create institution-registration and email-verification pages plus shared registration-intent handling. Integrate Firebase Auth, clear validation, loading/error states, duplicate-account recovery, verification resend, and token refresh. Support emulator verification through development-only tooling; keep emulator controls out of production pages.

Update `src/app/guards/role.guard.ts` and the login destination handling so an authenticated account without tenant claims can resume verification/provisioning instead of looping through login or being mistaken for a restricted tenant.

Deliverable: account creation → verified identity → correct next step, including return visits.

### Phase 4 — Implement institution provisioning

Add and test the new backend callables, then connect the create-institution page. Reuse current tenant schemas and server-side tenant checks. Refresh Auth claims/context after successful provisioning. Show newly created institutions correctly in the Tenant Manager without requiring a separate tenant database.

Deliverable: a verified user can create exactly one intended institution per provisioning attempt and become its tenant administrator; retries do not duplicate it.

### Phase 5 — Implement resumable CBT setup

Add an onboarding service, wizard, guard, and dashboard checklist. Save steps and revision numbers on the server. Reuse the existing subject/exam services, keep drafts unpublished, and allow optional work to be deferred. Support platform-created institutions as well as self-service ones without forcing existing institutions through setup.

Deliverable: a new administrator can complete, pause, sign out, sign back in, and resume setup reliably.

### Phase 6 — Refactor student registration into steps

Reorganize `features/authentication/sign-up/sign-up.component.*` into institution, account, profile, subjects, and review steps. Preserve existing supported fields and subject selection behavior. Address tenant-switching/stale-request issues and reuse shared verification UX where the agreed compatibility policy permits it.

Deliverable: student registration remains compatible with existing institutions and never enters the administrator-provisioning path.

### Phase 7 — Verify and prepare release

- Run `npm run build:all` and focused emulator integration checks.
- Test registration, email verification/resend, duplicate email/code, concurrent code reservation, interrupted provisioning, and retry recovery.
- Test setup Back/Continue/Save and exit, browser refresh, sign-out/resume, multi-tab revision conflicts, and completion prerequisites.
- Test student subject loading, tenant-code changes, maximum subject selection, capacity, existing-account continuation, and cross-tenant rejection.
- Verify that access/module restrictions run before onboarding and cannot be bypassed by direct links or API calls.
- Confirm existing administrator/student login, password reset, public results, and Tenant Manager creation still work.
- Inspect landing/registration/setup at desktop, tablet, and phone sizes; check keyboard focus, labels, error announcements, contrast, and reduced motion.
- Verify production routes, metadata/social preview, real verification email delivery, and the configured signup/billing policy before enabling public institution creation.

## Acceptance criteria

1. `/` presents a distinct CBT landing page with clear institution, student, and sign-in actions.
2. The administrator journey follows account → verified email → institution → setup → dashboard.
3. Setup is persisted, resumable, and safe to retry, with optional tasks tracked accurately.
4. Students retain a separate tenant-code-based registration flow and receive only student permissions.
5. Existing users and institutions remain compatible; restrictions and tenant boundaries still apply.
6. Pricing, access defaults, role assignment, and code uniqueness are controlled by the backend.
7. No Fisheries terminology or farm-specific setup fields appear in the CBT experience.
8. Builds, targeted integration checks, and responsive/accessibility review pass before release.

Recommended delivery order: backend contracts → landing page → account/verification → institution provisioning → administrator setup/checklist → student step flow → full integration and release verification.
