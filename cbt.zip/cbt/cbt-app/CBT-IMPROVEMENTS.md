# Question bank, blueprints, analytics and recovery

These changes implement the five priority improvements: bulk question import, organization, exam blueprints, performance analytics, and connection recovery.

Additional rich questions, review/history, practice, marking and release, accessibility, scheduling, account security, backups and readiness are documented in [ASSESSMENT-FEATURES.md](ASSESSMENT-FEATURES.md).

## Question organization

Create and edit questions with a topic, difficulty, class, curriculum, academic session and comma-separated tags. The subject question bank filters by those fields; search also matches topics and tags. Existing questions without metadata are treated as General / Medium when selecting exam questions.

## Bulk import

Open a subject's question bank and expand **Import questions**. Download the CSV template, or use the same headers in the first sheet of an Excel `.xlsx` workbook. Upload up to 200 questions in a file under 2 MB.

Preview rows, correct fields inline, and select **Validate edited rows**. Every row must pass validation before **Import questions** is enabled. Imports validate again on the server and commit atomically. Duplicate question text within the subject is skipped. Retrying an interrupted import does not create another copy.

The importer accepts MCQ and True/False questions, 2–6 consecutive options A–F, organization fields, and optional image URLs/descriptions. For True/False, use A=True and B=False. Direct image file uploads remain available in the question create/edit forms.

## Exam blueprints

Expand **Configure exam blueprint** in the subject question bank. Set questions per candidate and optionally add topic/difficulty quotas. Counts must sum to the configured question limit. A topic can have one Any-difficulty row or separate difficulty rows; overlapping rows are rejected.

The server checks the available bank both when saving and when creating a new examination. A blueprint that can no longer be fulfilled blocks the new attempt with an explanation. Existing assignments keep their selected questions. Disable quotas to return to unrestricted random selection.

New assignments keep a separate server-only marking snapshot. Editing or deleting a bank question later cannot alter the marking key or topic analysis for that assignment. Older assignments continue to use the existing question lookup.

## Performance analytics

Open **Performance Analytics** in the administrator sidebar, or follow the link from Results. Filter by date, subject, class and candidate. The report shows accuracy weighted by question count, pass rate, unanswered totals, subject/class comparisons, candidate progress, topic accuracy and frequently missed questions.

New results include question/topic metadata from the assigned snapshot. Older results retain their existing data; missing topic labels are shown as unclassified rather than guessed. Topic sample sizes count question appearances across attempts.

## Connection recovery

The examination displays connection and synchronization status. Changes are backed up locally before being synchronized, and failed saves retry every 10 seconds or when the connection returns. Resumed sessions restore the server draft and prefer locally queued changes from that device.

Submissions are persisted as a pending operation and lock answer editing until confirmed. An offline or interrupted submission retries automatically when the connection returns; reopening the exam on the same browser can resume that pending submission. Concurrent submission retries return the same result and PIN without charging another attempt.

Local backups are scoped by tenant and candidate, and are removed after server confirmation. A browser storage failure is shown explicitly. A fresh page load/sign-in and initial exam preparation still require a working connection; this is not a fully offline installation of the app. Image availability during an outage depends on the browser's cache.

## Verification

With the local Firebase emulators running:

```sh
npm run verify:improvements
```

With the development app also running on port 4200:

```sh
npm run verify:improvements:browser
```

Both scripts create and remove isolated QA fixtures. The browser test uses the existing Puppeteer dependency. Focused Angular specs cover analytics calculations, local recovery, stale save acknowledgments and question images.

Production rollout requires the updated application, Cloud Functions and Firestore rules together. Local changes do not deploy them automatically.
