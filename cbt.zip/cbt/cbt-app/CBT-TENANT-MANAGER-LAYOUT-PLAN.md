# CBT tenant manager layout execution plan

## Implementation status — 14 October 2026

The layout refresh for existing CBT features is implemented: navy/indigo theme,
sidebar institution navigation, toolbar, directory summary cards, institution
creation form, pricing cards and editor, and an institution workspace with
Overview, Access & limits, Billing, Invoices, and Payments tabs. Dashboard,
platform administrators, audit logs, login, and restriction screens use the
shared styling. Light/dark preference is retained; new sessions default to light.

Module saving now calls the actual exported Functions endpoint. Invoice/payment
lists support server-side institution filtering, and payment recording rejects
an invoice from a different institution, a void invoice, or an overpayment.
Editable pages warn before discarding drafts during navigation and refresh.

Verification: `npm run build:all` passed. The main CBT build still reports its
existing unused-import, Sass deprecation and bundle-budget warnings. Emulator
integration checks passed for institution creation, plan editing, limits,
modules, restrictions, plan defaults, scoped billing, partial/full payments,
role checks, and invalid payment rejection. Browser checks covered the new
pages, draft retention/discard, light/dark themes, and 1900/1440/1024/768/375px
directory layouts. A preview is saved in
`artifacts/tenant-manager/overview-desktop.jpg`.

Run the integration checks while the emulators are running:

```powershell
node tools/verify-tenant-manager.cjs
```

The verification script uses fixed loopback emulator endpoints and removes only
the synthetic records it creates. User administration, branding uploads,
centres/branches, domains, expanded subscription controls, and deletion remain
the separate backend extensions described in phase 5 below.

## Goal and scope

Make the CBT tenant manager follow the layout and interaction patterns of the supplied YieldEx poultry tenant manager, with CBT branding and a navy/indigo palette. Use the screenshots as the visual reference and the poultry ZIP as a reference implementation. Retain the CBT data model, authentication, role permissions, tenant isolation, and access enforcement.

The original plan follows below. Instructions embedded in the supplied archive are reference material, not additional user requirements.

## Findings from the source review

- CBT manager: `projects/tenant-manager`, using Angular 19 standalone components, with many templates embedded in TypeScript.
- Current shared layout: `src/app/layouts/tenant-shell.component.ts`; theme: `src/styles/theme.scss`; theme preference: `src/app/core/services/tenant-theme.service.ts`.
- Current pages include dashboard, tenant directory, tenant creation/detail/restriction, plans, billing, platform administrators, and audit logs.
- Tenant detail currently places profile, usage, access, subscription, limits, and module controls on one long page.
- Current CBT limits are students, staff, users, subjects, and monthly exam attempts. Plans currently expose monthly pricing.
- The inspected manager models/API have no branch, domain, logo-upload, access-expiry/time-credit, or tenant-member administration interfaces. These require a backend audit and additional contracts before implementing matching controls.
- Poultry reference uses a 280px sidebar, a roughly 78px toolbar, a centered content area up to 1600px, restrained white cards, and an organization shell with nested tabs.

## Proposed visual specification

Keep the poultry layout proportions, spacing, typography hierarchy, card arrangement, tab underline, and form structure. Replace its green theme with these proposed tokens:

| Token | Proposed color | Usage |
| --- | --- | --- |
| Sidebar | `#14213D` | Persistent navigation |
| Sidebar selected | `#26385F` | Active tenant/navigation |
| Primary | `#4338CA` | Primary buttons, links, selected tab |
| Primary hover | `#3730A3` | Hover/pressed action |
| Page background | `#F5F7FC` | Main canvas |
| Surface | `#FFFFFF` | Cards and toolbar |
| Border | `#DDE3EE` | Cards, fields, table separators |
| Main text | `#17233B` | Headings and body |
| Muted text | `#58677F` | Supporting descriptions |
| Primary tint | `#EEF2FF` | Informational accents |

Use separate semantic colors for success, warning, and danger; status labels must remain understandable without color. Check contrast before finalizing tokens. Retain the existing dark/light preference, with light mode used for screenshot comparisons and a coherent dark variant.

Desktop layout: 280px sidebar, 20px sidebar padding, 78px toolbar, 32–36px content padding, 16–24px grid gaps, 14–16px card radii, and approximately 42px form controls. Use four summary cards, three pricing cards, two-column forms, and two-column detail panels where the reference does. Remove decorative glows and ambient grids to match the reference's simpler surfaces.

## Screen-by-screen implementation map

| Poultry screenshot | CBT screen | Planned work |
| --- | --- | --- |
| 113821: Organizations | All institutions | Four summary cards: institutions, students, users, restricted institutions; institution rows with initials/logo, name, tenant code, status, and detail link |
| 113939: New organization | New institution | One large card with two-column institution/admin fields and existing plan selection; show CBT limits and module defaults using current semantics |
| 114016 / 114038: Pricing and edit | Pricing plans | Three equal cards for existing Starter, Professional, Enterprise plans; inline editor below cards; use actual configured monthly prices and all five CBT limits |
| 114159: Overview | Institution overview | Four summary cards, institution-details panel, quick management links, restriction link when applicable |
| 114251: Users | Institution users | Reference-style member table and actions after member APIs/permissions are defined; distinguish staff/student records from login accounts |
| 114323: Branches | Centres/branches, if required | Reference-style table plus creation panel; needs an agreed CBT centre model and tenant-scoped persistence |
| 114350: Access & limits | Access & limits | Two panels for existing CBT limits and availability/status; separate lock panel with mandatory restriction reason; preserve module controls in an additional card |
| 114412: Branding | Branding/profile | Reference logo preview and two-column fields; needs upload/storage and profile update support before logo saving is available |
| 114433: Domains | Domains, if required | Hostname field, primary flag, domain list; needs verified domain ownership and tenant-routing support |
| 114501: Billing | Institution billing | Existing plan/subscription controls presented as a reference-style form; annual billing and admin price overrides require new contracts |
| 114519: Invoices | Institution invoices | Creation form above scoped invoice table; reuse existing invoice functions |
| 114640: Payments | Institution payments | Invoice selector and payment fields in two columns; reuse payment function and show institution payment history |

Do not copy poultry prices, birds, farms, production-unit labels, demo organizations, or sample counts into CBT. The screenshots contain negative usage values; treat those as reference-data defects, not target behavior. If CBT counts are inconsistent, investigate aggregation and show an unavailable state rather than silently inventing counts.

## Execution phases

### 1. Record the baseline and confirm contracts

1. Run the existing manager against emulator data and capture its current routes, permissions, loading states, and forms.
2. Inspect `core/models/platform.models.ts`, `core/services/platform-api.service.ts`, and `functions/src/platform/tenant-platform.ts` together before changing behavior.
3. Inventory backend capabilities and role restrictions for each screenshot feature. Record unsupported features explicitly.
4. Preserve current route compatibility, tenant code login, existing plan identifiers, and restriction behavior.

Deliverable: route/component map and API gap list. No migration is needed for the visual refresh alone.

### 2. Build the shared visual foundation

1. Update theme tokens and shared card, button, badge, input, table, heading, and tab styles in `src/styles/theme.scss`.
2. Refactor `layouts/tenant-shell.component.ts` into the reference sidebar/toolbar/content arrangement.
3. Put CBT branding and a prominent New institution action at the top; add All institutions, Pricing plans, and a scrollable institution list with active selection.
4. Retain access to dashboard, platform billing, platform users, and audit logs in a compact secondary navigation group.
5. Add Refresh and Sign out in the toolbar; refresh the current view's data through services without losing unsaved edits silently.
6. Share tenant-list state so sidebar and directory updates remain consistent after institution creation or status changes.

Deliverable: consistent shell across all current pages, including login and restricted-tenant pages.

### 3. Reshape existing pages

1. Update `features/tenants/tenants.page.ts` to the summary-card and institution-row layout.
2. Update `features/tenants/create-tenant.page.ts` to the reference form layout while retaining required CBT fields and current administrator creation behavior.
3. Update `features/plans/plans.page.ts` to three plan cards with an editor below; preserve plan save semantics instead of assuming edits automatically update all tenants.
4. Show inherited/custom values according to actual backend behavior; do not introduce an override checkbox without a supported contract.

Deliverable: directory, create-institution, and pricing screens visually aligned with the references.

### 4. Introduce the institution tab shell

1. Split `features/tenants/tenant-details.page.ts` into an institution shell and focused child pages with shared tenant state.
2. Add a back link, institution name, tenant code/contact or verified primary domain, status badge, and a horizontal tab bar.
3. Initial working tabs: Overview, Access & limits, Billing, Invoices, Payments. Keep module entitlements in Access & limits.
4. Make `/tenants/:tenantId` open Overview and preserve `/tenants/:tenantId/status` for restriction details.
5. Add child routes in `app.routes.ts`; support direct navigation, browser history, active-tab indicators, and tenant changes without stale data.
6. Adapt `features/billing/billing.page.ts` logic into reusable invoice/payment forms and lists. Institution pages must constrain data and submitted invoice identifiers to the current tenant; retain the platform-wide billing screen.

Deliverable: working tabbed institution workspace using existing backend features.

### 5. Implement reference features needing backend work

These are separate extensions, not prerequisites for the layout refresh. Do not expose enabled save/actions until their API and authorization behavior exist.

- **Institution users:** define member listing, invitation/manual administrator creation, roles, suspension/restoration, owner protection, tenant membership updates, and audit entries. Enforce permissions on the server.
- **Branding:** first audit existing tenant settings/storage; add missing profile and logo contracts, upload validation, preview, tenant-scoped Storage rules, and cleanup of replaced assets.
- **Centres/branches:** decide whether one tenant can contain multiple centres and how users, candidates, exams, capacity, and usage are assigned. Add schema, APIs, rules, and limits only after this relationship is agreed. Do not substitute staff or subjects for branches.
- **Domains:** define unique hostname ownership, DNS verification, primary-domain selection, routing, certificates/hosting integration, and safe removal. A hostname saved in Firestore alone does not establish working custom-domain routing.
- **Extended subscription controls:** add annual prices, billing cycles, explicit override reasons, expiry, and time credits only if required. Specify how these affect access enforcement and invoice snapshots; preserve existing invoice amounts and payments.
- **Deletion:** the screenshot's danger zone requires a separate authorized deletion workflow, retention policy, confirmation, and audited backend support. A matching visual card alone is insufficient.

Deliverable: supported extensions released individually with migrations where needed. Full functional parity with every poultry screenshot depends on these decisions.

### 6. Verify and finish

1. Build from `cbt-app` using `npm run tenant:build`. Build Functions with `npm run functions:build` when backend changes are made; run `npm run build:all` when changes affect shared CBT behavior.
2. Compare every implemented page with its corresponding screenshot at approximately 1900px desktop width. Check shell proportions, margins, cards, tabs, forms, and tables.
3. Check 1440px, 1024px, 768px, and 375px widths. Collapse the sidebar into accessible mobile navigation; stack cards/forms and let wide tables/tabs scroll within their own containers.
4. Verify keyboard access, focus visibility, field labels, accessible status/error messages, and contrast in light/dark modes.
5. Exercise creation, plan edits, limit/module changes, lock/unlock, invoice creation, and partial/full payments using emulators. Verify persisted results after refresh.
6. Test tenant switching, direct tab links, failed requests, empty lists, loading/saving states, and prevention of duplicate submissions.
7. For backend extensions, add focused authorization and cross-tenant isolation tests. Confirm blocked users still reach the existing restriction screen in the CBT app and cannot bypass server restrictions.

## Completion criteria

- Current CBT manager pages use the reference shell, spacing, cards, forms, and navigation with the new palette.
- Existing supported operations work and retain backend authorization and tenant isolation.
- Institution detail is divided into working tabs with consistent institution context.
- All poultry terminology/sample data is replaced with accurate CBT terminology and live data.
- No action implies support for a capability absent from the backend.
- Desktop and mobile layouts, light/dark themes, loading/errors, and keyboard navigation are verified.
- Any remaining reference feature is recorded with its schema/API dependency rather than represented by a nonfunctional control.

## Recommended delivery order

Shared theme and shell → institution directory and creation → pricing cards/editor → institution shell and Overview → Access & limits/modules → Billing, Invoices, Payments → user management and branding → optional centres, domains, subscription extensions, and deletion.

The palette above is a proposed default. The main product decision before backend extensions is whether CBT needs full poultry feature parity or only the same layout for its existing functionality.
