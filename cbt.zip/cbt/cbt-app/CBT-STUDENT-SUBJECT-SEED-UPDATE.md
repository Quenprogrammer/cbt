# CBT student, subject registration and test-data update

## Implemented

- `/admin/edit-student/:id` now opens as a read-only **Student profile**. Use **Edit student** to enter edit mode.
- Student photograph support added to:
  - public student account registration (`/sign-up`)
  - admin Add Student
  - admin Student Profile / Edit Student
  - student dashboard profile
- Student photos are limited to 5 MB and stored under `student-images/...` in Firebase Storage.
- Student subject registration is limited to **11 subjects maximum** in both the Angular UI and the Cloud Function.
- Exam generation is strict: a student with no registered subjects cannot start an exam, and the server only loads the student's registered subject document IDs.
- Student dashboard now lists only registered subjects; it no longer falls back to all active subjects.
- Seed subject bank expanded to exactly **12 active subjects**:
  1. English
  2. Math
  3. Chemistry
  4. Computer
  5. Computer Hardware
  6. Computer Programming
  7. General Computer
  8. ICT
  9. Physics
  10. Biology
  11. Economics
  12. Civic Education
- New testing seed data is added for:
  - `/admin/activity-logs` — 12 audit records
  - `/admin/notifications` — 8 notifications
  - `/admin/attempt-monitoring` — 6 attempts (mix of in-progress/submitted)
  - `/admin/results` — 4 results with public result-check PINs
  - `/admin/users` — 4 invigilation schedules linked to seeded staff/students
- Linked seed student accounts receive subject registrations. One seeded student receives 11 subjects to test the maximum boundary.

## Useful emulator test accounts

- Admin: `user1@example.com` / `password123`
- Student: `user3@example.com` / `password123` — registered for Computer Hardware, Computer Programming, General Computer and ICT; exam access is started by the seed.
- Other student accounts include `user2@example.com`, `user4@example.com`, `user5@example.com`, `muhammad@example.com`, and `khaleel@example.com` with the passwords already defined by the original seed.

## Seeded result PINs

Use these on the public Result Checker after running the seed:

- `TEST-0002`
- `TEST-0004`
- `TEST-0005`
- `TEST-0006`

## Run

Install once:

```powershell
npm install
```

For a complete emulator reset + seed + Angular start:

```powershell
npm run dev
```

Or manually:

```powershell
npm run emulators
```

Then in a second terminal:

```powershell
npm run seed
npm start
```

> `npm run seed` resets emulator Auth/Firestore data before reseeding. Use it for local testing data only.
