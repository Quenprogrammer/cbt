import {onDocumentWritten} from "firebase-functions/firestore";

export const onExpenseWritten = onDocumentWritten("student/{studentId}",
    async (event) => {

        const studentId = event.params.studentId;


        console.log({'student_id': studentId})


    });