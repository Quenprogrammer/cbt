import * as admin from 'firebase-admin';
import { HttpsError } from 'firebase-functions/v2/https';
import { requireTenantUser } from './tenant-access';

export const permissionNames = ['questions.write', 'questions.review', 'results.manage', 'exams.manage', 'students.manage', 'reports.read', 'backups.manage'] as const;
export async function requirePermission(request: any, permission: string) {
  const state = await requireTenantUser(request, ['admin', 'staff']);
  if (state.role === 'admin') return state;
  const user = (await admin.firestore().doc(`tenants/${state.tenantId}/users/${request.auth.uid}`).get()).data();
  if (!user || user.status === 'disabled' || !Array.isArray(user.permissions) || !user.permissions.includes(permission)) throw new HttpsError('permission-denied', `Permission required: ${permission}.`);
  return state;
}
