import { FieldValue } from 'firebase-admin/firestore';
import * as admin from 'firebase-admin';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { requireTenantUser } from './tenant-access';
import { permissionNames } from './permissions';

export const list = onCall(async request => {
  const access = await requireTenantUser(request, ['admin']), rows = await admin.firestore().collection(`tenants/${access.tenantId}/users`).where('role', '==', 'staff').get();
  return { permissions: permissionNames, users: rows.docs.map(row => ({ uid: row.id, ...row.data() })) };
});
export const save = onCall(async request => {
  const access = await requireTenantUser(request, ['admin']), input = request.data || {}, permissions = Array.isArray(input.permissions) ? [...new Set<string>(input.permissions.map(String))] : [];
  if (permissions.some(permission => !(permissionNames as readonly string[]).includes(permission))) throw new HttpsError('invalid-argument', 'Unknown permission.');
  const email = String(input.email || '').trim().toLowerCase(), name = String(input.name || '').trim().slice(0, 150);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !name) throw new HttpsError('invalid-argument', 'Provide a name and valid email.');
  if (access.modules.staff === false) throw new HttpsError('permission-denied', 'Staff access is not enabled for this institution.');
  let user: admin.auth.UserRecord, created = false;
  try {
    user = await admin.auth().getUserByEmail(email);
    if (user.uid === request.auth!.uid || user.customClaims?.tenantId !== access.tenantId || user.customClaims?.role !== 'staff') throw new HttpsError('permission-denied', 'Only staff accounts belonging to this tenant can be edited here.');
  } catch (error: any) {
    if (error.code !== 'auth/user-not-found') throw error;
    if (String(input.password || '').length < 12) throw new HttpsError('invalid-argument', 'Use an initial staff password with at least 12 characters.');
    user = await admin.auth().createUser({ email, password: input.password, displayName: name });
    created = true;
  }
  const status = input.disabled ? 'disabled' : 'active';
  await admin.auth().setCustomUserClaims(user.uid, { ...user.customClaims, role: 'staff', tenantId: access.tenantId });
  const db = admin.firestore(), root = db.doc(`tenants/${access.tenantId}`);
  try {
    await db.runTransaction(async tx => {
      const [tenant, member] = await Promise.all([tx.get(root), tx.get(root.collection('users').doc(user.uid))]);
      if (!member.exists) {
        const userLimit = Number(tenant.data()?.limits?.users || 30), staffLimit = Number(tenant.data()?.limits?.staff || 20);
        const [accounts, staff] = await Promise.all([tx.get(root.collection('users').select().limit(userLimit)), tx.get(root.collection('users').where('role', '==', 'staff').select().limit(staffLimit))]);
        if (accounts.size >= userLimit || staff.size >= staffLimit) throw new HttpsError('resource-exhausted', 'This institution has reached its staff or user account limit.');
      }
      tx.set(root.collection('users').doc(user.uid), { uid: user.uid, email, displayName: name, role: 'staff', permissions, status }, { merge: true });
      tx.set(db.doc(`userTenancies/${user.uid}/tenants/${access.tenantId}`), { tenantId: access.tenantId, tenantName: access.tenantName, role: 'staff', status }, { merge: true });
      tx.set(root.collection('activityLogs').doc(), { action: 'staff_permissions_updated', actorId: request.auth!.uid, entityId: user.uid, metadata: { permissions, status }, createdAt: FieldValue.serverTimestamp() });
      tx.update(root, { registrationSequence: FieldValue.increment(1) });
    });
  } catch (error) {
    if (created) await admin.auth().deleteUser(user.uid);
    throw error;
  }
  return { saved: true, uid: user.uid };
});
