import { Timestamp } from 'firebase-admin/firestore';
import * as admin from 'firebase-admin';
import { createHash, randomUUID } from 'crypto';
import { gzipSync, gunzipSync } from 'zlib';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { onSchedule } from 'firebase-functions/v2/scheduler';
import { requirePermission } from './permissions';
import { publicResult } from '../exam/result-workflow';

const collections = ['subjects', 'student', 'staffs', 'results', 'examAttempts', 'examAssignments', 'examKeys', 'examDrafts', 'settings', 'appeals', 'studentNotifications', 'invigilationSchedules', 'examRegistrations', 'notifications', 'activityLogs'];
const bucket = () => admin.storage().bucket(admin.app().options.storageBucket || `${process.env.GCLOUD_PROJECT || 'cbt-sass'}.firebasestorage.app`);
function encode(value: any): any { if (value?.toDate && typeof value.seconds === 'number') return { __cbtType: 'timestamp', seconds: value.seconds, nanoseconds: value.nanoseconds }; if (Array.isArray(value)) return value.map(encode); if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, encode(item)])); return value; }
function decode(value: any): any { if (value?.__cbtType === 'timestamp') return new Timestamp(value.seconds, value.nanoseconds); if (Array.isArray(value)) return value.map(decode); if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, decode(item)])); return value; }
export async function takeBackup(tenantId: string, actorId: string) {
  const root = admin.firestore().doc(`tenants/${tenantId}`), documents: any[] = [];
  async function walk(collection: FirebaseFirestore.CollectionReference): Promise<void> {
    const rows = await collection.get();
    for (const row of rows.docs) {
      if (documents.length >= 5000) throw new HttpsError('resource-exhausted', 'This backup exceeds the 5,000-document limit.');
      documents.push({ path: row.ref.path.slice(root.path.length + 1), data: encode(row.data()) });
      for (const child of await row.ref.listCollections()) await walk(child);
    }
  }
  for (const name of collections) await walk(root.collection(name));
  const json = Buffer.from(JSON.stringify({ schema: 1, tenantId, createdAtMs: Date.now(), documents }));
  if (json.length > 15 * 1024 * 1024) throw new HttpsError('resource-exhausted', 'This backup exceeds the 15 MB assessment-data limit.');
  const compressed = gzipSync(json); if (compressed.length > 5 * 1024 * 1024) throw new HttpsError('resource-exhausted', 'The compressed backup exceeds 5 MB.');
  const id = randomUUID(), storagePath = `tenants/${tenantId}/backups/${id}.json.gz`, digest = createHash('sha256').update(compressed).digest('hex');
  await bucket().file(storagePath).save(compressed, { contentType: 'application/gzip' });
  await root.collection('backups').doc(id).set({ id, storagePath, digest, createdAtMs: Date.now(), documentCount: documents.length, bytes: compressed.length, actorId, status: 'complete' });
  return { id, documentCount: documents.length, bytes: compressed.length };
}
async function loadBackup(tenantId: string, id: string) {
  if (!/^[\w-]{10,80}$/.test(id)) throw new HttpsError('invalid-argument', 'Choose a backup.');
  const saved = await admin.firestore().doc(`tenants/${tenantId}/backups/${id}`).get(); if (!saved.exists) throw new HttpsError('not-found', 'Backup not found.');
  const manifest = saved.data()!;
  if (manifest.storagePath !== `tenants/${tenantId}/backups/${id}.json.gz`) throw new HttpsError('failed-precondition', 'Backup path validation failed.');
  const [compressed] = await bucket().file(manifest.storagePath).download();
  if (createHash('sha256').update(compressed).digest('hex') !== manifest.digest) throw new HttpsError('failed-precondition', 'Backup checksum validation failed.');
  const document = JSON.parse(gunzipSync(compressed, { maxOutputLength: 16 * 1024 * 1024 }).toString());
  if (document.schema !== 1 || document.tenantId !== tenantId || !Array.isArray(document.documents) || document.documents.length > 5000) throw new HttpsError('failed-precondition', 'Invalid backup format.');
  for (const row of document.documents) if (typeof row.path !== 'string' || row.path.split('/').length % 2 !== 0 || row.path.includes('..') || !collections.includes(row.path.split('/')[0])) throw new HttpsError('failed-precondition', 'Backup contains an invalid record path.');
  return { manifest, compressed, document };
}
export const list = onCall(async request => {
  const access = await requirePermission(request, 'backups.manage'), root = admin.firestore().doc(`tenants/${access.tenantId}`);
  const [rows, settings] = await Promise.all([root.collection('backups').orderBy('createdAtMs', 'desc').limit(30).get(), root.collection('settings').doc('backups').get()]);
  return { backups: rows.docs.map(row => ({ id: row.id, ...row.data() })), policy: settings.data() || { enabled: false, retention: 7 } };
});
export const create = onCall({ timeoutSeconds: 540, memory: '512MiB' }, async request => { const access = await requirePermission(request, 'backups.manage'); return takeBackup(access.tenantId, request.auth!.uid); });
export const download = onCall(async request => { const access = await requirePermission(request, 'backups.manage'), id = String(request.data?.backupId || ''), saved = await loadBackup(access.tenantId, id); return { fileName: `cbt-backup-${id}.json.gz`, base64: saved.compressed.toString('base64') }; });
export const previewRestore = onCall(async request => {
  const access = await requirePermission(request, 'backups.manage'), backup = await loadBackup(access.tenantId, String(request.data?.backupId || '')), root = admin.firestore().doc(`tenants/${access.tenantId}`);
  let existing = 0;
  for (let offset = 0; offset < backup.document.documents.length; offset += 200) { const rows = backup.document.documents.slice(offset, offset + 200); if (rows.length) existing += (await admin.firestore().getAll(...rows.map((row: any) => root.collection(row.path.split('/')[0]).doc(row.path.split('/').slice(1).join('/'))))).filter(row => row.exists).length; }
  return { records: backup.document.documents.length, missing: backup.document.documents.length - existing, existing, note: 'Missing records are restored by default. Overwriting existing records creates a safety backup first. Account credentials, permissions and billing are excluded.' };
});
export const restore = onCall({ timeoutSeconds: 540, memory: '512MiB' }, async request => {
  const access = await requirePermission(request, 'backups.manage'), id = String(request.data?.backupId || ''), jobId = String(request.data?.jobId || ''), overwrite = Boolean(request.data?.overwrite);
  if (!/^[\w-]{10,80}$/.test(jobId)) throw new HttpsError('invalid-argument', 'A restore job ID is required.');
  const db = admin.firestore(), root = db.doc(`tenants/${access.tenantId}`), job = root.collection('restoreJobs').doc(jobId);
  if (!(await root.collection('examAssignments').where('status', '==', 'in-progress').limit(1).get()).empty) throw new HttpsError('failed-precondition', 'Finish active examinations before restoring a backup.');
  const lease = await db.runTransaction(async tx => {
    const old = (await tx.get(job)).data();
    if (old && (old.backupId !== id || old.overwrite !== overwrite)) throw new HttpsError('invalid-argument', 'Restore job contents changed.');
    if (old?.status === 'complete') return old;
    if (Number(old?.leaseUntilMs || 0) > Date.now()) throw new HttpsError('aborted', 'This restore is already running. Refresh its status before retrying.');
    const state = { backupId: id, overwrite, progress: Number(old?.progress || 0), restored: Number(old?.restored || 0), safetyBackupId: old?.safetyBackupId || '', status: 'running', leaseUntilMs: Date.now() + 10 * 60 * 1000 };
    tx.set(job, state); return state;
  });
  if (lease.status === 'complete') return lease;
  try {
    const backup = await loadBackup(access.tenantId, id);
    if (overwrite && !lease.safetyBackupId) { lease.safetyBackupId = (await takeBackup(access.tenantId, request.auth!.uid)).id; await job.update({ safetyBackupId: lease.safetyBackupId }); }
    for (let offset = lease.progress; offset < backup.document.documents.length; offset += 200) {
      const rows = backup.document.documents.slice(offset, offset + 200), refs = rows.map((row: any) => db.doc(`${root.path}/${row.path}`));
      const current = await db.getAll(...refs), batch = db.batch();
      for (let i = 0; i < rows.length; i++) if (overwrite || !current[i].exists) {
        const data = decode(rows[i].data);
        batch.set(refs[i], data); lease.restored++;
        // Keep the public PIN summary consistent when a result is recovered.
        if (rows[i].path.startsWith('results/') && rows[i].path.split('/').length === 2 && /^CBT-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(data.pin || '')) batch.set(db.doc(`resultChecks/${data.pin}`), publicResult({ ...data, tenantId: access.tenantId, id: refs[i].id }));
      }
      lease.progress = offset + rows.length; batch.update(job, { progress: lease.progress, restored: lease.restored }); await batch.commit();
    }
    await job.update({ status: 'complete', leaseUntilMs: 0 }); return { ...lease, status: 'complete' };
  } catch (error: any) { await job.update({ status: 'failed', leaseUntilMs: 0, error: String(error.message || error).slice(0, 500) }); throw error; }
});
export const savePolicy = onCall(async request => {
  const access = await requirePermission(request, 'backups.manage'), retention = Number(request.data?.retention || 7);
  if (!Number.isInteger(retention) || retention < 1 || retention > 30) throw new HttpsError('invalid-argument', 'Keep between 1 and 30 automatic backups.');
  await admin.firestore().doc(`tenants/${access.tenantId}/settings/backups`).set({ enabled: Boolean(request.data?.enabled), retention }); return { saved: true };
});
export async function runBackupSweep(tenantId?:string) {
  const tenants=tenantId?[await admin.firestore().doc(`tenants/${tenantId}`).get()]:(await admin.firestore().collection('tenants').limit(500).get()).docs;
  for (const tenant of tenants) {
    const policy = (await tenant.ref.collection('settings').doc('backups').get()).data(); if (!policy?.enabled) continue;
    await takeBackup(tenant.id, 'scheduled');
    const rows = await tenant.ref.collection('backups').orderBy('createdAtMs', 'desc').get();
    for (const old of rows.docs.slice(Math.max(1, Math.min(30, Number(policy.retention || 7))))) { await bucket().file(old.data().storagePath).delete().catch(() => {}); await old.ref.delete(); }
  }
}
export const nightly = onSchedule({ schedule: '0 1 * * *', timeZone: 'Africa/Lagos', timeoutSeconds: 540, memory: '512MiB' }, async()=>{await runBackupSweep();});
