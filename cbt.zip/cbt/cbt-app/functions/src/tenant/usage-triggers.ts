import * as admin from 'firebase-admin';
import { FieldValue } from 'firebase-admin/firestore';
import { onDocumentWritten } from 'firebase-functions/v2/firestore';
function delta(event:any){const before=event.data?.before.exists??false,after=event.data?.after.exists??false;if(!before&&after)return 1;if(before&&!after)return-1;return 0;}
async function bump(tenantId:string,field:'students'|'staff'|'users'|'subjects',amount:number){if(!amount)return;await admin.firestore().doc(`tenants/${tenantId}`).update({[`usage.${field}`]:FieldValue.increment(amount),usageUpdatedAt:FieldValue.serverTimestamp()});}
export const onStudentUsageWritten=onDocumentWritten('tenants/{tenantId}/student/{id}',e=>bump(e.params.tenantId,'students',delta(e)));
export const onStaffUsageWritten=onDocumentWritten('tenants/{tenantId}/staffs/{id}',e=>bump(e.params.tenantId,'staff',delta(e)));
export const onUserUsageWritten=onDocumentWritten('tenants/{tenantId}/users/{id}',e=>bump(e.params.tenantId,'users',delta(e)));
export const onSubjectUsageWritten=onDocumentWritten('tenants/{tenantId}/subjects/{id}',e=>bump(e.params.tenantId,'subjects',delta(e)));
