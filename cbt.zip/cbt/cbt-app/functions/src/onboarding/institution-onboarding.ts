import * as admin from 'firebase-admin';
import { FieldValue, Timestamp } from 'firebase-admin/firestore';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { requireTenantUser } from '../tenant/tenant-access';
import { ensureDefaultPlans } from '../platform/tenant-platform';

const db = () => admin.firestore();
const steps = ['welcome','profile','academic','exam','registration','review'];
const text = (value:unknown,max=160) => String(value ?? '').trim().slice(0,max);
function required(value:unknown,label:string,max=160):string {
  const result=text(value,max);
  if(result.length<2) throw new HttpsError('invalid-argument',label+' must contain at least two characters.');
  return result;
}
function email(value:unknown):string {
  const result=text(value,200).toLowerCase();
  if(!/^\S+@\S+\.\S+$/.test(result)) throw new HttpsError('invalid-argument','Enter a valid contact email.');
  return result;
}
function code(value:unknown):string {
  const result=text(value,41).toLowerCase();
  if(result.length<3 || result.length>40 || !/^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/.test(result))
    throw new HttpsError('invalid-argument','Use 3–40 letters, numbers and single hyphens; start with a letter.');
  return result;
}
async function account(request:any,verified=false) {
  if(!request.auth) throw new HttpsError('unauthenticated','Sign in to continue.');
  const user=await admin.auth().getUser(request.auth.uid);
  if(verified && (!user.emailVerified || request.auth.token.email_verified!==true))
    throw new HttpsError('failed-precondition','Verify your email and check verification before continuing.');
  return user;
}
function initialProgress() {
  return {status:'not_started',currentStep:'welcome',completedSteps:[] as string[],deferredSteps:[] as string[],revision:0,paused:false};
}
async function throttle(uid:string,operation:string,limit:number) {
  const ref=db().doc('signupRateLimits/'+uid+'-'+operation);
  await db().runTransaction(async tx=>{
    const snap=await tx.get(ref), old=snap.data() ?? {}, now=Date.now();
    const sameWindow=now-Number(old.startedAt ?? 0)<3600000;
    const count=sameWindow ? Number(old.count ?? 0) : 0;
    if(count>=limit) throw new HttpsError('resource-exhausted','Too many requests. Please try again later.');
    tx.set(ref,{startedAt:sameWindow ? old.startedAt : now,count:count+1,expiresAt:Timestamp.fromMillis(now+86400000)});
  });
}

export const setRegistrationIntent=onCall(async request=>{
  const user=await account(request);
  const intent=request.data?.intent;
  if(!['institution','student'].includes(intent)) throw new HttpsError('invalid-argument','Choose institution or student registration.');
  if(user.customClaims?.['role'] || user.customClaims?.['tenantId']) throw new HttpsError('failed-precondition','This account already belongs to an institution.');
  await throttle(user.uid,'intent',30);
  await db().doc('registrationIntents/'+user.uid).set({intent,tenantCode:intent==='student' ? text(request.data?.tenantCode,40) : '',updatedAt:FieldValue.serverTimestamp()});
  return {ok:true};
});

export const registrationState=onCall(async request=>{
  const user=await account(request);
  let role=text(user.customClaims?.['role'],40), tenantId=text(user.customClaims?.['tenantId'],80);
  const signup=await db().doc('institutionSignups/'+user.uid).get();
  if(!tenantId && signup.exists) {
    tenantId=text(signup.data()?.['tenantId'],80);
    const tenant=await db().doc('tenants/'+tenantId).get();
    if(tenant.data()?.['ownerUid']!==user.uid) throw new HttpsError('permission-denied','Unable to recover this institution.');
    role='admin';
    await admin.auth().setCustomUserClaims(user.uid,{...user.customClaims,tenantId,role});
  }
  if(!tenantId) {
    const memberships=await db().collection('userTenancies/'+user.uid+'/tenants').where('status','==','active').limit(2).get();
    if(memberships.size===1 && ['admin','student'].includes(String(memberships.docs[0].data().role))) {
      tenantId=memberships.docs[0].id;role=String(memberships.docs[0].data().role);
      await admin.auth().setCustomUserClaims(user.uid,{...user.customClaims,tenantId,role});
    }
  }
  const intent=await db().doc('registrationIntents/'+user.uid).get();
  return {role,tenantId,emailVerified:user.emailVerified,intent:intent.data()?.['intent'] ?? 'institution',tenantCode:intent.data()?.['tenantCode'] ?? ''};
});

export const checkInstitutionCode=onCall(async request=>{
  const user=await account(request,true);
  await throttle(user.uid,'code',60);
  const tenantId=code(request.data?.code);
  return {available:!(await db().doc('tenants/'+tenantId).get()).exists};
});

export const provisionInstitution=onCall(async request=>{
  const user=await account(request,true), uid=user.uid;
  const data=request.data ?? {}, tenantId=code(data.code);
  const name=required(data.name,'Institution name',150), shortName=required(data.shortName,'Short name',40);
  const contactEmail=email(data.contactEmail), address=required(data.address,'Address',250), phone=required(data.phone,'Phone',40);
  const timezone=text(data.timezone,80)||'Africa/Lagos',currency='NGN';
  try { new Intl.DateTimeFormat('en',{timeZone:timezone}).format(); } catch { throw new HttpsError('invalid-argument','Choose a valid timezone.'); }
  const signupRef=db().doc('institutionSignups/'+uid), root=db().doc('tenants/'+tenantId);
  const saved=await signupRef.get();
  if(saved.exists && saved.data()?.['tenantId']!==tenantId) throw new HttpsError('already-exists','You have already created an institution. Sign in to open it.');
  if(!saved.exists) {
    if(user.customClaims?.['role'] || user.customClaims?.['tenantId']) throw new HttpsError('permission-denied','An existing account cannot be converted to an institution administrator.');
    if((await db().doc('platformAdmins/'+uid).get()).exists) throw new HttpsError('permission-denied','Use the Tenant Manager to create institutions with this account.');
  }
  await throttle(uid,'provision',15);
  await ensureDefaultPlans();
  const planRef=db().doc('platformPlans/starter');
  await db().runTransaction(async tx=>{
    const [existing,tenant,plan,memberships]=await Promise.all([
      tx.get(signupRef),tx.get(root),tx.get(planRef),tx.get(db().collection('userTenancies/'+uid+'/tenants').limit(1))
    ]);
    if(existing.exists) {
      if(existing.data()?.['tenantId']!==tenantId || tenant.data()?.['ownerUid']!==uid) throw new HttpsError('already-exists','This signup already has an institution.');
      return;
    }
    if(!memberships.empty) throw new HttpsError('permission-denied','This account is already linked to an institution.');
    if(tenant.exists) throw new HttpsError('already-exists','This institution code is taken. Choose another.');
    if(!plan.exists || plan.data()?.['status']!=='active') throw new HttpsError('failed-precondition','Self-service registration is currently unavailable. Contact the platform administrator.');
    const defaults=plan.data()!,now=FieldValue.serverTimestamp();
    tx.create(root,{name,shortName,tenantCode:tenantId.toUpperCase(),email:contactEmail,phone,address,timezone,currency,
      status:'trial',accessStatus:'enabled',locked:false,statusReason:'',planId:'starter',subscriptionStatus:'trial',
      limits:defaults.limits,modules:defaults.modules,usage:{students:0,staff:0,users:0,subjects:0,monthlyAttempts:0,attemptMonth:new Date().toISOString().slice(0,7)},
      ownerUid:uid,createdVia:'self-service',onboardingRequired:true,signupVersion:1,createdBy:uid,createdAt:now,updatedAt:now});
    tx.create(root.collection('users').doc(uid),{uid,email:user.email,displayName:user.displayName||name,role:'admin',status:'active',createdAt:now,updatedAt:now});
    tx.create(db().doc('userTenancies/'+uid+'/tenants/'+tenantId),{tenantId,tenantName:name,shortName,role:'admin',status:'active',createdAt:now});
    tx.create(root.collection('settings').doc('general'),{name,shortName,tenantCode:tenantId.toUpperCase(),timezone,currency,createdAt:now,updatedAt:now});
    tx.create(root.collection('settings').doc('onboarding'),{...initialProgress(),status:'in_progress',createdAt:now,updatedAt:now,updatedBy:uid,schemaVersion:1});
    tx.create(signupRef,{tenantId,createdAt:now});
    tx.create(db().collection('platformAuditLogs').doc(),{actorId:uid,actorName:user.displayName||user.email,actorRole:'admin',action:'tenant.self-service.created',tenantId,details:{planId:'starter'},createdAt:now});
  });
  // A retry or registrationState repairs this if Auth is temporarily unavailable.
  await admin.auth().setCustomUserClaims(uid,{...user.customClaims,role:'admin',tenantId});
  return {tenantId,role:'admin',tokenRefreshRequired:true};
});

export const getInstitutionOnboardingState=onCall(async request=>{
  const access=await requireTenantUser(request,['admin']);
  const root=db().doc('tenants/'+access.tenantId);
  const [tenant,progress,academic,subject,students,staff]=await Promise.all([
    root.get(),root.collection('settings').doc('onboarding').get(),root.collection('settings').doc('academic').get(),
    root.collection('subjects').limit(1).get(),root.collection('student').limit(1).get(),root.collection('staffs').limit(1).get()
  ]);
  const data=tenant.data()!;
  return {tenantId:access.tenantId,profile:{name:data.name,shortName:data.shortName,address:data.address,email:data.email,phone:data.phone,timezone:data.timezone,currency:data.currency},
    progress:progress.exists ? progress.data() : null,academic:academic.data() ?? {className:'',department:''},
    checks:{subjects:!subject.empty,candidates:!students.empty,staff:!staff.empty},
    modules:access.modules,setupSubjectId:progress.data()?.['setupSubjectId'] ?? '',
    registrationCode:data.tenantCode,signupPolicy:'Starter defaults; trial status. Contact the platform administrator for activation and billing.'};
});

export const setSubjectAvailability=onCall(async request=>{
  const access=await requireTenantUser(request,['admin']);
  if(!access.modules['subjects'] || !access.modules['exams']) throw new HttpsError('permission-denied','Subject and exam modules must be enabled.');
  const subjectId=text(request.data?.subjectId,120);
  if(!/^[A-Za-z0-9_-]+$/.test(subjectId) || typeof request.data?.active!=='boolean') throw new HttpsError('invalid-argument','Choose a subject and availability state.');
  const ref=db().doc('tenants/'+access.tenantId+'/subjects/'+subjectId);
  await db().runTransaction(async tx=>{
    const subject=await tx.get(ref);
    if(!subject.exists) throw new HttpsError('not-found','Subject not found.');
    if(request.data.active) {
      const questions=await tx.get(ref.collection('exams').limit(1));
      if(questions.empty) throw new HttpsError('failed-precondition','Add and review at least one question before enabling this subject.');
    }
    tx.update(ref,{active:request.data.active,updatedAt:FieldValue.serverTimestamp(),updatedBy:request.auth!.uid});
    tx.create(db().collection('tenants/'+access.tenantId+'/activityLogs').doc(),{actorId:request.auth!.uid,actorEmail:request.auth!.token.email??'',action:request.data.active?'subject_enabled':'subject_disabled',entityId:subjectId,createdAt:FieldValue.serverTimestamp()});
  });
  return {ok:true};
});

export const saveInstitutionOnboardingStep=onCall(async request=>{
  const access=await requireTenantUser(request,['admin']),uid=request.auth!.uid;
  const root=db().doc('tenants/'+access.tenantId),ref=root.collection('settings').doc('onboarding');
  const step=text(request.data?.step,30),action=text(request.data?.action,20)||'continue',input=request.data?.data ?? {};
  if(!steps.includes(step)||!['start','continue','pause','back','defer'].includes(action)) throw new HttpsError('invalid-argument','Invalid setup action.');
  return db().runTransaction(async tx=>{
    const [saved,tenant]=await Promise.all([tx.get(ref),tx.get(root)]);
    const progress=saved.exists ? saved.data()! : initialProgress();
    if(Number(request.data?.expectedRevision)!==Number(progress.revision)) throw new HttpsError('aborted','Setup changed in another tab. Reload saved progress before continuing.');
    if(progress.status==='completed') return {status:'completed',currentStep:'review',revision:progress.revision};
    if(!saved.exists && action!=='start') throw new HttpsError('failed-precondition','Start institution setup first.');
    if(step!==progress.currentStep) throw new HttpsError('failed-precondition','Reload your current setup step.');
    let updates:Record<string,unknown>={}, general:Record<string,unknown>|null=null, academic:Record<string,unknown>|null=null;
    let subject:Record<string,unknown>|null=null;
    const subjectRef=root.collection('subjects').doc('onboarding-first-subject');
    let subjectExists=false;
    if(step==='exam' && !['back','defer','start'].includes(action) && input.createSubject) {
      if(!access.modules['subjects'] || !access.modules['exams']) throw new HttpsError('permission-denied','Subject and exam modules must be enabled.');
      const [existing,subjects]=await Promise.all([tx.get(subjectRef),tx.get(root.collection('subjects').limit(Number(access.limits['subjects'])+1))]);
      subjectExists=existing.exists;
      if(!subjectExists && subjects.size>=Number(access.limits['subjects'])) throw new HttpsError('resource-exhausted','Your institution has reached its subject limit.');
      const timeLimit=Number(input.timeLimit),questionLimit=Number(input.questionLimit);
      if(!Number.isInteger(timeLimit)||timeLimit<1||timeLimit>480||!Number.isInteger(questionLimit)||questionLimit<1||questionLimit>500) throw new HttpsError('invalid-argument','Use 1–480 minutes and 1–500 questions.');
      subject={name:required(input.name,'Subject name',120),description:required(input.description,'Description',240),class:required(input.className,'Class',80),timeLimit,questionLimit,active:false,createdBy:uid,createdAt:FieldValue.serverTimestamp()};
    }
    if(!['back','defer','start'].includes(action)) {
      if(step==='profile') {
        const timezone=text(input.timezone,80)||'Africa/Lagos';
        try {new Intl.DateTimeFormat('en',{timeZone:timezone}).format();} catch {throw new HttpsError('invalid-argument','Choose a valid timezone.');}
        updates={name:required(input.name,'Institution name',150),shortName:required(input.shortName,'Short name',40),email:email(input.email),address:required(input.address,'Address',250),phone:required(input.phone,'Phone',40),timezone,currency:'NGN'};
        general=updates;
      }
      if(step==='academic') academic={className:required(input.className,'Class or level',80),department:text(input.department,120)};
      if(step==='review') {
        const profile=tenant.data()!;
        required(profile.name,'Institution name'); email(profile.email); required(profile.address,'Address'); required(profile.phone,'Phone');
        if(!(progress.completedSteps ?? []).includes('academic')) throw new HttpsError('failed-precondition','Complete academic structure before finishing.');
      }
    }
    if(action==='defer' && !['exam','registration'].includes(step)) throw new HttpsError('invalid-argument','This setup step cannot be skipped.');
    const index=steps.indexOf(step),completed=new Set<string>(progress.completedSteps ?? []),deferred=new Set<string>(progress.deferredSteps ?? []);
    if(!['back','start'].includes(action)) {
      if(action==='defer' || (step==='exam' && !input.createSubject && !progress.setupSubjectId)) deferred.add(step);
      else {completed.add(step);deferred.delete(step);}
    }
    const finished=step==='review' && action==='continue';
    const next=action==='back' ? steps[Math.max(0,index-1)] : ['pause','start'].includes(action) ? step : steps[Math.min(steps.length-1,index+1)];
    const revision=Number(progress.revision)+1;
    const result={status:finished?'completed':'in_progress',currentStep:next,completedSteps:[...completed],deferredSteps:[...deferred],revision,paused:action==='pause',schemaVersion:1,
      updatedAt:FieldValue.serverTimestamp(),updatedBy:uid,...(subject ? {setupSubjectId:subjectRef.id} : {})};
    if(Object.keys(updates).length) {
      tx.update(root,{...updates,updatedAt:FieldValue.serverTimestamp()});
      tx.set(db().doc('userTenancies/'+uid+'/tenants/'+access.tenantId),{tenantName:updates.name,shortName:updates.shortName},{merge:true});
    }
    if(general) tx.set(root.collection('settings').doc('general'),general,{merge:true});
    if(academic) tx.set(root.collection('settings').doc('academic'),academic,{merge:true});
    if(subject && !subjectExists) tx.create(subjectRef,subject);
    tx.set(ref,result,{merge:true});
    tx.create(root.collection('activityLogs').doc(),{actorId:uid,actorEmail:request.auth!.token.email ?? '',action:'onboarding_'+action,entityType:'onboarding',entityId:step,createdAt:FieldValue.serverTimestamp()});
    return {status:result.status,currentStep:next,revision};
  });
});

