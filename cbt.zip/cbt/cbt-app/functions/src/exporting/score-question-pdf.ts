import { logger } from "firebase-functions";
import * as admin from "firebase-admin";
import * as fs from "fs";
import * as path from "path";
import puppeteer from "puppeteer";
import { onRequest } from "firebase-functions/v2/https";

export const generateExamQuestionsPDF = onRequest(async (request, response) => {
    logger.info("Generating Exam Questions PDF");

    const subjectId = request.query.subjectId as string;

    if (!subjectId) {
        response.status(400).json({ error: "subjectId query parameter is required" });
        return;
    }

    try {
        const data = await generatePdf(subjectId);
        response.json(data);
    } catch (error) {
        logger.error("Error generating PDF:", error);
        response.status(500).json({ error: "Failed to generate PDF" });
    }
});

async function generatePdf(subjectId: string) {
    try {
        // Query scores from Firestore under subjects/{subjectId}/score
        const scoresSnapshot = await admin
            .firestore()
            .collection(`subjects/${subjectId}/score`)
            .get();

        if (scoresSnapshot.empty) {
            console.log(`No scores found for subject ${subjectId}.`);
            throw new Error(`No scores found for subject ${subjectId}.`);
        }

        // Prepare scores data for rendering
        const scoresData: {
            student: string;
            exam: string;
            score: number;
            totalQuestions: number;
            scorePercentage: number;
            grade: string;
            remark: string;
            date: string;
            questions: {
                question: string;
                options: { id: string; text: string }[];
                selectedAnswer: string;
                correctAnswerId: string;
            }[];
        }[] = [];
        scoresSnapshot.forEach((doc) => {
            const score = doc.data();
            scoresData.push({
                student: score.student || "N/A",
                exam: score.exam || "N/A",
                score: score.score || 0,
                totalQuestions: score.totalQuestions || 0,
                scorePercentage: score.scorePercentage || 0,
                grade: score.grade || "N/A",
                remark: score.remark || "N/A",
                date: score.date || "N/A",
                questions: score.questions || [],
            });
        });

        // Generate HTML with the scores and questions data
        let html = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title></title>
        <style>
          body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background-color: #f4f4f4;
          }
          .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
          }
          h1 {
            color: #333;
            margin-bottom: 10px;
          }
          h3 {
            color: #555;
            margin-top: 20px;
          }
          p {
            margin: 5px 0;
          }
          .score-section {
            border-bottom: 1px solid #ddd;
            padding-bottom: 20px;
            margin-bottom: 20px;
          }
          .question-list {
            list-style-type: none;
            padding: 0;
          }
          .question-item {
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 4px;
            background-color: #f9f9f9;
          }
          .options-list {
            padding-left: 20px;
            margin: 5px 0;
          }
          .correct {
            color: #28a745;
            font-weight: bold;
          }
          .incorrect {
            color: #dc3545;
            font-weight: bold;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>Exam Questions Report - Subject ${subjectId}</h1>
          <p>View all exam submissions and questions</p>
    `;

        // Append each score and its questions
        scoresData.forEach((score) => {
            html += `
        <div class="score-section">
          <h3>Exam: ${score.exam}</h3>
          <p><strong>Student:</strong> ${score.student}</p>
          <p><strong>Score:</strong> ${score.score} / ${score.totalQuestions}</p>
          <p><strong>Percentage:</strong> ${score.scorePercentage.toFixed(2)}%</p>
          <p><strong>Grade:</strong> ${score.grade}</p>
          <p><strong>Remark:</strong> ${score.remark}</p>
          <p><strong>Date:</strong> ${new Date(score.date).toLocaleString()}</p>
          <h4>Questions</h4>
          <ul class="question-list">
      `;

            score.questions.forEach((q) => {
                const isCorrect = q.selectedAnswer === q.correctAnswerId;
                html += `
          <li class="question-item">
            <strong>Question:</strong> ${q.question}<br />
            <strong>Options:</strong>
            <ul class="options-list">
              ${q.options
                    .map((opt) => `<li>${opt.id}: ${opt.text}</li>`)
                    .join("")}
            </ul>
            <strong>Selected Answer:</strong> ${
                    q.selectedAnswer
                } (${getOptionText(q.options, q.selectedAnswer)}) <span class="${
                    isCorrect ? "correct" : "incorrect"
                }">${isCorrect ? "✔" : "✖"}</span><br />
            <strong>Correct Answer:</strong> ${q.correctAnswerId} (${getOptionText(
                    q.options,
                    q.correctAnswerId
                )})
          </li>
        `;
            });

            html += `
          </ul>
        </div>
      `;
        });

        html += `
        </div>
      </body>
      </html>
    `;

        // Convert HTML to PDF using Puppeteer
        const browser = await puppeteer.launch({ headless: true });
        const page = await browser.newPage();

        await page.setContent(html, { waitUntil: "domcontentloaded" });

        const pdfFilePath = path.join("/tmp", `exam-questions-${subjectId}-${Date.now()}.pdf`);

        await page.pdf({
            path: pdfFilePath,
            format: "A4",
            printBackground: true,
        });

        await browser.close();

        console.log("PDF file created successfully.");

        // Upload PDF to Cloud Storage
        const bucket = admin.storage().bucket();
        const fileName = `exports/exam-questions-${subjectId}-${Date.now()}.pdf`;

        const file = bucket.file(fileName);
        await bucket.upload(pdfFilePath, {
            destination: fileName,
            metadata: {
                contentType: "application/pdf",
            },
        });

        console.log(`Exam questions PDF uploaded successfully to Cloud Storage: ${fileName}`);

        const url = file.publicUrl();

        console.log("Public URL generated:", url);

        // Clean up temporary PDF file
        fs.unlinkSync(pdfFilePath);

        return { downloadLink: url };
    } catch (error) {
        console.error("Error exporting exam questions to PDF:", error);
        throw new Error("Failed to generate and upload PDF.");
    }
}

// Helper function to get option text by ID (similar to your Angular component)
function getOptionText(options: { id: string; text: string }[], optionId: string): string {
    const option = options.find((opt) => opt.id === optionId);
    return option ? option.text : optionId;
}