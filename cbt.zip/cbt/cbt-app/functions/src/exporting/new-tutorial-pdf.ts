import { logger } from "firebase-functions";
import * as admin from "firebase-admin";
import * as fs from "fs";
import * as path from "path";
import puppeteer from "puppeteer";
import { onRequest } from "firebase-functions/v2/https";

// Ensure Firebase Admin is initialized
if (!admin.apps.length) {
    admin.initializeApp();
}

export const generateNewTutorialPDF = onRequest(async (request, response) => {
    logger.info("Generating Tutorial PDF");

    const tutorialId = request.query.tutorialId as string;

    if (!tutorialId) {
        logger.warn("No tutorialId provided in request");
        response.status(400).json({ error: "tutorialId query parameter is required" });
        return;
    }

    try {
        logger.info("Starting PDF generation process", { tutorialId });
        const data = await generatePdf(tutorialId);
        response.status(200).json(data);
    } catch (error) {
        logger.error("Error generating PDF:", {
            message: error instanceof Error ? error.message : "Unknown error",
            stack: error instanceof Error ? error.stack : undefined,
            tutorialId
        });
        response.status(500).json({
            error: "Failed to generate PDF",
            details: error instanceof Error ? error.message : "Unknown error occurred"
        });
    }
});

async function generatePdf(tutorialId: string) {
    let browser;
    try {
        // Fetch tutorial data from Firestore
        logger.info("Fetching tutorial data from Firestore", { tutorialId });
        const tutorialDocRef = admin.firestore().collection("tutorials").doc(tutorialId);
        const tutorialSnap = await tutorialDocRef.get();

        if (!tutorialSnap.exists) {
            logger.warn("Tutorial not found in Firestore", { tutorialId });
            throw new Error(`No tutorial found with ID: ${tutorialId}`);
        }

        const tutorial = tutorialSnap.data();
        if (!tutorial) {
            logger.error("Tutorial data is undefined despite document existing", { tutorialId });
            throw new Error("Tutorial data is undefined");
        }

        // Prepare tutorial data with defaults
        const tutorialData = {
            name: tutorial.name || "Untitled Tutorial",
            imageUrl: tutorial.imageUrl || "",
            description: tutorial.description || "No description available",
            createdAt: tutorial.createdAt?.toDate().toLocaleString() || "N/A",
            sections: tutorial.sections || [],
        };

        // Generate HTML content
        logger.info("Generating HTML content", { tutorialId });
        let html = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${tutorialData.name}</title>
        <style>
          body { font-family: 'Times New Roman', serif; margin: 0; line-height: 1.6; color: #333; }
          .cover-page { position: relative; height: 100vh; page-break-after: always; text-align: center; padding: 40px; display: flex; flex-direction: column; justify-content: center; align-items: center; }
          .cover-image { max-width: 300px; max-height: 400px; margin: 20px auto; }
          .cover-title { font-size: 36px; color: #06521c; margin: 20px 0; }
          .cover-description { font-size: 18px; font-style: italic; color: #666; max-width: 600px; }
          .cover-date { font-size: 14px; color: #888; margin-top: 20px; }
          .container { max-width: 800px; margin: 40px auto; }
          .section { margin-left: 20px; margin-bottom: 20px; }
          .section-title { font-size: 18px; font-weight: bold; margin-bottom: 8px; color: #444; }
          .section-content { font-size: 16px; white-space: pre-wrap; }
        </style>
      </head>
      <body>
        <div class="cover-page">
          ${tutorialData.imageUrl ? `<img src="${tutorialData.imageUrl}" class="cover-image" alt="Tutorial Cover" onerror="this.style.display='none'">` : ""}
          <h1 class="cover-title">${tutorialData.name}</h1>
          <p class="cover-description">${tutorialData.description}</p>
          <p class="cover-date">Created on: ${tutorialData.createdAt}</p>
        </div>
        <div class="container">
    `;

        if (tutorialData.sections.length > 0) {
            tutorialData.sections.forEach((section: { title: string; content: string }, index: number) => {
                html += `
          <div class="section">
            <div class="section-title">Chapter ${index + 1}: ${section.title || "Untitled"}</div>
            <div class="section-content">${section.content || "No content"}</div>
          </div>
        `;
            });
        } else {
            html += `<p>No sections available for this tutorial.</p>`;
        }

        html += `
        </div>
      </body>
      </html>
    `;

        // Generate PDF with Puppeteer
        logger.info("Launching Puppeteer", { tutorialId });
        browser = await puppeteer.launch({
            headless: true,
            args: ["--no-sandbox", "--disable-setuid-sandbox"] // For stability in serverless environments
        });
        const page = await browser.newPage();

        logger.info("Setting HTML content in Puppeteer", { tutorialId });
        await page.setContent(html, { waitUntil: "networkidle0" });

        const pdfFilePath = path.join("/tmp", `tutorial-${tutorialId}-${Date.now()}.pdf`);
        logger.info("Generating PDF file", { tutorialId, pdfFilePath });
        await page.pdf({
            path: pdfFilePath,
            format: "A4",
            printBackground: true,
            margin: { top: "20mm", right: "15mm", bottom: "20mm", left: "15mm" },
        });

        logger.info("PDF file created successfully", { tutorialId, pdfFilePath });

        // Upload to Cloud Storage
        logger.info("Uploading PDF to Cloud Storage", { tutorialId });
        const bucket = admin.storage().bucket();
        const fileName = `exports/tutorial-${tutorialId}-${Date.now()}.pdf`;
        const file = bucket.file(fileName);
        await bucket.upload(pdfFilePath, {
            destination: fileName,
            metadata: { contentType: "application/pdf" },
        });

        logger.info("PDF uploaded successfully to Cloud Storage", { tutorialId, fileName });

        const url = file.publicUrl();
        logger.info("Public URL generated", { tutorialId, url });

        // Clean up temporary file
        logger.info("Cleaning up temporary file", { tutorialId, pdfFilePath });
        try {
            fs.unlinkSync(pdfFilePath);
            logger.info("Temporary file deleted", { tutorialId, pdfFilePath });
        } catch (cleanupError) {
            logger.warn("Failed to delete temporary file", { tutorialId, error: cleanupError });
        }

        logger.info("PDF generation completed successfully", { tutorialId, downloadLink: url });
        return { downloadLink: url };
    } catch (error) {
        logger.error("Error in generatePdf:", {
            message: error instanceof Error ? error.message : "Unknown error",
            stack: error instanceof Error ? error.stack : undefined,
            tutorialId
        });
        throw new Error("Failed to generate and upload PDF");
    } finally {
        if (browser) {
            try {
                await browser.close();
                logger.info("Puppeteer browser closed", { tutorialId });
            } catch (closeError) {
                logger.warn("Failed to close Puppeteer browser", { tutorialId, error: closeError });
            }
        }
    }
}