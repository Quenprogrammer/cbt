import { logger } from "firebase-functions";
import * as admin from "firebase-admin";
import * as fs from "node:fs";
import * as path from "node:path";
import * as XLSX from "xlsx";
import { onRequest } from "firebase-functions/v2/https";
import { onInit } from "firebase-functions/v2/core";

// Define the AppointmentDetails interface to match Angular service
interface AppointmentDetails {
    id: string;
    patientName: string;
    email: string;
    phone: string;
    departmentName: string;
    doctorId: string;
    doctorName: string;
    appointmentType: string;
    appointmentDate: string;
    startTime: Date | admin.firestore.Timestamp;
    endTime: Date | admin.firestore.Timestamp;
    bookingId: string;
    createdAt: Date | admin.firestore.Timestamp;
}

// Declare shared instances
let firestore: admin.firestore.Firestore;
let bucket: ReturnType<admin.storage.Storage["bucket"]>;

// Defer initialization to runtime
onInit(() => {
    logger.info("Initializing Firestore and Storage for Excel export...");
    firestore = admin.firestore();
    bucket = admin.storage().bucket();
    logger.info("Initialization complete.");
});

// Export the function with increased timeout
export const generatePatientExcel = onRequest(
    { timeoutSeconds: 300 },
    async (request, response) => {
        try {
            logger.info("Excel generation request received.");
            const data = await generateExcelAndUploadToCloud();
            response.json(data);
        } catch (error:any) {
            logger.error("Excel export failed:", error);
            response.status(500).json({ error: "Failed to generate Excel.", details: error.message });
        }
    }
);

// Main Excel export logic
async function generateExcelAndUploadToCloud() {
    try {
        logger.info("Fetching bookings from Firestore...");
        const bookingsSnapshot = await firestore.collection("bookings").get();

        if (bookingsSnapshot.empty) {
            logger.warn("No bookings found in Firestore.");
            throw new Error("No bookings found in Firestore.");
        }

        // Format booking data for Excel
        const bookingsData = bookingsSnapshot.docs.map((doc) => {
            const booking = doc.data() as AppointmentDetails;
            return {
                Name: booking.patientName || "N/A",
                Email: booking.email || "N/A",
                Phone: booking.phone || "N/A",
                Department: booking.departmentName || "N/A",
                Doctor: booking.doctorName || "N/A",
                AppointmentType: booking.appointmentType || "N/A",
                AppointmentDate: booking.appointmentDate || "N/A",
                Time: `${
                    booking.startTime instanceof admin.firestore.Timestamp
                        ? booking.startTime.toDate().toLocaleTimeString()
                        : new Date(booking.startTime).toLocaleTimeString()
                } - ${
                    booking.endTime instanceof admin.firestore.Timestamp
                        ? booking.endTime.toDate().toLocaleTimeString()
                        : new Date(booking.endTime).toLocaleTimeString()
                }`,
                BookingID: booking.bookingId || "N/A",
                CreatedAt: booking.createdAt instanceof admin.firestore.Timestamp
                    ? booking.createdAt.toDate().toISOString()
                    : new Date(booking.createdAt).toISOString(),
            };
        });

        logger.info(`Fetched ${bookingsData.length} bookings.`);

        // Create workbook and worksheet
        const workbook = XLSX.utils.book_new();
        const worksheet = XLSX.utils.json_to_sheet(bookingsData);
        XLSX.utils.book_append_sheet(workbook, worksheet, "Bookings");

        // Write file to temp directory
        const fileName = `bookings-${Date.now()}.xlsx`;
        const filePath = path.join("/tmp", fileName);
        logger.info(`Writing Excel file to ${filePath}...`);
        XLSX.writeFile(workbook, filePath);

        // Upload to Firebase Storage
        const file = bucket.file(`exports/${fileName}`);
        logger.info(`Uploading Excel file to Storage: ${fileName}...`);
        await bucket.upload(filePath, {
            destination: `exports/${fileName}`,
            metadata: {
                contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            },
        });

        // Cleanup
        fs.unlinkSync(filePath);
        logger.info(`Excel file uploaded: exports/${fileName}`);

        // Return public URL
        const url = file.publicUrl();
        logger.info(`Excel uploaded successfully: ${url}`);
        return { downloadLink: url };
    } catch (error:any) {
        logger.error("Excel generation or upload failed:", error);
        throw new Error(`Failed to generate and upload Excel: ${error.message}`);
    }
}