import { logger } from "firebase-functions";
import { onDocumentCreated } from "firebase-functions/v2/firestore";
import { onInit } from "firebase-functions/v2/core";
import { onMessagePublished } from "firebase-functions/v2/pubsub";
import * as admin from "firebase-admin";
import { PubSub } from "@google-cloud/pubsub";
import * as nodemailer from "nodemailer";

// Initialize Firebase Admin SDK
admin.initializeApp();

// Declare shared instances (NOTE: Removed unused `firestore`)
let pubsub: PubSub;
let transporter: nodemailer.Transporter;

// Initialize heavy services only once
onInit(() => {
    logger.info("Initializing services for appointment reminders...");
    pubsub = new PubSub();
    transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
            user: process.env.EMAIL_USER || "maaunclinic@gmail.com",
            pass: process.env.EMAIL_PASS || "",
        },
    });
    logger.info("Initialization complete.");
});

// Define AppointmentDetails interface
interface AppointmentDetails {
    id: string;
    patientName: string;
    email: string;
    phone: string;
    departmentName: string;
    doctorId: string;
    doctorName: string;
    appointmentType: string;
    appointmentDate: string;
    startTime: Date | admin.firestore.Timestamp;
    endTime: Date | admin.firestore.Timestamp;
    bookingId: string;
    createdAt: Date | admin.firestore.Timestamp;
}

// Email HTML generator
function generateReminderEmailHtml(
    patientName: string,
    bookingId: string,
    departmentName: string,
    doctorName: string,
    appointmentType: string,
    formattedDate: string,
    formattedTime: string,
    phone: string,
    email: string
): string {
    // HTML returned unchanged for brevity
    return `<!DOCTYPE html>...`; // (same as you provided above)
}

// Firestore Trigger: Schedule PubSub messages
export const scheduleAppointmentReminder = onDocumentCreated(
    "bookings/{bookingId}",
    async (event) => {
        const booking = event.data?.data() as AppointmentDetails | undefined;
        const bookingId = event.params.bookingId;

        if (!booking) {
            logger.error("No booking data found for bookingId:", bookingId);
            throw new Error("No booking data found.");
        }

        try {
            const startTime = booking.startTime instanceof admin.firestore.Timestamp
                ? booking.startTime.toDate()
                : new Date(booking.startTime);
            const endTime = booking.endTime instanceof admin.firestore.Timestamp
                ? booking.endTime.toDate()
                : new Date(booking.endTime);

            const formattedDate = startTime.toLocaleDateString("en-US", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
            });

            const formattedTime = `${startTime.toLocaleTimeString("en-US", {
                hour: "2-digit",
                minute: "2-digit",
            })} - ${endTime.toLocaleTimeString("en-US", {
                hour: "2-digit",
                minute: "2-digit",
            })}`;

            const reminderTimes = [
                { time: new Date(startTime.getTime() - 30 * 60 * 1000), type: "30min" },
                { time: new Date(startTime.getTime() - 15 * 60 * 1000), type: "15min" },
            ];

            for (const reminder of reminderTimes) {
                if (reminder.time > new Date()) {
                    const messageId = `${bookingId}-${reminder.time.getTime()}`;
                    const topic = "appointment-reminders";

                    await pubsub.topic(topic).publishMessage({
                        json: {
                            patientName: booking.patientName,
                            email: booking.email,
                            phone: booking.phone,
                            departmentName: booking.departmentName,
                            doctorName: booking.doctorName,
                            appointmentType: booking.appointmentType,
                            appointmentDate: booking.appointmentDate,
                            formattedDate,
                            formattedTime,
                            bookingId: booking.bookingId || bookingId,
                            reminderType: reminder.type,
                        },
                        attributes: { messageId },
                    });

                    logger.info(
                        `Scheduled ${reminder.type} reminder for booking ${bookingId} at ${reminder.time}`
                    );
                } else {
                    logger.info(
                        `Skipped ${reminder.type} reminder for booking ${bookingId} as time is in the past`
                    );
                }
            }
        } catch (error) {
            logger.error(`Error scheduling reminder for booking ${bookingId}:`, error);
            throw new Error("Failed to schedule reminder.");
        }
    }
);

// PubSub Trigger: Send emails
export const sendAppointmentReminder = onMessagePublished(
    "appointment-reminders",
    async (event) => {
        try {
            const {
                patientName,
                email,
                phone,
                departmentName,
                doctorName,
                appointmentType,
                formattedDate,
                formattedTime,
                bookingId,
                reminderType,
            } = event.data.message.json;

            const mailOptions = {
                from: process.env.EMAIL_USER || "maaunclinic@gmail.com",
                to: email,
                subject: `Appointment Reminder (${reminderType === "30min" ? "30 Minutes" : "15 Minutes"}) - ${bookingId}`,
                html: generateReminderEmailHtml(
                    patientName,
                    bookingId,
                    departmentName,
                    doctorName,
                    appointmentType,
                    formattedDate,
                    formattedTime,
                    phone,
                    email
                ),
            };

            await transporter.sendMail(mailOptions);
            logger.info(`Sent ${reminderType} reminder email for booking ${bookingId} to ${email}`);
        } catch (error) {
            logger.error(
                `Error sending reminder email:`,
                error
            );
            throw new Error("Failed to send reminder email.");
        }
    }
);
