/*
import * as admin from "firebase-admin";
// Firebase Admin SDK
import * as fs from 'fs';
import * as path from 'path';
import puppeteer from "puppeteer";


export async function generatePdf(){
    try {
        // Query students from Firestore
        const studentsSnapshot = await admin.firestore().collection('student').get();

        if (studentsSnapshot.empty) {
            console.log('No students found in Firestore.');
            throw new Error('No students found in Firestore.');
        }

        // Prepare students' data for rendering
        const studentsData: { name: any; admissionNumber: any; department: any; dateOfBirth: any ;email:any; gender:any;   }[] = [];
        studentsSnapshot.forEach((doc) => {
            const student = doc.data();
            studentsData.push({
                name: student.name || 'N/A',
                admissionNumber: student.admissionNumber || 'N/A',
                department: student.department || 'N/A',
                dateOfBirth: student.dateOfBirth || 'N/A',
                email: student.email || 'N/A',
                gender: student.gender || 'N/A',
            });
        });

        // Generate HTML with the student data
        let html = `
        <!DOCTYPE html>
        <html lang="en">
       <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        h1 {
            margin: 0;
        }
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-primary {
            background-color: #06521c;
            color: white;
        }
        .btn-primary:hover {
            background-color: #06521c;
        }
        .table-container {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #6c6c6c;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .search-bar {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        .search-bar input[type="search"] {
            padding: 8px;
            width: 100%;
            max-width: 300px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
    </style>
</head>
        <body>
            <table>
               <div>
                <h1>Student List</h1>
                <p>View and manage all your students</p>
            </div>
              <thead>
                    <tr>
                        <th>S/N</th>
                        <th>Student Name</th>
                        <th>Email</th>
                        <th>Adm No</th>
                        <th>Department</th>
                        <th>Date Of Birth</th>
                        <th>Gender</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>
        `;

        // Append rows for each student
        studentsData.forEach((student) => {
            html += `
            <tr>
                <td>${student.name}</td> 
                  <td>${student.email}</td>
                <td>${student.admissionNumber}</td>
                <td>${student.department}</td>
                <td>${student.dateOfBirth}</td>
                <td>${student.gender}</tr>
                 <td><button class="btn btn-primary">View</button></td>
            `;
        });

        html += `
                </tbody>
            </table>
        </body>
        </html>
        `;

        // Convert HTML to PDF using Puppeteer
        const browser = await puppeteer.launch();
        const page = await browser.newPage();

        // Set the HTML content
        await page.setContent(html, {waitUntil: 'domcontentloaded'});

        // Define the PDF output path
        const pdfFilePath = path.join('/tmp', `students-${Date.now()}.pdf`);

        // Generate the PDF
        await page.pdf({
            path: pdfFilePath,
            format: 'A4',
            printBackground: true,
        });

        await browser.close();

        console.log('PDF file created successfully.');

        // Upload PDF file to Cloud Storage
        const bucket = admin.storage().bucket();
        const fileName = `exports/students-${Date.now()}.pdf`;

        const file = bucket.file(fileName);
        await bucket.upload(pdfFilePath, {
            destination: fileName,
            metadata: {
                contentType: 'application/pdf',
            },
        });

        console.log(`Student list PDF uploaded successfully to Cloud Storage: ${fileName}`);

        // Generate a signed URL valid for 24 hours
        console.log(file.publicUrl())
        const url =file.publicUrl()

        console.log('Signed URL generated:', url);

        // Clean up temporary PDF file
        fs.unlinkSync(pdfFilePath);

        // Return the signed URL to the client

        return ({downloadLink: url});
    } catch (error) {
        console.error('Error exporting students to PDF and uploading:', error);
        throw new Error('Failed to generate and upload PDF.');
    }
}
*/
