import { logger } from "firebase-functions";
import * as admin from "firebase-admin";
import * as fs from "fs";
import * as path from "path";
import { onRequest } from "firebase-functions/v2/https";
import { onInit } from "firebase-functions/v2/core";

// Define the AppointmentDetails interface to match Angular service
interface AppointmentDetails {
    id: string;
    patientName: string;
    email: string;
    phone: string;
    departmentName: string;
    doctorId: string;
    doctorName: string;
    appointmentType: string;
    appointmentDate: string;
    startTime: Date | admin.firestore.Timestamp;
    endTime: Date | admin.firestore.Timestamp;
    bookingId: string;
    createdAt: Date | admin.firestore.Timestamp;
}

// Declare these at the top so they can be initialized in onInit
let puppeteer: typeof import("puppeteer");
let firestore: admin.firestore.Firestore;
let bucket: ReturnType<admin.storage.Storage["bucket"]>;

// Initialize heavy services only once
onInit(async () => {
    logger.info("Initializing services for PDF generation...");
    try {
        puppeteer = await import("puppeteer");
        firestore = admin.firestore();
        bucket = admin.storage().bucket();
        logger.info("Initialization complete.");
    } catch (error: any) {
        logger.error("Initialization failed:", error.message, error.stack);
        throw new Error(`Initialization failed: ${error.message}`);
    }
});

// Export the function with corrected memory configuration
export const generatePatientPDF = onRequest(
    { memory: "1GiB", timeoutSeconds: 300 },
    async (request, response) => {
        try {
            const data = await generatePdf();
            response.json(data);
        } catch (error: any) {
            logger.error("PDF generation failed:", error.message, error.stack);
            response.status(500).json({ error: "Failed to generate PDF.", details: error.message });
        }
    }
);

// PDF generation logic
async function generatePdf() {
    try {
        logger.info("Fetching bookings from Firestore...");
        const bookingsSnapshot = await firestore.collection("bookings").get();

        if (bookingsSnapshot.empty) {
            logger.warn("No bookings found in Firestore.");
            throw new Error("No bookings found in Firestore.");
        }

        const bookingsData = bookingsSnapshot.docs.map((doc) => {
            const booking = doc.data() as AppointmentDetails;
            return {
                id: doc.id,
                patientName: booking.patientName || "N/A",
                email: booking.email || "N/A",
                phone: booking.phone || "N/A",
                departmentName: booking.departmentName || "N/A",
                doctorName: booking.doctorName || "N/A",
                appointmentType: booking.appointmentType || "N/A",
                appointmentDate: booking.appointmentDate || "N/A",
                startTime: booking.startTime instanceof admin.firestore.Timestamp
                    ? booking.startTime.toDate().toLocaleTimeString()
                    : new Date(booking.startTime).toLocaleTimeString(),
                endTime: booking.endTime instanceof admin.firestore.Timestamp
                    ? booking.endTime.toDate().toLocaleTimeString()
                    : new Date(booking.endTime).toLocaleTimeString(),
                bookingId: booking.bookingId || "N/A",
                createdAt: booking.createdAt instanceof admin.firestore.Timestamp
                    ? booking.createdAt.toDate().toISOString()
                    : new Date(booking.createdAt).toISOString(),
            };
        });

        logger.info(`Fetched ${bookingsData.length} bookings.`);

        const html = generateHtml(bookingsData);

        logger.info("Launching Puppeteer...");
        const browser = await puppeteer.launch({
            headless: true,
            args: ["--no-sandbox", "--disable-setuid-sandbox"],
        });
        const page = await browser.newPage();
        await page.setContent(html, { waitUntil: "domcontentloaded" });

        const pdfFilePath = path.join("/tmp", `bookings-${Date.now()}.pdf`);
        logger.info(`Generating PDF at ${pdfFilePath}...`);
        await page.pdf({
            path: pdfFilePath,
            format: "A4",
            printBackground: true,
        });

        await browser.close();
        logger.info("Puppeteer closed.");

        const fileName = `exports/bookings-${Date.now()}.pdf`;
        const file = bucket.file(fileName);

        logger.info(`Uploading PDF to Storage: ${fileName}...`);
        await bucket.upload(pdfFilePath, {
            destination: fileName,
            metadata: {
                contentType: "application/pdf",
            },
        });

        fs.unlinkSync(pdfFilePath); // Clean up temp file
        logger.info("Temporary file deleted.");

        const publicUrl = file.publicUrl();
        logger.info(`PDF uploaded successfully: ${publicUrl}`);
        return { downloadLink: publicUrl };
    } catch (error: any) {
        logger.error("Error during PDF export:", error.message, error.stack);
        throw new Error(`Failed to generate and upload PDF: ${error.message}`);
    }
}

// Generates HTML string
function generateHtml(bookingsData: any[]): string {
    let html = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Booking List</title>
      <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px; }
        table { width: 100%; border-collapse: collapse; background: white; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
        th { background-color: #333; color: #fff; }
        tr:nth-child(even) { background-color: #f9f9f9; }
      </style>
    </head>
    <body>
      <h1>Booking List</h1>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Department</th>
            <th>Doctor</th>
            <th>Appointment Type</th>
            <th>Appointment Date</th>
            <th>Time</th>
            <th>Booking ID</th>
          </tr>
        </thead>
        <tbody>
  `;

    for (const booking of bookingsData) {
        html += `
      <tr>
        <td>${booking.patientName}</td>
        <td>${booking.email}</td>
        <td>${booking.phone}</td>
        <td>${booking.departmentName}</td>
        <td>${booking.doctorName}</td>
        <td>${booking.appointmentType}</td>
        <td>${booking.appointmentDate}</td>
        <td>${booking.startTime} - ${booking.endTime}</td>
        <td>${booking.bookingId}</td>
      </tr>
    `;
    }

    html += `
        </tbody>
      </table>
    </body>
    </html>
  `;
    return html;
}