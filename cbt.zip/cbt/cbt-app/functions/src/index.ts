import * as admin from 'firebase-admin';

// Initialize the Firebase Admin SDK once for all callable functions and triggers.
admin.initializeApp();
admin.firestore().settings({ ignoreUndefinedProperties: true });

// Core CBT callable functions.
exports.exam_attempts = require('./exam/exam-attempts');
exports.question_bank = require('./exam/question-bank');
exports.question_lifecycle = require('./exam/question-lifecycle');
exports.exam_drafts = require('./exam/exam-drafts');
exports.account_security = require('./security/account-security');
exports.result_workflow = require('./exam/result-workflow');
exports.practice = require('./exam/practice');
exports.exam_scheduling = require('./exam/scheduling');
exports.staff_access = require('./tenant/staff-access');
exports.exam_readiness = require('./exam/readiness');
exports.tenant_backups = require('./tenant/backups');
exports.student_accounts = require('./students/student-accounts');
exports.institution_onboarding = require('./onboarding/institution-onboarding');

// Multi-tenant CBT platform management, access control and usage counters.
exports.tenant_platform = require('./platform/tenant-platform');
exports.tenant_access = require('./tenant/tenant-access');
exports.tenant_usage = require('./tenant/usage-triggers');

// The old sample / clinic PDF and Excel HTTP functions are intentionally not
// exported. They were unrelated demo utilities and did not enforce tenant
// boundaries. Their source files are retained for reference only.
