import * as admin from 'firebase-admin';
import { FieldValue } from 'firebase-admin/firestore';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { requireTenantUser } from '../tenant/tenant-access';
import { normalizeResponse, ResponseValue } from './question-model';

export const saveDraft = onCall({ cors: true }, async request => {
  const tenant = await requireTenantUser(request, ['student']);
  if (tenant.modules['exams'] === false) throw new HttpsError('permission-denied', 'Exams are disabled.');
  const input = request.data ?? {}, id = String(input.assignmentId ?? '');
  const clientId = String(input.clientId ?? ''), revision = Number(input.revision);
  if (!id || id.includes('/') || !/^[\w-]{10,80}$/.test(clientId) || !Number.isSafeInteger(revision) || revision < 1) throw new HttpsError('invalid-argument', 'Invalid exam draft.');
  if (!input.answers || typeof input.answers !== 'object' || Array.isArray(input.answers)) throw new HttpsError('invalid-argument', 'Draft answers must be an object.');
  const db = admin.firestore();
  const assignmentRef = db.doc(`tenants/${tenant.tenantId}/examAssignments/${id}`), draftRef = db.doc(`tenants/${tenant.tenantId}/examDrafts/${id}`);
  return db.runTransaction(async tx => {
    const [assignment, saved] = await Promise.all([tx.get(assignmentRef), tx.get(draftRef)]);
    if (!assignment.exists || assignment.data()!.studentId !== request.auth!.uid) throw new HttpsError('permission-denied', 'This exam does not belong to you.');
    if (assignment.data()!.status === 'submitted') return { submitted: true, revision };
    if (saved.data()?.clientId === clientId && Number(saved.data()?.revision) >= revision) return { saved: true, revision: saved.data()!.revision };
    const questions: Array<{ questionId: string; options: Array<{ id: string }> }> = assignment.data()!.questions ?? [];
    const answers: Record<string, ResponseValue> = {}, timePerQuestion: Record<string, number> = {};
    for (const question of questions) {
      const answer = input.answers[question.questionId];
      if (answer !== undefined) answers[question.questionId] = normalizeResponse(question, answer);
      const seconds = Number(input.timePerQuestion?.[question.questionId] ?? 0);
      timePerQuestion[question.questionId] = Number.isFinite(seconds) ? Math.max(0, Math.min(Math.floor(seconds), 86400)) : 0;
    }
    const currentQuestionIndex = Math.max(0, Math.min(Math.floor(Number(input.currentQuestionIndex) || 0), questions.length - 1));
    tx.set(draftRef, { studentId: request.auth!.uid, assignmentId: id, answers, timePerQuestion, currentQuestionIndex, clientId, revision, updatedAt: FieldValue.serverTimestamp(), updatedAtMs: Date.now() });
    return { saved: true, revision };
  });
});
