import * as admin from 'firebase-admin';
import { randomBytes } from 'crypto';
import { FieldValue } from 'firebase-admin/firestore';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { requireTenantUser } from '../tenant/tenant-access';
import { questionMetadata, selectQuestions, validateBlueprint } from './question-selection';
import { publicQuestion } from './question-model';
import { assertExamWindow } from './scheduling';
import { requirePermission } from '../tenant/permissions';

interface PublicOption {
  id: string;
  text: string;
}

interface AssignmentQuestion {
  subjectId: string;
  subjectName: string;
  questionId: string;
  question: string;
  imageUrl?: string;
  imageAlt?: string;
  topic?: string;
  difficulty?: string;
  questionType: string;
  [key: string]: any;
  options: PublicOption[];
}

export interface IncomingAnswer {
  questionId: string;
  selectedAnswerId?: string | null;
  timeSpentSeconds?: number;
}

function shuffle<T>(input: T[]): T[] {
  const copy = [...input];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

export function clampSeconds(value: unknown): number {
  const parsed = Number(value ?? 0);
  if (!Number.isFinite(parsed) || parsed < 0) return 0;
  return Math.min(Math.round(parsed), 24 * 60 * 60);
}

export function gradeFor(percentage: number): string {
  if (percentage >= 70) return 'A';
  if (percentage >= 60) return 'B';
  if (percentage >= 50) return 'C';
  if (percentage >= 45) return 'D';
  return 'F';
}

function generatePin(): string {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const bytes = randomBytes(8);
  let body = '';

  for (let i = 0; i < 8; i += 1) {
    body += alphabet[bytes[i] % alphabet.length];
  }

  return `CBT-${body.slice(0, 4)}-${body.slice(4)}`;
}

export async function generateUniquePin(db: FirebaseFirestore.Firestore): Promise<string> {
  for (let attempt = 0; attempt < 12; attempt += 1) {
    const pin = generatePin();
    const existing = await db.collection('resultChecks').doc(pin).get();
    if (!existing.exists) return pin;
  }

  throw new HttpsError(
    'resource-exhausted',
    'Unable to allocate a unique result PIN. Please retry.'
  );
}

async function loadStudentDetails(
  tenantId: string,
  uid: string,
  email?: string
): Promise<Record<string, unknown>> {
  const db = admin.firestore();
  const byUid = await db.collection(`tenants/${tenantId}/student`).where('authUid', '==', uid).limit(1).get();

  if (!byUid.empty) {
    return { id: byUid.docs[0].id, ...byUid.docs[0].data() };
  }

  if (email) {
    const byEmail = await db.collection(`tenants/${tenantId}/student`).where('loginEmail', '==', email).limit(1).get();
    if (!byEmail.empty) {
      return { id: byEmail.docs[0].id, ...byEmail.docs[0].data() };
    }
  }

  return {
    authUid: uid,
    email: email ?? '',
    firstname: '',
    lastname: '',
    admissionNumber: '',
    department: '',
    examStatus: 'Not Started',
  };
}

async function packageFromAssignment(
  tenantId: string,
  id: string,
  assignment: FirebaseFirestore.DocumentData
): Promise<Record<string, unknown> | null> {
  const questions = Array.isArray(assignment.questions)
    ? (assignment.questions as AssignmentQuestion[])
    : [];
  const subjects = Array.isArray(assignment.subjects) ? assignment.subjects : [];

  if (questions.length === 0 || subjects.length === 0) return null;

  return {
    assignmentId: id,
    durationMinutes: Number(assignment.durationMinutes ?? 1),
    expiresAtMs: Number(assignment.expiresAtMs ?? Date.now()),
    subjects: subjects.map((subject: Record<string, unknown>) => {
      const questionIds = Array.isArray(subject.questionIds) ? subject.questionIds : [];
      const publicSubject = { ...subject };
      delete publicSubject.questionIds;
      return { ...publicSubject, questionCount: questionIds.length };
    }),
    questions,
    resumed: true,
    draft: (await admin.firestore().doc(`tenants/${tenantId}/examDrafts/${id}`).get()).data() ?? null,
  };
}

export const getExamPackage = onCall({ cors: true }, async (request) => {
  try {
    if (!request.auth) {
      throw new HttpsError('unauthenticated', 'Sign in to start an exam.');
    }
    if (request.auth.token.role !== 'student') {
      throw new HttpsError('permission-denied', 'Student access required.');
    }

    const tenant = await requireTenantUser(request, ['student']);
    const tenantId = tenant.tenantId;
    if (tenant.modules['exams'] === false) {
      throw new HttpsError('failed-precondition', 'The Exams module is not enabled for your CBT tenant.');
    }
    const db = admin.firestore();
    const studentDetails = await loadStudentDetails(
      tenantId,
      request.auth.uid,
      request.auth.token.email as string | undefined
    );

    // Resume the candidate's current session instead of creating duplicate attempts.
    const studentAssignments = await db
      .collection(`tenants/${tenantId}/examAssignments`)
      .where('studentId', '==', request.auth.uid)
      .get();
    const activeDoc = studentAssignments.docs.find(
      (docSnapshot) => docSnapshot.data().status === 'in-progress'
    );

    if (activeDoc) {
      const existingPackage = await packageFromAssignment(tenantId, activeDoc.id, activeDoc.data());
      if (existingPackage) return existingPackage;
    }

    const tenantSnapshot = await db.doc(`tenants/${tenantId}`).get();
    const tenantData = tenantSnapshot.data() ?? {};
    const usage = (tenantData['usage'] ?? {}) as Record<string, unknown>;
    const limits = (tenantData['limits'] ?? {}) as Record<string, unknown>;
    const currentMonth = new Date().toISOString().slice(0, 7);
    const recordedMonth = String(usage['attemptMonth'] ?? '');
    const usedAttempts = recordedMonth === currentMonth ? Number(usage['monthlyAttempts'] ?? 0) : 0;
    const attemptLimit = Number(limits['monthlyAttempts'] ?? Number.MAX_SAFE_INTEGER);
    if (Number.isFinite(attemptLimit) && usedAttempts >= attemptLimit) {
      throw new HttpsError(
        'resource-exhausted',
        'This CBT tenant has reached its monthly examination-attempt limit. Contact your institution administrator.'
      );
    }

    // New attempts are allowed only after an administrator grants permission
    // from Exam Control by setting the student's examStatus to "Started".
    if (String(studentDetails.examStatus ?? '') !== 'Started') {
      throw new HttpsError(
        'failed-precondition',
        'Your exam has not been enabled by an administrator. Please wait for permission from Exam Control.'
      );
    }

    const registeredSubjectIds = Array.isArray(studentDetails.registeredSubjectIds)
      ? [...new Set(studentDetails.registeredSubjectIds.map((value) => String(value).trim()).filter(Boolean))]
      : [];

    if (registeredSubjectIds.length === 0) {
      throw new HttpsError(
        'failed-precondition',
        'You have not registered any exam subjects. Register your subjects before starting an examination.'
      );
    }

    if (registeredSubjectIds.length > 11) {
      throw new HttpsError(
        'failed-precondition',
        'Your subject registration is invalid because it exceeds the maximum of 11 subjects. Contact an administrator.'
      );
    }

    const subjectRefs = registeredSubjectIds.map((subjectId) =>
      db.collection(`tenants/${tenantId}/subjects`).doc(subjectId)
    );
    const registeredSubjectSnapshots = await db.getAll(...subjectRefs);
    const subjectDocs = registeredSubjectSnapshots
      .filter((subjectDoc) => subjectDoc.exists && subjectDoc.data()?.active !== false)
      .sort((a, b) =>
        String(a.data()?.name ?? '').localeCompare(String(b.data()?.name ?? ''))
      );

    if (subjectDocs.length === 0) {
      throw new HttpsError(
        'failed-precondition',
        'None of your registered subjects are currently available.'
      );
    }

    const assignmentQuestions: AssignmentQuestion[] = [];
    const gradingKeys: Record<string, Record<string, unknown>> = {};
    const assignmentSubjects: Array<Record<string, unknown>> = [];
    let totalTimeLimit = 0;
    let windowEnd = Infinity;

    for (const subjectDoc of subjectDocs) {
      const subject = subjectDoc.data();

      if (!subject) {
        continue;
      }
      windowEnd = Math.min(windowEnd, assertExamWindow(subject));

      const allQuestions = await subjectDoc.ref.collection('exams').get();
      const approvedQuestions = allQuestions.docs.filter(doc => !doc.data().archived && (!doc.data().publicationStatus || doc.data().publicationStatus === 'approved'));
      if (!approvedQuestions.length && !allQuestions.empty) throw new HttpsError('failed-precondition', `${subject.name} has no approved questions.`);
      if (allQuestions.empty) {
        if (subject.blueprint?.enabled) throw new HttpsError('failed-precondition', `${subject.name || 'Subject'} has an enabled blueprint but no questions.`);
        continue;
      }

      const configuredQuestionLimit = Number(subject.questionLimit);
      const questionLimit = Number.isFinite(configuredQuestionLimit) && configuredQuestionLimit > 0
        ? Math.floor(configuredQuestionLimit)
        : allQuestions.size;
      const blueprint = validateBlueprint(subject.blueprint, questionLimit);
      const selected = selectQuestions(approvedQuestions, blueprint, questionLimit, values => shuffle(values));
      const subjectName = String(subject.name ?? subjectDoc.id ?? 'Subject');
      const configuredTimeLimit = Number(subject.timeLimit);
      const timeLimit = Number.isFinite(configuredTimeLimit) && configuredTimeLimit > 0
        ? Math.floor(configuredTimeLimit)
        : 30;
      totalTimeLimit += timeLimit;

      const questionIds: string[] = [];
      for (const questionDoc of selected) {
        const question = questionDoc.data();
        const metadata = questionMetadata(question);
        const prepared = publicQuestion(question, values => shuffle(values));
        gradingKeys[`${subjectDoc.id}:${questionDoc.id}`] = prepared.key;

        questionIds.push(questionDoc.id);
        assignmentQuestions.push({
          ...prepared.publicData,
          subjectId: subjectDoc.id,
          subjectName,
          questionId: questionDoc.id,
          question: String(question.question ?? ''),
          imageUrl: String(question.imageUrl ?? ''),
          imageAlt: String(question.imageAlt ?? ''),
          topic: metadata.topic,
          difficulty: metadata.difficulty,
          questionType: question.questionType || 'mcq',
          options: prepared.publicData.options,
        });
      }

      assignmentSubjects.push({
        subjectId: subjectDoc.id,
        subjectName,
        description: String(subject.description ?? ''),
        timeLimit,
        questionIds,
        blueprint,
      });
    }

    if (assignmentQuestions.length === 0) {
      throw new HttpsError(
        'failed-precondition',
        'No questions are available. Add questions to at least one active subject.'
      );
    }

    const assignmentRef = db.collection(`tenants/${tenantId}/examAssignments`).doc();
    const now = Date.now();
    const safeDurationMinutes = Math.max(totalTimeLimit, 1);
    const expiresAtMs = Math.min(windowEnd, now + safeDurationMinutes * 60_000);

    const assignmentBatch = db.batch();
    assignmentBatch.set(assignmentRef, {
      studentId: request.auth!.uid,
      studentEmail: request.auth.token.email ?? '',
      studentDetails,
      subjects: assignmentSubjects,
      questions: assignmentQuestions,
      questionCount: assignmentQuestions.length,
      durationMinutes: safeDurationMinutes,
      status: 'in-progress',
      startedAt: FieldValue.serverTimestamp(),
      startedAtMs: now,
      expiresAtMs,
      lastActivityAt: FieldValue.serverTimestamp(),
    });
    // Keep marking keys in a separate server-only document, never in the public package.
    assignmentBatch.set(db.doc(`tenants/${tenantId}/examKeys/${assignmentRef.id}`), { questions: gradingKeys });
    await assignmentBatch.commit();

    await db.collection(`tenants/${tenantId}/activityLogs`).add({
      action: 'exam_started',
      actorId: request.auth!.uid,
      actorEmail: request.auth!.token.email ?? '',
      assignmentId: assignmentRef.id,
      createdAt: FieldValue.serverTimestamp(),
    });

    return {
      assignmentId: assignmentRef.id,
      durationMinutes: safeDurationMinutes,
      expiresAtMs,
      subjects: assignmentSubjects.map(({ questionIds, ...rest }) => ({
        ...rest,
        questionCount: (questionIds as string[]).length,
      })),
      questions: assignmentQuestions,
      resumed: false,
    };
  } catch (error) {
    console.error('getExamPackage FAILED:', error);
    if (error instanceof HttpsError) throw error;
    const message = error instanceof Error ? error.message : String(error);
    throw new HttpsError('internal', `Unable to start exam: ${message}`);
  }
});


export const setStudentExamStatus = onCall({ cors: true }, async (request) => {
  if (!request.auth) {
    throw new HttpsError('unauthenticated', 'Sign in as an administrator.');
  }
  const tenant = await requirePermission(request,'exams.manage');
  const tenantId = tenant.tenantId;
  if (tenant.modules['exams'] === false) {
    throw new HttpsError('failed-precondition', 'The Exams module is not enabled for this CBT tenant.');
  }

  const status = String(request.data?.status ?? '').trim();
  const allowedStatuses = new Set(['Started', 'Ended', 'Not Started']);
  if (!allowedStatuses.has(status)) {
    throw new HttpsError('invalid-argument', 'Invalid exam access status.');
  }

  const db = admin.firestore();
  const all = request.data?.all === true;
  const studentId = String(request.data?.studentId ?? '').trim();

  if (!all && !studentId) {
    throw new HttpsError('invalid-argument', 'studentId is required.');
  }

  let updated = 0;
  const updatedAt = FieldValue.serverTimestamp();

  if (all) {
    const students = await db.collection(`tenants/${tenantId}/student`).get();
    if (!students.empty) {
      for (let offset = 0; offset < students.docs.length; offset += 400) {
        const batch = db.batch();
        const chunk = students.docs.slice(offset, offset + 400);
        chunk.forEach((studentDoc) => {
          batch.update(studentDoc.ref, {
            examStatus: status,
            examPermissionUpdatedAt: updatedAt,
          });
        });
        await batch.commit();
        updated += chunk.length;
      }
    }
  } else {
    const studentRef = db.collection(`tenants/${tenantId}/student`).doc(studentId);
    const studentSnap = await studentRef.get();
    if (!studentSnap.exists) {
      throw new HttpsError('not-found', 'Student record was not found.');
    }

    await studentRef.update({
      examStatus: status,
      examPermissionUpdatedAt: updatedAt,
    });
    updated = 1;
  }

  await db.collection(`tenants/${tenantId}/activityLogs`).add({
    action: all ? 'exam_access_bulk_updated' : 'exam_access_updated',
    actorId: request.auth.uid,
    actorEmail: request.auth.token.email ?? '',
    studentId: all ? null : studentId,
    metadata: { status, updated },
    createdAt: FieldValue.serverTimestamp(),
  });

  return { updated, status };
});

export { submitExamAttempt } from './submit-attempt';
