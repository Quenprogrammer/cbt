import * as admin from 'firebase-admin';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { onSchedule } from 'firebase-functions/v2/scheduler';
import { requirePermission } from '../tenant/permissions';
import { requireTenantUser } from '../tenant/tenant-access';
import { publicResult, resultAvailable } from './result-workflow';

export function assertExamWindow(subject: any, now = Date.now()): number {
  const schedule = subject.schedule;
  if (!schedule?.enabled) return Infinity;
  if (now < Number(schedule.startsAtMs)) throw new HttpsError('failed-precondition', `${subject.name} opens at ${new Date(schedule.startsAtMs).toISOString()}.`);
  if (now >= Number(schedule.endsAtMs) || now > Number(schedule.startsAtMs) + Number(schedule.lateEntryMinutes) * 60000) throw new HttpsError('failed-precondition', `The entry window for ${subject.name} has closed.`);
  return Number(schedule.endsAtMs);
}
export const save = onCall(async request => {
  const access = await requirePermission(request, 'exams.manage'), id = String(request.data?.subjectId || ''), input = request.data || {};
  if (!id || id.includes('/')) throw new HttpsError('invalid-argument', 'Choose a subject.');
  const startsAtMs = Date.parse(String(input.startsAt || '')), endsAtMs = Date.parse(String(input.endsAt || '')), lateEntryMinutes = Number(input.lateEntryMinutes || 0);
  if (input.enabled && (!Number.isFinite(startsAtMs) || !Number.isFinite(endsAtMs) || endsAtMs <= startsAtMs || !Number.isInteger(lateEntryMinutes) || lateEntryMinutes < 0 || lateEntryMinutes > 480)) throw new HttpsError('invalid-argument', 'Choose a valid examination window and 0–480 late-entry minutes.');
  const ref = admin.firestore().doc(`tenants/${access.tenantId}/subjects/${id}`); if (!(await ref.get()).exists) throw new HttpsError('not-found', 'Subject not found.');
  await ref.update({ schedule: input.enabled ? { enabled: true, startsAtMs, endsAtMs, lateEntryMinutes, reminders: Boolean(input.reminders) } : { enabled: false } });
  return { saved: true };
});
export const studentHub = onCall(async request => {
  const access = await requireTenantUser(request, ['student']), root = admin.firestore().doc(`tenants/${access.tenantId}`), uid = request.auth!.uid;
  const [subjects, results, notifications, appeals] = await Promise.all([root.collection('subjects').get(), root.collection('results').where('studentId', '==', uid).limit(100).get(), root.collection('studentNotifications').where('studentId', '==', uid).limit(100).get(), root.collection('appeals').where('studentId', '==', uid).limit(100).get()]);
  const profile = await root.collection('student').where('authUid', '==', uid).limit(1).get(), registered = profile.docs[0]?.data().registeredSubjectIds || [];
  return {
    subjects: subjects.docs.filter(row => registered.includes(row.id)).map(row => ({ id: row.id, name: row.data().name, schedule: row.data().schedule || { enabled: false } })),
    results: results.docs.map(row => { const data = row.data(); return access.modules['publicResults']===true&&access.modules['results']!==false&&resultAvailable(data) ? { ...publicResult(data), available: true } : { resultId: row.id, pin: data.pin, submittedAtIso: data.submittedAtIso, available: false, status: data.pendingManual ? 'Awaiting marking' : 'Awaiting release' }; }).sort((a: any, b: any) => String(b.submittedAtIso).localeCompare(a.submittedAtIso)),
    notifications: notifications.docs.map(row => ({ id: row.id, ...row.data() })).filter((row: any) => Number(row.visibleAtMs || 0) <= Date.now()).sort((a: any, b: any) => b.createdAtMs - a.createdAtMs),
    appeals: appeals.docs.map(row => ({ id: row.id, ...row.data() })),
  };
});
export const markNotificationRead = onCall(async request => {
  const access = await requireTenantUser(request, ['student']), id = String(request.data?.id || ''); if (!id || id.includes('/')) throw new HttpsError('invalid-argument', 'Invalid notification.');
  const ref = admin.firestore().doc(`tenants/${access.tenantId}/studentNotifications/${id}`), saved = await ref.get();
  if (saved.data()?.studentId !== request.auth!.uid) throw new HttpsError('permission-denied', 'Notification does not belong to you.');
  await ref.update({ read: true }); return { saved: true };
});
export async function runReminderSweep(tenantFilter?: string) {
  const db = admin.firestore(), tenants = tenantFilter ? [await db.doc(`tenants/${tenantFilter}`).get()] : (await db.collection('tenants').limit(500).get()).docs;
  let created = 0;
  for (const tenant of tenants) {
    if (!tenant.exists || tenant.data()?.accessStatus !== 'enabled' || tenant.data()?.locked) continue;
    const [subjects, students] = await Promise.all([tenant.ref.collection('subjects').get(), tenant.ref.collection('student').get()]);
    for (const subject of subjects.docs) {
      const schedule = subject.data().schedule;
      if (!schedule?.enabled || !schedule.reminders || schedule.startsAtMs <= Date.now() || schedule.startsAtMs > Date.now() + 24 * 60 * 60 * 1000) continue;
      for (const student of students.docs) {
        const data = student.data(); if (!data.authUid || !data.registeredSubjectIds?.includes(subject.id)) continue;
        const ref = tenant.ref.collection('studentNotifications').doc(`exam-${subject.id}-${schedule.startsAtMs}-${data.authUid}`);
        try { await ref.create({ studentId: data.authUid, title: 'Upcoming examination', message: `${subject.data().name} starts at ${new Date(schedule.startsAtMs).toISOString()}.`, subjectId: subject.id, startsAtMs: schedule.startsAtMs, createdAtMs: Date.now(), visibleAtMs: 0, read: false }); created++; }
        catch (error: any) { if (error.code !== 6 && error.code !== 'already-exists') throw error; }
      }
    }
  }
  return { created };
}
export const sendReminders = onCall(async request => { const access = await requirePermission(request, 'exams.manage'); return runReminderSweep(access.tenantId); });
export const scheduledReminders = onSchedule('every 15 minutes', async () => { await runReminderSweep(); });
