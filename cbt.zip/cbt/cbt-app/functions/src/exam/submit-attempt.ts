import * as admin from 'firebase-admin';
import { FieldValue } from 'firebase-admin/firestore';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { randomBytes } from 'crypto';
import { requireTenantUser } from '../tenant/tenant-access';
import { gradeResponse, normalizeResponse, summarizeAnalysis } from './question-model';
import { questionMetadata } from './question-selection';
import { publicResult } from './result-workflow';

export const submitExamAttempt = onCall({ cors: true }, async request => {
  const access = await requireTenantUser(request, ['student']), db = admin.firestore(), tenantId = access.tenantId;
  const assignmentId = String(request.data?.assignmentId || '');
  if (!assignmentId || assignmentId.includes('/')) throw new HttpsError('invalid-argument', 'Choose a valid exam assignment.');
  const ref = db.doc(`tenants/${tenantId}/examAssignments/${assignmentId}`), saved = await ref.get(), assignment = saved.data();
  if (!assignment || assignment.studentId !== request.auth!.uid) throw new HttpsError('permission-denied', 'This examination does not belong to you.');
  if (assignment.status === 'submitted') return { submitted: true, resultId: assignment.resultId, pin: assignment.resultPin };
  const keyDocument = (await db.doc(`tenants/${tenantId}/examKeys/${assignmentId}`).get()).data()?.questions || {};
  const answers = new Map<string, any>((Array.isArray(request.data?.answers) ? request.data.answers : []).map((answer: any) => [String(answer.questionId), answer]));
  const analysis: any[] = [];
  for (const subject of assignment.subjects || []) {
    for (const questionId of subject.questionIds || []) {
      const key = keyDocument[`${subject.subjectId}:${questionId}`] || (await db.doc(`tenants/${tenantId}/subjects/${subject.subjectId}/exams/${questionId}`).get()).data() || {};
      const assigned = (assignment.questions || []).find((q: any) => q.questionId === questionId && q.subjectId === subject.subjectId) || { ...key, questionId };
      const answer = answers.get(questionId), response = normalizeResponse(assigned, answer?.response ?? answer?.selectedAnswerId ?? '');
      const grade = gradeResponse(key, response), seconds = Number(answer?.timeSpentSeconds || 0);
      analysis.push({ subjectId: subject.subjectId, subjectName: subject.subjectName, questionId, question: String(key.question || ''), questionType: key.questionType || assigned.questionType || 'mcq', response, selectedAnswerId: typeof response === 'string' ? response || null : null, isCorrect: grade.isCorrect, marks: grade.marks, pendingManual: grade.pendingManual, unanswered: !grade.answered, timeSpentSeconds: Number.isFinite(seconds) ? Math.max(0, Math.min(Math.floor(seconds), 86400)) : 0, ...questionMetadata(key) });
    }
  }
  const summary = summarizeAnalysis(analysis, assignment.subjects), root = db.doc(`tenants/${tenantId}`), resultRef = root.collection('results').doc(assignmentId);
  const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789', bytes=randomBytes(8), body=Array.from(bytes,value=>alphabet[value%alphabet.length]).join('');
  const pin = `CBT-${body.slice(0,4)}-${body.slice(4)}`, nowIso = new Date().toISOString();
  return db.runTransaction(async tx => {
    const [latest, tenant, policy, pinSnapshot] = await Promise.all([tx.get(ref), tx.get(root), tx.get(root.collection('settings').doc('assessment')), tx.get(db.doc(`resultChecks/${pin}`))]);
    if (latest.data()?.status === 'submitted') return { submitted: true, resultId: latest.data()!.resultId, pin: latest.data()!.resultPin };
    if (pinSnapshot.exists) throw new HttpsError('aborted', 'Please retry submission.');
    const studentId = assignment.studentDetails?.id;
    const student = studentId ? await tx.get(root.collection('student').doc(String(studentId))) : null;
    const result = { ...summary, id: resultRef.id, tenantId, pin, assignmentId, studentId: request.auth!.uid, studentEmail: request.auth!.token.email || '', studentDetails: assignment.studentDetails || {}, className: assignment.studentDetails?.department || '', questionAnalysis: analysis, revision: 0, releaseStatus: policy.data()?.releaseMode || 'immediate', releaseAtMs: 0, submittedAt: FieldValue.serverTimestamp(), submittedAtIso: nowIso };
    tx.set(resultRef, result); tx.set(root.collection('examAttempts').doc(resultRef.id), result); tx.set(db.doc(`resultChecks/${pin}`), publicResult(result));
    tx.update(ref, { status: 'submitted', resultId: resultRef.id, resultPin: pin, submittedAt: FieldValue.serverTimestamp() }); tx.delete(root.collection('examDrafts').doc(assignmentId));
    if (student?.exists) tx.update(student.ref, { examStatus: 'Completed', lastExamSubmittedAt: FieldValue.serverTimestamp() });
    tx.set(root.collection('notifications').doc(), { type: 'exam_result', title: summary.pendingManual ? 'Manual marking required' : 'Exam attempt submitted', message: `${publicResult(result).candidate.name} submitted an examination.`, studentId: request.auth!.uid, resultId: resultRef.id, read: false, createdAt: FieldValue.serverTimestamp() });
    tx.set(root.collection('activityLogs').doc(), { action: 'exam_submitted', actorId: request.auth!.uid, entityId: resultRef.id, createdAt: FieldValue.serverTimestamp() });
    const month = nowIso.slice(0, 7);
    tx.update(root, { 'usage.monthlyAttempts': tenant.data()?.usage?.attemptMonth === month ? FieldValue.increment(1) : 1, 'usage.attemptMonth': month });
    return { submitted: true, resultId: resultRef.id, pin, submittedAtIso: nowIso };
  });
});
