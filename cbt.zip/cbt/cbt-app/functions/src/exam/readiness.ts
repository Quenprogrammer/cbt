import * as admin from 'firebase-admin';
import { onCall } from 'firebase-functions/v2/https';
import { requirePermission } from '../tenant/permissions';
import { selectQuestions, validateBlueprint } from './question-selection';

export const inspect = onCall(async request => {
  const access = await requirePermission(request, 'exams.manage'), started = Date.now(), root = admin.firestore().doc(`tenants/${access.tenantId}`);
  const [subjects, students, assignments] = await Promise.all([root.collection('subjects').get(), root.collection('student').get(), root.collection('examAssignments').where('status', '==', 'in-progress').get()]);
  const report = [];
  for (const subject of subjects.docs) {
    const data = subject.data(), bank = await subject.ref.collection('exams').get(), approved = bank.docs.filter(row => !row.data().archived && (!row.data().publicationStatus || row.data().publicationStatus === 'approved'));
    const issues: string[] = [], limit = Number(data.questionLimit || approved.length);
    if (!approved.length) issues.push('No approved questions.');
    if (approved.length < limit) issues.push(`Only ${approved.length} approved questions for a target of ${limit}.`);
    try { selectQuestions(approved, validateBlueprint(data.blueprint, limit), limit, rows => rows); } catch (error: any) { issues.push(error.message); }
    if (data.schedule?.enabled && data.schedule.endsAtMs <= Date.now()) issues.push('The examination window has ended.');
    report.push({ id: subject.id, name: data.name, active: data.active !== false, approved: approved.length, drafts: bank.size - approved.length, target: limit, issues, imageUrls: [...new Set(approved.flatMap(row => [row.data().imageUrl, ...(row.data().options || []).map((option: any) => option.imageUrl)]).filter(Boolean))] });
  }
  const subjectIds = new Set(subjects.docs.filter(row => row.data().active !== false).map(row => row.id));
  const candidateIssues = students.docs.map(row => { const data = row.data(), registered = data.registeredSubjectIds || []; return { id: row.id, name: [data.firstname, data.lastname].filter(Boolean).join(' '), issues: [...(!registered.length ? ['No registered subjects.'] : []), ...(registered.some((id: string) => !subjectIds.has(id)) ? ['A registered subject is unavailable.'] : []), ...(data.examStatus !== 'Started' ? ['Exam access has not been enabled.'] : [])] }; }).filter(row => row.issues.length);
  return { subjects: report, candidateIssues, candidates: students.size, activeSessions: assignments.size, usedAttempts: access.usage.monthlyAttempts || 0, attemptLimit: access.limits.monthlyAttempts || null, roundTripMs: Date.now() - started, checkedAtMs: Date.now() };
});
