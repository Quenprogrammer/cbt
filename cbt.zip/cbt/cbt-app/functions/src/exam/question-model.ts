import { randomBytes } from 'crypto';
import { HttpsError } from 'firebase-functions/v2/https';
import { questionMetadata } from './question-selection';

export const questionTypes = ['mcq', 'true_false', 'multiple_answer', 'fill_blank', 'matching', 'essay'] as const;
export type QuestionType = typeof questionTypes[number];
export type ResponseValue = string | string[] | { text: string } | { matches: Record<string, string> };
export const cleanText = (value: unknown, max = 10000) => String(value ?? '').trim().slice(0, max);
function required(value: unknown, name: string, max = 10000): string { const text = cleanText(value, max); if (!text) throw new HttpsError('invalid-argument', `${name} is required.`); return text; }
export function safeMediaUrl(value: unknown): string {
  const text = cleanText(value, 2500);
  if (!text || /^\/question-images\/[\w.-]+\.svg$/.test(text)) return text;
  try { const url = new URL(text); if (['https:', 'http:'].includes(url.protocol) && !url.username && !url.password) return text; } catch { /* Invalid URL. */ }
  throw new HttpsError('invalid-argument', 'Media URLs must use HTTP or HTTPS.');
}

export function normalizeQuestion(input: any): Record<string, any> {
  const type = String(input.questionType || 'mcq') as QuestionType;
  if (!questionTypes.includes(type)) throw new HttpsError('invalid-argument', 'Choose a supported question type.');
  const options = ['mcq', 'true_false', 'multiple_answer'].includes(type) && Array.isArray(input.options) ? input.options.slice(0, 6).map((option: any, index: number) => ({ id: String.fromCharCode(65 + index), text: required(option.text, `Option ${index + 1}`, 3000), imageUrl: safeMediaUrl(option.imageUrl), imageAlt: cleanText(option.imageAlt, 500) })) : [];
  if (['mcq', 'true_false', 'multiple_answer'].includes(type) && options.length < 2) throw new HttpsError('invalid-argument', 'Provide between two and six options.');
  const ids = options.map((option: any) => option.id);
  const answer = cleanText(input.correctAnswerId, 1);
  const multiple = Array.isArray(input.correctAnswerIds) ? [...new Set<string>(input.correctAnswerIds.map(String))] : [];
  if (['mcq', 'true_false'].includes(type) && !ids.includes(answer)) throw new HttpsError('invalid-argument', 'Select the correct answer.');
  if (type === 'true_false' && (options.length !== 2 || options[0].text.toLowerCase() !== 'true' || options[1].text.toLowerCase() !== 'false')) throw new HttpsError('invalid-argument', 'True/False requires options A=True and B=False.');
  if (type === 'multiple_answer' && (!multiple.length || multiple.some(id => !ids.includes(id)))) throw new HttpsError('invalid-argument', 'Select at least one correct answer.');
  const acceptedAnswers = (Array.isArray(input.acceptedAnswers) ? input.acceptedAnswers : String(input.acceptedAnswers || '').split('\n')).map((value: unknown) => cleanText(value, 1000)).filter(Boolean).slice(0, 20);
  if (type === 'fill_blank' && !acceptedAnswers.length) throw new HttpsError('invalid-argument', 'Provide at least one accepted answer.');
  const pairs = (type === 'matching' && Array.isArray(input.matchingPairs) ? input.matchingPairs : []).slice(0, 10).map((pair: any, index: number) => ({ id: `L${index + 1}`, left: required(pair.left, 'Left matching item', 1000), right: required(pair.right, 'Right matching item', 1000) }));
  if (type === 'matching' && pairs.length < 2) throw new HttpsError('invalid-argument', 'Provide at least two matching pairs.');
  const tableRows = (Array.isArray(input.tableRows) ? input.tableRows : []).slice(0, 20).map((row: any) => ({cells:(Array.isArray(row) ? row : Array.isArray(row?.cells)?row.cells:[]).slice(0, 10).map((cell: unknown) => cleanText(cell, 1000))}));
  return {
    ...questionMetadata(input), question: required(input.question, 'Question'), questionType: type,
    options: ['mcq', 'true_false', 'multiple_answer'].includes(type) ? options : [],
    correctAnswerId: ['mcq', 'true_false'].includes(type) ? answer : '', correctAnswerIds: type === 'multiple_answer' ? multiple : [],
    acceptedAnswers: type === 'fill_blank' ? acceptedAnswers : [], caseSensitive: Boolean(input.caseSensitive),
    matchingPairs: type === 'matching' ? pairs : [], rubric: cleanText(input.rubric, 10000), explanation: cleanText(input.explanation, 10000),
    passage: cleanText(input.passage, 20000), formula: cleanText(input.formula, 2000), tableRows,
    imageUrl: safeMediaUrl(input.imageUrl), imageAlt: cleanText(input.imageAlt, 500), audioUrl: safeMediaUrl(input.audioUrl), videoUrl: safeMediaUrl(input.videoUrl),
    practiceEnabled: Boolean(input.practiceEnabled),
  };
}

export function publicQuestion(question: Record<string, any>, shuffle: <T>(values: T[]) => T[]): { publicData: Record<string, any>; key: Record<string, any> } {
  const key = { ...question };
  const data: Record<string, any> = {
    question: String(question.question || ''), questionType: question.questionType || 'mcq', ...questionMetadata(question),
    options: shuffle((question.options || []).map((option: any) => ({ id: String(option.id), text: String(option.text || ''), imageUrl: String(option.imageUrl || ''), imageAlt: String(option.imageAlt || '') }))),
    imageUrl: String(question.imageUrl || ''), imageAlt: String(question.imageAlt || ''), passage: String(question.passage || ''), formula: String(question.formula || ''), tableRows: question.tableRows || [],
    audioUrl: String(question.audioUrl || ''), videoUrl: String(question.videoUrl || ''),
  };
  if (question.questionType === 'matching') {
    const choices = (question.matchingPairs || []).map((pair: any) => ({ id: 'R' + randomBytes(8).toString('hex'), text: pair.right, leftId: pair.id }));
    data.matchingItems = (question.matchingPairs || []).map((pair: any) => ({ id: pair.id, text: pair.left }));
    data.matchingChoices = shuffle(choices.map(({ id, text }: any) => ({ id, text })));
    key.matchingAnswerMap = Object.fromEntries(choices.map((choice: any) => [choice.leftId, choice.id]));
  }
  return { publicData: data, key };
}

export function normalizeResponse(question: any, value: any): ResponseValue {
  const type = question.questionType || 'mcq', ids = (question.options || []).map((option: any) => String(option.id));
  if (type === 'multiple_answer') {
    if (!Array.isArray(value)) return [];
    const chosen = [...new Set<string>(value.map(String))];
    if (chosen.some(id => !ids.includes(id))) throw new HttpsError('invalid-argument', 'An answer is not an assigned option.');
    return chosen;
  }
  if (type === 'fill_blank' || type === 'essay') return { text: String((typeof value === 'string' ? value : value?.text)??'').slice(0,type === 'essay' ? 20000 : 1000) };
  if (type === 'matching') {
    const matches: Record<string, string> = {}, choices = (question.matchingChoices || []).map((choice: any) => choice.id);
    for (const item of question.matchingItems || []) {
      const chosen = value?.matches?.[item.id];
      if (chosen && !choices.includes(chosen)) throw new HttpsError('invalid-argument', 'Invalid matching answer.');
      if (chosen) matches[item.id] = String(chosen);
    }
    return { matches };
  }
  const answer = typeof value === 'string' ? value : '';
  if (answer && !ids.includes(answer)) throw new HttpsError('invalid-argument', 'An answer is not an assigned option.');
  return answer;
}
export function hasResponse(value: any): boolean {
  return typeof value === 'string' ? Boolean(value.trim()) : Array.isArray(value) ? value.length > 0 : Boolean(value?.text?.trim() || Object.keys(value?.matches || {}).length);
}
export function gradeResponse(key: any, response: ResponseValue) {
  const answered = hasResponse(response), type = key.questionType || 'mcq';
  let correct = false;
  if (answered) {
    if (type === 'multiple_answer') correct = JSON.stringify([...(response as string[])].sort()) === JSON.stringify([...(key.correctAnswerIds || [])].sort());
    else if (type === 'fill_blank') {
      const normalize = (value: string) => { const normalized = value.normalize('NFKC').trim().replace(/\s+/g, ' '); return key.caseSensitive ? normalized : normalized.toLowerCase(); };
      correct = (key.acceptedAnswers || []).some((answer: string) => normalize(answer) === normalize((response as { text: string }).text));
    } else if (type === 'matching') correct = Object.entries(key.matchingAnswerMap || {}).every(([id, choice]) => (response as { matches: Record<string, string> }).matches[id] === choice) && Object.keys(key.matchingAnswerMap || {}).length > 0;
    else if (type !== 'essay') correct = response === String(key.correctAnswerId || '');
  }
  return { answered, isCorrect: correct, marks: correct ? 1 : 0, pendingManual: answered && type === 'essay' };
}

export function summarizeAnalysis(analysis: any[], subjects: any[]) {
  const grade = (percentage: number) => percentage >= 70 ? 'A' : percentage >= 60 ? 'B' : percentage >= 50 ? 'C' : percentage >= 45 ? 'D' : 'F';
  const summarize = (rows: any[], total: number) => {
    const score = rows.reduce((sum, row) => sum + Number(row.marks ?? (row.isCorrect ? 1 : 0)), 0), answered = rows.filter(row => !row.unanswered).length;
    const correct = rows.filter(row => row.isCorrect).length, pendingManual = rows.filter(row => row.pendingManual).length;
    const percentage = total ? Math.round(score / total * 100) : 0;
    return { score, totalQuestions: total, answered, unanswered: total - answered, incorrect: Math.max(0, answered - correct - pendingManual), pendingManual, percentage, grade: pendingManual ? 'Pending' : grade(percentage), status: pendingManual ? 'Awaiting marking' : percentage >= 50 ? 'Pass' : 'Fail', timeSpentSeconds: rows.reduce((sum, row) => sum + Number(row.timeSpentSeconds || 0), 0) };
  };
  const subjectResults = subjects.map(subject => ({ subjectId: subject.subjectId, subjectName: subject.subjectName, ...summarize(analysis.filter(row => row.subjectId === subject.subjectId), subject.questionIds?.length ?? subject.totalQuestions ?? 0) }));
  const total = subjectResults.reduce((sum, subject) => sum + subject.totalQuestions, 0);
  const totals = summarize(analysis, total);
  return { ...totals, totalTimeSpentSeconds: totals.timeSpentSeconds, subjectResults };
}
