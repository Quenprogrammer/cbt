import * as admin from 'firebase-admin';
import { createHash } from 'crypto';
import { FieldValue } from 'firebase-admin/firestore';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { requirePermission } from '../tenant/permissions';
import { importFingerprint, importQuestion, readImportFile, validateImportRows } from './question-import';
import { selectQuestions, validateBlueprint } from './question-selection';

async function subjectFor(request: any) {
  const tenant = await requirePermission(request, 'questions.write');
  if (tenant.modules['exams'] === false || tenant.modules['subjects'] === false) throw new HttpsError('permission-denied', 'Question management is disabled for this tenant.');
  const id = String(request.data?.subjectId ?? '');
  if (!id || id.includes('/') || id.length > 200) throw new HttpsError('invalid-argument', 'Choose a valid subject.');
  const subject = admin.firestore().doc(`tenants/${tenant.tenantId}/subjects/${id}`);
  if (!(await subject.get()).exists) throw new HttpsError('not-found', 'Subject not found.');
  return { subject, tenantId: tenant.tenantId };
}

export const previewImport = onCall({ cors: true, maxInstances: 10 }, async request => {
  const { subject } = await subjectFor(request);
  const rows = request.data?.rows ? validateImportRows(request.data.rows) : readImportFile(request.data?.fileName, request.data?.base64);
  const existing = await subject.collection('exams').get();
  const fingerprints = new Set(existing.docs.map(doc => String(doc.data().question ?? '').trim().toLowerCase().replace(/\s+/g, ' ')));
  return { rows: rows.map(row => ({ ...row, duplicate: row.duplicate || fingerprints.has(row.values.question.toLowerCase().replace(/\s+/g, ' ')) })) };
});

export const importQuestions = onCall({ cors: true }, async request => {
  const { subject, tenantId } = await subjectFor(request);
  const rows = validateImportRows(request.data?.rows);
  let canPublish = false;
  try { await requirePermission(request, 'questions.review'); canPublish = true; } catch { /* Authors import drafts for review. */ }
  const digest = createHash('sha256').update(JSON.stringify(rows.map(row => row.values))).digest('hex');
  if (rows.some(row => row.errors.length)) throw new HttpsError('invalid-argument', 'Correct every invalid row before importing.');
  const importId = String(request.data?.importId ?? '');
  if (!/^[\w-]{10,80}$/.test(importId)) throw new HttpsError('invalid-argument', 'A valid import ID is required.');
  const db = admin.firestore(), marker = db.doc(`tenants/${tenantId}/questionImports/${importId}`);
  return db.runTransaction(async tx => {
    const previous = await tx.get(marker);
    if (previous.exists) {
      if (previous.data()!.subjectId !== subject.id) throw new HttpsError('already-exists', 'This import ID belongs to another subject.');
      if (previous.data()!.digest !== digest) throw new HttpsError('already-exists', 'The contents of this import changed. Preview the edited rows again.');
      return previous.data()!.summary;
    }
    const existing = await tx.get(subject.collection('exams'));
    const texts = new Set(existing.docs.map(doc => String(doc.data().question ?? '').trim().toLowerCase().replace(/\s+/g, ' ')));
    let added = 0, skipped = 0;
    for (const row of rows) {
      const text = row.values.question.toLowerCase().replace(/\s+/g, ' ');
      if (texts.has(text)) { skipped++; continue; }
      texts.add(text);
      const questionId = createHash('sha256').update(subject.id + ':' + importFingerprint(row.values)).digest('hex');
      const questionRef = subject.collection('exams').doc(`import-${questionId}`), question = { ...importQuestion(row.values), version: 1, publicationStatus: canPublish ? 'approved' : 'draft', createdAt: FieldValue.serverTimestamp(), createdBy: request.auth!.uid, importId };
      tx.set(questionRef, question);
      tx.set(questionRef.collection('versions').doc('1'), { question, version: 1, action: 'imported', actorId: request.auth!.uid, createdAt: FieldValue.serverTimestamp() });
      added++;
    }
    const summary = { added, skipped };
    tx.set(marker, { subjectId: subject.id, digest, summary, createdAt: FieldValue.serverTimestamp(), actorId: request.auth!.uid });
    tx.set(db.collection(`tenants/${tenantId}/activityLogs`).doc(), { action: 'questions_imported', actorId: request.auth!.uid, entityId: subject.id, metadata: summary, createdAt: FieldValue.serverTimestamp() });
    return summary;
  });
});

export const saveBlueprint = onCall({ cors: true }, async request => {
  await requirePermission(request, 'exams.manage');
  const { subject, tenantId } = await subjectFor(request);
  const limit = Number(request.data?.questionLimit);
  if (!Number.isInteger(limit) || limit < 1 || limit > 500) throw new HttpsError('invalid-argument', 'Questions per candidate must be between 1 and 500.');
  const blueprint = validateBlueprint(request.data?.blueprint, limit);
  const pool = await subject.collection('exams').get();
  selectQuestions(pool.docs.filter(row => !row.data().archived && (!row.data().publicationStatus || row.data().publicationStatus === 'approved')), blueprint, limit, values => values);
  await subject.update({ questionLimit: limit, blueprint, updatedAt: FieldValue.serverTimestamp() });
  await admin.firestore().collection(`tenants/${tenantId}/activityLogs`).add({ action: 'exam_blueprint_updated', actorId: request.auth!.uid, entityId: subject.id, createdAt: FieldValue.serverTimestamp() });
  return { saved: true };
});
