import { HttpsError } from 'firebase-functions/v2/https';

export const difficulties = ['easy', 'medium', 'hard'] as const;
export type Difficulty = typeof difficulties[number];
export interface BlueprintRow { topic: string; difficulty: Difficulty | 'any'; count: number; }
export interface QuestionBlueprint { enabled: boolean; rows: BlueprintRow[]; }

export function questionMetadata(data: Record<string, unknown>) {
  return {
    topic: String(data.topic ?? '').trim() || 'General',
    difficulty: difficulties.includes(data.difficulty as Difficulty) ? data.difficulty as Difficulty : 'medium' as Difficulty,
    className: String(data.className ?? '').trim(),
    curriculum: String(data.curriculum ?? '').trim(),
    academicSession: String(data.academicSession ?? '').trim(),
    tags: Array.isArray(data.tags) ? data.tags.map(String).map(tag => tag.trim()).filter(Boolean).slice(0, 20) : [],
  };
}

export function validateBlueprint(input: unknown, questionLimit: number): QuestionBlueprint {
  const value = input as Partial<QuestionBlueprint> | undefined;
  if (!value?.enabled) return { enabled: false, rows: [] };
  if (!Array.isArray(value.rows) || value.rows.length === 0 || value.rows.length > 50) {
    throw new HttpsError('invalid-argument', 'Add between 1 and 50 blueprint rows.');
  }
  const rows = value.rows.map(row => ({ topic: String(row.topic ?? '').trim(), difficulty: row.difficulty, count: Number(row.count) }));
  for (const [index, row] of rows.entries()) {
    if (!row.topic || row.topic.length > 120 || !['any', ...difficulties].includes(row.difficulty) || !Number.isInteger(row.count) || row.count < 1 || row.count > 500) {
      throw new HttpsError('invalid-argument', `Blueprint row ${index + 1} needs a topic, difficulty and a count between 1 and 500.`);
    }
    if (rows.slice(0, index).some(previous => previous.topic.toLowerCase() === row.topic.toLowerCase() &&
      (previous.difficulty === row.difficulty || previous.difficulty === 'any' || row.difficulty === 'any'))) {
      throw new HttpsError('invalid-argument', `Blueprint rows for ${row.topic} overlap. Use separate difficulty levels or one Any row.`);
    }
  }
  if (rows.reduce((sum, row) => sum + row.count, 0) !== questionLimit) {
    throw new HttpsError('invalid-argument', 'Blueprint counts must add up to the questions per candidate.');
  }
  return { enabled: true, rows };
}

export function selectQuestions<T extends { data(): Record<string, unknown> }>(pool: T[], blueprint: QuestionBlueprint, limit: number, randomize: (values: T[]) => T[]): T[] {
  if (!blueprint.enabled) return randomize(pool).slice(0, Math.min(limit, pool.length));
  const selected: T[] = [];
  for (const row of blueprint.rows) {
    const matches = pool.filter(question => {
      const metadata = questionMetadata(question.data());
      return metadata.topic.toLowerCase() === row.topic.toLowerCase() && (row.difficulty === 'any' || metadata.difficulty === row.difficulty);
    });
    if (matches.length < row.count) {
      throw new HttpsError('failed-precondition', `${row.topic} (${row.difficulty}) needs ${row.count} questions, but only ${matches.length} are available. Update the blueprint or add questions.`);
    }
    selected.push(...randomize(matches).slice(0, row.count));
  }
  return randomize(selected);
}
