import { createHash } from 'crypto';
import * as XLSX from 'xlsx';
import { HttpsError } from 'firebase-functions/v2/https';

export const importColumns = ['question', 'questionType', 'optionA', 'optionB', 'optionC', 'optionD', 'optionE', 'optionF', 'correctAnswerId', 'imageUrl', 'imageAlt', 'topic', 'difficulty', 'className', 'curriculum', 'academicSession', 'tags'] as const;
export type ImportValues = Record<typeof importColumns[number], string>;
export interface ImportRow { rowNumber: number; values: ImportValues; errors: string[]; duplicate: boolean; }

export function validateImportRows(input: unknown): ImportRow[] {
  if (!Array.isArray(input) || input.length === 0 || input.length > 200) throw new HttpsError('invalid-argument', 'Import between 1 and 200 question rows at a time.');
  const seen = new Set<string>();
  return input.map((source, index) => {
    const raw = source?.values ?? source ?? {};
    const values = Object.fromEntries(importColumns.map(column => [column, String(raw[column] ?? '').trim()])) as ImportValues;
    values.questionType = values.questionType || 'mcq';
    values.difficulty = values.difficulty.toLowerCase() || 'medium';
    values.topic = values.topic || 'General';
    values.correctAnswerId = values.correctAnswerId.toUpperCase();
    if (values.questionType === 'true_false' && !values.optionA && !values.optionB) { values.optionA = 'True'; values.optionB = 'False'; }
    const errors: string[] = [];
    if (!values.question || values.question.length > 10000) errors.push('Question text is required (maximum 10,000 characters).');
    if (!['mcq', 'true_false'].includes(values.questionType)) errors.push('Question type must be mcq or true_false.');
    const options = ['A', 'B', 'C', 'D', 'E', 'F'].map(id => values[`option${id}` as keyof ImportValues]);
    const count = options.filter(Boolean).length;
    if (count < 2 || options.slice(0, count).some(value => !value)) errors.push('Provide 2–6 consecutive options starting at A.');
    if (options.some(value => value.length > 3000)) errors.push('Each option must be at most 3,000 characters.');
    if (values.questionType === 'true_false' && (count !== 2 || values.optionA.toLowerCase() !== 'true' || values.optionB.toLowerCase() !== 'false')) errors.push('True/False questions must have option A=True and B=False.');
    if (!['A', 'B', 'C', 'D', 'E', 'F'].slice(0, count).includes(values.correctAnswerId)) errors.push('Correct answer must identify a supplied option.');
    if (!['easy', 'medium', 'hard'].includes(values.difficulty)) errors.push('Difficulty must be easy, medium or hard.');
    if (values.imageUrl) {
      let valid = /^\/question-images\/[\w.-]+\.svg$/.test(values.imageUrl);
      try { const url = new URL(values.imageUrl); valid = ['http:', 'https:'].includes(url.protocol) && !url.username && !url.password; } catch { /* Local seed diagrams are allowed. */ }
      if (!valid || values.imageUrl.length > 2500) errors.push('Image URL must be an HTTP/HTTPS URL or a bundled question diagram.');
    }
    if (values.imageAlt.length > 500) errors.push('Image description must be at most 500 characters.');
    for (const key of ['topic', 'className', 'curriculum', 'academicSession'] as const) if (values[key].length > 120) errors.push(`${key} must be at most 120 characters.`);
    if (values.tags.length > 1000 || values.tags.split(',').filter(tag => tag.trim()).length > 20) errors.push('Use at most 20 comma-separated tags (maximum 1,000 characters).');
    const fingerprint = values.question.toLowerCase().replace(/\s+/g, ' ');
    const duplicate = seen.has(fingerprint);
    seen.add(fingerprint);
    return { rowNumber: index + 2, values, errors, duplicate };
  });
}

export function readImportFile(fileName: unknown, base64: unknown): ImportRow[] {
  if (typeof base64 !== 'string' || base64.length > 3_000_000 || !/\.(csv|xlsx)$/i.test(String(fileName))) throw new HttpsError('invalid-argument', 'Choose a CSV or XLSX file under 2 MB.');
  const buffer = Buffer.from(base64, 'base64');
  if (buffer.length === 0 || buffer.length > 2 * 1024 * 1024) throw new HttpsError('invalid-argument', 'Choose a nonempty file under 2 MB.');
  try {
    const workbook = XLSX.read(buffer, { type: 'buffer', raw: true, sheetRows: 202 });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const records = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: '', raw: false });
    if (!records.length || !('question' in records[0]) || !('correctAnswerId' in records[0])) throw new HttpsError('invalid-argument', 'Use the template headers, including question and correctAnswerId.');
    return validateImportRows(records);
  } catch (error) {
    if (error instanceof HttpsError) throw error;
    throw new HttpsError('invalid-argument', 'Unable to read this spreadsheet. Save it as CSV or XLSX and try again.');
  }
}

export function importQuestion(values: ImportValues) {
  return {
    question: values.question, questionType: values.questionType, correctAnswerId: values.correctAnswerId,
    options: ['A', 'B', 'C', 'D', 'E', 'F'].filter(id => values[`option${id}` as keyof ImportValues]).map(id => ({ id, text: values[`option${id}` as keyof ImportValues] })),
    imageUrl: values.imageUrl, imageAlt: values.imageUrl ? values.imageAlt : '',
    topic: values.topic, difficulty: values.difficulty, className: values.className,
    curriculum: values.curriculum, academicSession: values.academicSession,
    tags: [...new Set(values.tags.split(',').map(tag => tag.trim()).filter(Boolean))],
  };
}

export function importFingerprint(values: ImportValues): string {
  return createHash('sha256').update(values.question.toLowerCase().replace(/\s+/g, ' ')).digest('hex');
}
