import * as admin from 'firebase-admin';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { requireTenantUser } from '../tenant/tenant-access';
import { gradeResponse, normalizeResponse, publicQuestion } from './question-model';

function shuffle<T>(values: T[]): T[] { const copy = [...values]; for (let i = copy.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [copy[i], copy[j]] = [copy[j], copy[i]]; } return copy; }
async function practiceAccess(request: any) {
  const access = await requireTenantUser(request, ['student']);
  if (access.modules.exams === false || access.modules.subjects === false) throw new HttpsError('permission-denied', 'Practice is not enabled for this institution.');
  return access;
}
export const subjects = onCall(async request => {
  const access = await practiceAccess(request);
  const rows = await admin.firestore().collection(`tenants/${access.tenantId}/subjects`).get();
  const subjects = [];
  for (const row of rows.docs) {
    const pool = await row.ref.collection('exams').where('practiceEnabled', '==', true).get();
    const questions = pool.docs.filter(q => !q.data().archived && (!q.data().publicationStatus || q.data().publicationStatus === 'approved'));
    if (row.data().active !== false && questions.length) subjects.push({ id: row.id, name: row.data().name, topics: [...new Set(questions.map(q => q.data().topic || 'General'))], count: questions.length });
  }
  return { subjects };
});
export const start = onCall(async request => {
  const access = await practiceAccess(request), id = String(request.data?.subjectId || ''), limit = Number(request.data?.limit || 10), topic = String(request.data?.topic || '');
  if (!id || id.includes('/') || !Number.isInteger(limit) || limit < 1 || limit > 30) throw new HttpsError('invalid-argument', 'Choose a subject and between 1 and 30 practice questions.');
  const subject = admin.firestore().doc(`tenants/${access.tenantId}/subjects/${id}`), saved = await subject.get();
  if (!saved.exists || saved.data()!.active === false) throw new HttpsError('not-found', 'Subject unavailable.');
  const rows = await subject.collection('exams').where('practiceEnabled', '==', true).get();
  const selected = shuffle(rows.docs.filter(q => !q.data().archived && (!q.data().publicationStatus || q.data().publicationStatus === 'approved') && (!topic || (q.data().topic || 'General') === topic))).slice(0, limit);
  if (!selected.length) throw new HttpsError('failed-precondition', 'No approved practice questions match this topic.');
  const questions: any[] = [], keys: Record<string, unknown> = {};
  for (const q of selected) { const value = publicQuestion(q.data(), shuffle); questions.push({ ...value.publicData, questionId: q.id, subjectId: id, subjectName: saved.data()!.name }); keys[q.id] = value.key; }
  const session = admin.firestore().collection(`tenants/${access.tenantId}/practiceSessions`).doc();
  await session.set({ studentId: request.auth!.uid, subjectId: id, questions, keys, responses: {}, createdAtMs: Date.now() });
  return { sessionId: session.id, questions };
});
export const check = onCall(async request => {
  const access = await practiceAccess(request), id = String(request.data?.sessionId || ''), questionId = String(request.data?.questionId || '');
  if (!id || id.includes('/')) throw new HttpsError('invalid-argument', 'Invalid practice session.');
  const ref = admin.firestore().doc(`tenants/${access.tenantId}/practiceSessions/${id}`);
  return admin.firestore().runTransaction(async tx => {
    const saved = await tx.get(ref), session = saved.data();
    if (!session || session.studentId !== request.auth!.uid || Date.now() - session.createdAtMs > 24 * 60 * 60 * 1000) throw new HttpsError('permission-denied', 'Practice session expired. Start another session.');
    const question = session.questions.find((q: any) => q.questionId === questionId), key = session.keys[questionId];
    if (!question || !key) throw new HttpsError('invalid-argument', 'Question not in this practice session.');
    const response = normalizeResponse(question, request.data?.response), grade = gradeResponse(key, response);
    const feedback = { ...grade, explanation: String(key.explanation || 'No explanation has been added for this question.'), correctAnswerId: key.correctAnswerId || '', correctAnswerIds: key.correctAnswerIds || [], acceptedAnswers: key.acceptedAnswers || [], matchingPairs: key.matchingPairs || [], rubric: key.questionType === 'essay' ? key.rubric || 'Compare your answer with the teacher guidance.' : '' };
    tx.set(ref, { responses: { ...session.responses, [questionId]: { response, ...feedback } } }, { merge: true });
    return feedback;
  });
});
