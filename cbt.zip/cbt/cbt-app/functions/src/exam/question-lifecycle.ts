import { FieldValue } from 'firebase-admin/firestore';
import * as admin from 'firebase-admin';
import { randomUUID } from 'crypto';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { requirePermission } from '../tenant/permissions';
import { cleanText, normalizeQuestion } from './question-model';

function ids(data: any) { const subjectId = String(data?.subjectId || ''), questionId = String(data?.questionId || ''); if (!subjectId || subjectId.includes('/') || questionId.includes('/')) throw new HttpsError('invalid-argument', 'Invalid question reference.'); return { subjectId, questionId }; }
export const saveQuestion = onCall({ cors: true }, async request => {
  const access = await requirePermission(request, 'questions.write'), { subjectId, questionId } = ids(request.data);
  const data = normalizeQuestion(request.data?.question || {}), db = admin.firestore(), subject = db.doc(`tenants/${access.tenantId}/subjects/${subjectId}`);
  if (!(await subject.get()).exists) throw new HttpsError('not-found', 'Subject not found.');
  if (request.data?.action === 'approve') await requirePermission(request, 'questions.review');
  const ref = questionId ? subject.collection('exams').doc(questionId) : subject.collection('exams').doc();
  const version = await db.runTransaction(async tx => {
    const old = await tx.get(ref), previous = old.data() || {}, current = Number(previous.version || 0);
    if (old.exists && Number(request.data?.expectedVersion ?? 0) !== current) throw new HttpsError('aborted', 'This question changed. Reload it before saving.');
    if (old.exists && current === 0) tx.set(ref.collection('versions').doc('0'), { question: previous, version: 0, actorId: request.auth!.uid, action: 'legacy_snapshot', createdAt: FieldValue.serverTimestamp() });
    const publicationStatus = request.data?.action === 'approve' ? 'approved' : request.data?.action === 'submit' ? 'in_review' : 'draft';
    const next = { ...data, version: current + 1, publicationStatus, archived: false, createdBy: previous.createdBy || request.auth!.uid, createdAt: previous.createdAt || FieldValue.serverTimestamp(), updatedBy: request.auth!.uid, updatedAt: FieldValue.serverTimestamp(), reviewComment: '' };
    tx.set(ref, next);
    tx.set(ref.collection('versions').doc(String(current + 1)), { question: next, version: current + 1, actorId: request.auth!.uid, action: 'saved_' + publicationStatus, createdAt: FieldValue.serverTimestamp() });
    tx.set(db.collection(`tenants/${access.tenantId}/activityLogs`).doc(), { action: 'question_version_saved', actorId: request.auth!.uid, entityId: ref.id, metadata: { subjectId, version: current + 1, publicationStatus }, createdAt: FieldValue.serverTimestamp() });
    return current + 1;
  });
  return { questionId: ref.id, version };
});
export const reviewQuestion = onCall(async request => {
  const access = await requirePermission(request, 'questions.review'), { subjectId, questionId } = ids(request.data), decision = String(request.data?.decision || '');
  if (!['approved', 'rejected'].includes(decision)) throw new HttpsError('invalid-argument', 'Choose approve or reject.');
  const db = admin.firestore(), ref = db.doc(`tenants/${access.tenantId}/subjects/${subjectId}/exams/${questionId}`);
  await db.runTransaction(async tx => {
    const old = await tx.get(ref); if (!old.exists) throw new HttpsError('not-found', 'Question not found.');
    const data = old.data()!;
    if (Number(request.data?.expectedVersion) !== Number(data.version || 0)) throw new HttpsError('aborted', 'This question changed. Reload it.');
    if (data.publicationStatus !== 'in_review') throw new HttpsError('failed-precondition', 'Only submitted drafts can be reviewed.');
    if (access.role === 'staff' && data.updatedBy === request.auth!.uid) throw new HttpsError('permission-denied', 'Another reviewer must approve your own question.');
    const next = { ...data, publicationStatus: decision, reviewComment: cleanText(request.data?.comment, 3000), reviewedBy: request.auth!.uid, reviewedAt: FieldValue.serverTimestamp(), version: Number(data.version || 0) + 1 };
    tx.set(ref, next); tx.set(ref.collection('versions').doc(String(next.version)), { question: next, version: next.version, action: decision, actorId: request.auth!.uid, createdAt: FieldValue.serverTimestamp() });
  });
  return { reviewed: true };
});
export const history = onCall(async request => {
  const access = await requirePermission(request, 'questions.write'), { subjectId, questionId } = ids(request.data);
  const rows = await admin.firestore().collection(`tenants/${access.tenantId}/subjects/${subjectId}/exams/${questionId}/versions`).orderBy('version', 'desc').limit(50).get();
  return { versions: rows.docs.map(row => ({ id: row.id, ...row.data(), createdAtIso: row.data().createdAt?.toDate?.().toISOString() || '' })) };
});
export const restoreVersion = onCall(async request => {
  const access = await requirePermission(request, 'questions.write'), { subjectId, questionId } = ids(request.data), version = String(Number(request.data?.version));
  const db = admin.firestore(), ref = db.doc(`tenants/${access.tenantId}/subjects/${subjectId}/exams/${questionId}`);
  const saved = await ref.collection('versions').doc(version).get(); if (!saved.exists) throw new HttpsError('not-found', 'Version not found.');
  return saveQuestion.run({ ...request, data: { subjectId, questionId, expectedVersion: request.data?.expectedVersion, question: saved.data()!.question, action: 'draft' } } as any);
});
export const archiveQuestion = onCall(async request => {
  const access = await requirePermission(request, 'questions.write'), { subjectId, questionId } = ids(request.data);
  const ref = admin.firestore().doc(`tenants/${access.tenantId}/subjects/${subjectId}/exams/${questionId}`);
  await admin.firestore().runTransaction(async tx => {
    const saved = await tx.get(ref); if (!saved.exists) throw new HttpsError('not-found', 'Question not found.');
    const next = { ...saved.data(), archived: true, publicationStatus: 'draft', version: Number(saved.data()!.version || 0) + 1 };
    tx.set(ref, next); tx.set(ref.collection('versions').doc(String(next.version)), { question: next, version: next.version, action: 'archived', actorId: request.auth!.uid, createdAt: FieldValue.serverTimestamp() });
  });
  return { archived: true };
});
export const uploadMedia = onCall({ cors: true }, async request => {
  const access = await requirePermission(request, 'questions.write'), type = String(request.data?.contentType || '');
  const extensions: Record<string, string> = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif', 'audio/mpeg': 'mp3', 'audio/ogg': 'ogg', 'audio/wav': 'wav', 'audio/webm': 'webm', 'video/mp4': 'mp4', 'video/webm': 'webm', 'video/ogg': 'ogv' };
  const base64 = String(request.data?.base64 || '');
  if (!extensions[type] || base64.length > 7_000_000) throw new HttpsError('invalid-argument', 'Choose a supported image, audio or video file under 5 MB.');
  const data = Buffer.from(base64, 'base64'); if (!data.length || data.length >= 5 * 1024 * 1024) throw new HttpsError('invalid-argument', 'Media must be under 5 MB.');
  const bucket = admin.storage().bucket(admin.app().options.storageBucket || `${process.env.GCLOUD_PROJECT || 'cbt-sass'}.firebasestorage.app`), name = `tenants/${access.tenantId}/question-images/${randomUUID()}.${extensions[type]}`, token = randomUUID();
  await bucket.file(name).save(data, { contentType: type, metadata: { metadata: { firebaseStorageDownloadTokens: token } } });
  const host = process.env.FIREBASE_STORAGE_EMULATOR_HOST ? `http://${process.env.FIREBASE_STORAGE_EMULATOR_HOST.replace(/^https?:\/\//, '')}` : 'https://firebasestorage.googleapis.com';
  return { url: `${host}/v0/b/${bucket.name}/o/${encodeURIComponent(name)}?alt=media&token=${token}` };
});
