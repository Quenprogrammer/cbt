import { FieldValue } from 'firebase-admin/firestore';
import * as admin from 'firebase-admin';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { requirePermission } from '../tenant/permissions';
import { requireTenantUser } from '../tenant/tenant-access';
import { cleanText, summarizeAnalysis } from './question-model';

export function publicResult(result: any) {
  const student = result.studentDetails || {};
  return {
    pin: result.pin, tenantId: result.tenantId, resultId: result.id,
    candidate: { name: [student.firstname, student.lastname].filter(Boolean).join(' ') || result.studentEmail || 'Candidate', admissionNumber: student.admissionNumber || '', department: student.department || '' },
    subjectResults: result.subjectResults || [], score: result.score, totalQuestions: result.totalQuestions, answered: result.answered, unanswered: result.unanswered, incorrect: result.incorrect,
    percentage: result.percentage, grade: result.grade, status: result.status, submittedAtIso: result.submittedAtIso,
    releaseStatus: result.releaseStatus || 'immediate', releaseAtMs: Number(result.releaseAtMs || 0), pendingManual: Number(result.pendingManual || 0),
  };
}
export function resultAvailable(result: any, now = Date.now()): boolean { return !result.pendingManual && result.status !== 'Awaiting marking' && result.releaseStatus !== 'withheld' && Number(result.releaseAtMs || 0) <= now; }
export const checkResult = onCall({ cors: true, maxInstances: 10 }, async request => {
  const pin = cleanText(request.data?.pin, 30).toUpperCase(); if (!/^CBT-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(pin)) return { result: null, message: 'Enter a valid result PIN.' };
  const saved = await admin.firestore().doc(`resultChecks/${pin}`).get(); if (!saved.exists) return { result: null, message: 'No result was found for this PIN.' };
  const result = saved.data()!, tenant = (await admin.firestore().doc(`tenants/${result.tenantId}`).get()).data();
  if (!tenant || tenant.locked || tenant.accessStatus !== 'enabled' || ['suspended', 'cancelled', 'deleted'].includes(tenant.status) || tenant.modules?.publicResults !== true) return { result: null, message: 'Result checking is unavailable for this institution.' };
  if (!resultAvailable(result)) return { result: null, message: result.pendingManual ? 'This examination is awaiting manual marking.' : 'This result has not been released yet.' };
  return { result, message: '' };
});
export const desk = onCall(async request => {
  const access = await requirePermission(request, 'results.manage'), db = admin.firestore(), root = db.doc(`tenants/${access.tenantId}`);
  const [results, appeals, settings] = await Promise.all([root.collection('results').orderBy('submittedAtIso', 'desc').limit(100).get(), root.collection('appeals').limit(100).get(), root.collection('settings').doc('assessment').get()]);
  return { results: results.docs.map(row => { const data = row.data(); return { id: row.id, ...publicResult(data), studentId: data.studentId, pendingManual: data.pendingManual || 0, revision: data.revision || 0 }; }), appeals: appeals.docs.map(row => ({ id: row.id, ...row.data() })), policy: settings.data() || {} };
});
export const details = onCall(async request => {
  const access = await requirePermission(request, 'results.manage'), id = cleanText(request.data?.resultId, 200);
  if (!id || id.includes('/')) throw new HttpsError('invalid-argument', 'Choose a result.');
  const result = (await admin.firestore().doc(`tenants/${access.tenantId}/results/${id}`).get()).data(); if (!result) throw new HttpsError('not-found', 'Result not found.');
  const keys = (await admin.firestore().doc(`tenants/${access.tenantId}/examKeys/${result.assignmentId}`).get()).data()?.questions || {};
  return { ...result, questionAnalysis: (result.questionAnalysis || []).map((row: any) => ({ ...row, rubric: keys[`${row.subjectId}:${row.questionId}`]?.rubric || '' })) };
});
export const markEssay = onCall(async request => {
  const access = await requirePermission(request, 'results.manage'), data = request.data || {}, id = cleanText(data.resultId, 200), marks = Number(data.marks);
  if (!id || id.includes('/') || !Number.isFinite(marks) || marks < 0 || marks > 1) throw new HttpsError('invalid-argument', 'Essay marks must be between 0 and 1.');
  const db = admin.firestore(), ref = db.doc(`tenants/${access.tenantId}/results/${id}`);
  return db.runTransaction(async tx => {
    const saved = await tx.get(ref); if (!saved.exists) throw new HttpsError('not-found', 'Result not found.');
    const result = saved.data()!;
    if (Number(data.expectedRevision) !== Number(result.revision || 0)) throw new HttpsError('aborted', 'Marking changed. Reload the result.');
    const analysis = (result.questionAnalysis || []).map((row: any) => ({ ...row }));
    const row = analysis.find((value: any) => value.subjectId === data.subjectId && value.questionId === data.questionId);
    if (!row || row.questionType !== 'essay' || row.unanswered) throw new HttpsError('invalid-argument', 'Choose an answered essay question.');
    Object.assign(row, { marks, isCorrect: marks === 1, pendingManual: false, markingFeedback: cleanText(data.feedback, 4000), markedBy: request.auth!.uid });
    const next = { ...result, ...summarizeAnalysis(analysis, result.subjectResults), questionAnalysis: analysis, revision: Number(result.revision || 0) + 1 };
    tx.set(ref, next); tx.set(db.doc(`tenants/${access.tenantId}/examAttempts/${id}`), next); tx.set(db.doc(`resultChecks/${result.pin}`), publicResult(next));
    tx.set(db.collection(`tenants/${access.tenantId}/activityLogs`).doc(), { action: 'essay_marked', actorId: request.auth!.uid, entityId: id, metadata: { subjectId: data.subjectId, questionId: data.questionId, marks }, createdAt: FieldValue.serverTimestamp() });
    return { marked: true, pendingManual: next.pendingManual, revision: next.revision };
  });
});
export const release = onCall(async request => {
  const access = await requirePermission(request, 'results.manage'), id = cleanText(request.data?.resultId, 200), mode = String(request.data?.mode || '');
  const at = mode === 'scheduled' ? Date.parse(String(request.data?.releaseAt || '')) : 0;
  if (!id || id.includes('/') || !['immediate', 'withheld', 'scheduled'].includes(mode) || mode === 'scheduled' && (!Number.isFinite(at) || at <= Date.now())) throw new HttpsError('invalid-argument', 'Choose a valid release mode and future release time.');
  const db = admin.firestore(), ref = db.doc(`tenants/${access.tenantId}/results/${id}`);
  await db.runTransaction(async tx => {
    const saved = await tx.get(ref); if (!saved.exists) throw new HttpsError('not-found', 'Result not found.');
    const result = { ...saved.data(), releaseStatus: mode, releaseAtMs: at } as any;
    if (mode !== 'withheld' && result.pendingManual) throw new HttpsError('failed-precondition', 'Finish manual marking before releasing this result.');
    tx.update(ref, { releaseStatus: mode, releaseAtMs: at }); tx.set(db.doc(`tenants/${access.tenantId}/examAttempts/${id}`), { releaseStatus: mode, releaseAtMs: at },{merge:true}); tx.set(db.doc(`resultChecks/${result.pin}`), publicResult(result));
    if (mode !== 'withheld') tx.set(db.collection(`tenants/${access.tenantId}/studentNotifications`).doc(), { studentId: result.studentId, title: 'Examination result available', message: 'Your result is available in the result checker.', visibleAtMs: at, createdAtMs: Date.now(), read: false });
  });
  return { saved: true };
});
export const savePolicy = onCall(async request => {
  const access = await requirePermission(request, 'results.manage'), mode = String(request.data?.releaseMode || '');
  if (!['immediate', 'withheld'].includes(mode)) throw new HttpsError('invalid-argument', 'Choose immediate release or administrator approval.');
  await admin.firestore().doc(`tenants/${access.tenantId}/settings/assessment`).set({ releaseMode: mode }, { merge: true }); return { saved: true };
});
export const appeal = onCall(async request => {
  const access = await requireTenantUser(request, ['student']), id = cleanText(request.data?.resultId, 200), reason = cleanText(request.data?.reason, 4000);
  if (!id || id.includes('/') || reason.length < 10) throw new HttpsError('invalid-argument', 'Explain the appeal in at least 10 characters.');
  const root = admin.firestore().doc(`tenants/${access.tenantId}`), result = (await root.collection('results').doc(id).get()).data();
  if (!result || result.studentId !== request.auth!.uid || !resultAvailable(result)) throw new HttpsError('permission-denied', 'Only your released results can be appealed.');
  const ref = root.collection('appeals').doc(`${id}_${request.auth!.uid}`);
  try { await ref.create({ resultId: id, studentId: request.auth!.uid, candidate: publicResult(result).candidate.name, reason, status: 'open', createdAtMs: Date.now(), response: '' }); }
  catch (error: any) { if (error.code === 6 || error.code === 'already-exists') throw new HttpsError('already-exists', 'An appeal already exists for this result.'); throw error; }
  return { created: true };
});
export const resolveAppeal = onCall(async request => {
  const access = await requirePermission(request, 'results.manage'), id = cleanText(request.data?.appealId, 300), response = cleanText(request.data?.response, 4000);
  if (!id || id.includes('/') || !response) throw new HttpsError('invalid-argument', 'Write a response to the appeal.');
  const db = admin.firestore(), ref = db.doc(`tenants/${access.tenantId}/appeals/${id}`), saved = await ref.get(); if (!saved.exists) throw new HttpsError('not-found', 'Appeal not found.');
  await ref.update({ response, status: 'resolved', resolvedAtMs: Date.now(), resolvedBy: request.auth!.uid });
  await db.collection(`tenants/${access.tenantId}/studentNotifications`).add({ studentId: saved.data()!.studentId, title: 'Appeal reviewed', message: response, createdAtMs: Date.now(), visibleAtMs: 0, read: false });
  return { saved: true };
});
