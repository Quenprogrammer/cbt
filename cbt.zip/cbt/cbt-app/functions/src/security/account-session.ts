import * as admin from 'firebase-admin';
import { HttpsError } from 'firebase-functions/v2/https';

export function sessionId(auth: any): string { return `${auth.uid}_${auth.token.auth_time || 0}`; }
export async function accountSessionState(auth: any) {
  if (!auth) throw new HttpsError('unauthenticated', 'Sign in is required.');
  const db = admin.firestore(), security = (await db.doc(`accountSecurity/${auth.uid}`).get()).data() || {};
  const revoked = Number(security.revokedAfter || 0) >= Number(auth.token.auth_time || Number.MAX_SAFE_INTEGER);
  const session = security.enrolled ? (await db.doc(`secondFactorSessions/${sessionId(auth)}`).get()).data() : null;
  return { enrolled: Boolean(security.enrolled), revoked, verified: !security.enrolled || Boolean(session && session.uid === auth.uid && Number(session.expiresAtMs) > Date.now()), security };
}
export async function assertAccountSession(auth: any): Promise<void> {
  const state = await accountSessionState(auth);
  if (state.revoked) throw new HttpsError('unauthenticated', 'This session was revoked. Sign in again.');
  if (!state.verified) throw new HttpsError('permission-denied', 'SECOND_FACTOR_REQUIRED');
}
