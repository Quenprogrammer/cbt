import { FieldValue, Timestamp } from 'firebase-admin/firestore';
import * as admin from 'firebase-admin';
import { createHash, createHmac, randomBytes } from 'crypto';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { accountSessionState, assertAccountSession, sessionId } from './account-session';

const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
export function base32(buffer: Buffer): string { let bits = 0, value = 0, out = ''; for (const byte of buffer) { value = (value << 8) | byte; bits += 8; while (bits >= 5) { out += alphabet[(value >>> (bits - 5)) & 31]; bits -= 5; } } if (bits) out += alphabet[(value << (5 - bits)) & 31]; return out; }
export function totp(secret: string, step = Math.floor(Date.now() / 30000)): string {
  let bits = 0, value = 0; const bytes: number[] = [];
  for (const char of secret) { value = (value << 5) | alphabet.indexOf(char); bits += 5; if (bits >= 8) { bytes.push((value >>> (bits - 8)) & 255); bits -= 8; } }
  const counter = Buffer.alloc(8); counter.writeBigUInt64BE(BigInt(step));
  const digest = createHmac('sha1', Buffer.from(bytes)).update(counter).digest(), offset = digest[19] & 15;
  return String((digest.readUInt32BE(offset) & 0x7fffffff) % 1000000).padStart(6, '0');
}
const hash = (value: string) => createHash('sha256').update(value).digest('hex');
function signedIn(request: any) { if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in is required.'); return request.auth; }
async function verifyCode(auth: any, code: string, enrollment: boolean, recoveryCodes: string[] = []) {
  const db = admin.firestore(), ref = db.doc(`accountSecurity/${auth.uid}`);
  return db.runTransaction(async tx => {
    const state = (await tx.get(ref)).data() || {}, now = Date.now();
    if (enrollment && state.enrolled) throw new HttpsError('failed-precondition','Two-factor authentication is already enabled.');
    if (Number(state.lockedUntil || 0) > now) throw new HttpsError('resource-exhausted', 'Too many attempts. Wait a minute before trying again.');
    const secret = enrollment ? state.pendingSecret : state.secret;
    if (!secret || enrollment && Number(state.pendingExpiresAtMs) < now) throw new HttpsError('failed-precondition', 'Start authenticator enrollment again.');
    const step = Math.floor(now / 30000), matched = [step - 1, step, step + 1].find(value => totp(secret, value) === code && value > Number(state.lastUsedStep || 0));
    const recovery = !enrollment && (state.recoveryHashes || []).includes(hash(code));
    if (matched === undefined && !recovery) {
      const failed = Number(state.failedAttempts || 0) + 1;
      tx.set(ref, { failedAttempts: failed >= 5 ? 0 : failed, lockedUntil: failed >= 5 ? now + 60000 : 0 }, { merge: true });
      return false;
    }
    const updates: Record<string, unknown> = { failedAttempts: 0, lockedUntil: 0 };
    if (matched !== undefined) updates.lastUsedStep = matched;
    if (recovery) updates.recoveryHashes = state.recoveryHashes.filter((value: string) => value !== hash(code));
    if (enrollment) Object.assign(updates,{secret,enrolled:true,recoveryHashes:recoveryCodes.map(hash),pendingSecret:FieldValue.delete(),pendingExpiresAtMs:FieldValue.delete()});
    tx.set(ref, updates, { merge: true });
    tx.set(db.doc(`secondFactorSessions/${sessionId(auth)}`), { uid: auth.uid, expiresAtMs: now + 8 * 60 * 60 * 1000, expiresAt: Timestamp.fromMillis(now + 8 * 60 * 60 * 1000) });
    return true;
  });
}
export const state = onCall(async request => { const auth = signedIn(request), result = await accountSessionState(auth); return { enrolled: result.enrolled, verified: result.verified, revoked: result.revoked, recoveryCodesRemaining: result.security.recoveryHashes?.length || 0 }; });
export const beginEnrollment = onCall(async request => {
  const auth = signedIn(request); await assertAccountSession(auth);
  if (!['admin', 'staff'].includes(String(auth.token.role))) throw new HttpsError('permission-denied', 'Administrator or staff access is required.');
  if (Date.now() / 1000 - Number(auth.token.auth_time || 0) > 600) throw new HttpsError('failed-precondition', 'Sign in again before enabling two-factor authentication.');
  const ref = admin.firestore().doc(`accountSecurity/${auth.uid}`), existing = (await ref.get()).data();
  if (existing?.enrolled) throw new HttpsError('failed-precondition', 'Two-factor authentication is already enabled.');
  const secret = base32(randomBytes(20));
  await ref.set({ pendingSecret: secret, pendingExpiresAtMs: Date.now() + 600000 }, { merge: true });
  return { secret, uri: `otpauth://totp/CBT:${encodeURIComponent(String(auth.token.email || auth.uid))}?secret=${secret}&issuer=CBT&algorithm=SHA1&digits=6&period=30` };
});
export const finishEnrollment = onCall(async request => {
  const auth = signedIn(request), code = String(request.data?.code || '').replace(/[\s-]/g, '');
  await assertAccountSession(auth);
  const codes = Array.from({ length: 8 }, () => randomBytes(8).toString('hex'));
  if (!await verifyCode(auth, code, true,codes)) throw new HttpsError('invalid-argument', 'The authenticator code is incorrect or has already been used.');
  return { enabled: true, recoveryCodes: codes };
});
export const verify = onCall(async request => {
  const auth = signedIn(request), security = await accountSessionState(auth);
  if (security.revoked) throw new HttpsError('unauthenticated', 'Sign in again.');
  if (!security.enrolled) return { verified: true };
  if (!await verifyCode(auth, String(request.data?.code || '').replace(/[\s-]/g, ''), false)) throw new HttpsError('invalid-argument', 'The code is incorrect, expired or already used.');
  return { verified: true };
});
export const disable = onCall(async request => {
  const auth = signedIn(request); await assertAccountSession(auth);
  if (!await verifyCode(auth, String(request.data?.code || '').replace(/[\s-]/g, ''), false)) throw new HttpsError('invalid-argument', 'Enter a fresh authenticator code or unused recovery code.');
  await admin.firestore().doc(`accountSecurity/${auth.uid}`).set({ enrolled: false, secret: FieldValue.delete(), recoveryHashes: [] }, { merge: true });
  return { disabled: true };
});
export const revokeSessions = onCall(async request => {
  const auth = signedIn(request); await assertAccountSession(auth);
  await admin.firestore().doc(`accountSecurity/${auth.uid}`).set({ revokedAfter: Math.floor(Date.now() / 1000) }, { merge: true });
  await admin.auth().revokeRefreshTokens(auth.uid);
  return { revoked: true };
});
