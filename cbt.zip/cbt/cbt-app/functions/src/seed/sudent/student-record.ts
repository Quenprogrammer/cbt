export interface Student {
    firstname: string;
    lastname: string;
    admissionNumber: string;
    department: string;
    email: string;
    gender: string;
    dateOfBirth: string;
    examStatus: string; // 'Not Started', 'Started', 'Ended'
}

// Define the Student interface
/*export interface Student {
    id: number;             // Unique ID for the student
    fullName: string;       // Full name of the student
    age: number;            // Age of the student
    gender: string;         // Gender (e.g., "Male", "Female", "Other")
    grade: string;          // Current grade or class
    email: string;          // Contact email
    phoneNumber: string;    // Contact phone number
    courses: string[];      // List of enrolled courses
    isActive: boolean;      // Whether the student is currently active
    level: string;          // Academic level or classification (e.g., Level 1, Level 2)
}*/

// Array of students
export const students: Student[] = [




    {

        firstname: 'John',
        lastname: 'Doe',
        admissionNumber: 'ADM1001',
        department: 'JSS1',
        email: 'john.doe@example.com',
        gender: 'Male',
        dateOfBirth: '2006-05-12',
        examStatus: 'Not Started',
    },
    {
        firstname: 'Jane',
        lastname: 'Smith',
        admissionNumber: 'ADM1002',
        department: 'JSS2',
        email: 'jane.smith@example.com',
        gender: 'Female',
        dateOfBirth: '2005-07-08',
        examStatus: 'Not Started',
    },
    {

        firstname: 'Ahmed',
        lastname: 'Ali',
        admissionNumber: 'ADM1003',
        department: 'JSS3',
        email: 'ahmed.ali@example.com',
        gender: 'Male',
        dateOfBirth: '2004-09-15',
        examStatus: 'Not Started',
    },
    {
        firstname: 'Muhammadu',
        lastname: 'Buhari',
        admissionNumber: '001',
        department: 'JSS3',
        email: 'muhammadu.buhari@example.com',
        gender: 'Male',
        dateOfBirth: '2004-09-15',
        examStatus: 'Not Started',
    },
    {

        firstname: 'Khaleel',
        lastname: 'Musa',
        admissionNumber: '002',
        department: 'JSS3',
        email: 'khaleel.musa@example.com',
        gender: 'Male',
        dateOfBirth: '2004-09-15',
        examStatus: 'Not Started',
    },
    {
        firstname: 'Aisha',
        lastname: 'Yusuf',
        admissionNumber: 'ADM1004',
        department: 'JSS1',
        email: 'aisha.yusuf@example.com',
        gender: 'Female',
        dateOfBirth: '2006-03-22',
        examStatus: 'Not Started',
    },
    {
        firstname: 'Chinedu',
        lastname: 'Okoro',
        admissionNumber: 'ADM1005',
        department: 'JSS2',
        email: 'chinedu.okoro@example.com',
        gender: 'Male',
        dateOfBirth: '2005-11-10',
        examStatus: 'Not Started',
    },
    {
        firstname: 'Fatima',
        lastname: 'Ibrahim',
        admissionNumber: 'ADM1006',
        department: 'JSS3',
        email: 'fatima.ibrahim@example.com',
        gender: 'Female',
        dateOfBirth: '2004-08-17',
        examStatus: 'Not Started',
    },
    {
        firstname: 'Emeka',
        lastname: 'Nwankwo',
        admissionNumber: 'ADM1007',
        department: 'JSS1',
        email: 'emeka.nwankwo@example.com',
        gender: 'Male',
        dateOfBirth: '2006-02-14',
        examStatus: 'Not Started',
    },
    {
        firstname: 'Zainab',
        lastname: 'Abdullahi',
        admissionNumber: 'ADM1008',
        department: 'JSS2',
        email: 'zainab.abdullahi@example.com',
        gender: 'Female',
        dateOfBirth: '2005-06-19',
        examStatus: 'Not Started',
    },
    {
        firstname: 'Oluwatobi',
        lastname: 'Adeyemi',
        admissionNumber: 'ADM1009',
        department: 'JSS3',
        email: 'oluwatobi.adeyemi@example.com',
        gender: 'Male',
        dateOfBirth: '2004-12-25',
        examStatus: 'Not Started',
    },
    {
        firstname: 'Halima',
        lastname: 'Sani',
        admissionNumber: 'ADM1010',
        department: 'JSS1',
        email: 'halima.sani@example.com',
        gender: 'Female',
        dateOfBirth: '2006-04-30',
        examStatus: 'Not Started',
    },
    {
        firstname: 'Samuel',
        lastname: 'Johnson',
        admissionNumber: 'ADM1011',
        department: 'JSS2',
        email: 'samuel.johnson@example.com',
        gender: 'Male',
        dateOfBirth: '2005-10-05',
        examStatus: 'Not Started',
    },
    {
        firstname: 'Amina',
        lastname: 'Mohammed',
        admissionNumber: 'ADM1012',
        department: 'JSS3',
        email: 'amina.mohammed@example.com',
        gender: 'Female',
        dateOfBirth: '2004-07-20',
        examStatus: 'Not Started',
    },
    {
        firstname: 'Victor',
        lastname: 'Okonkwo',
        admissionNumber: 'ADM1013',
        department: 'JSS1',
        email: 'victor.okonkwo@example.com',
        gender: 'Male',
        dateOfBirth: '2006-01-18',
        examStatus: 'Not Started',
    },
    {
        firstname: 'Grace',
        lastname: 'Eze',
        admissionNumber: 'ADM1014',
        department: 'JSS2',
        email: 'grace.eze@example.com',
        gender: 'Female',
        dateOfBirth: '2005-09-12',
        examStatus: 'Not Started',
    },
    {
        firstname: 'Ibrahim',
        lastname: 'Suleiman',
        admissionNumber: 'ADM1015',
        department: 'JSS3',
        email: 'ibrahim.suleiman@example.com',
        gender: 'Male',
        dateOfBirth: '2004-11-28',
        examStatus: 'Not Started',
    },
    {
        firstname: 'Patience',
        lastname: 'Okoro',
        admissionNumber: 'ADM1016',
        department: 'JSS1',
        email: 'patience.okoro@example.com',
        gender: 'Female',
        dateOfBirth: '2006-08-15',
        examStatus: 'Not Started',
    },
    {
        firstname: 'Daniel',
        lastname: 'Adeleke',
        admissionNumber: 'ADM1017',
        department: 'JSS2',
        email: 'daniel.adeleke@example.com',
        gender: 'Male',
        dateOfBirth: '2005-03-25',
        examStatus: 'Not Started',
    },
    {
        firstname: 'Maryam',
        lastname: 'Yakubu',
        admissionNumber: 'ADM1018',
        department: 'JSS3',
        email: 'maryam.yakubu@example.com',
        gender: 'Female',
        dateOfBirth: '2004-06-10',
        examStatus: 'Not Started',
    },


];


console.log(students);
/*

{ id: 2, fullName: "Jane Smith", age: 17, gender: "Female", grade: "11th", email: "jane.smith@example.com", phoneNumber: "08023456789", courses: ["English", "Biology"], isActive: true, level: "Level 1" },
{ id: 3, fullName: "Michael Brown", age: 19, gender: "Male", grade: "12th", email: "michael.brown@example.com", phoneNumber: "08034567890", courses: ["Chemistry", "History"], isActive: true, level: "Level 1" },
{ id: 4, fullName: "Emily Davis", age: 16, gender: "Female", grade: "10th", email: "emily.davis@example.com", phoneNumber: "08045678901", courses: ["Economics", "Art"], isActive: true, level: "Level 1" },
{ id: 5, fullName: "Liam Wilson", age: 20, gender: "Male", grade: "College Freshman", email: "liam.wilson@example.com", phoneNumber: "08056789012", courses: ["Programming", "Statistics"], isActive: true, level: "Level 2" },
{ id: 6, fullName: "Sophia Martinez", age: 15, gender: "Female", grade: "9th", email: "sophia.martinez@example.com", phoneNumber: "08067890123", courses: ["Geography", "Sociology"], isActive: true, level: "Level 1" },
{ id: 7, fullName: "Ethan Garcia", age: 17, gender: "Male", grade: "11th", email: "ethan.garcia@example.com", phoneNumber: "08078901234", courses: ["Political Science", "Philosophy"], isActive: true, level: "Level 1" },
{ id: 8, fullName: "Isabella Hernandez", age: 18, gender: "Female", grade: "12th", email: "isabella.hernandez@example.com", phoneNumber: "08089012345", courses: ["Computer Science", "Psychology"], isActive: true, level: "Level 1" },
{ id: 9, fullName: "Mason Lee", age: 16, gender: "Male", grade: "10th", email: "mason.lee@example.com", phoneNumber: "08090123456", courses: ["Biology", "Chemistry"], isActive: true, level: "Level 1" },
{ id: 10, fullName: "Olivia Clark", age: 14, gender: "Female", grade: "8th", email: "olivia.clark@example.com", phoneNumber: "08101234567", courses: ["English", "Art"], isActive: true, level: "Level 0" },
{ id: 11, fullName: "Noah Adams", age: 19, gender: "Male", grade: "College Sophomore", email: "noah.adams@example.com", phoneNumber: "08112345678", courses: ["Physics", "Mathematics"], isActive: true, level: "Level 2" },
{ id: 12, fullName: "Emma Wright", age: 15, gender: "Female", grade: "9th", email: "emma.wright@example.com", phoneNumber: "08123456789", courses: ["History", "Sociology"], isActive: true, level: "Level 1" },
{ id: 13, fullName: "Alexander Scott", age: 17, gender: "Male", grade: "11th", email: "alexander.scott@example.com", phoneNumber: "08134567890", courses: ["Programming", "Statistics"], isActive: true, level: "Level 1" },
{ id: 14, fullName: "Ava Rivera", age: 16, gender: "Female", grade: "10th", email: "ava.rivera@example.com", phoneNumber: "08145678901", courses: ["Economics", "Philosophy"], isActive: true, level: "Level 1" },
{ id: 15, fullName: "William Walker", age: 18, gender: "Male", grade: "12th", email: "william.walker@example.com", phoneNumber: "08156789012", courses: ["Computer Science", "Geography"], isActive: true, level: "Level 1" }*/
