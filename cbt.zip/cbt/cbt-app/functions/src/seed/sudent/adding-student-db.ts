
import {ad as admin} from "../firebase";
import {students} from "./student-record";

export  async function AddingStudentDb() {

    const studentList = students;

    for(let i = 0; i < studentList.length; i++){
        console.log(studentList[i]);

        await admin.firestore().collection('student').add({...studentList[i]});

    }
}