import {ad as admin}from '../firebase';
interface User {
    email: string;
    password: string;
    imageUrl?: string;
    role?: string;
}

// List of users
const users: User[] = [
    { email: 'user1@example.com', password: 'password123', imageUrl: 'https://example.com/user1.jpg', role: 'admin' },
    { email: 'user2@example.com', password: 'password123', imageUrl: 'https://example.com/user2.jpg', role: 'student' },
    { email: 'user3@example.com', password: 'password123', imageUrl: 'https://example.com/user3.jpg', role: 'student' },
    { email: 'user4@example.com', password: 'password123', imageUrl: 'https://example.com/user4.jpg', role: 'student' },
    { email: 'user5@example.com', password: 'password123', imageUrl: 'https://example.com/user5.jpg', role: 'student' },
    { email: 'muhammad@example.com', password: '123456', imageUrl: 'https://example.com/muhammad.jpg', role: 'student' },
    { email: 'khaleel@example.com', password: '123456', imageUrl: 'https://example.com/khaleel.jpg', role: 'student' },
    // Add more users as needed
];

// Function to assign custom claims
async function assignCustomClaims(uid: string, role: string) {
    try {
        // Set custom user claims
        await admin.auth().setCustomUserClaims(uid, { role });
        console.log(`Custom claims for user ${uid} set to: ${role}`);
    } catch (error) {
        console.error(`Error setting custom claims for ${uid}:`, error);
    }
}

// Function to create users
export async function createUsersWithClaims() {
    for (const user of users) {
        try {
            // Create user in Firebase Authentication
            const createdUser = await admin.auth().createUser({
                email: user.email,
                password: user.password,
            });

            console.log(`User ${user.email} created successfully with UID: ${createdUser.uid}`);

            // Update user photo URL if provided
            if (user.imageUrl) {
                await admin.auth().updateUser(createdUser.uid, { photoURL: user.imageUrl });
                console.log(`Photo URL for ${user.email} updated.`);
            }

            // Assign custom claims if a role is provided. Also persist the role
            // in Firestore so security rules have a stable fallback during token refresh.
            if (user.role) {
                await assignCustomClaims(createdUser.uid, user.role);
                await admin.firestore().collection('users').doc(createdUser.uid).set({
                    email: user.email,
                    role: user.role,
                    createdAt: admin.firestore.FieldValue.serverTimestamp(),
                }, { merge: true });
            }

            if (user.role === 'student') {
                const studentEmailMap: Record<string, string> = {
                    'user2@example.com': 'john.doe@example.com',
                    'user3@example.com': 'jane.smith@example.com',
                    'user4@example.com': 'ahmed.ali@example.com',
                    'user5@example.com': 'aisha.yusuf@example.com',
                    'muhammad@example.com': 'muhammadu.buhari@example.com',
                    'khaleel@example.com': 'khaleel.musa@example.com',
                };
                const studentEmail = studentEmailMap[user.email] || user.email;
                const matches = await admin.firestore().collection('student').where('email', '==', studentEmail).limit(1).get();
                if (!matches.empty) {
                    await matches.docs[0].ref.update({ authUid: createdUser.uid, loginEmail: user.email });
                    console.log(`Linked ${user.email} to student ${matches.docs[0].id}`);
                }
            }



        } catch (error) {
            console.error(`Error creating user ${user.email}:`, error);
        }
    }
}

// Call the function to create users
