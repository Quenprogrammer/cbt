import {ad as admin} from "../firebase";
import staffList from "./staff-record";


export  async function AddingStaffToDb() {

    const staffLists = staffList;

    for(let i = 0; i < staffLists.length; i++){
        console.log(staffLists[i]);

        await admin.firestore().collection('staffs').add({...staffLists[i]});

    }
}