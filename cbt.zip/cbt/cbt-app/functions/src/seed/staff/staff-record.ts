export interface Staff {
    id: string;
    firstname: string;
    lastname: string;
    email: string;
    department: string;
    role: string;
    dateOfBirth: string;
    gender: string;
}

export const staffList: Staff[] = [
    {
        id: "1",
        firstname: "John",
        lastname: "Doe",
        email: "john.doe@school.com",
        department: "Mathematics",
        role: "Teacher",
        dateOfBirth: "1985-04-12",
        gender: "Male",
    },
    {
        id: "2",
        firstname: "Alice",
        lastname: "Smith",
        email: "alice.smith@school.com",
        department: "Science",
        role: "Teacher",
        dateOfBirth: "1990-07-23",
        gender: "Female",
    },
    {
        id: "3",
        firstname: "Robert",
        lastname: "Brown",
        email: "robert.brown@school.com",
        department: "Administration",
        role: "Principal",
        dateOfBirth: "1975-09-30",
        gender: "Male",
    },
    {
        id: "4",
        firstname: "Emma",
        lastname: "Johnson",
        email: "emma.johnson@school.com",
        department: "English",
        role: "Teacher",
        dateOfBirth: "1988-11-15",
        gender: "Female",
    },
    {
        id: "5",
        firstname: "Michael",
        lastname: "Williams",
        email: "michael.williams@school.com",
        department: "IT",
        role: "Technician",
        dateOfBirth: "1992-03-05",
        gender: "Male",
    },
    {
        id: "6",
        firstname: "Sophia",
        lastname: "Martinez",
        email: "sophia.martinez@school.com",
        department: "Counseling",
        role: "Guidance Counselor",
        dateOfBirth: "1983-06-22",
        gender: "Female",
    },
    {
        id: "7",
        firstname: "James",
        lastname: "Garcia",
        email: "james.garcia@school.com",
        department: "Sports",
        role: "Physical Education Teacher",
        dateOfBirth: "1987-12-10",
        gender: "Male",
    },
    {
        id: "8",
        firstname: "Olivia",
        lastname: "Rodriguez",
        email: "olivia.rodriguez@school.com",
        department: "Library",
        role: "Librarian",
        dateOfBirth: "1991-08-28",
        gender: "Female",
    },
    {
        id: "9",
        firstname: "William",
        lastname: "Hernandez",
        email: "william.hernandez@school.com",
        department: "Maintenance",
        role: "Janitor",
        dateOfBirth: "1970-05-18",
        gender: "Male",
    },
    {
        id: "10",
        firstname: "Charlotte",
        lastname: "Lopez",
        email: "charlotte.lopez@school.com",
        department: "Administration",
        role: "Secretary",
        dateOfBirth: "1985-09-08",
        gender: "Female",
    },
];

export default staffList;