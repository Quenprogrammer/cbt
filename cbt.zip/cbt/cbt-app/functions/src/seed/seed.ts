import { ad as admin } from './firebase';
import { AddingStudentDb } from './sudent/adding-student-db';
import { addMultipleExams } from './exams/adding-multiple-exams';
import { createUsersWithClaims } from './users/create-user-with-claims';
import { AddingStaffToDb } from './staff/adding-staff-db';
import { registerUser3ForComputerExams } from './exams/register-user3-exams';
import { seedAdminTestingData } from './testing/admin-testing-data';
import { seedMultiTenantPlatform } from './multitenancy';

async function clearFirestore(): Promise<void> {
  const db = admin.firestore();
  const collections = ['student', 'staffs', 'subjects', 'users', 'exports', 'examAssignments', 'examDrafts', 'examAttempts', 'results', 'resultChecks', 'activityLogs', 'notifications', 'invigilationSchedules', 'examRegistrations', 'tenants', 'userTenancies', 'platformAdmins', 'platformPlans', 'platformInvoices', 'platformPayments', 'platformAuditLogs'];

  for (const collectionName of collections) {
    const docs = await db.collection(collectionName).listDocuments();
    for (const doc of docs) {
      await db.recursiveDelete(doc);
    }
  }
}

async function clearAuth(): Promise<void> {
  let pageToken: string | undefined;
  do {
    const page = await admin.auth().listUsers(1000, pageToken);
    for (const user of page.users) {
      await admin.auth().deleteUser(user.uid);
    }
    pageToken = page.pageToken;
  } while (pageToken);
}

async function seed(): Promise<void> {
  console.log('Resetting Firebase emulator data...');
  await Promise.all([clearFirestore(), clearAuth()]);

  console.log('Seeding Firestore and Auth...');
  await AddingStudentDb();
  await AddingStaffToDb();
  await addMultipleExams();
  await createUsersWithClaims();
  await registerUser3ForComputerExams();
  await seedAdminTestingData();
  await seedMultiTenantPlatform();

  const [students, staffs, subjects, authUsers] = await Promise.all([
    admin.firestore().collection('student').get(),
    admin.firestore().collection('staffs').get(),
    admin.firestore().collection('subjects').get(),
    admin.auth().listUsers(1000),
  ]);

  console.log('Seed complete.');
  console.log(`  students: ${students.size}`);
  console.log(`  staff:    ${staffs.size}`);
  console.log(`  subjects: ${subjects.size}`);
  console.log(`  users:    ${authUsers.users.length}`);
  console.log('  admin login:   user1@example.com / password123');
  console.log('  student login: khaleel@example.com / 123456');
  console.log('  registered exam login: user3@example.com / password123');
  console.log('  user3 subjects: Computer Hardware, Computer Programming, General Computer, ICT');
  console.log('  testing data: activity logs, notifications, attempts, results and invigilation schedules');
  console.log('  tenant code for existing users: DEMO-CBT');
  console.log('  tenant manager: platform@cbt.test / Password123!');
  console.log('  second tenant: greenfield.admin@cbt.test / Password123!');
}

seed()
  .then(() => process.exit(0))
  .catch((error: unknown) => {
    console.error('Seed failed:', error);
    process.exit(1);
  });
