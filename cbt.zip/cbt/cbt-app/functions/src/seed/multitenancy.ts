import { ad as admin } from './firebase';

const DEFAULT_LIMITS = {
  students: 500,
  staff: 30,
  users: 30,
  subjects: 20,
  monthlyAttempts: 2000,
};

const DEFAULT_MODULES = {
  students: true,
  staff: true,
  subjects: true,
  exams: true,
  invigilation: true,
  results: true,
  notifications: true,
  exports: true,
  publicResults: true,
};

const ENTERPRISE_LIMITS = {
  students: 10000,
  staff: 1000,
  users: 1000,
  subjects: 500,
  monthlyAttempts: 100000,
};

const TENANT_COLLECTIONS = [
  'student',
  'staffs',
  'subjects',
  'users',
  'exports',
  'examAssignments',
  'examDrafts',
  'examAttempts',
  'results',
  'activityLogs',
  'notifications',
  'invigilationSchedules',
  'examRegistrations',
] as const;

async function copyDocumentTree(
  source: FirebaseFirestore.DocumentReference,
  target: FirebaseFirestore.DocumentReference
): Promise<void> {
  const snapshot = await source.get();
  if (snapshot.exists) {
    await target.set(snapshot.data() ?? {}, { merge: true });
  }

  const children = await source.listCollections();
  for (const child of children) {
    const docs = await child.listDocuments();
    for (const childDoc of docs) {
      await copyDocumentTree(childDoc, target.collection(child.id).doc(childDoc.id));
    }
  }
}

async function copyLegacyDataIntoTenant(tenantId: string): Promise<void> {
  const db = admin.firestore();
  for (const collectionName of TENANT_COLLECTIONS) {
    const sourceCollection = db.collection(collectionName);
    const documents = await sourceCollection.listDocuments();
    for (const sourceDoc of documents) {
      const targetDoc = db.doc(`tenants/${tenantId}/${collectionName}/${sourceDoc.id}`);
      await copyDocumentTree(sourceDoc, targetDoc);
    }
  }
}

async function tagLegacyPublicResults(tenantId: string): Promise<void> {
  const db = admin.firestore();
  const snapshot = await db.collection('resultChecks').get();
  const chunks: FirebaseFirestore.QueryDocumentSnapshot[][] = [];
  for (let index = 0; index < snapshot.docs.length; index += 400) {
    chunks.push(snapshot.docs.slice(index, index + 400));
  }
  for (const docs of chunks) {
    const batch = db.batch();
    for (const result of docs) {
      batch.set(result.ref, { tenantId }, { merge: true });
    }
    await batch.commit();
  }
}

async function createPlatformOwner(): Promise<void> {
  const db = admin.firestore();
  let user: any;

  try {
    user = await admin.auth().getUserByEmail('platform@cbt.test');
    await admin.auth().updateUser(user.uid, {
      password: 'Password123!',
      displayName: 'CBT Platform Owner',
      emailVerified: true,
    });
  } catch (error) {
    const code = (error as { code?: string }).code;
    if (code !== 'auth/user-not-found') throw error;
    user = await admin.auth().createUser({
      email: 'platform@cbt.test',
      password: 'Password123!',
      displayName: 'CBT Platform Owner',
      emailVerified: true,
    });
  }

  await db.doc(`platformAdmins/${user.uid}`).set({
    uid: user.uid,
    email: user.email,
    displayName: user.displayName ?? 'CBT Platform Owner',
    role: 'platform-owner',
    status: 'active',
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  }, { merge: true });
}

async function seedPlans(): Promise<void> {
  const db = admin.firestore();
  const plans = [
    {
      id: 'starter',
      name: 'Starter',
      description: 'For small CBT centres and growing schools.',
      priceMonthly: 50000,
      limits: DEFAULT_LIMITS,
      modules: {
        ...DEFAULT_MODULES,
        invigilation: false,
        exports: false,
      },
    },
    {
      id: 'professional',
      name: 'Professional',
      description: 'For established institutions running regular examinations.',
      priceMonthly: 120000,
      limits: {
        students: 2500,
        staff: 150,
        users: 200,
        subjects: 100,
        monthlyAttempts: 15000,
      },
      modules: DEFAULT_MODULES,
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      description: 'High-capacity CBT operations with all modules enabled.',
      priceMonthly: 250000,
      limits: ENTERPRISE_LIMITS,
      modules: DEFAULT_MODULES,
    },
  ];

  for (const plan of plans) {
    await db.doc(`platformPlans/${plan.id}`).set({
      ...plan,
      currency: 'NGN',
      status: 'active',
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    }, { merge: true });
  }
}

async function linkExistingUsers(tenantId: string, tenantName: string, shortName: string): Promise<void> {
  const db = admin.firestore();
  let pageToken: string | undefined;

  do {
    const page = await admin.auth().listUsers(1000, pageToken);
    for (const user of page.users) {
      if (user.email === 'platform@cbt.test') continue;

      const currentClaims = user.customClaims ?? {};
      const role = String(currentClaims['role'] ?? 'student');
      await admin.auth().setCustomUserClaims(user.uid, {
        ...currentClaims,
        role,
        tenantId,
      });

      await db.doc(`tenants/${tenantId}/users/${user.uid}`).set({
        uid: user.uid,
        email: user.email ?? '',
        displayName: user.displayName ?? '',
        role,
        status: 'active',
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      }, { merge: true });

      await db.doc(`userTenancies/${user.uid}/tenants/${tenantId}`).set({
        tenantId,
        tenantName,
        shortName,
        role,
        status: 'active',
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      }, { merge: true });
    }
    pageToken = page.pageToken;
  } while (pageToken);
}

async function createSecondTenant(): Promise<void> {
  const db = admin.firestore();
  const tenantId = 'greenfield-cbt';
  const now = admin.firestore.FieldValue.serverTimestamp();

  await db.doc(`tenants/${tenantId}`).set({
    name: 'Greenfield CBT Centre',
    shortName: 'Greenfield CBT',
    tenantCode: 'GREENFIELD-CBT',
    email: 'admin@greenfield.test',
    phone: '08000000000',
    address: 'Demo tenant for emulator testing',
    timezone: 'Africa/Lagos',
    currency: 'NGN',
    status: 'trial',
    accessStatus: 'enabled',
    locked: false,
    statusReason: '',
    planId: 'starter',
    subscriptionStatus: 'trial',
    limits: DEFAULT_LIMITS,
    modules: DEFAULT_MODULES,
    usage: {
      students: 0,
      staff: 0,
      users: 0,
      subjects: 0,
      monthlyAttempts: 0,
      attemptMonth: new Date().toISOString().slice(0, 7),
    },
    createdAt: now,
    updatedAt: now,
  }, { merge: true });

  let user: any;
  try {
    user = await admin.auth().getUserByEmail('greenfield.admin@cbt.test');
  } catch (error) {
    const code = (error as { code?: string }).code;
    if (code !== 'auth/user-not-found') throw error;
    user = await admin.auth().createUser({
      email: 'greenfield.admin@cbt.test',
      password: 'Password123!',
      displayName: 'Greenfield CBT Admin',
      emailVerified: true,
    });
  }

  await admin.auth().setCustomUserClaims(user.uid, { role: 'admin', tenantId });
  await db.doc(`tenants/${tenantId}/users/${user.uid}`).set({
    uid: user.uid,
    email: user.email,
    displayName: user.displayName,
    role: 'admin',
    status: 'active',
    createdAt: now,
    updatedAt: now,
  }, { merge: true });
  await db.doc(`userTenancies/${user.uid}/tenants/${tenantId}`).set({
    tenantId,
    tenantName: 'Greenfield CBT Centre',
    shortName: 'Greenfield CBT',
    role: 'admin',
    status: 'active',
    createdAt: now,
    updatedAt: now,
  }, { merge: true });
}

export async function seedMultiTenantPlatform(): Promise<void> {
  const db = admin.firestore();
  const tenantId = 'demo-cbt';
  const tenantName = 'Demo CBT Institution';
  const shortName = 'Demo CBT';
  const now = admin.firestore.FieldValue.serverTimestamp();

  console.log('Creating CBT tenant platform data...');

  await seedPlans();
  await db.doc(`tenants/${tenantId}`).set({
    name: tenantName,
    shortName,
    tenantCode: 'DEMO-CBT',
    email: 'admin@demo-cbt.test',
    phone: '08000000000',
    address: 'Existing CBT emulator dataset',
    timezone: 'Africa/Lagos',
    currency: 'NGN',
    status: 'active',
    accessStatus: 'enabled',
    locked: false,
    statusReason: '',
    planId: 'enterprise',
    subscriptionStatus: 'active',
    limits: ENTERPRISE_LIMITS,
    modules: DEFAULT_MODULES,
    usage: {
      students: 0,
      staff: 0,
      users: 0,
      subjects: 0,
      monthlyAttempts: 0,
      attemptMonth: new Date().toISOString().slice(0, 7),
    },
    createdAt: now,
    updatedAt: now,
  }, { merge: true });

  await copyLegacyDataIntoTenant(tenantId);
  await tagLegacyPublicResults(tenantId);
  await linkExistingUsers(tenantId, tenantName, shortName);
  await createSecondTenant();
  await createPlatformOwner();

  await db.doc(`platformAuditLogs/emulator-seed-${Date.now()}`).set({
    actorId: 'emulator-seed',
    actorName: 'Emulator Seeder',
    actorRole: 'system',
    action: 'platform.seeded',
    tenantId,
    details: { source: 'legacy CBT emulator data' },
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  console.log('Multi-tenant CBT seed complete.');
  console.log('  platform owner: platform@cbt.test / Password123!');
  console.log('  primary tenant: DEMO-CBT');
  console.log('  second tenant admin: greenfield.admin@cbt.test / Password123!');
}
