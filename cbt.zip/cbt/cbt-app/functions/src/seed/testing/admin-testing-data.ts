import { ad as admin } from '../firebase';

interface SeedStudent {
  id: string;
  authUid?: string;
  firstname: string;
  middlename?: string;
  lastname: string;
  admissionNumber: string;
  department: string;
  email: string;
  loginEmail?: string;
  registeredSubjectIds?: string[];
  registeredSubjects?: string[];
}

interface SeedStaff {
  id: string;
  firstname: string;
  lastname: string;
  department: string;
  role: string;
}

interface SeedSubject {
  id: string;
  name: string;
}

function studentName(student: SeedStudent): string {
  return [student.firstname, student.middlename, student.lastname].filter(Boolean).join(' ');
}

function staffName(staff: SeedStaff): string {
  return [staff.firstname, staff.lastname].filter(Boolean).join(' ');
}

export async function seedAdminTestingData(): Promise<void> {
  const db = admin.firestore();
  const [studentSnapshot, staffSnapshot, subjectSnapshot] = await Promise.all([
    db.collection('student').get(),
    db.collection('staffs').get(),
    db.collection('subjects').get(),
  ]);

  const students: SeedStudent[] = studentSnapshot.docs
    .map((docSnapshot) => ({ id: docSnapshot.id, ...docSnapshot.data() } as SeedStudent))
    .sort((a, b) => a.admissionNumber.localeCompare(b.admissionNumber));

  const staffs: SeedStaff[] = staffSnapshot.docs
    .map((docSnapshot) => ({ ...docSnapshot.data(), id: docSnapshot.id } as SeedStaff))
    .sort((a, b) => a.firstname.localeCompare(b.firstname));

  const subjects: SeedSubject[] = subjectSnapshot.docs
    .map((docSnapshot) => ({ id: docSnapshot.id, name: String(docSnapshot.data().name ?? '') }))
    .filter((subject) => subject.name)
    .sort((a, b) => a.name.localeCompare(b.name));

  if (students.length === 0 || subjects.length === 0) {
    throw new Error('Students and subjects must be seeded before admin testing data.');
  }

  // Give linked student accounts realistic subject registrations for testing.
  const linkedStudents = students.filter((student) => Boolean(student.authUid)).slice(0, 6);
  for (let index = 0; index < linkedStudents.length; index += 1) {
    const student = linkedStudents[index];
    const existingIds = Array.isArray(student.registeredSubjectIds) ? student.registeredSubjectIds : [];
    const desiredSubjectCount = index === linkedStudents.length - 1
      ? Math.min(11, subjects.length)
      : Math.min(5 + (index % 3), subjects.length);
    const subjectSelection = existingIds.length > 0
      ? subjects.filter((subject) => existingIds.includes(subject.id)).slice(0, 11)
      : Array.from({ length: desiredSubjectCount }, (_, offset) =>
          subjects[(index + offset) % subjects.length]
        );

    const subjectIds = subjectSelection.map((subject) => subject.id);
    const subjectNames = subjectSelection.map((subject) => subject.name);
    const examStatus = index % 3 === 0 ? 'Started' : index % 3 === 1 ? 'Not Started' : 'Ended';

    await db.collection('student').doc(student.id).set({
      registeredSubjectIds: subjectIds,
      registeredSubjects: subjectNames,
      examStatus,
      status: 'Active',
      classLevel: student.department,
      phone: `08030000${String(index + 1).padStart(3, '0')}`,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    }, { merge: true });

    if (student.authUid) {
      await db.collection('users').doc(student.authUid).set({
        registeredSubjectIds: subjectIds,
        registeredSubjects: subjectNames,
        role: 'student',
      }, { merge: true });

      await db.collection('examRegistrations').doc(student.authUid).set({
        studentId: student.id,
        studentAuthUid: student.authUid,
        studentEmail: student.loginEmail || student.email,
        subjectIds,
        subjectNames,
        status: 'registered',
        examStatus,
        registeredAt: admin.firestore.FieldValue.serverTimestamp(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      }, { merge: true });
    }
  }

  const testStudents = linkedStudents.length > 0 ? linkedStudents : students.slice(0, 6);
  const adminUser = await admin.auth().getUserByEmail('user1@example.com').catch(() => null);
  const adminActorId = adminUser?.uid ?? 'seed-admin';
  const adminActorEmail = adminUser?.email ?? 'user1@example.com';

  for (let index = 0; index < staffs.length; index += 1) {
    await db.collection('staffs').doc(staffs[index].id).set({
      employeeId: `STF-${String(index + 1).padStart(3, '0')}`,
      status: index === staffs.length - 1 ? 'On Leave' : 'Active',
      employmentType: index % 2 === 0 ? 'Full-time' : 'Contract',
    }, { merge: true });
  }

  const assignmentIds: string[] = [];
  const resultIds: string[] = [];

  for (let index = 0; index < Math.min(6, testStudents.length); index += 1) {
    const student = testStudents[index];
    const currentStudentSnap = await db.collection('student').doc(student.id).get();
    const currentStudent = { id: student.id, ...currentStudentSnap.data() } as SeedStudent;
    const assignedNames = Array.isArray(currentStudent.registeredSubjects)
      ? currentStudent.registeredSubjects
      : subjects.slice(0, 4).map((subject) => subject.name);
    const assignedIds = Array.isArray(currentStudent.registeredSubjectIds)
      ? currentStudent.registeredSubjectIds
      : subjects.slice(0, 4).map((subject) => subject.id);
    const submitted = index % 2 === 1 || index === 4;
    const pin = `TEST-${String(index + 1).padStart(4, '0')}`;
    const totalQuestions = 20 + index * 5;
    const score = submitted ? Math.max(10, totalQuestions - (3 + index)) : 0;
    const percentage = submitted ? Math.round((score / totalQuestions) * 100) : 0;
    const grade = percentage >= 70 ? 'A' : percentage >= 60 ? 'B' : percentage >= 50 ? 'C' : 'F';
    const status = percentage >= 50 ? 'Pass' : 'Fail';
    const assignmentRef = db.collection('examAssignments').doc();
    assignmentIds.push(assignmentRef.id);

    const studentDetails = {
      id: student.id,
      firstname: currentStudent.firstname,
      middlename: currentStudent.middlename ?? '',
      lastname: currentStudent.lastname,
      admissionNumber: currentStudent.admissionNumber,
      department: currentStudent.department,
      email: currentStudent.email,
    };

    const startedAtMs = Date.parse(`2026-09-${String(12 + index).padStart(2, '0')}T09:00:00+01:00`);
    await assignmentRef.set({
      studentId: student.id,
      studentEmail: currentStudent.loginEmail || currentStudent.email,
      studentDetails,
      subjects: assignedIds.slice(0, 4).map((subjectId, subjectIndex) => ({
        subjectId,
        subjectName: assignedNames[subjectIndex] || `Subject ${subjectIndex + 1}`,
        timeLimit: 30,
        questionIds: [],
      })),
      questionCount: totalQuestions,
      durationMinutes: 90,
      status: submitted ? 'submitted' : 'in-progress',
      startedAtMs,
      expiresAtMs: startedAtMs + 90 * 60_000,
      resultPin: submitted ? pin : '',
      resultId: '',
      lastActivityAt: admin.firestore.FieldValue.serverTimestamp(),
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    if (submitted) {
      const resultRef = db.collection('results').doc();
      resultIds.push(resultRef.id);
      const submittedAtIso = `2026-09-${String(12 + index).padStart(2, '0')}T11:00:00+01:00`;
      const subjectResults = assignedNames.slice(0, 4).map((subjectName, subjectIndex) => ({
        subjectName,
        score: Math.max(2, 5 - (subjectIndex % 2)),
        totalQuestions: 5,
        percentage: subjectIndex % 2 === 0 ? 80 : 60,
      }));

      const resultData = {
        pin,
        resultId: resultRef.id,
        assignmentId: assignmentRef.id,
        studentId: student.id,
        studentDetails,
        candidate: {
          name: studentName(currentStudent),
          admissionNumber: currentStudent.admissionNumber,
          department: currentStudent.department,
        },
        subjectResults,
        score,
        totalQuestions,
        answered: totalQuestions - 1,
        unanswered: 1,
        incorrect: Math.max(0, totalQuestions - score - 1),
        percentage,
        grade,
        status,
        submittedAtIso,
        submittedAt: admin.firestore.FieldValue.serverTimestamp(),
      };

      await resultRef.set(resultData);
      await db.collection('resultChecks').doc(pin).set(resultData);
      await assignmentRef.set({ resultId: resultRef.id }, { merge: true });
    }
  }

  const activityActions = [
    'admin_login',
    'student_created',
    'exam_access_updated',
    'exam_started',
    'exam_submitted',
    'result_generated',
    'invigilation_scheduled',
    'notification_read',
    'student_updated',
    'exam_access_bulk_updated',
    'result_checked',
    'staff_updated',
  ];

  for (let index = 0; index < activityActions.length; index += 1) {
    const metadata: Record<string, unknown> = {
      status: index % 2 === 0 ? 'Success' : 'Completed',
    };
    if (index % 4 === 0) {
      metadata.percentage = 76 + index;
      metadata.grade = 'A';
    }

    await db.collection('activityLogs').add({
      action: activityActions[index],
      actorId: index % 3 === 0 && testStudents[index % testStudents.length]?.authUid
        ? testStudents[index % testStudents.length].authUid
        : adminActorId,
      actorEmail: index % 3 === 0
        ? (testStudents[index % testStudents.length]?.loginEmail || testStudents[index % testStudents.length]?.email || adminActorEmail)
        : adminActorEmail,
      assignmentId: assignmentIds[index % Math.max(assignmentIds.length, 1)] || null,
      resultId: resultIds.length > 0 ? resultIds[index % resultIds.length] : null,
      metadata,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  }

  const notificationRows = [
    ['Exam access enabled', 'Exam access has been enabled for selected candidates.'],
    ['New result submitted', 'A candidate completed an examination and a result PIN was generated.'],
    ['Invigilation schedule created', 'A new CBT Lab A supervision schedule is ready for review.'],
    ['Candidate registration', 'A student completed account and subject registration.'],
    ['Attempt still in progress', 'One or more candidates currently have active examination sessions.'],
    ['Result checker activity', 'A seeded result PIN was used to test the public result checker.'],
    ['Subject bank updated', 'The seed now contains twelve active examination subjects.'],
    ['System test data ready', 'Activity logs, attempts, results and invigilation test data are available.'],
  ] as const;

  for (let index = 0; index < notificationRows.length; index += 1) {
    const [title, message] = notificationRows[index];
    await db.collection('notifications').add({
      title,
      message,
      type: index % 3 === 0 ? 'info' : index % 3 === 1 ? 'success' : 'warning',
      read: index >= 5,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });
  }

  if (staffs.length > 0) {
    for (let index = 0; index < Math.min(4, staffs.length); index += 1) {
      const staff = staffs[index];
      const assignedStudents = students.slice(index * 3, index * 3 + 5);
      await db.collection('invigilationSchedules').add({
        examTitle: index % 2 === 0 ? 'First Term CBT' : 'CBT Mock Examination',
        subjectName: index === 0 ? 'English & Mathematics' : index === 1 ? 'Science subjects' : 'Registered subjects',
        examDate: `2026-09-${18 + index}`,
        startTime: index < 2 ? '09:00' : '13:00',
        endTime: index < 2 ? '11:00' : '15:00',
        venue: `CBT Lab ${String.fromCharCode(65 + index)}`,
        staffId: staff.id,
        staffName: staffName(staff),
        staffEmployeeId: `STF-${String(index + 1).padStart(3, '0')}`,
        staffDepartment: staff.department,
        studentIds: assignedStudents.map((student) => student.id),
        students: assignedStudents.map((student) => ({
          id: student.id,
          name: studentName(student),
          admissionNumber: student.admissionNumber,
          department: student.department,
        })),
        studentCount: assignedStudents.length,
        status: index === 3 ? 'Completed' : 'Scheduled',
        notes: index === 0 ? 'Report 30 minutes before the examination begins.' : 'Seeded schedule for system testing.',
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
    }
  }

  console.log(`Seeded admin testing data: ${activityActions.length} logs, ${notificationRows.length} notifications, ${assignmentIds.length} attempts, ${resultIds.length} results, ${Math.min(4, staffs.length)} invigilation schedules.`);
}
