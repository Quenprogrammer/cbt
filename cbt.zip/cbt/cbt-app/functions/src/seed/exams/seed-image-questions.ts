import { ad as admin } from '../firebase';
import { imageQuestionSeeds, imageQuestionsForSubject } from './image-questions';

// Adds examples to existing emulator data without resetting users or questions.
async function seedImageQuestions(): Promise<void> {
  const db = admin.firestore();
  const tenants = await db.collection('tenants').get();
  const subjectCollections = [db.collection('subjects'), ...tenants.docs.map(tenant => tenant.ref.collection('subjects'))];
  let count = 0;
  for (const subjects of subjectCollections) {
    const snapshot = await subjects.get();
    for (const subject of snapshot.docs) {
      const name = String(subject.data().name ?? '');
      const seed = imageQuestionSeeds.find(value => value.subject === name);
      if (!seed) continue;
      const question = imageQuestionsForSubject(name)[0];
      // A full seed may already have inserted this example using an auto ID.
      const existing = await subject.ref.collection('exams').where('imageUrl', '==', question.imageUrl).limit(1).get();
      if (!existing.empty) continue;
      await subject.ref.collection('exams').doc(`seed-image-${seed.slug}`).set(question);
      count++;
    }
  }
  console.log(`Added ${count} image questions to existing emulator subjects. Existing questions and accounts were preserved.`);
}

seedImageQuestions().then(() => process.exit(0)).catch(error => { console.error(error); process.exit(1); });
