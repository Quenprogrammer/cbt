import type { Question } from './adding-multiple-exams';

interface ImageQuestionSeed {
  subject: string;
  slug: string;
  question: string;
  imageAlt: string;
  options: [string, string, string, string];
  correctAnswerId: 'A' | 'B' | 'C' | 'D';
}

export const imageQuestionSeeds: ImageQuestionSeed[] = [
  { subject: 'English', slug: 'english', question: 'Which preposition correctly completes the sentence about the picture: The ball is ___ the table?', imageAlt: 'A red ball resting on the floor directly below a table.', options: ['above', 'under', 'beside', 'inside'], correctAnswerId: 'B' },
  { subject: 'Math', slug: 'math', question: 'Find the area of the triangle shown in the diagram.', imageAlt: 'A triangle with a base of 8 cm and a perpendicular height of 6 cm.', options: ['48 cm²', '14 cm²', '24 cm²', '28 cm²'], correctAnswerId: 'C' },
  { subject: 'Chemistry', slug: 'chemistry', question: 'Which separation method is illustrated in the diagram?', imageAlt: 'A mixture is poured through filter paper in a funnel into a beaker; solid particles remain in the paper.', options: ['Distillation', 'Evaporation', 'Chromatography', 'Filtration'], correctAnswerId: 'D' },
  { subject: 'Computer', slug: 'computer', question: 'Which stage of the information-processing cycle belongs in the box marked X?', imageAlt: 'Three boxes connected from left to right: Input, X, Output.', options: ['Processing', 'Printing', 'Deletion', 'Shutdown'], correctAnswerId: 'A' },
  { subject: 'Computer Hardware', slug: 'computer-hardware', question: 'Which device is illustrated in the diagram?', imageAlt: 'A computer peripheral with rows of letter keys, a number row and a long space bar.', options: ['Scanner', 'Monitor', 'Keyboard', 'Speaker'], correctAnswerId: 'C' },
  { subject: 'Computer Programming', slug: 'computer-programming', question: 'What value will be displayed when the flowchart is executed?', imageAlt: 'Flowchart: Start, set x to 3, set x to x times 2, display x, End.', options: ['3', '6', '5', '9'], correctAnswerId: 'B' },
  { subject: 'General Computer', slug: 'general-computer', question: 'Which item in the folder listing is an image file?', imageAlt: 'A folder listing with four files: notes.txt, photo.png, music.mp3 and report.pdf.', options: ['notes.txt', 'report.pdf', 'music.mp3', 'photo.png'], correctAnswerId: 'D' },
  { subject: 'ICT', slug: 'ict', question: 'Which network topology is shown in the diagram?', imageAlt: 'Four computers each connected by a separate line to a central network switch, with no connections between the computers.', options: ['Star', 'Ring', 'Bus', 'Mesh'], correctAnswerId: 'A' },
  { subject: 'Physics', slug: 'physics', question: 'What is the resultant horizontal force acting on the block?', imageAlt: 'A block with a horizontal force of 10 N to the right and a horizontal force of 4 N to the left.', options: ['14 N to the right', '6 N to the right', '6 N to the left', '14 N to the left'], correctAnswerId: 'B' },
  { subject: 'Biology', slug: 'biology', question: 'Which structure is labelled X in the animal cell diagram?', imageAlt: 'An animal cell with a membrane, cytoplasm, and a central circular structure indicated by an arrow labelled X.', options: ['Cell wall', 'Chloroplast', 'Nucleus', 'Vacuole'], correctAnswerId: 'C' },
  { subject: 'Economics', slug: 'economics', question: 'What does the downward-sloping curve show about price and quantity demanded?', imageAlt: 'A graph with Price on the vertical axis and Quantity demanded on the horizontal axis; the curve slopes from upper left to lower right.', options: ['Demand rises as price rises', 'Price and demand are unrelated', 'Quantity demanded stays constant', 'Quantity demanded rises as price falls'], correctAnswerId: 'D' },
  { subject: 'Civic Education', slug: 'civic-education', question: 'Which civic activity is illustrated in the picture?', imageAlt: 'A hand placing a ballot paper into a ballot box.', options: ['Voting in an election', 'Paying a tax', 'Attending a court hearing', 'Taking a census'], correctAnswerId: 'A' },
];

export function imageQuestionsForSubject(subject: string): Question[] {
  return imageQuestionSeeds.filter(seed => seed.subject === subject).map(seed => ({
    id: 10000 + imageQuestionSeeds.indexOf(seed),
    subject,
    question: seed.question,
    imageUrl: `/question-images/${seed.slug}.svg`,
    imageAlt: seed.imageAlt,
    options: seed.options.map((text, index) => ({ id: (['A', 'B', 'C', 'D'] as const)[index], text })),
    correctAnswerId: seed.correctAnswerId,
  }));
}
