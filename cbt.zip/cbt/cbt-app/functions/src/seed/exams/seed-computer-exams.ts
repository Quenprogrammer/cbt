import { ad as admin } from '../firebase';
import { computerSpecialistSubjects } from './computer-specialist-subjects';
import { registerUser3ForComputerExams } from './register-user3-exams';
import { imageQuestionsForSubject } from './image-questions';

function slugify(value: string): string {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');
}

async function upsertComputerSubjects(): Promise<void> {
  const db = admin.firestore();

  for (const subject of computerSpecialistSubjects) {
    const matches = await db
      .collection('subjects')
      .where('name', '==', subject.name)
      .get();

    let subjectRef: FirebaseFirestore.DocumentReference;

    if (matches.empty) {
      subjectRef = db.collection('subjects').doc(slugify(subject.name));
    } else {
      subjectRef = matches.docs[0].ref;

      // Remove accidental duplicates while keeping the first matching subject.
      for (const duplicate of matches.docs.slice(1)) {
        await db.recursiveDelete(duplicate.ref);
      }
    }

    const existingQuestions = await subjectRef.collection('exams').get();
    const batch = db.batch();

    batch.set(subjectRef, {
      name: subject.name,
      description: subject.description,
      timeLimit: subject.timeLimit,
      questionLimit: subject.questionLimit ?? 30,
      active: subject.active ?? true,
    }, { merge: true });

    for (const existing of existingQuestions.docs) {
      batch.delete(existing.ref);
    }

    const questions = [...subject.questions, ...imageQuestionsForSubject(subject.name)];
    questions.forEach((question, index) => {
      const questionId = `q${String(index + 1).padStart(3, '0')}`;
      batch.set(subjectRef.collection('exams').doc(questionId), question);
    });

    await batch.commit();
    console.log(`Upserted ${subject.name}: ${questions.length} questions`);
  }
}

async function seedComputerExams(): Promise<void> {
  console.log('Adding/updating the four computer exam subjects without resetting other data...');
  await upsertComputerSubjects();
  await registerUser3ForComputerExams();
  console.log('Computer exam registration seed complete.');
  console.log('  login: user3@example.com / password123');
  console.log('  access: Started');
  console.log('  subjects: Computer Hardware, Computer Programming, General Computer, ICT');
}

seedComputerExams()
  .then(() => process.exit(0))
  .catch((error: unknown) => {
    console.error('Computer exam seed failed:', error);
    process.exit(1);
  });
