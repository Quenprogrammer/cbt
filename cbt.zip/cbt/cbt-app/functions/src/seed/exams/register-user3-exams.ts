import { ad as admin } from '../firebase';

const registeredSubjectNames = [
  'Computer Hardware',
  'Computer Programming',
  'General Computer',
  'ICT',
] as const;

async function ensureUser3() {
  try {
    return await admin.auth().getUserByEmail('user3@example.com');
  } catch (error) {
    const code = (error as { code?: string }).code;
    if (code !== 'auth/user-not-found') throw error;

    return admin.auth().createUser({
      email: 'user3@example.com',
      password: 'password123',
    });
  }
}

export async function registerUser3ForComputerExams(): Promise<void> {
  const db = admin.firestore();
  const authUser = await ensureUser3();

  await admin.auth().setCustomUserClaims(authUser.uid, { role: 'student' });
  await db.collection('users').doc(authUser.uid).set({
    email: 'user3@example.com',
    role: 'student',
  }, { merge: true });

  let studentQuery = await db
    .collection('student')
    .where('authUid', '==', authUser.uid)
    .limit(1)
    .get();

  if (studentQuery.empty) {
    studentQuery = await db
      .collection('student')
      .where('loginEmail', '==', 'user3@example.com')
      .limit(1)
      .get();
  }

  if (studentQuery.empty) {
    studentQuery = await db
      .collection('student')
      .where('email', '==', 'jane.smith@example.com')
      .limit(1)
      .get();
  }

  let studentDoc: FirebaseFirestore.DocumentReference;

  if (studentQuery.empty) {
    studentDoc = await db.collection('student').add({
      firstname: 'Jane',
      lastname: 'Smith',
      admissionNumber: 'ADM1002',
      department: 'JSS2',
      email: 'jane.smith@example.com',
      loginEmail: 'user3@example.com',
      authUid: authUser.uid,
      gender: 'Female',
      dateOfBirth: '2005-07-08',
      examStatus: 'Not Started',
    });
  } else {
    studentDoc = studentQuery.docs[0].ref;
  }

  const subjectIds: string[] = [];

  for (const subjectName of registeredSubjectNames) {
    const subjectQuery = await db
      .collection('subjects')
      .where('name', '==', subjectName)
      .limit(1)
      .get();

    if (subjectQuery.empty) {
      throw new Error(`Unable to register user3@example.com: subject "${subjectName}" was not found.`);
    }

    subjectIds.push(subjectQuery.docs[0].id);
  }

  const registeredAt = new Date();

  await studentDoc.update({
    authUid: authUser.uid,
    loginEmail: 'user3@example.com',
    examStatus: 'Started',
    registeredSubjectIds: subjectIds,
    registeredSubjects: [...registeredSubjectNames],
    examPermissionUpdatedAt: registeredAt,
  });

  await db.collection('examRegistrations').doc(authUser.uid).set({
    studentId: studentDoc.id,
    studentAuthUid: authUser.uid,
    studentEmail: 'user3@example.com',
    subjectIds,
    subjectNames: [...registeredSubjectNames],
    status: 'approved',
    examStatus: 'Started',
    registeredAt,
  });

  await db.collection('users').doc(authUser.uid).set({
    registeredSubjectIds: subjectIds,
    registeredSubjects: [...registeredSubjectNames],
  }, { merge: true });

  console.log(
    `Registered user3@example.com for ${registeredSubjectNames.length} exams: ${registeredSubjectNames.join(', ')}`
  );
}
