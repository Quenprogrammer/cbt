import type { Question, Subject } from './adding-multiple-exams';

type QuestionRow = readonly [
  question: string,
  options: readonly [string, string, string, string],
  correctAnswerId: 'A' | 'B' | 'C' | 'D'
];

function buildQuestions(subject: string, rows: readonly QuestionRow[]): Question[] {
  const ids: Array<'A' | 'B' | 'C' | 'D'> = ['A', 'B', 'C', 'D'];

  return rows.map(([question, options, correctAnswerId], index) => {
    // Rotate answer positions so seeded questions do not all share the same
    // correct option letter. The first option in each source row is usually
    // the intended answer, and this preserves correctness after rotation.
    const shift = index % ids.length;
    const originalCorrectIndex = ids.indexOf(correctAnswerId);
    const rotatedOptions = options.map(
      (_value, optionIndex) => options[(optionIndex - shift + ids.length) % ids.length]
    );
    const rotatedCorrectAnswerId = ids[
      (originalCorrectIndex + shift) % ids.length
    ];

    return {
      id: index + 1,
      subject,
      question,
      options: rotatedOptions.map((text, optionIndex) => ({
        id: ids[optionIndex],
        text,
      })),
      correctAnswerId: rotatedCorrectAnswerId,
    };
  });
}

const computerHardwareRows: readonly QuestionRow[] = [
  ["Which component is known as the brain of the computer?", ["CPU", "Monitor", "Keyboard", "Printer"], "A"],
  ["Which component temporarily stores data that the CPU is actively using?", ["RAM", "ROM", "SSD", "Power supply"], "A"],
  ["Which storage device has no moving mechanical parts?", ["SSD", "Floppy disk", "DVD drive", "Magnetic tape"], "A"],
  ["What is the main function of the motherboard?", ["Connect and allow communication between computer components", "Print documents", "Display graphics only", "Store files permanently"], "A"],
  ["Which component converts AC electricity from the wall into DC power used by a desktop computer?", ["Power supply unit", "CPU cooler", "RAM module", "Network card"], "A"],
  ["Which device is primarily used to enter text into a computer?", ["Keyboard", "Monitor", "Speaker", "Projector"], "A"],
  ["Which of these is an output device?", ["Monitor", "Mouse", "Scanner", "Microphone"], "A"],
  ["Which port is commonly used for modern digital video and audio output to a monitor or TV?", ["HDMI", "PS/2", "RJ-11", "Serial"], "A"],
  ["What does USB stand for?", ["Universal Serial Bus", "Unified System Board", "User Storage Base", "Universal System Buffer"], "A"],
  ["Which component is responsible for rendering images and video?", ["GPU", "PSU", "NIC", "BIOS battery"], "A"],
  ["What is the purpose of a heat sink?", ["Dissipate heat from electronic components", "Store electrical power", "Increase hard-drive capacity", "Connect to Wi-Fi"], "A"],
  ["Which device is used to move the pointer on a graphical desktop?", ["Mouse", "Printer", "Router", "Speaker"], "A"],
  ["Which type of memory normally retains its contents when power is removed?", ["ROM", "RAM", "CPU cache", "Registers"], "A"],
  ["What is the purpose of a network interface card (NIC)?", ["Connect a computer to a network", "Cool the processor", "Store the operating system", "Control the keyboard"], "A"],
  ["Which connector is commonly used for wired Ethernet networking?", ["RJ-45", "HDMI", "VGA", "3.5 mm audio"], "A"],
  ["Which component provides long-term storage for files and applications?", ["SSD or hard drive", "RAM", "CPU cache", "Register"], "A"],
  ["What is BIOS/UEFI mainly used for?", ["Initialize hardware and start the boot process", "Create spreadsheets", "Browse the web", "Edit images"], "A"],
  ["Which expansion slot is commonly used for a modern graphics card?", ["PCI Express x16", "DIMM", "SATA", "M.2 key E only"], "A"],
  ["What is the purpose of thermal paste between a CPU and heat sink?", ["Improve heat transfer", "Increase storage capacity", "Provide electrical power", "Prevent network attacks"], "A"],
  ["Which computer component usually contains DIMM slots?", ["Motherboard", "Monitor", "Keyboard", "Printer"], "A"],
  ["Which device can convert paper documents into digital images?", ["Scanner", "Speaker", "Router", "UPS"], "A"],
  ["What does a UPS provide during a short power failure?", ["Temporary backup power", "Extra CPU speed", "More RAM", "Internet bandwidth"], "A"],
  ["Which hardware component stores frequently used data very close to the CPU for fast access?", ["Cache memory", "Hard disk", "Optical disc", "USB flash drive"], "A"],
  ["Which cable standard is commonly used to connect internal SATA drives?", ["SATA", "VGA", "PS/2", "RJ-45"], "A"],
  ["What is the main purpose of a computer case?", ["Protect and hold internal components", "Create internet accounts", "Compile programs", "Scan documents"], "A"],
  ["Which device is an example of removable flash storage?", ["USB flash drive", "CPU", "Motherboard", "Heat sink"], "A"],
  ["Which component provides sound output from a computer?", ["Speakers", "Scanner", "Webcam", "Mouse"], "A"],
  ["What is the purpose of a CMOS/RTC battery on many motherboards?", ["Maintain clock and firmware settings when powered off", "Run the CPU at full speed", "Store user documents", "Power the monitor"], "A"],
  ["Which unit is commonly used to express processor clock frequency?", ["Hertz", "Byte", "Pixel", "Volt-hour"], "A"],
  ["What should normally be done before opening a desktop computer case for maintenance?", ["Shut down and disconnect power", "Increase screen brightness", "Start a download", "Enable Bluetooth"], "A"],
];

const computerProgrammingRows: readonly QuestionRow[] = [
  ["What is an algorithm?", ["A step-by-step procedure for solving a problem", "A type of monitor", "A network cable", "A storage device"], "A"],
  ["Which programming structure repeats a block of code?", ["Loop", "Variable", "Comment", "Constant"], "A"],
  ["What is a variable used for in programming?", ["Store a value that may change", "Print paper documents", "Connect to Wi-Fi", "Cool the CPU"], "A"],
  ["Which operator is commonly used to test equality in many programming languages?", ["==", "=", "++", "//"], "A"],
  ["What is a function?", ["A reusable block of code that performs a task", "A computer case", "A database cable", "A screen resolution"], "A"],
  ["Which data type is normally used for true/false values?", ["Boolean", "String", "Float only", "Character array only"], "A"],
  ["What is debugging?", ["Finding and fixing errors in a program", "Installing a printer", "Formatting a disk", "Designing a network cable"], "A"],
  ["Which statement is used to make a decision based on a condition?", ["if statement", "import statement only", "comment", "variable declaration only"], "A"],
  ["What does a compiler generally do?", ["Translates source code into another form such as machine code", "Creates computer hardware", "Stores passwords", "Connects a router"], "A"],
  ["Which symbol commonly begins a single-line comment in JavaScript?", ["//", "##", "<>", "%%"], "A"],
  ["What is an array?", ["A collection that stores multiple values", "A power supply", "A type of printer", "A network address"], "A"],
  ["What is the value produced by 5 + 3 * 2 using normal operator precedence?", ["11", "16", "13", "10"], "A"],
  ["Which concept means a function calls itself?", ["Recursion", "Iteration only", "Compilation", "Encryption"], "A"],
  ["What is a syntax error?", ["Code that breaks the grammar rules of the language", "A broken keyboard", "A slow network", "A full hard drive"], "A"],
  ["Which programming language runs natively in modern web browsers?", ["JavaScript", "C only", "SQL only", "Assembly only"], "A"],
  ["What does an assignment statement usually do?", ["Stores a value in a variable", "Deletes the operating system", "Connects a network cable", "Creates a monitor"], "A"],
  ["What is the purpose of a return statement in a function?", ["Send a value back to the caller", "Restart the computer", "Declare a network route", "Format a drive"], "A"],
  ["Which of these is an example of an integer?", ["42", "3.14", "Hello", "true"], "A"],
  ["What is a string?", ["A sequence of characters", "A CPU core", "A graphics card", "A power connector"], "A"],
  ["What is the result of the Boolean expression true AND false?", ["false", "true", "0.5", "undefined in every language"], "A"],
  ["Which loop is commonly used when the number of iterations is known?", ["for loop", "if statement", "switch only", "class declaration"], "A"],
  ["What is pseudocode?", ["Human-readable steps describing program logic", "Compiled machine code", "A hardware driver", "A network protocol"], "A"],
  ["What does IDE stand for in programming?", ["Integrated Development Environment", "Internal Data Engine", "Internet Design Extension", "Integrated Device Equipment"], "A"],
  ["Which operation usually combines two strings end-to-end?", ["Concatenation", "Division", "Subtraction", "Modulo"], "A"],
  ["What is an infinite loop?", ["A loop whose stopping condition is never reached", "A deleted function", "A syntax comment", "A hardware interrupt"], "A"],
  ["Which concept groups data and behavior into objects?", ["Object-oriented programming", "Disk formatting", "Packet switching", "Word processing"], "A"],
  ["What is a parameter?", ["A value or variable supplied to a function definition/call", "A graphics card slot", "A network switch", "A storage partition only"], "A"],
  ["What is source code?", ["Human-readable program instructions written in a programming language", "Only binary digits stored in RAM", "A printed circuit board", "An internet address"], "A"],
  ["Which testing approach checks a small individual unit such as a function?", ["Unit testing", "Load balancing", "Disk testing only", "Network routing"], "A"],
  ["Why are meaningful variable names useful?", ["They make code easier to understand and maintain", "They make monitors brighter", "They increase disk size", "They replace backups"], "A"],
];

const generalComputerRows: readonly QuestionRow[] = [
  ["What is a computer?", ["An electronic device that processes data according to instructions", "Only a calculator", "A device used only for printing", "A type of network cable"], "A"],
  ["What does CPU stand for?", ["Central Processing Unit", "Computer Personal Unit", "Central Print Utility", "Core Program User"], "A"],
  ["Which software manages a computer's hardware and provides services to applications?", ["Operating system", "Spreadsheet only", "Web page", "Presentation slide"], "A"],
  ["Which of these is an operating system?", ["Windows", "Microsoft Word", "Google Chrome", "Adobe Reader"], "A"],
  ["What is the main purpose of a web browser?", ["Access and display web content", "Replace RAM", "Control the power supply", "Print without software"], "A"],
  ["Which application is commonly used to create text documents?", ["Word processor", "Media player", "Calculator only", "Device driver"], "A"],
  ["Which application is commonly used to organize data in rows and columns?", ["Spreadsheet", "Paint program only", "Audio player", "BIOS setup"], "A"],
  ["What is a file?", ["A named collection of stored data", "A physical CPU fan", "A type of monitor", "A keyboard key"], "A"],
  ["What is a folder used for?", ["Organize files and other folders", "Increase CPU speed", "Provide internet access", "Charge a laptop"], "A"],
  ["Which keyboard shortcut commonly copies selected content on Windows?", ["Ctrl+C", "Ctrl+V", "Ctrl+Z", "Ctrl+P"], "A"],
  ["Which keyboard shortcut commonly pastes copied content on Windows?", ["Ctrl+V", "Ctrl+C", "Ctrl+X", "Ctrl+S"], "A"],
  ["What does saving a document do?", ["Writes its current data to storage", "Deletes it", "Turns off the computer", "Connects to Wi-Fi"], "A"],
  ["Which unit is larger?", ["Gigabyte", "Megabyte", "Kilobyte", "Byte"], "A"],
  ["What is malware?", ["Software designed to harm, disrupt, or misuse systems", "A word-processing feature", "A monitor cable", "A backup battery"], "A"],
  ["What is a strong password more likely to contain?", ["A long mix of unpredictable characters or words", "Only the word password", "Only your first name", "123456"], "A"],
  ["What is the Recycle Bin/Trash commonly used for?", ["Temporarily hold deleted files", "Store RAM instructions", "Manage network routing", "Install CPU drivers"], "A"],
  ["What is a backup?", ["An extra copy of data kept for recovery", "A second monitor only", "A browser tab", "A password hint"], "A"],
  ["Which device is commonly used to print hard copies?", ["Printer", "Scanner", "Microphone", "Router"], "A"],
  ["Which of these is an input device?", ["Microphone", "Speaker", "Projector", "Monitor"], "A"],
  ["What is the desktop in a graphical operating system?", ["The main on-screen workspace", "A physical table only", "A type of CPU", "A network protocol"], "A"],
  ["What is an application?", ["Software designed to help users perform tasks", "A motherboard connector", "A power cable", "A CPU temperature"], "A"],
  ["What does reboot mean?", ["Restart the computer", "Delete all files", "Create an email address", "Replace the keyboard"], "A"],
  ["What is a computer virus?", ["Malicious code capable of spreading or infecting files/systems", "A broken mouse", "A web browser setting", "A legitimate driver"], "A"],
  ["What is cloud storage?", ["Storage accessed over a network, usually the internet", "Only storage inside RAM", "A paper filing cabinet", "A CPU register"], "A"],
  ["What does PDF stand for?", ["Portable Document Format", "Personal Data File", "Program Display Function", "Public Document Folder"], "A"],
  ["Which action helps protect important work from data loss?", ["Save regularly and keep backups", "Never update software", "Use the same weak password everywhere", "Disable all security"], "A"],
  ["Which file extension is commonly associated with a plain text file?", [".txt", ".jpg", ".mp3", ".exe"], "A"],
  ["What is the purpose of antivirus software?", ["Detect and help remove malicious software", "Increase monitor size", "Create spreadsheets only", "Replace the operating system"], "A"],
  ["What is a login account used for?", ["Identify and authenticate a user", "Increase CPU speed", "Connect a printer cable", "Cool the computer"], "A"],
  ["What should you do before removing a USB storage device when the system recommends safe removal?", ["Eject/safely remove it", "Turn up the volume", "Open more applications", "Change the wallpaper"], "A"],
];

const iCTRows: readonly QuestionRow[] = [
  ["What does ICT stand for?", ["Information and Communication Technology", "Integrated Computer Terminal", "Internet Control Technology", "Information Coding Tool"], "A"],
  ["Which device forwards data between different networks?", ["Router", "Keyboard", "Scanner", "Monitor"], "A"],
  ["What is the internet?", ["A global network of interconnected networks", "A single computer program", "A type of printer", "A local folder"], "A"],
  ["What does URL stand for?", ["Uniform Resource Locator", "Universal Router Link", "User Record Location", "Unified Resource Login"], "A"],
  ["Which protocol is commonly used for secure web browsing?", ["HTTPS", "FTP only", "SMTP only", "USB"], "A"],
  ["What is email primarily used for?", ["Sending and receiving electronic messages", "Cooling processors", "Formatting disks", "Printing without a printer"], "A"],
  ["What is a LAN?", ["A network covering a limited local area", "A global satellite only", "A programming language", "A storage format"], "A"],
  ["What is Wi-Fi used for?", ["Wireless network connectivity", "Printing paper directly", "Increasing CPU clock speed", "Cooling a server"], "A"],
  ["What is a modem used for?", ["Connect a local network/device to an internet service through a communications link", "Store files permanently", "Display video", "Scan documents"], "A"],
  ["Which device connects multiple devices within the same Ethernet LAN?", ["Network switch", "Projector", "Scanner", "Microphone"], "A"],
  ["What is an IP address used for?", ["Identify a device/interface on an IP network", "Name a word-processing file only", "Measure storage capacity", "Cool network equipment"], "A"],
  ["What is phishing?", ["A fraudulent attempt to steal sensitive information by pretending to be trustworthy", "A method of compressing images", "A legal software update", "A type of keyboard"], "A"],
  ["What is two-factor authentication?", ["Using two different verification factors to sign in", "Using two usernames only", "Having two monitors", "Installing two browsers"], "A"],
  ["Which service translates domain names into IP addresses?", ["DNS", "USB", "HDMI", "BIOS"], "A"],
  ["What does ISP stand for?", ["Internet Service Provider", "Internal System Program", "Information Storage Protocol", "Integrated Security Port"], "A"],
  ["What is bandwidth?", ["The capacity of a communication link to carry data", "The width of a monitor", "The size of a keyboard", "A file password"], "A"],
  ["What is video conferencing?", ["Real-time audio/video communication over a network", "A method of disk formatting", "A spreadsheet function", "A printer setting"], "A"],
  ["What is e-commerce?", ["Buying and selling goods or services electronically", "Repairing computer hardware only", "Writing source code only", "Creating local folders"], "A"],
  ["What is a database?", ["An organized collection of data", "A network cable", "A CPU fan", "A monitor mode"], "A"],
  ["What is a search engine?", ["A service that helps users find information on the web", "A hard-drive motor", "A programming compiler only", "A Wi-Fi password"], "A"],
  ["What is social media?", ["Online platforms for creating, sharing, and interacting with content and people", "A physical storage device", "A CPU instruction set", "A printer driver"], "A"],
  ["What is cloud computing?", ["Delivering computing services such as storage or processing over a network", "Using only offline calculators", "Printing over USB only", "Replacing RAM with paper"], "A"],
  ["What is cybersecurity?", ["Protecting systems, networks, and data from digital threats", "Designing office furniture", "Increasing screen resolution", "Typing faster"], "A"],
  ["Which is a good practice when receiving an unexpected email attachment?", ["Verify the sender and scan or avoid suspicious attachments", "Open it immediately", "Disable antivirus first", "Forward it to everyone"], "A"],
  ["What is a firewall?", ["A security control that filters network traffic according to rules", "A physical wall around a computer", "A word processor", "A storage folder"], "A"],
  ["What is a website?", ["A collection of related web pages/resources available under a domain or address", "A type of RAM", "A motherboard slot", "A printer queue"], "A"],
  ["What does download mean?", ["Transfer data from a remote system to your device", "Delete a file permanently", "Turn off Wi-Fi", "Send only printed pages"], "A"],
  ["What does upload mean?", ["Transfer data from your device to a remote system", "Restart a computer", "Reduce screen brightness", "Delete browser history"], "A"],
  ["What is digital literacy?", ["The ability to use digital technologies effectively, safely, and critically", "The ability to repair every motherboard", "A measure of internet speed", "A file compression method"], "A"],
  ["Why should software be updated regularly?", ["To receive fixes, security patches, and improvements", "To make passwords shorter", "To remove all backups", "To disable network security"], "A"],
];

export const computerSpecialistSubjects: Subject[] = [
  {
    name: "Computer Hardware",
    id: 101,
    description: "Computer hardware, components, maintenance and peripherals",
    timeLimit: 30,
    questionLimit: 30,
    active: true,
    questions: buildQuestions("Computer Hardware", computerHardwareRows),
  },
  {
    name: "Computer Programming",
    id: 102,
    description: "Programming fundamentals, logic, algorithms and software development",
    timeLimit: 30,
    questionLimit: 30,
    active: true,
    questions: buildQuestions("Computer Programming", computerProgrammingRows),
  },
  {
    name: "General Computer",
    id: 103,
    description: "General computer knowledge, operating systems, files and digital safety",
    timeLimit: 30,
    questionLimit: 30,
    active: true,
    questions: buildQuestions("General Computer", generalComputerRows),
  },
  {
    name: "ICT",
    id: 104,
    description: "Information and Communication Technology, networking, internet and digital services",
    timeLimit: 30,
    questionLimit: 30,
    active: true,
    questions: buildQuestions("ICT", iCTRows),
  },
];
