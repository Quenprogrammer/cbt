import { computerSpecialistSubjects } from './computer-specialist-subjects';
import { ad as admin } from '../firebase';
import { imageQuestionsForSubject } from './image-questions';

export interface Option {
    id: "A" | "B" | "C" | "D"; // IDs for options
    text: string; // Text of the option
}

export interface Question {
    id: number; // Unique ID for the question
    question: string; // The question text
    imageUrl?: string;
    imageAlt?: string;
    options: Option[]; // Array of options
    correctAnswerId: "A" | "B" | "C" | "D"; // Correct option ID
    subject: string; // Subject of the question (e.g., English, Math, Chemistry)
    selectedAnswer?: string;
    visited?: boolean;
}

// Updated subject with name, id, description, and timeLimit fields
export interface Subject {
    name: string;
    id: number;
    description: string; // Description of the subject
    timeLimit: number; // Time limit for the exam in minutes
    questionLimit?: number; // Number of questions served to a candidate
    active?: boolean;
    questions: Question[]; // Questions for the subject
}

// English Questions
const englishQuestions: Question[] = [
    {
        id: 1,
        subject: "English",
        question: "Choose the correct option: She _____ a beautiful dress to the party.",
        options: [
            { id: "A", text: "wear" },
            { id: "B", text: "wore" },
            { id: "C", text: "wears" },
            { id: "D", text: "wearing" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 2,
        subject: "English",
        question: "What is the synonym of 'angry'?",
        options: [
            { id: "A", text: "Furious" },
            { id: "B", text: "Happy" },
            { id: "C", text: "Calm" },
            { id: "D", text: "Excited" }
        ],
        correctAnswerId: "A"
    },
    {
        id: 3,
        subject: "English",
        question: "What is the plural of 'child'?",
        options: [
            { id: "A", text: "Childs" },
            { id: "B", text: "Children" },
            { id: "C", text: "Childes" },
            { id: "D", text: "Childies" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 4,
        subject: "English",
        question: "What is the past tense of 'run'?",
        options: [
            { id: "A", text: "Ran" },
            { id: "B", text: "Runned" },
            { id: "C", text: "Running" },
            { id: "D", text: "Runs" }
        ],
        correctAnswerId: "A"
    },
    {
        id: 5,
        subject: "English",
        question: "Which word is a noun?",
        options: [
            { id: "A", text: "Jump" },
            { id: "B", text: "Happy" },
            { id: "C", text: "Table" },
            { id: "D", text: "Quickly" }
        ],
        correctAnswerId: "C"
    },
    {
        id: 6,
        subject: "English",
        question: "What is the opposite of 'strong'?",
        options: [
            { id: "A", text: "Weak" },
            { id: "B", text: "Fast" },
            { id: "C", text: "Tall" },
            { id: "D", text: "Short" }
        ],
        correctAnswerId: "A"
    },
    {
        id: 7,
        subject: "English",
        question: "Choose the correct article: I saw _____ elephant at the zoo.",
        options: [
            { id: "A", text: "a" },
            { id: "B", text: "an" },
            { id: "C", text: "the" },
            { id: "D", text: "none" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 8,
        subject: "English",
        question: "Which word is an adjective?",
        options: [
            { id: "A", text: "Run" },
            { id: "B", text: "Quick" },
            { id: "C", text: "Dog" },
            { id: "D", text: "Jump" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 9,
        subject: "English",
        question: "What is the comparative form of 'big'?",
        options: [
            { id: "A", text: "Bigger" },
            { id: "B", text: "Biggest" },
            { id: "C", text: "More big" },
            { id: "D", text: "Most big" }
        ],
        correctAnswerId: "A"
    },
    {
        id: 10,
        subject: "English",
        question: "Which sentence is correct?",
        options: [
            { id: "A", text: "She don't like ice cream." },
            { id: "B", text: "He goes to school every day." },
            { id: "C", text: "They is playing outside." },
            { id: "D", text: "I has a big dog." },


        ],
        correctAnswerId: "B"
    },
    {
        id: 11,
        subject: "English",
        question: "Which word is a synonym for 'difficult'?",
        options: [
            { id: "A", text: "Easy" },
            { id: "B", text: "Hard" },
            { id: "C", text: "Simple" },
            { id: "D", text: "Light" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 12,
        subject: "English",
        question: "Which sentence is in the future tense?",
        options: [
            { id: "A", text: "She runs every morning." },
            { id: "B", text: "He ate dinner." },
            { id: "C", text: "They will travel tomorrow." },
            { id: "D", text: "I am reading a book." }
        ],
        correctAnswerId: "C"
    },
    {
        id: 13,
        subject: "English",
        question: "What is the superlative form of 'fast'?",
        options: [
            { id: "A", text: "Faster" },
            { id: "B", text: "Fastest" },
            { id: "C", text: "Most fast" },
            { id: "D", text: "More fast" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 14,
        subject: "English",
        question: "Which word is an adverb?",
        options: [
            { id: "A", text: "Quickly" },
            { id: "B", text: "Beautiful" },
            { id: "C", text: "Table" },
            { id: "D", text: "Soft" }
        ],
        correctAnswerId: "A"
    },
    {
        id: 15,
        subject: "English",
        question: "Choose the correct conjunction: She was tired _____ she finished the project anyway.",
        options: [
            { id: "A", text: "but" },
            { id: "B", text: "so" },
            { id: "C", text: "and" },
            { id: "D", text: "because" }
        ],
        correctAnswerId: "A"
    },
    {
        id: 16,
        subject: "English",
        question: "Which word is a pronoun?",
        options: [
            { id: "A", text: "Jump" },
            { id: "B", text: "She" },
            { id: "C", text: "Happy" },
            { id: "D", text: "Slowly" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 17,
        subject: "English",
        question: "Choose the correct preposition: The book is _____ the table.",
        options: [
            { id: "A", text: "on" },
            { id: "B", text: "under" },
            { id: "C", text: "above" },
            { id: "D", text: "all of the above" }
        ],
        correctAnswerId: "D"
    },
    {
        id: 18,
        subject: "English",
        question: "Which word is a verb?",
        options: [
            { id: "A", text: "Run" },
            { id: "B", text: "Fast" },
            { id: "C", text: "Beautiful" },
            { id: "D", text: "Chair" }
        ],
        correctAnswerId: "A"
    },
    {
        id: 19,
        subject: "English",
        question: "Which sentence is correctly punctuated?",
        options: [
            { id: "A", text: "Its raining outside." },
            { id: "B", text: "It's raining outside." },
            { id: "C", text: "Its' raining outside." },
            { id: "D", text: "It raining outside." }
        ],
        correctAnswerId: "B"
    },
    {
        id: 20,
        subject: "English",
        question: "Which of the following is an interrogative sentence?",
        options: [
            { id: "A", text: "She loves reading." },
            { id: "B", text: "What time is it?" },
            { id: "C", text: "They went to the park." },
            { id: "D", text: "He is very tall." }
        ],
        correctAnswerId: "B"
    }
];

// Math Questions
const mathQuestions: Question[] = [
    {
        id: 1,
        subject: "Math",
        question: "What is 15 - 7?",
        options: [
            { id: "A", text: "5" },
            { id: "B", text: "8" },
            { id: "C", text: "10" },
            { id: "D", text: "12" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 2,
        subject: "Math",
        question: "What is the value of π (pi) rounded to two decimal places?",
        options: [
            { id: "A", text: "3.00" },
            { id: "B", text: "3.14" },
            { id: "C", text: "3.50" },
            { id: "D", text: "4.00" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 3,
        subject: "Math",
        question: "What is 9 × 7?",
        options: [
            { id: "A", text: "56" },
            { id: "B", text: "63" },
            { id: "C", text: "72" },
            { id: "D", text: "81" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 4,
        subject: "Math",
        question: "What is 100 divided by 4?",
        options: [
            { id: "A", text: "20" },
            { id: "B", text: "25" },
            { id: "C", text: "30" },
            { id: "D", text: "40" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 5,
        subject: "Math",
        question: "What is the square of 9?",
        options: [
            { id: "A", text: "18" },
            { id: "B", text: "27" },
            { id: "C", text: "81" },
            { id: "D", text: "99" }
        ],
        correctAnswerId: "C"
    },
    {
        id: 6,
        subject: "Math",
        question: "What is the smallest prime number?",
        options: [
            { id: "A", text: "0" },
            { id: "B", text: "1" },
            { id: "C", text: "2" },
            { id: "D", text: "3" }
        ],
        correctAnswerId: "C"
    },
    {
        id: 7,
        subject: "Math",
        question: "What is 3 to the power of 3 (3³)?",
        options: [
            { id: "A", text: "6" },
            { id: "B", text: "9" },
            { id: "C", text: "27" },
            { id: "D", text: "33" }
        ],
        correctAnswerId: "C"
    },
    {
        id: 8,
        subject: "Math",
        question: "What is the perimeter of a square with sides of length 5?",
        options: [
            { id: "A", text: "10" },
            { id: "B", text: "15" },
            { id: "C", text: "20" },
            { id: "D", text: "25" }
        ],
        correctAnswerId: "C"
    },
    {
        id: 9,
        subject: "Math",
        question: "What is 20% of 150?",
        options: [
            { id: "A", text: "20" },
            { id: "B", text: "30" },
            { id: "C", text: "40" },
            { id: "D", text: "50" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 10,
        subject: "Math",
        question: "If a triangle has angles of 90° and 45°, what is the third angle?",
        options: [
            { id: "A", text: "30°" },
            { id: "B", text: "45°" },
            { id: "C", text: "60°" },
            { id: "D", text: "90°" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 11,
        subject: "Math",
        question: "What is 25 + 17?",
        options: [
            { id: "A", text: "32" },
            { id: "B", text: "42" },
            { id: "C", text: "48" },
            { id: "D", text: "50" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 12,
        subject: "Math",
        question: "What is the cube root of 27?",
        options: [
            { id: "A", text: "2" },
            { id: "B", text: "3" },
            { id: "C", text: "4" },
            { id: "D", text: "5" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 13,
        subject: "Math",
        question: "What is 11 × 6?",
        options: [
            { id: "A", text: "60" },
            { id: "B", text: "66" },
            { id: "C", text: "72" },
            { id: "D", text: "78" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 14,
        subject: "Math",
        question: "What is 81 divided by 9?",
        options: [
            { id: "A", text: "8" },
            { id: "B", text: "9" },
            { id: "C", text: "10" },
            { id: "D", text: "11" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 15,
        subject: "Math",
        question: "What is the square of 8?",
        options: [
            { id: "A", text: "48" },
            { id: "B", text: "56" },
            { id: "C", text: "64" },
            { id: "D", text: "72" }
        ],
        correctAnswerId: "C"
    },
    {
        id:16,
        subject: "Math",
        question: "What is the first prime number greater than 10?",
        options: [
            { id: "A", text: "11" },
            { id: "B", text: "12" },
            { id: "C", text: "13" },
            { id: "D", text: "14" }
        ],
        correctAnswerId: "A"
    },
    {
        id: 17,
        subject: "Math",
        question: "What is 4 to the power of 2 (4²)?",
        options: [
            { id: "A", text: "8" },
            { id: "B", text: "12" },
            { id: "C", text: "16" },
            { id: "D", text: "20" }
        ],
        correctAnswerId: "C"
    },
    {
        id: 18,
        subject: "Math",
        question: "What is the area of a rectangle with length 10 and width 4?",
        options: [
            { id: "A", text: "20" },
            { id: "B", text: "30" },
            { id: "C", text: "40" },
            { id: "D", text: "50" }
        ],
        correctAnswerId: "C"
    },
    {
        id: 19,
        subject: "Math",
        question: "What is 15% of 200?",
        options: [
            { id: "A", text: "20" },
            { id: "B", text: "25" },
            { id: "C", text: "30" },
            { id: "D", text: "35" }
        ],
        correctAnswerId: "C"
    },
    {
        id: 20,
        subject: "Math",
        question: "If a triangle has angles of 60° and 45°, what is the third angle?",
        options: [
            { id: "A", text: "30°" },
            { id: "B", text: "45°" },
            { id: "C", text: "60°" },
            { id: "D", text: "75°" }
        ],
        correctAnswerId: "D"
    }
];

// Chemistry Questions
const chemistryQuestions: Question[] = [
    {
        id: 1,
        subject: "Chemistry",
        question: "What is the chemical formula for water?",
        options: [
            { id: "A", text: "H2O" },
            { id: "B", text: "HO2" },
            { id: "C", text: "H2O2" },
            { id: "D", text: "H2" }
        ],
        correctAnswerId: "A"
    },
    {
        id: 2,
        subject: "Chemistry",
        question: "Which of these elements is a noble gas?",
        options: [
            { id: "A", text: "Oxygen" },
            { id: "B", text: "Nitrogen" },
            { id: "C", text: "Argon" },
            { id: "D", text: "Chlorine" }
        ],
        correctAnswerId: "C"
    },
    {
        id: 3,
        subject: "Chemistry",
        question: "What is the pH of a neutral solution at 25°C?",
        options: [
            { id: "A", text: "7" },
            { id: "B", text: "1" },
            { id: "C", text: "0" },
            { id: "D", text: "14" }
        ],
        correctAnswerId: "A"
    },
    {
        id: 4,
        subject: "Chemistry",
        question: "Which subatomic particle carries a positive charge?",
        options: [
            { id: "A", text: "Neutron" },
            { id: "B", text: "Proton" },
            { id: "C", text: "Electron" },
            { id: "D", text: "Positron" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 5,
        subject: "Chemistry",
        question: "What is the main component of natural gas?",
        options: [
            { id: "A", text: "Methane" },
            { id: "B", text: "Ethane" },
            { id: "C", text: "Propane" },
            { id: "D", text: "Butane" }
        ],
        correctAnswerId: "A"
    },
    {
        id: 6,
        subject: "Chemistry",
        question: "What type of bond is formed when electrons are shared?",
        options: [
            { id: "A", text: "Ionic bond" },
            { id: "B", text: "Covalent bond" },
            { id: "C", text: "Hydrogen bond" },
            { id: "D", text: "Metallic bond" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 7,
        subject: "Chemistry",
        question: "Which gas is responsible for the greenhouse effect?",
        options: [
            { id: "A", text: "Oxygen" },
            { id: "B", text: "Nitrogen" },
            { id: "C", text: "Carbon dioxide" },
            { id: "D", text: "Helium" }
        ],
        correctAnswerId: "C"
    },
    {
        id: 8,
        subject: "Chemistry",
        question: "Which element is represented by the symbol 'Na'?",
        options: [
            { id: "A", text: "Nitrogen" },
            { id: "B", text: "Sodium" },
            { id: "C", text: "Neon" },
            { id: "D", text: "Nickel" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 9,
        subject: "Chemistry",
        question: "Which of these is an alkaline earth metal?",
        options: [
            { id: "A", text: "Calcium" },
            { id: "B", text: "Sodium" },
            { id: "C", text: "Iron" },
            { id: "D", text: "Lead" }
        ],
        correctAnswerId: "A"
    },
    {
        id: 10,
        subject: "Chemistry",
        question: "What is the process by which plants convert sunlight into energy?",
        options: [
            { id: "A", text: "Respiration" },
            { id: "B", text: "Fermentation" },
            { id: "C", text: "Photosynthesis" },
            { id: "D", text: "Combustion" }
        ],
        correctAnswerId: "C"
    },

    {
        id: 11,
        subject: "Chemistry",
        question: "What is the chemical symbol for gold?",
        options: [
            { id: "A", text: "Au" },
            { id: "B", text: "Ag" },
            { id: "C", text: "Pb" },
            { id: "D", text: "Fe" }
        ],
        correctAnswerId: "A"
    },
    {
        id: 12,
        subject: "Chemistry",
        question: "What is the most abundant gas in Earth's atmosphere?",
        options: [
            { id: "A", text: "Oxygen" },
            { id: "B", text: "Carbon dioxide" },
            { id: "C", text: "Nitrogen" },
            { id: "D", text: "Helium" }
        ],
        correctAnswerId: "C"
    },
    {
        id: 13,
        subject: "Chemistry",
        question: "What is the common name for sodium chloride?",
        options: [
            { id: "A", text: "Baking soda" },
            { id: "B", text: "Table salt" },
            { id: "C", text: "Vinegar" },
            { id: "D", text: "Sugar" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 14,
        subject: "Chemistry",
        question: "Which acid is commonly found in lemons?",
        options: [
            { id: "A", text: "Acetic acid" },
            { id: "B", text: "Citric acid" },
            { id: "C", text: "Sulfuric acid" },
            { id: "D", text: "Hydrochloric acid" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 15,
        subject: "Chemistry",
        question: "What is the chemical formula for ozone?",
        options: [
            { id: "A", text: "O" },
            { id: "B", text: "O2" },
            { id: "C", text: "O3" },
            { id: "D", text: "CO2" }
        ],
        correctAnswerId: "C"
    },
    {
        id: 16,
        subject: "Chemistry",
        question: "Which metal is liquid at room temperature?",
        options: [
            { id: "A", text: "Mercury" },
            { id: "B", text: "Iron" },
            { id: "C", text: "Aluminum" },
            { id: "D", text: "Lead" }
        ],
        correctAnswerId: "A"
    },
    {
        id: 17,
        subject: "Chemistry",
        question: "Which gas is used in balloons to make them float?",
        options: [
            { id: "A", text: "Hydrogen" },
            { id: "B", text: "Oxygen" },
            { id: "C", text: "Nitrogen" },
            { id: "D", text: "Helium" }
        ],
        correctAnswerId: "D"
    },
    {
        id: 18,
        subject: "Chemistry",
        question: "Which element is necessary for combustion?",
        options: [
            { id: "A", text: "Hydrogen" },
            { id: "B", text: "Oxygen" },
            { id: "C", text: "Carbon" },
            { id: "D", text: "Nitrogen" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 19,
        subject: "Chemistry",
        question: "What is the chemical formula for sulfuric acid?",
        options: [
            { id: "A", text: "HCl" },
            { id: "B", text: "H2SO4" },
            { id: "C", text: "HNO3" },
            { id: "D", text: "CH3COOH" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 20,
        subject: "Chemistry",
        question: "What is the hardest naturally occurring substance on Earth?",
        options: [
            { id: "A", text: "Graphite" },
            { id: "B", text: "Diamond" },
            { id: "C", text: "Quartz" },
            { id: "D", text: "Topaz" }
        ],
        correctAnswerId: "B"
    },
    {
        id: 21,
        subject: "Chemistry",
        question: "What is the chemical name for quicklime?",
        options: [
            { id: "A", text: "Calcium carbonate" },
            { id: "B", text: "Calcium oxide" },
            { id: "C", text: "Calcium hydroxide" },
            { id: "D", text: "Calcium sulfate" }
        ],
        correctAnswerId: "B"
    }
];

// Computer Questions
const computerQuestion: Question[] = [
    {
        id: 1,
        question: "What is the time complexity of binary search?",
        options: [
            { id: "A", text: "O(n)" },
            { id: "B", text: "O(log n)" },
            { id: "C", text: "O(n^2)" },
            { id: "D", text: "O(1)" },
        ],
        correctAnswerId: "B",
        subject: "Algorithms",
    },
    {
        id: 2,
        question: "Which data structure is used in Depth First Search (DFS)?",
        options: [
            { id: "A", text: "Queue" },
            { id: "B", text: "Stack" },
            { id: "C", text: "Array" },
            { id: "D", text: "Hash Table" },
        ],
        correctAnswerId: "B",
        subject: "Data Structures",
    },
    {
        id: 3,
        question: "Which of the following is not a programming paradigm?",
        options: [
            { id: "A", text: "Functional" },
            { id: "B", text: "Object-Oriented" },
            { id: "C", text: "Procedural" },
            { id: "D", text: "Binary" },
        ],
        correctAnswerId: "D",
        subject: "Programming Paradigms",
    },
    {
        id: 4,
        question: "In a relational database, what does SQL stand for?",
        options: [
            { id: "A", text: "Structured Query Language" },
            { id: "B", text: "Simple Query Logic" },
            { id: "C", text: "Standard Query Language" },
            { id: "D", text: "Sequential Query Language" },
        ],
        correctAnswerId: "A",
        subject: "Databases",
    },
    {
        id: 5,
        question: "Which sorting algorithm has the worst-case time complexity of O(n log n)?",
        options: [
            { id: "A", text: "Bubble Sort" },
            { id: "B", text: "Quick Sort" },
            { id: "C", text: "Merge Sort" },
            { id: "D", text: "Selection Sort" },
        ],
        correctAnswerId: "C",
        subject: "Algorithms",
    },
    {
        id: 6,
        question: "What is the main feature of an object in Object-Oriented Programming?",
        options: [
            { id: "A", text: "Inheritance" },
            { id: "B", text: "Polymorphism" },
            { id: "C", text: "Encapsulation" },
            { id: "D", text: "All of the above" },
        ],
        correctAnswerId: "D",
        subject: "Object-Oriented Programming",
    },
    {
        id: 7,
        question: "What is the primary purpose of an operating system?",
        options: [
            { id: "A", text: "To execute JavaScript" },
            { id: "B", text: "To manage hardware and software resources" },
            { id: "C", text: "To connect to the internet" },
            { id: "D", text: "To compile code" },
        ],
        correctAnswerId: "B",
        subject: "Operating Systems",
    },
    {
        id: 8,
        question: "What does the acronym HTTP stand for?",
        options: [
            { id: "A", text: "Hyper Text Transfer Protocol" },
            { id: "B", text: "High-Level Transfer Protocol" },
            { id: "C", text: "Hyperlink Text Transmission Protocol" },
            { id: "D", text: "High Text Transfer Protocol" },
        ],
        correctAnswerId: "A",
        subject: "Networking",
    },
    {
        id: 9,
        question: "Which principle does a blockchain rely on?",
        options: [
            { id: "A", text: "Centralized databases" },
            { id: "B", text: "Distributed ledger technology" },
            { id: "C", text: "Single-server operations" },
            { id: "D", text: "Hierarchical architecture" },
        ],
        correctAnswerId: "B",
        subject: "Blockchain",
    },
    {
        id: 10,
        question: "What is the difference between TCP and UDP?",
        options: [
            { id: "A", text: "TCP is connectionless, UDP is connection-oriented" },
            { id: "B", text: "TCP is reliable, UDP is unreliable" },
            { id: "C", text: "TCP is faster than UDP" },
            { id: "D", text: "TCP does not support error checking, UDP does" },
        ],
        correctAnswerId: "B",
        subject: "Networking",
    },
    {
        id: 11,
        question: "What does CPU stand for?",
        options: [
            { id: "A", text: "Central Processing Unit" },
            { id: "B", text: "Computer Processing Unit" },
            { id: "C", text: "Central Power Unit" },
            { id: "D", text: "Core Processing Utility" },
        ],
        correctAnswerId: "A",
        subject: "Computer Science",
    },
    {
        id: 12,
        question: "Which type of memory is volatile?",
        options: [
            { id: "A", text: "ROM" },
            { id: "B", text: "RAM" },
            { id: "C", text: "Hard Drive" },
            { id: "D", text: "Flash Memory" },
        ],
        correctAnswerId: "B",
        subject: "Computer Science",
    },
    {
        id: 13,
        question: "What is the primary function of an operating system?",
        options: [
            { id: "A", text: "To manage hardware and software resources" },
            { id: "B", text: "To browse the internet" },
            { id: "C", text: "To run applications only" },
            { id: "D", text: "To compile code" },
        ],
        correctAnswerId: "A",
        subject: "Operating Systems",
    },
    {
        id: 14,
        question: "Which of the following is an example of an input device?",
        options: [
            { id: "A", text: "Monitor" },
            { id: "B", text: "Printer" },
            { id: "C", text: "Keyboard" },
            { id: "D", text: "Speaker" },
        ],
        correctAnswerId: "C",
        subject: "Hardware",
    },
    {
        id: 15,
        question: "Which programming language is known for its use in web development?",
        options: [
            { id: "A", text: "Java" },
            { id: "B", text: "Python" },
            { id: "C", text: "JavaScript" },
            { id: "D", text: "C++" },
        ],
        correctAnswerId: "C",
        subject: "Programming",
    },
    {
        id: 16,
        question: "What does HTML stand for?",
        options: [
            { id: "A", text: "HyperText Markup Language" },
            { id: "B", text: "High-level Text Management Language" },
            { id: "C", text: "Hyperlink and Text Marking Language" },
            { id: "D", text: "Hyper Transfer Markup Language" },
        ],
        correctAnswerId: "A",
        subject: "Web Development",
    },
    {
        id: 17,
        question: "What is the purpose of a firewall in a computer network?",
        options: [
            { id: "A", text: "To speed up internet connection" },
            { id: "B", text: "To block unauthorized access" },
            { id: "C", text: "To store passwords" },
            { id: "D", text: "To connect multiple networks" },
        ],
        correctAnswerId: "B",
        subject: "Networking",
    },
    {
        id: 18,
        question: "Which file format is commonly used for storing images?",
        options: [
            { id: "A", text: "MP3" },
            { id: "B", text: "JPEG" },
            { id: "C", text: "TXT" },
            { id: "D", text: "DOC" },
        ],
        correctAnswerId: "B",
        subject: "Computer Applications",
    },
    {
        id: 19,
        question: "Which company developed the Windows operating system?",
        options: [
            { id: "A", text: "Apple" },
            { id: "B", text: "Microsoft" },
            { id: "C", text: "Google" },
            { id: "D", text: "IBM" },
        ],
        correctAnswerId: "B",
        subject: "Technology",
    },
    {
        id: 20,
        question: "Which of the following is an example of cloud storage?",
        options: [
            { id: "A", text: "USB Drive" },
            { id: "B", text: "Google Drive" },
            { id: "C", text: "Hard Disk" },
            { id: "D", text: "CD-ROM" },
        ],
        correctAnswerId: "B",
        subject: "Cloud Computing",
    },
];

function createSeedQuestions(
    subject: string,
    rows: Array<{ question: string; options: [string, string, string, string]; correct: "A" | "B" | "C" | "D" }>
): Question[] {
    return rows.map((row, index) => ({
        id: index + 1,
        subject,
        question: row.question,
        options: [
            { id: "A", text: row.options[0] },
            { id: "B", text: row.options[1] },
            { id: "C", text: row.options[2] },
            { id: "D", text: row.options[3] },
        ],
        correctAnswerId: row.correct,
    }));
}

const extraSubjects: Subject[] = [
    {
        name: "Physics",
        id: 9,
        description: "Physics Exam",
        timeLimit: 45,
        questionLimit: 5,
        active: true,
        questions: createSeedQuestions("Physics", [
            { question: "What is the SI unit of force?", options: ["Newton", "Joule", "Watt", "Pascal"], correct: "A" },
            { question: "Which instrument measures electric current?", options: ["Voltmeter", "Ammeter", "Thermometer", "Barometer"], correct: "B" },
            { question: "The speed of light is approximately?", options: ["3 × 10^8 m/s", "3 × 10^6 m/s", "300 m/s", "30,000 m/s"], correct: "A" },
            { question: "Energy possessed by a moving body is called?", options: ["Potential energy", "Chemical energy", "Kinetic energy", "Heat energy"], correct: "C" },
            { question: "Which simple machine is a sloping surface?", options: ["Lever", "Pulley", "Inclined plane", "Wheel and axle"], correct: "C" },
        ]),
    },
    {
        name: "Biology",
        id: 10,
        description: "Biology Exam",
        timeLimit: 40,
        questionLimit: 5,
        active: true,
        questions: createSeedQuestions("Biology", [
            { question: "What is the basic unit of life?", options: ["Tissue", "Cell", "Organ", "System"], correct: "B" },
            { question: "Which organ pumps blood around the body?", options: ["Liver", "Kidney", "Heart", "Lung"], correct: "C" },
            { question: "Green plants manufacture food by?", options: ["Respiration", "Photosynthesis", "Transpiration", "Digestion"], correct: "B" },
            { question: "Which blood cells help fight infection?", options: ["Red blood cells", "Platelets", "White blood cells", "Plasma"], correct: "C" },
            { question: "The transfer of pollen from anther to stigma is called?", options: ["Fertilization", "Pollination", "Germination", "Respiration"], correct: "B" },
        ]),
    },
    {
        name: "Economics",
        id: 11,
        description: "Economics Exam",
        timeLimit: 40,
        questionLimit: 5,
        active: true,
        questions: createSeedQuestions("Economics", [
            { question: "The basic economic problem is?", options: ["Inflation", "Scarcity", "Taxation", "Unemployment"], correct: "B" },
            { question: "A market with one seller is called?", options: ["Monopoly", "Oligopoly", "Perfect competition", "Monopsony"], correct: "A" },
            { question: "Money used to start or expand a business is known as?", options: ["Rent", "Capital", "Wage", "Interest"], correct: "B" },
            { question: "Demand generally increases when price?", options: ["Rises", "Falls", "Doubles", "Is fixed by law"], correct: "B" },
            { question: "Which institution is responsible for monetary policy in Nigeria?", options: ["Central Bank of Nigeria", "Federal Inland Revenue Service", "Nigerian Ports Authority", "National Bureau of Statistics"], correct: "A" },
        ]),
    },
    {
        name: "Civic Education",
        id: 12,
        description: "Civic Education Exam",
        timeLimit: 30,
        questionLimit: 5,
        active: true,
        questions: createSeedQuestions("Civic Education", [
            { question: "A citizen's legal membership of a country is called?", options: ["Citizenship", "Leadership", "Federalism", "Democracy"], correct: "A" },
            { question: "Which is a responsibility of a good citizen?", options: ["Obeying lawful rules", "Destroying public property", "Avoiding taxes", "Ignoring elections"], correct: "A" },
            { question: "The rule of law means?", options: ["Only leaders obey the law", "Everyone is subject to the law", "Courts have no authority", "Citizens make private laws"], correct: "B" },
            { question: "Voting is a form of?", options: ["Civic participation", "Punishment", "Private ownership", "Migration"], correct: "A" },
            { question: "Public property should be?", options: ["Protected and used responsibly", "Damaged during disputes", "Used only by officials", "Sold without permission"], correct: "A" },
        ]),
    },
];

// Updated subjects with unique ids and time limits
const subjects: Subject[] = [
    {
        name: "English",
        questions: englishQuestions,
        id: 1,
        description: 'English Language Exam',
        timeLimit: 30 // 30 minutes
    },
    {
        name: "Math",
        questions: mathQuestions,
        id: 2,
        description: 'Mathematics Exam',
        timeLimit: 45 // 45 minutes
    },
    {
        name: "Chemistry",
        questions: chemistryQuestions,
        id: 3,
        description: 'Chemistry Exam',
        timeLimit: 60 // 60 minutes
    },
    {
        name: "Computer",
        questions: computerQuestion,
        id: 4,
        description: 'Computer Science Exam',
        timeLimit: 90 // 90 minutes
    },
    ...computerSpecialistSubjects,
    ...extraSubjects
];

// Firestore Function to Add Questions by Subject
export async function addMultipleExams() {
    for (const subject of subjects) {
        const questions = [...subject.questions, ...imageQuestionsForSubject(subject.name)];
        const subjectDocRef = await admin.firestore()
            .collection('subjects')
            .add({
                name: subject.name,
                description: subject.description,
                timeLimit: subject.timeLimit,
                questionLimit: subject.questionLimit ?? questions.length,
                active: subject.active ?? true,
            });

        const writes = questions.map((question) =>
            subjectDocRef.collection('exams').add(question)
        );
        await Promise.all(writes);
        console.log(`Seeded ${subject.name}: ${questions.length} questions (including image questions)`);
    }
}
