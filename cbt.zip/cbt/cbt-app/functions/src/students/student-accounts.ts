import * as admin from 'firebase-admin';
import { FieldValue } from 'firebase-admin/firestore';
import { HttpsError, onCall } from 'firebase-functions/v2/https';
import { createHash } from 'node:crypto';
import { getTenantAccessForAuth } from '../tenant/tenant-access';

interface RegistrationSubject{id:string;name:string;description:string;class:string;timeLimit:number;questionLimit:number}
function cleanText(v:unknown,max=160){return String(v??'').trim().slice(0,max)}
function requiredText(v:unknown,name:string,max=160){const s=cleanText(v,max);if(!s)throw new HttpsError('invalid-argument',name+' is required.');return s;}
function slug(v:unknown){return cleanText(v,80).toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,60)}
const MAX_REGISTERED_SUBJECTS=11;
function normalizeSubjectIds(v:unknown){if(!Array.isArray(v))return[];return [...new Set(v.map(x=>cleanText(x,120)).filter(Boolean))].slice(0,30)}
function checkAccess(data:FirebaseFirestore.DocumentData):void {
  if(data.locked || data.accessStatus==='disabled' || ['suspended','cancelled','deleted'].includes(data.status))
    throw new HttpsError('permission-denied',String(data.statusReason||'This institution is not currently accepting access.'));
}
async function publicTenantByCode(value:unknown){
  const tenantId=slug(value);if(!tenantId)throw new HttpsError('invalid-argument','Enter your institution code.');
  const snap=await admin.firestore().doc('tenants/'+tenantId).get();if(!snap.exists)throw new HttpsError('not-found','The institution code was not found.');
  const data=snap.data()!;checkAccess(data);return{tenantId,data};
}
export const resolveRegistrationTenant=onCall({cors:true},async request=>{
  const t=await publicTenantByCode(request.data?.tenantCode);
  return{tenantId:t.tenantId,name:String(t.data.name??t.tenantId),shortName:String(t.data.shortName??''),tenantCode:String(t.data.tenantCode??request.data?.tenantCode),status:String(t.data.status??'active')};
});
export const listRegistrationSubjects=onCall({cors:true},async request=>{
  let tenantId:string;
  if(cleanText(request.data?.tenantCode)){
    const selected=await publicTenantByCode(request.data.tenantCode);tenantId=selected.tenantId;
    if(selected.data.modules?.students===false || selected.data.modules?.subjects===false)throw new HttpsError('permission-denied','Student registration is not enabled for this institution.');
    const claimed=cleanText(request.auth?.token.tenantId);
    if(claimed && claimed!==tenantId)throw new HttpsError('permission-denied','This account belongs to a different institution.');
  }else tenantId=(await getTenantAccessForAuth(request.auth)).tenantId;
  const snapshot=await admin.firestore().collection('tenants/'+tenantId+'/subjects').get();
  const subjects:RegistrationSubject[]=snapshot.docs.filter(d=>d.data().active!==false).map(d=>{const x=d.data();return{id:d.id,name:cleanText(x.name,120),description:cleanText(x.description,240),class:cleanText(x.class,80),timeLimit:Math.max(Number(x.timeLimit??30)||30,1),questionLimit:Math.max(Number(x.questionLimit??20)||20,1)}}).sort((a,b)=>a.name.localeCompare(b.name));
  return{tenantId,subjects};
});
export const registerStudent=onCall({cors:true},async request=>{
  if(!request.auth)throw new HttpsError('unauthenticated','Create or sign in to your account first.');
  const uid=request.auth.uid,user=await admin.auth().getUser(uid),existingRole=user.customClaims?.['role'];
  if(existingRole && existingRole!=='student')throw new HttpsError('permission-denied','This account cannot be converted to a student account.');
  if(!existingRole && (!user.emailVerified || request.auth.token.email_verified!==true))throw new HttpsError('failed-precondition','Verify your email before completing registration.');
  const database=admin.firestore();
  if((await database.doc('platformAdmins/'+uid).get()).exists)throw new HttpsError('permission-denied','Use a student account for registration.');
  const tenant=await publicTenantByCode(request.data?.tenantCode||user.customClaims?.['tenantId']),tenantId=tenant.tenantId;
  if(user.customClaims?.['tenantId'] && user.customClaims['tenantId']!==tenantId)throw new HttpsError('permission-denied','This student account belongs to a different institution.');
  const email=cleanText(user.email,200).toLowerCase();if(!email)throw new HttpsError('failed-precondition','An email address is required.');
  const subjectIds=normalizeSubjectIds(request.data?.subjectIds);
  if(!subjectIds.length||subjectIds.length>MAX_REGISTERED_SUBJECTS)throw new HttpsError('invalid-argument','Choose between 1 and 11 subjects.');
  const data=request.data??{};
  const profile={admissionNumber:requiredText(data.admissionNumber,'Admission number',80),firstname:requiredText(data.firstname,'First name',100),middlename:cleanText(data.middlename,100),lastname:requiredText(data.lastname,'Last name',100),gender:requiredText(data.gender,'Gender',40),dateOfBirth:requiredText(data.dateOfBirth,'Date of birth',40),department:requiredText(data.department,'Department / class',100),classLevel:cleanText(data.classLevel,80),enrollmentDate:cleanText(data.enrollmentDate,40),phone:cleanText(data.phone,60),address:cleanText(data.address,300),stateOfOrigin:cleanText(data.stateOfOrigin,100),lga:cleanText(data.lga,100),guardianName:cleanText(data.guardianName,160),guardianPhone:cleanText(data.guardianPhone,60),guardianEmail:cleanText(data.guardianEmail,200).toLowerCase(),emergencyContact:cleanText(data.emergencyContact,80),bloodGroup:cleanText(data.bloodGroup,20),genotype:cleanText(data.genotype,20),notes:cleanText(data.notes,500)};
  const photoURL=cleanText(data.photoURL,1500),root=database.doc('tenants/'+tenantId);
  const binding=database.doc('studentAccountBindings/'+uid),admissionRef=root.collection('studentAdmissions').doc(createHash('sha256').update(profile.admissionNumber.toLowerCase()).digest('hex'));
  let studentId='';
  let registeredSubjects:string[]=[];
  await database.runTransaction(async tx=>{
    const [fresh,bound,admissionIndex,admission,existing,accountDoc]=await Promise.all([
      tx.get(root),tx.get(binding),tx.get(admissionRef),tx.get(root.collection('student').where('admissionNumber','==',profile.admissionNumber).limit(2)),
      tx.get(root.collection('student').where('authUid','==',uid).limit(2)),tx.get(root.collection('users').doc(uid))
    ]);
    const td=fresh.data();if(!td)throw new HttpsError('not-found','Institution not found.');checkAccess(td);
    if(td.modules?.students===false || td.modules?.subjects===false)throw new HttpsError('permission-denied','Student registration is not enabled.');
    if(bound.exists && bound.data()?.['tenantId']!==tenantId)throw new HttpsError('permission-denied','This account is already registered with another institution.');
    if(admissionIndex.exists && admissionIndex.data()?.['uid']!==uid)throw new HttpsError('already-exists','This admission number is already registered.');
    if(existing.size>1 || admission.size>1)throw new HttpsError('failed-precondition','Duplicate student records require administrator review.');
    const match=existing.docs[0] ?? admission.docs[0],old=match?.data() ?? {};
    if(old.authUid && old.authUid!==uid)throw new HttpsError('already-exists','This admission number belongs to another account.');
    if(!old.authUid && old.email && cleanText(old.email,200).toLowerCase()!==email)throw new HttpsError('permission-denied','Contact your institution to link this admission number to your email.');
    const lim=Number(td.limits?.students ?? 500),userLimit=Number(td.limits?.users ?? 30);
    if(!Number.isInteger(lim)||lim<1||!Number.isInteger(userLimit)||userLimit<1)throw new HttpsError('failed-precondition','Institution capacity is not configured.');
    const [validSubjects,candidates,accounts]=await Promise.all([
      Promise.all(subjectIds.map(id=>tx.get(root.collection('subjects').doc(id)))),
      match ? Promise.resolve(null) : tx.get(root.collection('student').select().limit(lim)),
      accountDoc.exists ? Promise.resolve(null) : tx.get(root.collection('users').select().limit(userLimit))
    ]);
    if(candidates && candidates.size>=lim)throw new HttpsError('resource-exhausted','This institution has reached its student limit.');
    if(accounts && accounts.size>=userLimit)throw new HttpsError('resource-exhausted','This institution has reached its user account limit.');
    if(validSubjects.some(s=>!s.exists||s.data()?.['active']===false))throw new HttpsError('failed-precondition','One or more selected subjects are no longer available.');
    const names=validSubjects.map(s=>cleanText(s.data()?.['name'],120));
    registeredSubjects=names;
    const studentRef=match?.ref ?? root.collection('student').doc(uid);studentId=studentRef.id;
    const now=FieldValue.serverTimestamp();
    tx.set(studentRef,{...profile,email,loginEmail:email,authUid:uid,status:cleanText(old.status,40)||'Active',examStatus:cleanText(old.examStatus,40)||'Not Started',registeredSubjectIds:subjectIds,registeredSubjects:names,photoURL:photoURL||cleanText(old.photoURL,1500),updatedAt:now,createdAt:old.createdAt??now},{merge:true});
    tx.set(root.collection('users').doc(uid),{uid,email,displayName:[profile.firstname,profile.lastname].join(' '),role:'student',studentId,status:accountDoc.data()?.['status']??'active',registeredSubjectIds:subjectIds,registeredSubjects:names,photoURL:photoURL||cleanText(old.photoURL,1500),updatedAt:now,createdAt:accountDoc.data()?.['createdAt']??now},{merge:true});
    tx.set(root.collection('examRegistrations').doc(uid),{studentId,studentAuthUid:uid,studentEmail:email,subjectIds,subjectNames:names,status:'registered',examStatus:cleanText(old.examStatus,40)||'Not Started',registeredAt:now,updatedAt:now},{merge:true});
    tx.set(database.doc('userTenancies/'+uid+'/tenants/'+tenantId),{tenantId,tenantName:String(td.name??tenantId),shortName:String(td.shortName??''),role:'student',status:'active',updatedAt:now,createdAt:accountDoc.data()?.['createdAt']??now},{merge:true});
    tx.set(binding,{tenantId,studentId,updatedAt:now});
    tx.set(admissionRef,{uid,studentId,updatedAt:now});
    // Serializes public registrations against the same institution, even while usage triggers lag.
    tx.update(root,{registrationSequence:FieldValue.increment(1)});
  });
  await admin.auth().setCustomUserClaims(uid,{...user.customClaims,role:'student',tenantId});
  return{studentId,tenantId,role:'student',registeredSubjectIds:subjectIds,registeredSubjects,tokenRefreshRequired:true};
});
