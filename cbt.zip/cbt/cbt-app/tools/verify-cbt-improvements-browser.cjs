// Local UI regression test. Requires the app at :4200 and Firebase emulators.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const puppeteer = require('../functions/node_modules/puppeteer');
const { ad: admin } = require('../functions/lib/seed/firebase');
const db = admin.firestore(), suffix = Date.now().toString(36), tenantId = 'qa-cbt-ui-' + suffix;
const root = db.doc('tenants/' + tenantId), subject = root.collection('subjects').doc('math');
const users = [], output = path.resolve(__dirname, '../artifacts/cbt-improvements');
let browser;
const watchdog = setTimeout(() => { console.error('Browser regression exceeded its time limit.'); if (browser) browser.process()?.kill(); }, 180000);
watchdog.unref();
async function account(role) {
  const email = `${tenantId}-${role}@cbt.test`;
  const user = await admin.auth().createUser({ email, password: 'Improvement123!', emailVerified: true });
  users.push(user.uid); await admin.auth().setCustomUserClaims(user.uid, { role, tenantId });
  await root.collection('users').doc(user.uid).set({ role, email });
  return user;
}
async function clickText(page, selector, text) {
  for (const handle of await page.$$(selector)) if ((await handle.evaluate(el => el.textContent.trim())) === text) { await handle.evaluate(el => el.scrollIntoView({ block: 'center', inline: 'center' })); await handle.click(); return; }
  throw new Error(`Cannot find ${selector}: ${text}`);
}
async function login(page, user, destination) {
  await page.goto('http://127.0.0.1:4200/authentication');
  await page.waitForSelector('#signinSrEmail'); await page.type('#signinSrEmail', user.email); await page.type('#signupSrPassword', 'Improvement123!'); await page.click('button[type=submit]');
  await page.waitForFunction(expected => location.pathname.startsWith(expected), { timeout: 30000 }, destination);
}
async function main() {
  fs.mkdirSync(output, { recursive: true });
  try {
    await root.set({ name: 'CBT improvement browser QA', shortName: 'QA', tenantCode: tenantId, status: 'active', accessStatus: 'enabled', locked: false, modules: { subjects: true, exams: true, results: true, students: true, staff: true, notifications: true, exports: true, publicResults: true }, limits: { subjects: 20, monthlyAttempts: 100 }, usage: { subjects: 1, monthlyAttempts: 0 }, address: 'QA', email: 'qa@cbt.test', phone: '08000000000', timezone: 'Africa/Lagos', currency: 'NGN' });
    await subject.set({ name: 'Math', active: true, questionLimit: 2, timeLimit: 10 });
    const teacher = await account('admin'), student = await account('student');
    await root.collection('student').doc(student.uid).set({ authUid: student.uid, firstname: 'QA', lastname: 'Student', admissionNumber: 'QA-01', department: 'SS2', registeredSubjectIds: ['math'], examStatus: 'Started' });
    browser = await puppeteer.launch({ headless: true });
    const page = await browser.newPage(); await page.setViewport({ width: 1440, height: 1080 });
    page.setDefaultTimeout(20000); page.setDefaultNavigationTimeout(20000);
    await login(page, teacher, '/admin');
    await page.goto('http://127.0.0.1:4200/admin/view-exam/math');
    await page.waitForSelector('app-question-import');
    await clickText(page, 'summary', 'Import questions');
    const csv = path.join(output, 'questions.csv');
    fs.writeFileSync(csv, 'question,optionA,optionB,correctAnswerId,topic,difficulty,className\r\nWhat is 1+1?,2,3,Z,Algebra,easy,SS2\r\nHow many sides has a triangle?,3,4,A,Geometry,medium,SS2\r\n');
    await (await page.$('app-question-import input[type=file]')).uploadFile(csv);
    await page.waitForSelector('#import-2-correctAnswerId');
    await page.$eval('#import-2-correctAnswerId', el => { el.value = ''; el.dispatchEvent(new Event('input', { bubbles: true })); });
    await page.type('#import-2-correctAnswerId', 'A');
    await clickText(page, 'app-question-import button', 'Validate edited rows');
    await page.waitForFunction(() => document.querySelector('app-question-import').textContent.includes('0 invalid'));
    await clickText(page, 'app-question-import button', 'Import questions');
    await page.waitForFunction(() => document.querySelector('app-question-import').textContent.includes('Imported 2 questions.'));
    assert.equal((await subject.collection('exams').get()).size, 2);
    await page.select('select[aria-label="Filter by topic"]', 'Algebra');
    await page.waitForFunction(() => document.querySelectorAll('app-view-exam table tbody tr').length === 1);
    assert.equal(await page.$$eval('app-view-exam table tbody tr', rows => rows.length), 1);
    await page.select('select[aria-label="Filter by topic"]', '');
    await clickText(page, 'summary', 'Configure exam blueprint');
    await page.click('app-exam-blueprint input[type=checkbox]');
    await clickText(page, 'app-exam-blueprint button', 'Add quota');
    await page.waitForSelector('#blueprint-topic-0');
    await page.select('#blueprint-topic-0', 'Algebra'); await page.select('#blueprint-level-0', 'easy');
    await clickText(page, 'app-exam-blueprint button', 'Add quota');
    await page.waitForSelector('#blueprint-topic-1');
    await page.select('#blueprint-topic-1', 'Geometry'); await page.select('#blueprint-level-1', 'medium');
    await clickText(page, 'app-exam-blueprint button', 'Save blueprint');
    await page.waitForFunction(() => document.querySelector('app-exam-blueprint').textContent.includes('Blueprint saved.'));
    assert.equal((await subject.get()).data().blueprint.rows.length, 2);
    await page.screenshot({ path: path.join(output, 'question-bank.png'), fullPage: true });
    const imported = await subject.collection('exams').get();
    for (const [i, score] of [1, 2].entries()) await root.collection('results').doc('historical-' + i).set({ id: 'historical-' + i, tenantId, studentId: student.uid, studentEmail: student.email, studentDetails: { firstname: 'QA', lastname: 'Student', department: 'SS2', admissionNumber: 'QA-01' }, className: 'SS2', score, totalQuestions: 2, unanswered: 0, submittedAtIso: `2026-10-0${i + 1}T12:00:00Z`, subjectResults: [{ subjectId: 'math', subjectName: 'Math', score, totalQuestions: 2, unanswered: 0 }], questionAnalysis: [{ subjectId: 'math', subjectName: 'Math', questionId: imported.docs[0].id, question: 'Historical QA question', topic: 'Algebra', isCorrect: i > 0, timeSpentSeconds: 10 }] });
    await page.goto('http://127.0.0.1:4200/admin/performance');
    await page.waitForFunction(() => [...document.querySelectorAll('.metric')].map(el => el.textContent).includes('75%'));
    await page.screenshot({ path: path.join(output, 'analytics.png'), fullPage: true });
    console.log('Browser import correction, organization filters, blueprint configuration and analytics passed.');

    const context = await browser.createBrowserContext(), candidate = await context.newPage();
    candidate.setDefaultTimeout(20000); candidate.setDefaultNavigationTimeout(20000);
    await candidate.setViewport({ width: 1440, height: 1080 }); await login(candidate, student, '/home');
    console.log('Student sign-in passed.');
    await candidate.goto('http://127.0.0.1:4200/student/exam');
    await candidate.waitForSelector('.accept-row input'); await candidate.click('.accept-row input'); await clickText(candidate, 'button', 'Begin exam');
    await candidate.waitForSelector('.option-row input'); await candidate.click('.option-row');
    await candidate.waitForSelector('.option-row input:checked');
    await candidate.waitForFunction(() => document.body.textContent.includes('Answers synchronized.'));
    console.log('Initial student answer synchronized.');
    await candidate.reload({ waitUntil: 'domcontentloaded' }); await candidate.waitForSelector('.accept-row input'); await candidate.click('.accept-row input'); await clickText(candidate, 'button', 'Begin exam');
    await candidate.waitForSelector('.option-row input:checked');
    console.log('Student answer restored after reload.');
    assert.equal((await root.collection('examAssignments').get()).size, 1);
    await candidate.setOfflineMode(true); await clickText(candidate, '.question-actions button', 'Next →');
    await candidate.waitForFunction(() => document.querySelector('.question-number')?.textContent.includes('Question 2 of 2'));
    await candidate.click('.option-row');
    await candidate.waitForFunction(() => document.body.textContent.includes('waiting to synchronize'));
    await clickText(candidate, '.submit-bar button', 'Submit all subjects'); await clickText(candidate, '.confirm-dialog button', 'Submit now');
    await candidate.waitForFunction(() => document.body.textContent.includes('Submission is queued on this device'));
    const cacheKey = `cbt.exam.v2.${tenantId}.${student.uid}`;
    assert.equal(await candidate.evaluate(key => JSON.parse(localStorage.getItem(key)).pendingSubmission, cacheKey), true);
    assert.equal(await candidate.evaluate(key => Object.keys(JSON.parse(localStorage.getItem(key)).answers).length, cacheKey), 2);
    await candidate.screenshot({ path: path.join(output, 'offline-submission.png'), fullPage: true });
    await candidate.setOfflineMode(false);
    await candidate.waitForSelector('.submission-card', { timeout: 40000 });
    assert.equal(await candidate.evaluate(key => localStorage.getItem(key), cacheKey), null);
    const assignments = await root.collection('examAssignments').get();
    assert.equal(assignments.docs[0].data().status, 'submitted');
    assert.equal((await root.collection('results').get()).size, 3);
    console.log('Browser reload recovery, offline answer queue and automatic submission retry passed.');
  } catch (error) {
    if (browser) {
      const pages = await browser.pages();
      for (const [index, page] of pages.entries()) {
        await page.screenshot({ path: path.join(output, `failure-${index}.png`), fullPage: true }).catch(() => {});
        const body = await page.$eval('body', el => el.innerText).catch(() => '');
        fs.writeFileSync(path.join(output, `failure-${index}.txt`), body);
      }
    }
    throw error;
  } finally {
    clearTimeout(watchdog);
    if (browser) await browser.close();
    const checks = await db.collection('resultChecks').where('tenantId', '==', tenantId).get();
    for (const check of checks.docs) await check.ref.delete();
    await db.recursiveDelete(root);
    for (const uid of users) await admin.auth().deleteUser(uid);
    await admin.app().delete();
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
