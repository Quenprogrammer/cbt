// Uses only the running local Firebase emulators and removes its own fixtures.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
process.env.FIRESTORE_EMULATOR_HOST = '127.0.0.1:8980';
process.env.FIREBASE_AUTH_EMULATOR_HOST = '127.0.0.1:9099';
process.env.FIREBASE_STORAGE_EMULATOR_HOST = '127.0.0.1:9199';
const admin = require('../functions/node_modules/firebase-admin');
admin.initializeApp({ projectId: 'cbt-sass', storageBucket: 'cbt-sass.firebasestorage.app' });
const { imageQuestionSeeds, imageQuestionsForSubject } = require('../functions/lib/seed/exams/image-questions');
const { getExamPackage } = require('../functions/lib/exam/exam-attempts');
const { initializeApp, deleteApp } = require('firebase/app');
const { getAuth, connectAuthEmulator, signInWithEmailAndPassword } = require('firebase/auth');
const { getStorage, connectStorageEmulator, ref, uploadBytes, getBytes, deleteObject } = require('firebase/storage');
const suffix = Date.now().toString(36);
const tenantId = 'qa-image-' + suffix;
const db = admin.firestore();
const tenant = db.doc('tenants/' + tenantId);
const accounts = [], apps = [], uploaded = [];

async function identity(role, tenantClaim = tenantId) {
  const email = `qa-image-${role}-${accounts.length}-${suffix}@cbt.test`;
  const user = await admin.auth().createUser({ email, password: 'ImageTest123!' });
  accounts.push(user.uid);
  await admin.auth().setCustomUserClaims(user.uid, { role, tenantId: tenantClaim });
  const app = initializeApp({ projectId: 'cbt-sass', apiKey: 'emulator', storageBucket: 'cbt-sass.firebasestorage.app' }, email);
  apps.push(app);
  const auth = getAuth(app);
  connectAuthEmulator(auth, 'http://127.0.0.1:9099', { disableWarnings: true });
  await signInWithEmailAndPassword(auth, email, 'ImageTest123!');
  const storage = getStorage(app);
  connectStorageEmulator(storage, '127.0.0.1', 9199);
  storage.maxUploadRetryTime = 1000;
  return { user, storage, requestAuth: { uid: user.uid, token: { role, tenantId: tenantClaim, email } } };
}

async function main() {
  try {
    assert.equal(imageQuestionSeeds.length, 12);
    for (const seed of imageQuestionSeeds) {
      const question = imageQuestionsForSubject(seed.subject)[0];
      assert.ok(question.options.some(option => option.id === question.correctAnswerId));
      assert.ok(fs.existsSync(path.join(__dirname, '../public', question.imageUrl)));
    }
    await tenant.set({ name: 'Image question QA', status: 'active', accessStatus: 'enabled', locked: false, modules: { exams: true } });
    for (const seed of imageQuestionSeeds) {
      const subject = tenant.collection('subjects').doc(seed.slug);
      await subject.set({ name: seed.subject, timeLimit: 1, questionLimit: 2, active: true });
      await subject.collection('exams').doc(seed.slug + '-image').set(imageQuestionsForSubject(seed.subject)[0]);
      await subject.collection('exams').doc(seed.slug + '-text').set({ question: 'Text-only compatibility question', options: [{ id: 'A', text: 'Yes' }, { id: 'B', text: 'No' }], correctAnswerId: 'A' });
    }
    const teacher = await identity('admin');
    const student = await identity('student');
    const stranger = await identity('admin', 'qa-other-' + suffix);
    const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=', 'base64');
    const storagePath = `tenants/${tenantId}/question-images/test.png`;
    const imageRef = ref(teacher.storage, storagePath);
    await uploadBytes(imageRef, png, { contentType: 'image/png' });
    uploaded.push(storagePath);
    assert.equal((await getBytes(ref(student.storage, storagePath))).byteLength, png.length);
    await assert.rejects(uploadBytes(ref(student.storage, storagePath), png, { contentType: 'image/png' }), /unauthorized/);
    await assert.rejects(getBytes(ref(stranger.storage, storagePath)), /unauthorized/);
    await assert.rejects(uploadBytes(ref(teacher.storage, `tenants/${tenantId}/question-images/bad.svg`), Buffer.from('<svg/>'), { contentType: 'image/svg+xml' }), /unauthorized/);
    await assert.rejects(uploadBytes(ref(teacher.storage, `tenants/${tenantId}/question-images/large.png`), new Uint8Array(5 * 1024 * 1024), { contentType: 'image/png' }), /unauthorized/);
    console.log('Storage checks passed: admin upload, tenant student read, tenant isolation, type and size validation.');

    // Exercise every subject in batches below the 11-subject registration limit.
    for (const seeds of [imageQuestionSeeds.slice(0, 8), imageQuestionSeeds.slice(8)]) {
      const candidate = await identity('student');
      await tenant.collection('student').doc(candidate.user.uid).set({ authUid: candidate.user.uid, examStatus: 'Started', registeredSubjectIds: seeds.map(seed => seed.slug) });
      const result = await getExamPackage.run({ auth: candidate.requestAuth, data: {} });
      assert.equal(result.questions.length, seeds.length * 2);
      for (const seed of seeds) {
        const q = result.questions.find(q => q.questionId === seed.slug + '-image');
        assert.equal(q.imageUrl, '/question-images/' + seed.slug + '.svg');
        assert.equal(q.imageAlt, seed.imageAlt);
        assert.ok(!('correctAnswerId' in q));
      }
      for (const question of result.questions.filter(q => q.questionId.endsWith('-text'))) assert.equal(question.imageUrl, '');
      const resumed = await getExamPackage.run({ auth: candidate.requestAuth, data: {} });
      assert.equal(resumed.resumed, true);
      assert.deepEqual(resumed.questions, result.questions);
    }
    await deleteObject(imageRef);
    uploaded.length = 0;
    console.log('Exam checks passed: images in all 12 subjects, text-only compatibility, answer secrecy and resume.');
  } finally {
    for (const key of uploaded) await admin.storage().bucket().file(key).delete().catch(() => {});
    await db.recursiveDelete(tenant);
    for (const uid of accounts) await admin.auth().deleteUser(uid);
    for (const app of apps) await deleteApp(app);
    await admin.app().delete();
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
