// Local Firebase emulator checks. Every account, file and record is an isolated QA fixture.
const assert = require('node:assert/strict');
const { randomUUID } = require('node:crypto');
const { ad: admin } = require('../functions/lib/seed/firebase');
const lifecycle = require('../functions/lib/exam/question-lifecycle');
const practice = require('../functions/lib/exam/practice');
const scheduling = require('../functions/lib/exam/scheduling');
const results = require('../functions/lib/exam/result-workflow');
const backups = require('../functions/lib/tenant/backups');
const staffAccess = require('../functions/lib/tenant/staff-access');
const security = require('../functions/lib/security/account-security');
const { sessionId } = require('../functions/lib/security/account-session');
const { getExamPackage, submitExamAttempt } = require('../functions/lib/exam/exam-attempts');
const { saveDraft } = require('../functions/lib/exam/exam-drafts');
const { inspect } = require('../functions/lib/exam/readiness');
const db = admin.firestore(), tenantId = 'qa-remaining-' + Date.now().toString(36), root = db.doc('tenants/' + tenantId), subject = root.collection('subjects').doc('mixed');
const users = [];
const request = (auth, data = {}) => ({ auth, data });
const denied = (promise, code) => assert.rejects(promise, error => error.code === code);
async function identity(role, permissions = []) {
  const user = await admin.auth().createUser({ email: `${tenantId}-${users.length}@cbt.test`, password: 'RemainingFeatures123!', emailVerified: true }); users.push(user.uid);
  await admin.auth().setCustomUserClaims(user.uid, { role, tenantId });
  await root.collection('users').doc(user.uid).set({ uid: user.uid, email: user.email, role, permissions, status: 'active' });
  const response = await fetch('http://127.0.0.1:9099/identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=emulator', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: user.email, password: 'RemainingFeatures123!', returnSecureToken: true }) });
  const token = (await response.json()).idToken, payload = JSON.parse(Buffer.from(token.split('.')[1], 'base64url'));
  return { uid: user.uid, token: { role, tenantId, email: user.email, auth_time: payload.auth_time }, jwt: token };
}
async function rest(path, who, method = 'GET', fields) {
  return fetch('http://127.0.0.1:8980/v1/projects/cbt-sass/databases/(default)/documents/' + path, { method, headers: { ...(who ? { Authorization: 'Bearer ' + who.jwt } : {}), 'Content-Type': 'application/json' }, ...(fields ? { body: JSON.stringify({ fields }) } : {}) });
}
const baseQuestion = (questionType, extra = {}) => ({ question: questionType + ' fixture question', questionType, options: [{ id: 'A', text: 'One' }, { id: 'B', text: 'Two' }], correctAnswerId: 'A', topic: 'Fundamentals', difficulty: 'medium', practiceEnabled: true, explanation: 'A fixture explanation.', ...extra });
async function storageMetadata(who, name) {
  return fetch(`http://127.0.0.1:9199/v0/b/${admin.storage().bucket().name}/o/${encodeURIComponent(name)}`, { headers: { Authorization: 'Bearer ' + who.jwt } });
}
async function main() {
  try {
    await root.set({ name: 'Remaining feature QA', status: 'active', accessStatus: 'enabled', locked: false, modules: { subjects: true, exams: true, results: true, publicResults: true, students: true }, limits: { monthlyAttempts: 100, users: 100 }, usage: { monthlyAttempts: 0 } });
    await subject.set({ name: 'Mixed assessment', questionLimit: 5, timeLimit: 20, active: true });
    const owner = await identity('admin'), author = await identity('staff', ['questions.write']), reviewer = await identity('staff', ['questions.write', 'questions.review']), student = await identity('student');
    await root.collection('student').doc(student.uid).set({ authUid: student.uid, firstname: 'QA', lastname: 'Learner', department: 'SS2', registeredSubjectIds: ['mixed'], examStatus: 'Started' });
    const original = baseQuestion('mcq', { passage: 'Read this passage.', formula: '\\frac{1}{2}+x^2', tableRows: [['Item', 'Value'], ['A', '1']] });
    let saved = await lifecycle.saveQuestion.run(request(author, { subjectId: 'mixed', question: original, action: 'draft' }));
    const firstId = saved.questionId;
    await denied(lifecycle.saveQuestion.run(request(author, { subjectId: 'mixed', questionId: firstId, expectedVersion: 1, question: original, action: 'approve' })), 'permission-denied');
    saved = await lifecycle.saveQuestion.run(request(author, { subjectId: 'mixed', questionId: firstId, expectedVersion: 1, question: original, action: 'submit' }));
    await lifecycle.reviewQuestion.run(request(reviewer, { subjectId: 'mixed', questionId: firstId, expectedVersion: saved.version, decision: 'approved' }));
    const history = await lifecycle.history.run(request(author, { subjectId: 'mixed', questionId: firstId })); assert.equal(history.versions.length, 3);
    await lifecycle.restoreVersion.run(request(author, { subjectId: 'mixed', questionId: firstId, version: 1, expectedVersion: 3 }));
    assert.equal((await subject.collection('exams').doc(firstId).get()).data().publicationStatus, 'draft');
    await lifecycle.saveQuestion.run(request(owner, { subjectId: 'mixed', questionId: firstId, expectedVersion: 4, question: original, action: 'approve' }));
    await denied(lifecycle.saveQuestion.run(request(author, { subjectId: 'mixed', questionId: firstId, expectedVersion: 0, question: original, action: 'draft' })), 'aborted');
    assert.equal((await rest(`${subject.path}/exams/${firstId}`, author, 'PATCH', { question: { stringValue: 'Bypass review' } })).status, 403);
    const png = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=';
    const media = await lifecycle.uploadMedia.run(request(author, { base64: png, contentType: 'image/png' })); assert.equal((await fetch(media.url)).status, 200);
    const definitions = [baseQuestion('multiple_answer', { correctAnswerIds: ['A', 'B'] }), baseQuestion('fill_blank', { acceptedAnswers: ['Lagos'] }), baseQuestion('matching', { matchingPairs: [{ left: 'Capital of Nigeria', right: 'Abuja' }, { left: 'Largest planet', right: 'Jupiter' }] }), baseQuestion('essay', { rubric: 'Explain the idea clearly; partial marks allowed.', matchingPairs: [{ left: '', right: '' }, { left: '', right: '' }] })];
    for (const question of definitions) await lifecycle.saveQuestion.run(request(owner, { subjectId: 'mixed', question, action: 'approve' }));
    console.log('Rich question authoring, media upload, review permissions and version restore passed.');

    const practiceSession = await practice.start.run(request(student, { subjectId: 'mixed', limit: 10 }));
    await root.update({ 'modules.exams': false }); await denied(practice.start.run(request(student, { subjectId: 'mixed' })), 'permission-denied'); await root.update({ 'modules.exams': true });
    assert.equal(practiceSession.questions.length, 5);
    assert.ok(!JSON.stringify(practiceSession.questions).includes('correctAnswerId')); assert.ok(!JSON.stringify(practiceSession.questions).includes('matchingPairs'));
    const feedback = await practice.check.run(request(student, { sessionId: practiceSession.sessionId, questionId: firstId, response: 'A' })); assert.equal(feedback.isCorrect, true); assert.ok(feedback.explanation);
    assert.equal((await root.collection('results').get()).size, 0);
    await scheduling.save.run(request(owner, { subjectId: 'mixed', enabled: true, startsAt: new Date(Date.now() + 3600000).toISOString(), endsAt: new Date(Date.now() + 7200000).toISOString(), lateEntryMinutes: 15, reminders: true }));
    await denied(getExamPackage.run(request(student)), 'failed-precondition');
    assert.equal((await scheduling.runReminderSweep(tenantId)).created, 1); assert.equal((await scheduling.runReminderSweep(tenantId)).created, 0);
    await scheduling.save.run(request(owner, { subjectId: 'mixed', enabled: true, startsAt: new Date(Date.now() - 60000).toISOString(), endsAt: new Date(Date.now() + 1800000).toISOString(), lateEntryMinutes: 15, reminders: true }));
    await results.savePolicy.run(request(owner, { releaseMode: 'withheld' }));
    const pkg = await getExamPackage.run(request(student)); assert.equal(pkg.questions.length, 5);
    assert.ok(pkg.expiresAtMs <= Date.now() + 1800000);
    const responses = {};
    for (const question of pkg.questions) {
      responses[question.questionId] = question.questionType === 'multiple_answer' ? ['A', 'B'] : question.questionType === 'fill_blank' ? { text: ' lagos ' } : question.questionType === 'essay' ? { text: 'A considered essay response.' } : question.questionType === 'matching' ? { matches: Object.fromEntries(question.matchingItems.map(item => [item.id, question.matchingChoices.find(choice => choice.text === (item.text === 'Capital of Nigeria' ? 'Abuja' : 'Jupiter')).id])) } : 'A';
    }
    await saveDraft.run(request(student, { assignmentId: pkg.assignmentId, answers: responses, timePerQuestion: {}, currentQuestionIndex: 2, clientId: randomUUID(), revision: 1 }));
    assert.deepEqual((await getExamPackage.run(request(student))).draft.answers, responses);
    const receipt = await submitExamAttempt.run(request(student, { assignmentId: pkg.assignmentId, answers: pkg.questions.map(question => ({ questionId: question.questionId, response: responses[question.questionId], timeSpentSeconds: 15 })) }));
    const resultRef = root.collection('results').doc(receipt.resultId), submitted = (await resultRef.get()).data();
    assert.equal(submitted.score, 4); assert.equal(submitted.pendingManual, 1); assert.equal(submitted.status, 'Awaiting marking');
    assert.equal((await results.checkResult.run(request(null, { pin: receipt.pin }))).result, null);
    await denied(results.release.run(request(owner, { resultId: receipt.resultId, mode: 'immediate' })), 'failed-precondition');
    const essay = submitted.questionAnalysis.find(row => row.questionType === 'essay');
    await results.markEssay.run(request(owner, { resultId: receipt.resultId, subjectId: essay.subjectId, questionId: essay.questionId, expectedRevision: 0, marks: 0.5, feedback: 'Partially correct.' }));
    assert.equal((await resultRef.get()).data().score, 4.5); assert.equal((await results.checkResult.run(request(null, { pin: receipt.pin }))).result, null);
    await results.release.run(request(owner, { resultId: receipt.resultId, mode: 'scheduled', releaseAt: new Date(Date.now() + 3600000).toISOString() }));
    assert.equal((await rest(`resultChecks/${receipt.pin}`, null)).status, 403);
    await results.release.run(request(owner, { resultId: receipt.resultId, mode: 'immediate' }));
    assert.equal((await results.checkResult.run(request(null, { pin: receipt.pin }))).result.score, 4.5);
    await results.appeal.run(request(student, { resultId: receipt.resultId, reason: 'Please review the partial essay mark.' }));
    const appeal = (await root.collection('appeals').get()).docs[0];
    await results.resolveAppeal.run(request(owner, { appealId: appeal.id, response: 'Reviewed against the rubric; the mark is confirmed.' }));
    const hub = await scheduling.studentHub.run(request(student)); assert.equal(hub.appeals[0].status, 'resolved'); assert.ok(hub.notifications.length >= 2);
    assert.equal((await inspect.run(request(owner))).subjects[0].approved, 5);
    console.log('Practice, all response types, scheduling, reminders, marking, release, appeals and readiness passed.');

    const backup = await backups.create.run(request(owner)), manifestCount = (await root.collection('backups').get()).size;
    assert.ok(backup.documentCount > 5); assert.ok((await backups.download.run(request(owner, { backupId: backup.id }))).base64);
    const originalQuestion = (await subject.collection('exams').doc(firstId).get()).data();
    await subject.collection('exams').doc(firstId).delete();
    await resultRef.delete(); await db.doc(`resultChecks/${receipt.pin}`).delete();
    assert.ok((await backups.previewRestore.run(request(owner, { backupId: backup.id }))).missing >= 1);
    const restored = await backups.restore.run(request(owner, { backupId: backup.id, jobId: randomUUID(), overwrite: false })); assert.ok(restored.restored >= 1);
    assert.equal((await subject.collection('exams').doc(firstId).get()).data().question, originalQuestion.question);
    assert.equal((await results.checkResult.run(request(null, { pin: receipt.pin }))).result.score, 4.5);
    await subject.collection('exams').doc(firstId).update({ question: 'Changed fixture question' });
    const jobId = randomUUID(); await backups.restore.run(request(owner, { backupId: backup.id, jobId, overwrite: true }));
    assert.equal((await subject.collection('exams').doc(firstId).get()).data().question, originalQuestion.question);
    assert.ok((await root.collection('backups').get()).size > manifestCount);
    assert.equal((await backups.restore.run(request(owner, { backupId: backup.id, jobId, overwrite: true }))).status, 'complete');
    await denied(backups.list.run(request(author)), 'permission-denied');
    await backups.savePolicy.run(request(owner, { enabled: true, retention: 1 })); await backups.runBackupSweep(tenantId);
    assert.equal((await root.collection('backups').get()).size, 1);
    console.log('Backup download, checksum validation, missing-record restore, safety backup and retention passed.');

    assert.equal(security.totp(security.base32(Buffer.from('12345678901234567890')), 1), '287082');
    const enrolled = await security.beginEnrollment.run(request(owner)), codes = await security.finishEnrollment.run(request(owner, { code: security.totp(enrolled.secret) })); assert.equal(codes.recoveryCodes.length, 8);
    const mediaPath = decodeURIComponent(new URL(media.url).pathname.split('/o/')[1]);
    assert.equal((await storageMetadata(owner, mediaPath)).status, 200);
    assert.equal((await rest(`${subject.path}/exams/${firstId}`, owner)).status, 200);
    await db.doc(`secondFactorSessions/${sessionId(owner)}`).delete();
    await denied(backups.list.run(request(owner)), 'permission-denied');
    assert.equal((await rest(`${subject.path}/exams/${firstId}`, owner)).status, 403);
    assert.equal((await storageMetadata(owner, mediaPath)).status, 403);
    await security.verify.run(request(owner, { code: codes.recoveryCodes[0] }));
    assert.equal((await rest(`${subject.path}/exams/${firstId}`, owner)).status, 200);
    assert.equal((await storageMetadata(owner, mediaPath)).status, 200);
    await denied(security.verify.run(request(owner, { code: codes.recoveryCodes[0] })), 'invalid-argument');
    assert.equal((await rest(`accountSecurity/${owner.uid}`, owner)).status, 403);
    const added = await staffAccess.save.run(request(owner, { name: 'Scoped teacher', email: `${tenantId}-created@cbt.test`, password: 'TeacherPassword123!', permissions: ['questions.write'] })); users.push(added.uid);
    await root.update({ 'limits.users': users.length });
    const excessEmail = `${tenantId}-excess@cbt.test`;
    await denied(staffAccess.save.run(request(owner, { name: 'Over capacity', email: excessEmail, password: 'TeacherPassword123!', permissions: ['questions.write'] })), 'resource-exhausted');
    await assert.rejects(admin.auth().getUserByEmail(excessEmail), error => error.code === 'auth/user-not-found');
    await staffAccess.save.run(request(owner, { name: 'Disabled author', email: author.token.email, permissions: ['questions.write'], disabled: true }));
    await denied(lifecycle.history.run(request(author, { subjectId: 'mixed', questionId: firstId })), 'permission-denied');
    await security.revokeSessions.run(request(owner));
    await denied(backups.list.run(request(owner)), 'unauthenticated');
    assert.equal((await rest(`${subject.path}/exams/${firstId}`, owner)).status, 403);
    assert.equal((await storageMetadata(owner, mediaPath)).status, 403);
    console.log('TOTP vectors, factor enforcement in callables and rules, single-use recovery codes, staff scope and revocation passed.');
  } finally {
    for (const check of (await db.collection('resultChecks').where('tenantId', '==', tenantId).get()).docs) await check.ref.delete();
    const [files] = await admin.storage().bucket().getFiles({ prefix: `tenants/${tenantId}/` }); for (const file of files) await file.delete();
    await db.recursiveDelete(root);
    for (const uid of users) { for (const session of (await db.collection('secondFactorSessions').where('uid', '==', uid).get()).docs) await session.ref.delete(); await db.doc(`accountSecurity/${uid}`).delete(); await db.recursiveDelete(db.doc(`userTenancies/${uid}`)); await admin.auth().deleteUser(uid); }
    await admin.app().delete();
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
