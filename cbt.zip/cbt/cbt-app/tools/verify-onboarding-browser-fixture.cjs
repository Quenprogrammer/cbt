// Local browser-test accounts only; never contacts production Firebase.
const admin=require('../functions/node_modules/firebase-admin');
process.env.FIRESTORE_EMULATOR_HOST='127.0.0.1:8980';
process.env.FIREBASE_AUTH_EMULATOR_HOST='127.0.0.1:9099';
const app=admin.initializeApp({projectId:'cbt-sass'},'browser-fixture');
const [mode,email]=process.argv.slice(2);
if(!/^ui-(onboarding|student)-[a-z0-9]+@cbt\.test$/.test(email||''))throw new Error('Only a synthetic ui-onboarding/ui-student email is allowed.');
async function main(){
 const user=await app.auth().getUserByEmail(email);
 if(mode==='verify'){
  if(user.emailVerified){console.log('Synthetic browser account is already verified.');await app.delete();return;}
  const data=await(await fetch('http://127.0.0.1:9099/emulator/v1/projects/cbt-sass/oobCodes')).json();
  const matches=(data.oobCodes||[]).filter(c=>c.email===email&&c.requestType==='VERIFY_EMAIL'),item=matches[matches.length-1];
  if(!item)throw new Error('No verification email found.');
  const response=await fetch('http://127.0.0.1:9099/identitytoolkit.googleapis.com/v1/accounts:update?key=emulator',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({oobCode:item.oobCode})});
  if(!response.ok)throw new Error('Emulator verification failed.');
  console.log('Verified synthetic browser account.');
 }else if(mode==='cleanup'){
  const db=app.firestore();
  const owned=await db.collection('tenants').where('ownerUid','==',user.uid).get();
  for(const tenant of owned.docs){
   if(tenant.data().createdVia!=='self-service')throw new Error('Refusing to remove an unrelated institution.');
   for(const collection of ['platformAuditLogs','platformInvoices','platformPayments']){
    const records=await db.collection(collection).where('tenantId','==',tenant.id).get();for(const record of records.docs)await record.ref.delete();
   }
   await db.recursiveDelete(tenant.ref);
  }
  for(const collection of ['institutionSignups','registrationIntents','studentAccountBindings'])await db.doc(collection+'/'+user.uid).delete();
  await db.recursiveDelete(db.doc('userTenancies/'+user.uid));
  const rate=await db.collection('signupRateLimits').where(admin.firestore.FieldPath.documentId(),'>=',user.uid+'-').where(admin.firestore.FieldPath.documentId(),'<',user.uid+'.').get();for(const item of rate.docs)await item.ref.delete();
  await app.auth().deleteUser(user.uid);console.log('Removed synthetic browser account and its fixture data.');
 }else throw new Error('Use verify or cleanup.');
 await app.delete();
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});

