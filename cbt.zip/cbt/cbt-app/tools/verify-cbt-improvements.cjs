// Regression checks against local Firebase emulators; creates and removes only QA fixtures.
const assert = require('node:assert/strict');
const { ad: admin } = require('../functions/lib/seed/firebase');
const XLSX = require('../functions/node_modules/xlsx');
const bank = require('../functions/lib/exam/question-bank');
const { readImportFile, validateImportRows } = require('../functions/lib/exam/question-import');
const { validateBlueprint, selectQuestions } = require('../functions/lib/exam/question-selection');
const { getExamPackage, submitExamAttempt } = require('../functions/lib/exam/exam-attempts');
const { saveDraft } = require('../functions/lib/exam/exam-drafts');
const suffix = Date.now().toString(36), tenantId = 'qa-improvements-' + suffix;
const db = admin.firestore(), root = db.doc('tenants/' + tenantId), subject = root.collection('subjects').doc('math');
const users = [];
const authFor = async (role, extra = {}) => {
  const user = await admin.auth().createUser({ email: `qa-improvements-${role}-${users.length}-${suffix}@cbt.test`, password: 'Improvement123!', emailVerified: true });
  users.push(user.uid); await admin.auth().setCustomUserClaims(user.uid, { role, tenantId, ...extra });
  return { uid: user.uid, token: { role, tenantId, email: user.email, ...extra } };
};
const request = (auth, data) => ({ auth, data });
const rejectCode = (promise, code) => assert.rejects(promise, error => error.code === code);

async function main() {
  try {
    const csv = 'question,optionA,optionB,correctAnswerId,topic,difficulty\r\n"A quoted, multi-line\nquestion?",One,Two,B,Algebra,easy\r\n';
    const parsed = readImportFile('sample.csv', Buffer.from(csv).toString('base64'));
    assert.equal(parsed[0].errors.length, 0); assert.ok(parsed[0].values.question.includes('\n'));
    assert.throws(() => validateImportRows(new Array(201).fill({ question: 'Test' })), /200/);
    assert.ok(validateImportRows([{ question: 'Bad image', optionA: 'A', optionB: 'B', correctAnswerId: 'A', imageUrl: 'javascript:alert(1)' }])[0].errors.length);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet([{ question: 'Unicode: Ìbéèrè?', optionA: 'One', optionB: 'Two', correctAnswerId: 'A' }]), 'Questions');
    const excel = XLSX.write(workbook, { type: 'base64', bookType: 'xlsx' });
    assert.equal(readImportFile('sample.xlsx', excel)[0].values.question, 'Unicode: Ìbéèrè?');
    assert.throws(() => validateBlueprint({ enabled: true, rows: [{ topic: 'Algebra', difficulty: 'any', count: 1 }, { topic: 'algebra', difficulty: 'easy', count: 1 }] }, 2), /overlap/);
    assert.throws(() => validateBlueprint({ enabled: true, rows: [{ topic: 'Algebra', difficulty: 'easy', count: 1 }] }, 2), /add up/);
    assert.throws(() => selectQuestions([], { enabled: true, rows: [{ topic: 'Missing', difficulty: 'hard', count: 1 }] }, 1, rows => rows), /only 0/);
    console.log('Import parser and blueprint validation checks passed.');

    await root.set({ name: 'CBT improvements QA', status: 'active', accessStatus: 'enabled', locked: false, modules: { subjects: true, exams: true, results: true, publicResults: true }, usage: { monthlyAttempts: 0 }, limits: { monthlyAttempts: 100 } });
    await subject.set({ name: 'Math', active: true, timeLimit: 3, questionLimit: 2 });
    const teacher = await authFor('admin'), student = await authFor('student'), stranger = await authFor('student');
    const values = [
      { question: 'Algebra easy?', optionA: 'One', optionB: 'Two', correctAnswerId: 'A', topic: 'Algebra', difficulty: 'easy' },
      { question: 'Algebra hard?', optionA: 'One', optionB: 'Two', correctAnswerId: 'B', topic: 'Algebra', difficulty: 'hard' },
      { question: 'Geometry medium?', optionA: 'One', optionB: 'Two', correctAnswerId: 'A', topic: 'Geometry', difficulty: 'medium' },
      { question: 'Geometry medium?', optionA: 'One', optionB: 'Two', correctAnswerId: 'A', topic: 'Geometry', difficulty: 'medium' },
    ];
    const rows = validateImportRows(values), importId = 'qa-import-' + suffix;
    await rejectCode(bank.importQuestions.run(request(student, { subjectId: 'math', rows, importId })), 'permission-denied');
    await rejectCode(bank.importQuestions.run(request(teacher, { subjectId: 'math', rows: [{ question: 'Invalid' }], importId })), 'invalid-argument');
    assert.equal((await subject.collection('exams').get()).size, 0);
    const first = await bank.importQuestions.run(request(teacher, { subjectId: 'math', rows, importId }));
    assert.deepEqual(first, { added: 3, skipped: 1 });
    assert.deepEqual(await bank.importQuestions.run(request(teacher, { subjectId: 'math', rows, importId })), first);
    assert.deepEqual(await bank.importQuestions.run(request(teacher, { subjectId: 'math', rows, importId: importId + '-repeat' })), { added: 0, skipped: 4 });
    const modified = structuredClone(rows); modified[0].values.question = 'Changed question?';
    await rejectCode(bank.importQuestions.run(request(teacher, { subjectId: 'math', rows: modified, importId })), 'already-exists');
    const preview = await bank.previewImport.run(request(teacher, { subjectId: 'math', rows }));
    assert.ok(preview.rows.every(row => row.duplicate));
    await rejectCode(bank.previewImport.run(request({ ...teacher, token: { ...teacher.token, tenantId: 'other-tenant' } }, { subjectId: 'math', rows })), 'failed-precondition');
    const blueprint = { enabled: true, rows: [{ topic: 'Algebra', difficulty: 'easy', count: 1 }, { topic: 'Geometry', difficulty: 'medium', count: 1 }] };
    await bank.saveBlueprint.run(request(teacher, { subjectId: 'math', questionLimit: 2, blueprint }));
    await rejectCode(bank.saveBlueprint.run(request(teacher, { subjectId: 'math', questionLimit: 3, blueprint: { enabled: true, rows: [{ topic: 'Geometry', difficulty: 'medium', count: 3 }] } })), 'failed-precondition');
    await root.collection('student').doc(student.uid).set({ authUid: student.uid, firstname: 'QA', lastname: 'Candidate', department: 'SS2', examStatus: 'Started', registeredSubjectIds: ['math'] });
    const pkg = await getExamPackage.run(request(student, {}));
    assert.equal(pkg.questions.length, 2); assert.deepEqual(pkg.questions.map(q => q.topic).sort(), ['Algebra', 'Geometry']);
    assert.ok(pkg.questions.every(q => !('correctAnswerId' in q)));
    console.log('Tenant isolation, atomic imports, duplicate handling and blueprint selection passed.');

    const answers = Object.fromEntries(pkg.questions.map(q => [q.questionId, 'A']));
    const draft = { assignmentId: pkg.assignmentId, answers, timePerQuestion: {}, currentQuestionIndex: 1, clientId: 'qa-device-' + suffix, revision: 2 };
    await saveDraft.run(request(student, draft));
    await saveDraft.run(request(student, { ...draft, answers: {}, revision: 1 }));
    assert.deepEqual((await root.collection('examDrafts').doc(pkg.assignmentId).get()).data().answers, answers);
    await rejectCode(saveDraft.run(request(stranger, draft)), 'permission-denied');
    await rejectCode(saveDraft.run(request(student, { ...draft, answers: { [pkg.questions[0].questionId]: 'Z' }, revision: 3 })), 'invalid-argument');
    const resumed = await getExamPackage.run(request(student, {}));
    assert.equal(resumed.resumed, true); assert.deepEqual(resumed.draft.answers, answers);
    const signIn = await fetch('http://127.0.0.1:9099/identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=emulator', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: student.token.email, password: 'Improvement123!', returnSecureToken: true }) });
    const token = (await signIn.json()).idToken;
    const keyRead = await fetch(`http://127.0.0.1:8980/v1/projects/cbt-sass/databases/(default)/documents/tenants/${tenantId}/examKeys/${pkg.assignmentId}`, { headers: { Authorization: 'Bearer ' + token } });
    assert.equal(keyRead.status, 403);
    const directDraftWrite = await fetch(`http://127.0.0.1:8980/v1/projects/cbt-sass/databases/(default)/documents/tenants/${tenantId}/examDrafts/${pkg.assignmentId}`, { method: 'PATCH', headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' }, body: JSON.stringify({ fields: { studentId: { stringValue: student.uid } } }) });
    assert.equal(directDraftWrite.status, 403);
    console.log('Cloud draft restoration, stale revision protection, answer validation and private marking keys passed.');

    const keys = (await root.collection('examKeys').doc(pkg.assignmentId).get()).data().questions;
    const finalAnswers = pkg.questions.map(q => ({ questionId: q.questionId, selectedAnswerId: keys['math:' + q.questionId].correctAnswerId, timeSpentSeconds: 10 }));
    for (const q of pkg.questions) await subject.collection('exams').doc(q.questionId).update({ correctAnswerId: 'B', topic: 'Edited after start' });
    const receipts = await Promise.all([submitExamAttempt.run(request(student, { assignmentId: pkg.assignmentId, answers: finalAnswers })), submitExamAttempt.run(request(student, { assignmentId: pkg.assignmentId, answers: finalAnswers }))]);
    assert.equal(receipts[0].resultId, receipts[1].resultId); assert.equal(receipts[0].pin, receipts[1].pin);
    assert.equal((await root.collection('results').get()).size, 1);
    const result = (await root.collection('results').doc(receipts[0].resultId).get()).data();
    assert.equal(result.score, 2); assert.equal(result.className, 'SS2');
    assert.deepEqual(result.questionAnalysis.map(q => q.topic).sort(), ['Algebra', 'Geometry']);
    assert.equal((await root.get()).data().usage.monthlyAttempts, 1);
    assert.equal((await root.collection('examDrafts').doc(pkg.assignmentId).get()).exists, false);
    console.log('Stable scoring, analytics metadata and concurrent submission retries passed.');
    for (const question of (await subject.collection('exams').get()).docs) await question.ref.delete();
    await root.collection('student').doc(student.uid).update({ examStatus: 'Started' });
    await rejectCode(getExamPackage.run(request(student, {})), 'failed-precondition');
    assert.equal((await root.collection('examAssignments').get()).size, 1);
    console.log('An unfulfillable blueprint blocks new sessions without creating a partial assignment.');
  } finally {
    const checks = await db.collection('resultChecks').where('tenantId', '==', tenantId).get();
    for (const doc of checks.docs) await doc.ref.delete();
    await db.recursiveDelete(root);
    for (const uid of users) await admin.auth().deleteUser(uid);
    await admin.app().delete();
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
