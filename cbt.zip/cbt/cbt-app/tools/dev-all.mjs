import { spawn } from 'node:child_process';
import net from 'node:net';

const isWindows = process.platform === 'win32';
const children = [];
let shuttingDown = false;

function quoteWindowsArg(value) {
  const text = String(value);

  if (text.length === 0) {
    return '""';
  }

  if (!/[\s"&|<>^]/.test(text)) {
    return text;
  }

  return `"${text.replace(/"/g, '""')}"`;
}

function commandSpec(command, args = []) {
  if (!isWindows) {
    return {
      file: command,
      args,
      shell: false,
    };
  }

  const comspec =
    process.env.ComSpec ||
    process.env.COMSPEC ||
    'cmd.exe';

  const commandLine = [
    command,
    ...args,
  ]
    .map(quoteWindowsArg)
    .join(' ');

  return {
    file: comspec,
    args: ['/d', '/s', '/c', commandLine],
    shell: false,
  };
}

function run(command, args = [], options = {}) {
  return new Promise((resolve, reject) => {
    const spec = commandSpec(command, args);

    console.log(`\n> ${command} ${args.join(' ')}\n`);

    let child;

    try {
      child = spawn(spec.file, spec.args, {
        stdio: 'inherit',
        shell: spec.shell,
        windowsHide: false,
        ...options,
      });
    } catch (error) {
      reject(error);
      return;
    }

    child.once('error', reject);

    child.once('exit', (code, signal) => {
      if (code === 0) {
        resolve();
        return;
      }

      reject(
        new Error(
          `${command} ${args.join(' ')} exited with code ${
            code ?? 'null'
          }${signal ? ` (signal ${signal})` : ''}`
        )
      );
    });
  });
}

function startProcess(name, command, args = [], options = {}) {
  const spec = commandSpec(command, args);

  console.log(`\n[START] ${name}`);
  console.log(`> ${command} ${args.join(' ')}\n`);

  const child = spawn(spec.file, spec.args, {
    stdio: 'inherit',
    shell: spec.shell,
    windowsHide: false,
    ...options,
  });

  const entry = { name, child };
  children.push(entry);

  child.once('error', (error) => {
    console.error(`\n[${name}] Failed to start.`);
    console.error(error);

    if (!shuttingDown) {
      shutdown(1);
    }
  });

  child.once('exit', (code, signal) => {
    if (!shuttingDown) {
      console.log(
        `\n[${name}] exited with code ${code ?? 'null'}${
          signal ? ` (signal ${signal})` : ''
        }`
      );
    }
  });

  return child;
}

function isPortReady(port, host = '127.0.0.1') {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    let settled = false;

    const finish = (ready) => {
      if (settled) return;

      settled = true;
      socket.destroy();
      resolve(ready);
    };

    socket.setTimeout(800);

    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));

    socket.connect(port, host);
  });
}

async function waitForPort(
  port,
  name,
  timeoutMs = 120000,
  host = '127.0.0.1'
) {
  const startedAt = Date.now();

  process.stdout.write(
    `[WAIT] ${name} (${host}:${port})`
  );

  while (Date.now() - startedAt < timeoutMs) {
    if (await isPortReady(port, host)) {
      console.log(' ready');
      return;
    }

    process.stdout.write('.');
    await new Promise((resolve) =>
      setTimeout(resolve, 1000)
    );
  }

  console.log('');

  throw new Error(
    `${name} did not become ready on ${host}:${port} within ${
      timeoutMs / 1000
    } seconds.`
  );
}

async function waitForFirebase() {
  console.log(
    '\nWaiting for Firebase Emulator Suite...\n'
  );

  await Promise.all([
    waitForPort(
      9099,
      'Authentication Emulator'
    ),
    waitForPort(
      8980,
      'Firestore Emulator'
    ),
    waitForPort(
      5001,
      'Functions Emulator'
    ),
    waitForPort(
      9199,
      'Storage Emulator'
    ),
  ]);

  console.log(
    '\nFirebase emulators are ready.\n'
  );
}

function stopProcess(entry) {
  const { name, child } = entry;

  if (!child || child.killed || !child.pid) {
    return;
  }

  console.log(`[STOP] ${name}`);

  try {
    if (isWindows) {
      spawn(
        process.env.ComSpec ||
        process.env.COMSPEC ||
        'cmd.exe',
        [
          '/d',
          '/s',
          '/c',
          `taskkill /PID ${child.pid} /T /F >NUL 2>&1`,
        ],
        {
          stdio: 'ignore',
          windowsHide: true,
        }
      );
    } else {
      child.kill('SIGTERM');
    }
  } catch {
    // Best-effort shutdown.
  }
}

function shutdown(exitCode = 0) {
  if (shuttingDown) return;

  shuttingDown = true;

  console.log(
    '\n\nStopping CBT development environment...\n'
  );

  for (const entry of [...children].reverse()) {
    stopProcess(entry);
  }

  setTimeout(() => {
    process.exit(exitCode);
  }, 1200);
}

process.on(
  'SIGINT',
  () => shutdown(0)
);

process.on(
  'SIGTERM',
  () => shutdown(0)
);

process.on(
  'uncaughtException',
  (error) => {
    console.error(
      '\nUnexpected error:',
      error
    );

    shutdown(1);
  }
);

process.on(
  'unhandledRejection',
  (error) => {
    console.error(
      '\nUnhandled error:',
      error
    );

    shutdown(1);
  }
);

async function main() {
  console.log(`
========================================================
          CBT MULTI-TENANT DEVELOPMENT SUITE
========================================================

 Firebase Authentication : http://127.0.0.1:9099
 Firebase Firestore       : http://127.0.0.1:8980
 Firebase Functions       : http://127.0.0.1:5001
 Firebase Storage         : http://127.0.0.1:9199
 Emulator UI              : http://127.0.0.1:4000

 CBT Application          : http://127.0.0.1:4200
 Tenant Manager           : http://127.0.0.1:4300

========================================================
`);

  console.log(
    '\n[1/5] Building Firebase Functions...\n'
  );

  await run(
    'pnpm',
    [
      'run',
      'functions:build',
    ]
  );

  console.log(
    '\n[2/5] Starting Firebase Emulator Suite...\n'
  );

  const firebaseProcess =
    startProcess(
      'Firebase Emulators',
      'pnpm',
      [
        'exec',
        'firebase',
        'emulators:start',
        '--project',
        'cbt-sass',
        '--only',
        'auth,firestore,functions,storage',
      ]
    );

  firebaseProcess.once(
    'exit',
    (code) => {
      if (!shuttingDown) {
        console.error(
          `\nFirebase Emulator Suite stopped unexpectedly with code ${
            code ?? 'null'
          }.\n`
        );

        shutdown(code || 1);
      }
    }
  );

  console.log(
    '\n[3/5] Waiting for Firebase emulators...\n'
  );

  await waitForFirebase();

  console.log(
    '[WAIT] Allowing Functions emulator to finish loading...'
  );

  await new Promise((resolve) =>
    setTimeout(resolve, 3000)
  );

  console.log(
    '\n[4/5] Seeding CBT tenants and test data...\n'
  );

  await run(
    'pnpm',
    [
      'run',
      'seed:reset',
    ]
  );

  console.log(
    '\n[OK] Emulator seed completed successfully.\n'
  );

  console.log(
    '\n[5/5] Starting Angular applications...\n'
  );

  startProcess(
    'CBT Application',
    'pnpm',
    [
      'run',
      'start:app',
    ]
  );

  startProcess(
    'Tenant Manager',
    'pnpm',
    [
      'run',
      'start:tenant',
    ]
  );

  console.log(`
========================================================
                   DEVELOPMENT STARTED
========================================================

 CBT Application
 http://127.0.0.1:4200

 Tenant Manager
 http://127.0.0.1:4300

 Firebase Emulator UI
 http://127.0.0.1:4000

 Authentication Emulator
 http://127.0.0.1:9099

 Firestore Emulator
 http://127.0.0.1:8980

 Functions Emulator
 http://127.0.0.1:5001

 Storage Emulator
 http://127.0.0.1:9199

 Angular may take a few seconds to finish compiling.
 Press CTRL+C in this terminal to stop the whole suite.

========================================================
`);
}

main().catch((error) => {
  console.error(
    '\nDevelopment environment failed to start.\n'
  );

  console.error(error);

  shutdown(1);
});
