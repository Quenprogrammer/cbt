import { spawn } from 'node:child_process';
import net from 'node:net';

const children = new Set();
const projectRoot = process.cwd();

function npmCommand(script) {
  // When this file is started via `npm run dev`, npm exposes the absolute
  // path to npm-cli.js in npm_execpath. Running that file with the current
  // Node executable is reliable on Windows and avoids spawn EINVAL from
  // attempting to execute npm.cmd directly with shell:false.
  if (process.env.npm_execpath) {
    return {
      command: process.execPath,
      args: [process.env.npm_execpath, 'run', script],
    };
  }

  if (process.platform === 'win32') {
    return {
      command: process.env.ComSpec || 'cmd.exe',
      args: ['/d', '/s', '/c', `npm run ${script}`],
    };
  }

  return {
    command: 'npm',
    args: ['run', script],
  };
}

function runNpm(script) {
  const { command, args } = npmCommand(script);
  const child = spawn(command, args, {
    cwd: projectRoot,
    stdio: 'inherit',
    shell: false,
    windowsHide: false,
  });

  children.add(child);
  child.once('exit', () => children.delete(child));
  child.once('error', (error) => {
    console.error(`Failed to start npm script "${script}": ${error.message}`);
  });
  return child;
}

function waitForPort(port, host = '127.0.0.1', timeoutMs = 120000) {
  const started = Date.now();
  return new Promise((resolve, reject) => {
    const tryConnect = () => {
      const socket = net.createConnection({ host, port });
      socket.once('connect', () => {
        socket.destroy();
        resolve();
      });
      socket.once('error', () => {
        socket.destroy();
        if (Date.now() - started >= timeoutMs) {
          reject(new Error(`Timed out waiting for ${host}:${port}`));
          return;
        }
        setTimeout(tryConnect, 500);
      });
    };
    tryConnect();
  });
}

function waitForExit(child) {
  return new Promise((resolve, reject) => {
    child.once('error', reject);
    child.once('exit', (code, signal) => {
      if (code === 0) {
        resolve();
      } else {
        const suffix = signal ? ` (signal ${signal})` : '';
        reject(new Error(`Process exited with code ${code ?? 'unknown'}${suffix}`));
      }
    });
  });
}

async function terminate(child) {
  if (!child || child.killed || !child.pid) return;

  if (process.platform === 'win32') {
    await new Promise((resolve) => {
      const killer = spawn(process.env.ComSpec || 'cmd.exe', [
        '/d', '/s', '/c', `taskkill /PID ${child.pid} /T /F >NUL 2>&1`,
      ], {
        stdio: 'ignore',
        shell: false,
        windowsHide: true,
      });
      killer.once('exit', resolve);
      killer.once('error', resolve);
    });
  } else {
    child.kill('SIGTERM');
  }
}

let shuttingDown = false;
async function shutdown(code = 0) {
  if (shuttingDown) return;
  shuttingDown = true;
  await Promise.all([...children].map(terminate));
  process.exit(code);
}

process.on('SIGINT', () => void shutdown(0));
process.on('SIGTERM', () => void shutdown(0));

try {
  console.log('Starting Firebase emulators...');
  const emulator = runNpm('emulators');

  await Promise.race([
    Promise.all([9099, 8980, 5001, 9199].map((port) => waitForPort(port))),
    waitForExit(emulator).then(() => {
      throw new Error('Firebase emulators stopped before becoming ready.');
    }),
  ]);

  console.log('Emulators are ready. Resetting and loading seed data...');
  await waitForExit(runNpm('seed'));

  console.log('Starting Angular application on http://localhost:4200 ...');
  const app = runNpm('start:app');

  await Promise.race([
    waitForExit(emulator).then(() => {
      throw new Error('Firebase emulators stopped.');
    }),
    waitForExit(app).then(() => {
      throw new Error('Angular dev server stopped.');
    }),
  ]);
} catch (error) {
  console.error(error instanceof Error ? error.message : error);
  await shutdown(1);
}
