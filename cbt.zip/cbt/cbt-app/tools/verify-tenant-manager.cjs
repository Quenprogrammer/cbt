// Integration checks run only against the local Firebase emulators.
// Run from cbt-app: node tools/verify-tenant-manager.cjs
const assert = require('node:assert/strict');
const admin = require('../functions/node_modules/firebase-admin');
process.env.FIRESTORE_EMULATOR_HOST = '127.0.0.1:8980';
process.env.FIREBASE_AUTH_EMULATOR_HOST = '127.0.0.1:9099';
const projectId = 'cbt-sass';
const app = admin.initializeApp({projectId}, 'tenant-manager-verification');
const db = app.firestore();
const auth = app.auth();
const suffix = Date.now().toString(36);
const tenantIds = [];
const userIds = [];
const planId = 'qa-plan-' + suffix;
let planCreated = false;
const tokens = {};
async function signIn(email) {
  const response = await fetch('http://127.0.0.1:9099/identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=emulator', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body:JSON.stringify({email,password:'LocalTest123!',returnSecureToken:true})
  });
  const result = await response.json();
  assert.ok(response.ok, JSON.stringify(result.error));
  return result.idToken;
}
async function call(name,data={},role='owner') {
  const response = await fetch('http://127.0.0.1:5001/' + projectId + '/us-central1/tenant_platform-' + name, {
    method:'POST', headers:{'Content-Type':'application/json',...(tokens[role] ? {Authorization:'Bearer '+tokens[role]} : {})},
    body:JSON.stringify({data})
  });
  const result = await response.json();
  return result;
}
async function ok(name,data={},role='owner') {
  const result = await call(name,data,role);
  assert.ok(!result.error, name + ': ' + JSON.stringify(result.error));
  return result.result;
}
async function denied(name,data,status,role='owner') {
  const result = await call(name,data,role);
  assert.equal(result.error?.status,status,name+': '+JSON.stringify(result));
}
async function main() {
  try {
    for (const [role,platformRole] of [['owner','platform-owner'],['support','support']]) {
      const email = 'qa-' + role + '-' + suffix + '@cbt.test';
      const user = await auth.createUser({email,password:'LocalTest123!'});
      userIds.push(user.uid);
      await db.doc('platformAdmins/'+user.uid).set({email,displayName:'Layout verification',role:platformRole,status:'active'});
      tokens[role] = await signIn(email);
    }
    await denied('listTenantInstitutions',{},'UNAUTHENTICATED','anonymous');
    const plans=(await ok('listPlatformPlans')).plans;
    const base=plans.find(p=>p.id==='starter');
    assert.ok(base);
    await ok('savePlatformPlan',{plan:{...base,id:planId,name:'QA plan',priceMonthly:100}});
    planCreated=true;
    for (const letter of ['a','b']) {
      const tenantCode='QA-'+suffix+'-'+letter;
      const email='qa-admin-'+letter+'-'+suffix+'@cbt.test';
      const created=await ok('createTenantInstitution',{name:'Layout verification '+letter,shortName:'QA',tenantCode,email,adminEmail:email,adminName:'QA administrator',adminPassword:'LocalTest123!',planId,status:'active',limits:base.limits,modules:base.modules});
      tenantIds.push(created.tenantId); userIds.push(created.adminUid);
    }
    const [first,second]=tenantIds;
    await ok('setTenantInstitutionLimits',{tenantId:first,limits:{...base.limits,students:501}});
    assert.equal((await ok('getTenantInstitution',{tenantId:first})).limits.students,501);
    await denied('setTenantInstitutionLimits',{tenantId:first,limits:base.limits},'PERMISSION_DENIED','support');
    await ok('setTenantInstitutionModules',{tenantId:first,modules:{...base.modules,exports:true}});
    assert.equal((await ok('getTenantInstitution',{tenantId:first})).modules.exports,true);
    await denied('setTenantInstitutionStatus',{tenantId:first,status:'suspended',accessStatus:'disabled',locked:true,statusReason:''},'INVALID_ARGUMENT');
    await ok('setTenantInstitutionStatus',{tenantId:first,status:'suspended',accessStatus:'disabled',locked:true,statusReason:'QA restriction'});
    const blocked=await ok('getTenantInstitution',{tenantId:first});
    assert.equal(blocked.statusReason,'QA restriction'); assert.equal(blocked.locked,true);
    await ok('setTenantInstitutionStatus',{tenantId:first,status:'active',accessStatus:'enabled',locked:false,statusReason:''});
    await ok('setTenantInstitutionPlan',{tenantId:first,planId,subscriptionStatus:'active',applyPlanDefaults:true});
    assert.equal((await ok('getTenantInstitution',{tenantId:first})).limits.students,base.limits.students);
    const invoice=await ok('createPlatformInvoice',{tenantId:first,planId,amount:100,currency:'NGN',dueDate:'2026-11-01',description:'Layout verification'});
    await ok('createPlatformInvoice',{tenantId:second,planId,amount:200,currency:'NGN',dueDate:'2026-11-01'});
    const scoped=await ok('listPlatformInvoices',{tenantId:first});
    assert.equal(scoped.invoices.length,1);
    assert.ok(scoped.invoices.every(i=>i.tenantId===first));
    await denied('recordPlatformPayment',{invoiceId:invoice.invoiceId,tenantId:second,amount:25},'INVALID_ARGUMENT');
    await denied('recordPlatformPayment',{invoiceId:invoice.invoiceId,tenantId:first,amount:101},'INVALID_ARGUMENT');
    await denied('recordPlatformPayment',{invoiceId:invoice.invoiceId,tenantId:first,amount:25},'PERMISSION_DENIED','support');
    await ok('recordPlatformPayment',{invoiceId:invoice.invoiceId,tenantId:first,amount:25,reference:'QA partial'});
    let saved=(await ok('listPlatformInvoices',{tenantId:first})).invoices[0];
    assert.equal(saved.balance,75); assert.equal(saved.status,'part-paid');
    await ok('recordPlatformPayment',{invoiceId:invoice.invoiceId,tenantId:first,amount:75,reference:'QA final'});
    saved=(await ok('listPlatformInvoices',{tenantId:first})).invoices[0];
    assert.equal(saved.balance,0); assert.equal(saved.amountPaid,100); assert.equal(saved.status,'paid');
    const payments=(await ok('listPlatformPayments',{tenantId:first})).payments;
    assert.equal(payments.length,2); assert.ok(payments.every(p=>p.tenantId===first));
    await denied('recordPlatformPayment',{invoiceId:invoice.invoiceId,tenantId:first,amount:1},'INVALID_ARGUMENT');
    console.log('PASS: tenant creation, plan editing, limits/modules, restrictions, plan defaults, scoped invoices/payments, partial/full payments, role checks and invalid payment rejection.');
  } finally {
    // Remove only synthetic records created by this verification run.
    for (const tenantId of tenantIds) {
      for (const collection of ['platformInvoices','platformPayments','platformAuditLogs']) {
        const records=await db.collection(collection).where('tenantId','==',tenantId).get();
        for (const record of records.docs) await record.ref.delete();
      }
      await db.recursiveDelete(db.doc('tenants/'+tenantId));
    }
    for (const uid of userIds) {
      await db.recursiveDelete(db.doc('userTenancies/'+uid));
      await db.doc('platformAdmins/'+uid).delete();
      const logs=await db.collection('platformAuditLogs').where('actorId','==',uid).get();
      for(const log of logs.docs) await log.ref.delete();
      await auth.deleteUser(uid).catch(()=>{});
    }
    if(planCreated) await db.doc('platformPlans/'+planId).delete();
    await app.delete();
  }
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});

