// Original, self-contained diagrams for the seeded image questions.
const fs = require('node:fs');
const path = require('node:path');
const text = (x, y, value, size = 24) => `<text x="${x}" y="${y}" font-size="${size}" text-anchor="middle" fill="#172b4d">${value}</text>`;
const line = (x1, y1, x2, y2, arrow = false) => `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#2455a4" stroke-width="4"${arrow ? ' marker-end="url(#arrow)"' : ''}/>`;
const box = (x, y, width, height, label) => `<rect x="${x}" y="${y}" width="${width}" height="${height}" rx="12" fill="#e8f1ff" stroke="#2455a4" stroke-width="3"/>${text(x + width / 2, y + height / 2 + 8, label)}`;
const diagrams = {
  english: {
    title: 'A ball and a table',
    body: `<path d="M160 130H540V155H160Z M190 155V315 M510 155V315" fill="#d8b48a" stroke="#80512b" stroke-width="12"/><circle cx="350" cy="282" r="29" fill="#e35454" stroke="#a32525" stroke-width="3"/>${line(110, 317, 590, 317)}`,
  },
  math: {
    title: 'Triangle dimensions',
    body: `<path d="M160 280L430 95L540 280Z" fill="#e8f1ff" stroke="#2455a4" stroke-width="4"/><path d="M430 95V280" stroke="#2455a4" stroke-dasharray="8 6" stroke-width="3"/><path d="M410 280V260H430" fill="none" stroke="#2455a4" stroke-width="2"/>${text(350, 320, '8 cm')}${text(472, 201, '6 cm')}`,
  },
  chemistry: {
    title: 'Separating a mixture',
    body: `<path d="M230 95H470L368 202V245H332V202Z" fill="#e8f1ff" stroke="#2455a4" stroke-width="3"/><path d="M250 108L350 188L450 108" fill="#fff4db" stroke="#a67a28" stroke-width="3"/><g fill="#80512b"><circle cx="320" cy="143" r="5"/><circle cx="341" cy="151" r="5"/><circle cx="364" cy="142" r="5"/></g><path d="M285 240V328H415V240" fill="none" stroke="#2455a4" stroke-width="4"/><path d="M288 290H412V325H288Z" fill="#8ecbfa"/>${line(350, 250, 350, 278, true)}${text(520, 130, 'Filter paper', 20)}${line(463, 135, 425, 128)}${text(515, 308, 'Liquid', 20)}${line(475, 302, 417, 302)}`,
  },
  computer: {
    title: 'Information-processing cycle',
    body: `${box(35, 150, 170, 90, 'Input')}${line(212, 195, 252, 195, true)}${box(265, 150, 170, 90, 'X')}${line(442, 195, 482, 195, true)}${box(495, 150, 170, 90, 'Output')}`,
  },
  'computer-hardware': {
    title: 'Computer peripheral',
    body: `<rect x="95" y="105" width="510" height="220" rx="18" fill="#e8f1ff" stroke="#2455a4" stroke-width="4"/>${['1234567890', 'QWERTYUIOP', 'ASDFGHJKL', 'ZXCVBNM'].map((row, r) => [...row].map((key, i) => `<rect x="${115 + i * 47 + r * 6}" y="${120 + r * 43}" width="36" height="32" rx="4" fill="white" stroke="#52739e"/>${text(133 + i * 47 + r * 6, 143 + r * 43, key, 18)}`).join('')).join('')}<rect x="245" y="293" width="230" height="19" rx="4" fill="white" stroke="#52739e"/>`,
  },
  'computer-programming': {
    title: 'Trace the flowchart',
    body: `${box(235, 65, 230, 40, 'Start')}${line(350, 108, 350, 126, true)}${box(235, 137, 230, 40, 'x = 3')}${line(350, 180, 350, 198, true)}${box(235, 209, 230, 40, 'x = x × 2')}${line(350, 252, 350, 270, true)}${box(235, 281, 230, 40, 'Display x')}${line(350, 324, 350, 342, true)}${box(235, 353, 230, 40, 'End')}`,
  },
  'general-computer': {
    title: 'Files in a folder',
    body: `<path d="M170 100V80H315L340 100H530V350H170Z" fill="#fff4db" stroke="#a67a28" stroke-width="3"/>${['notes.txt', 'photo.png', 'music.mp3', 'report.pdf'].map((file, i) => `<rect x="200" y="${128 + 50 * i}" width="26" height="32" rx="3" fill="white" stroke="#52739e"/>${text(375, 152 + 50 * i, file)}`).join('')}`,
  },
  ict: {
    title: 'Network connections',
    body: `${line(350, 203, 150, 110)}${line(350, 203, 550, 110)}${line(350, 203, 150, 315)}${line(350, 203, 550, 315)}${box(275, 174, 150, 58, 'Switch')}${[[90, 75], [490, 75], [90, 290], [490, 290]].map(([x, y], i) => `${box(x, y, 120, 62, 'PC ' + (i + 1))}${line(x + 35, y + 72, x + 85, y + 72)}`).join('')}`,
  },
  physics: {
    title: 'Horizontal forces on a block',
    body: `${box(270, 150, 160, 110, 'Block')}${line(265, 205, 125, 205, true)}${line(435, 205, 605, 205, true)}${text(180, 177, '4 N')}${text(525, 177, '10 N')}${line(90, 265, 625, 265)}`,
  },
  biology: {
    title: 'Animal cell',
    body: `<ellipse cx="330" cy="225" rx="180" ry="120" fill="#e5f6ed" stroke="#29835a" stroke-width="4"/><circle cx="330" cy="225" r="50" fill="#d3c2ef" stroke="#7753a5" stroke-width="3"/><circle cx="340" cy="220" r="13" fill="#7753a5"/><g fill="#f6cd9a" stroke="#b67b34" stroke-width="2"><ellipse cx="220" cy="195" rx="25" ry="12"/><ellipse cx="420" cy="260" rx="25" ry="12"/><ellipse cx="270" cy="293" rx="25" ry="12"/></g>${text(540, 118, 'X', 28)}${line(525, 130, 373, 193, true)}`,
  },
  economics: {
    title: 'Price and quantity demanded',
    body: `${line(160, 310, 160, 85, true)}${line(160, 310, 585, 310, true)}${text(135, 69, 'Price', 22)}${text(400, 360, 'Quantity demanded', 22)}${text(135, 334, '0', 18)}<path d="M210 110C270 170 390 240 540 280" fill="none" stroke="#b65a32" stroke-width="5"/>${text(550, 265, 'D', 22)}`,
  },
  'civic-education': {
    title: 'A civic activity',
    body: `<path d="M220 200L275 165H455L510 200V340H220Z" fill="#e8f1ff" stroke="#2455a4" stroke-width="4"/><path d="M220 200H510" stroke="#2455a4" stroke-width="3"/><path d="M300 185H425" stroke="#172b4d" stroke-width="8"/><path d="M320 110L398 102L411 184L333 192Z" fill="white" stroke="#52739e" stroke-width="3"/><path d="M350 143L364 156L387 126" fill="none" stroke="#29835a" stroke-width="5"/><path d="M425 62L371 75Q350 80 353 104L397 114L445 103L510 77" fill="#e4bb98" stroke="#80512b" stroke-width="3"/>${text(365, 285, 'BALLOT BOX', 24)}`,
  },
};
const directory = path.resolve(__dirname, '../public/question-images');
fs.mkdirSync(directory, { recursive: true });
for (const [slug, { title, body }] of Object.entries(diagrams)) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="700" height="420" viewBox="0 0 700 420" role="img" aria-labelledby="title"><title id="title">${title}</title><defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto"><path d="M0 0L6 3L0 6Z" fill="#2455a4"/></marker></defs><rect width="700" height="420" rx="16" fill="white"/><g font-family="Arial, Helvetica, sans-serif">${text(350, 38, title, 25)}${body}</g></svg>\n`;
  fs.writeFileSync(path.join(directory, slug + '.svg'), svg);
}
console.log(`Generated ${Object.keys(diagrams).length} question diagrams.`);
