// Local browser regression. Creates and removes only an isolated QA tenant.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const puppeteer = require('../functions/node_modules/puppeteer');
const { ad: admin } = require('../functions/lib/seed/firebase');
const lifecycle = require('../functions/lib/exam/question-lifecycle');
const { totp } = require('../functions/lib/security/account-security');
const db = admin.firestore(), tenantId = 'qa-features-ui-' + Date.now().toString(36);
const root = db.doc('tenants/' + tenantId), subject = root.collection('subjects').doc('mixed');
const users = [], output = path.resolve(__dirname, '../artifacts/remaining-features');
let browser;
const watchdog = setTimeout(() => { console.error('Browser regression timed out.'); browser?.process()?.kill(); }, 300000); watchdog.unref();
async function account(role) {
  const user = await admin.auth().createUser({ email: `${tenantId}-${role}@cbt.test`, password: 'Remaining12345!', emailVerified: true });
  users.push(user.uid); await admin.auth().setCustomUserClaims(user.uid, { role, tenantId });
  await root.collection('users').doc(user.uid).set({ uid: user.uid, email: user.email, role, status: 'active' }); return user;
}
async function click(page, selector, text) {
  await page.waitForFunction((selector, text) => [...document.querySelectorAll(selector)].some(el => el.textContent.trim() === text), {}, selector, text);
  for (const handle of await page.$$(selector)) if ((await handle.evaluate(el => el.textContent.trim())) === text) { await handle.evaluate(el => el.scrollIntoView({ block: 'center' })); await handle.click(); return; }
  throw new Error(`Missing ${selector}: ${text}`);
}
async function contains(page, text) { await page.waitForFunction(value => document.body.textContent.includes(value), { timeout: 45000 }, text); }
async function fill(page, selector, value) {
  await page.waitForSelector(selector); await page.$eval(selector, (el, value) => { el.value = value; el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); }, value);
}
async function go(page, route) { console.log('Checking', route); await page.goto('http://127.0.0.1:4200' + route, { waitUntil: 'domcontentloaded' }); }
async function login(page, user, route) {
  await go(page, '/authentication'); await page.waitForSelector('#signinSrEmail'); await page.type('#signinSrEmail', user.email); await page.type('#signupSrPassword', 'Remaining12345!'); await page.click('button[type=submit]');
  await page.waitForFunction(value => location.pathname.startsWith(value), { timeout: 60000 }, route);
}
async function main() {
  fs.mkdirSync(output, { recursive: true });
  try {
    await root.set({ name: 'Assessment browser QA', shortName: 'QA', tenantCode: tenantId, status: 'active', accessStatus: 'enabled', locked: false, modules: { subjects: true, exams: true, results: true, students: true, staff: true, notifications: true, exports: true, publicResults: true }, limits: { subjects: 20, users: 100, staff: 20, monthlyAttempts: 100 }, usage: { subjects: 1, monthlyAttempts: 0 }, address: 'QA', email: 'qa@cbt.test', phone: '08000000000', timezone: 'Africa/Lagos', currency: 'NGN' });
    await subject.set({ name: 'Mixed assessment', active: true, questionLimit: 5, timeLimit: 15 });
    const owner = await account('admin'), student = await account('student');
    await root.collection('student').doc(student.uid).set({ authUid: student.uid, firstname: 'QA', lastname: 'Learner', admissionNumber: 'QA-01', department: 'SS2', registeredSubjectIds: ['mixed'], examStatus: 'Started' });
    browser = await puppeteer.launch({ headless: true, protocolTimeout: 90000 });
    const page = await browser.newPage(); page.setDefaultTimeout(25000); await page.setViewport({ width: 1440, height: 1080 });
    page.on('response', async response => { if (response.url().includes('question_lifecycle-saveQuestion') && response.status() >= 400) console.error('Question save failed:', await response.text()); });
    await login(page, owner, '/admin');
    await go(page, '/admin/adding-exam-question?id=mixed');
    await page.waitForSelector('#question-type'); await page.select('#question-type', 'essay');
    await fill(page, '#question-text', 'Explain the water cycle.'); await fill(page, '#question-passage', 'Use this passage about water.');
    await fill(page, '#question-formula', '\\frac{1}{2}+x^2'); await fill(page, '#question-table', 'Stage|Description\nEvaporation|Vapour');
    await fill(page, '#essay-rubric', 'One mark for a coherent explanation; partial marks allowed.'); await fill(page, '#question-explanation', 'Water evaporates, condenses and falls as precipitation.');
    await page.click('input[formcontrolname=practiceEnabled]');
    await click(page, 'button', 'Preview question'); await page.waitForSelector('app-question-content math mfrac');
    assert.equal(await page.$$eval('app-question-content td', cells => cells.length), 4);
    await click(page, 'button', 'Save draft'); await contains(page, 'Version 1 saved');
    await click(page, 'button', 'Submit for review'); await contains(page, 'Version 2 saved');
    const essay = (await subject.collection('exams').get()).docs[0];
    await go(page, '/admin/question-review'); await page.waitForSelector('#review-subject');
    await page.waitForFunction(() => document.querySelector('#review-subject').options.length > 1); await page.select('#review-subject', 'mixed'); await contains(page, 'Explain the water cycle.');
    await click(page, 'button', 'Approve'); await contains(page, 'Question approved.');
    await go(page, `/admin/updating-exams/mixed/${essay.id}`); await contains(page, 'Version 3'); await click(page, 'button', 'Version history');
    await click(page, 'button', 'Version 1 — saved_draft'); await click(page, 'button', 'Restore this version as a new draft'); await contains(page, 'Version restored as a new draft.');
    await click(page, 'button', 'Save and approve'); await contains(page, 'Version 5 saved');
    await page.screenshot({ path: path.join(output, 'rich-editor.png'), fullPage: true });
    console.log('Browser rich editor, MathML, tables, review and version restoration passed.');

    const auth = { uid: owner.uid, token: { role: 'admin', tenantId, auth_time: Math.floor(Date.now() / 1000) } };
    const base = { question: 'Fixture', questionType: 'mcq', options: [{ id: 'A', text: 'One' }, { id: 'B', text: 'Two' }], correctAnswerId: 'A', practiceEnabled: true, explanation: 'A practice explanation.', topic: 'Fundamentals', difficulty: 'medium' };
    for (const question of [
      { ...base, question: 'Select both values.', questionType: 'multiple_answer', correctAnswerIds: ['A', 'B'] },
      { ...base, question: 'Name the city.', questionType: 'fill_blank', acceptedAnswers: ['Lagos'] },
      { ...base, question: 'Match each item.', questionType: 'matching', matchingPairs: [{ left: 'Nigeria', right: 'Abuja' }, { left: 'Planet', right: 'Jupiter' }] },
      { ...base, question: 'Choose One.', imageUrl: '/question-images/math.svg', imageAlt: 'Mathematics diagram', options: [{ id: 'A', text: 'One', imageUrl: '/question-images/math.svg', imageAlt: 'Option illustration' }, { id: 'B', text: 'Two' }] },
    ]) await lifecycle.saveQuestion.run({ auth, data: { subjectId: 'mixed', question, action: 'approve' } });
    await go(page, '/admin/staff-access'); await page.waitForSelector('#staff-access-name');
    await fill(page, '#staff-access-name', 'QA Author'); await fill(page, '#staff-access-email', `${tenantId}-author@cbt.test`); await fill(page, '#staff-access-password', 'Remaining12345!');
    await click(page, 'button', 'Question author preset'); await click(page, 'button', 'Save staff access'); await contains(page, 'Staff access saved.');
    const author = await admin.auth().getUserByEmail(`${tenantId}-author@cbt.test`); users.push(author.uid);
    assert.deepEqual((await root.collection('users').doc(author.uid).get()).data().permissions, ['questions.write']);
    await go(page, '/admin/scheduling'); await page.waitForSelector('#schedule-subject'); await page.waitForFunction(() => document.querySelector('#schedule-subject').options.length > 1); await page.select('#schedule-subject', 'mixed');
    await page.click('app-exam-scheduling input[type=checkbox]');
    const localDate = ms => { const d = new Date(ms); return new Date(ms - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16); };
    await fill(page, '#exam-start', localDate(Date.now() + 3600000)); await fill(page, '#exam-end', localDate(Date.now() + 7200000));
    await click(page, 'button', 'Save schedule'); await contains(page, 'Schedule saved.'); await click(page, 'button', 'Generate upcoming in-app reminders now'); await contains(page, 'Created 1 new reminders.');
    // Disable only this fixture's window to exercise the examination immediately.
    await page.click('app-exam-scheduling input[type=checkbox]'); await click(page, 'button', 'Save schedule'); await contains(page, 'Schedule saved.');
    await go(page, '/admin/result-workflow'); await page.waitForSelector('select[aria-label="Default release policy"]'); await page.select('select[aria-label="Default release policy"]', 'withheld'); await click(page, 'button', 'Save release policy'); await contains(page, 'Release policy saved.');

    const context = await browser.createBrowserContext(), candidate = await context.newPage(); candidate.setDefaultTimeout(25000); await candidate.setViewport({ width: 1440, height: 1080 });
    await login(candidate, student, '/home'); await go(candidate, '/student/practice'); await candidate.waitForSelector('#practice-subject'); await candidate.waitForFunction(() => document.querySelector('#practice-subject').options.length > 1);
    await candidate.select('#practice-subject', 'mixed'); await click(candidate, 'button', 'Start practice session'); await candidate.waitForSelector('app-question-response'); await click(candidate, 'button', 'Check answer'); await contains(candidate, '1 checked');
    assert.equal((await root.collection('results').get()).size, 0);
    await candidate.screenshot({ path: path.join(output, 'practice.png'), fullPage: true });
    await go(candidate, '/student/assessments'); await contains(candidate, 'Upcoming examination');
    await go(candidate, '/student/exam'); await candidate.waitForSelector('.accept-row input'); await candidate.click('.accept-row input'); await click(candidate, 'button', 'Begin exam'); await candidate.waitForSelector('app-question-response');
    for (let index = 0; index < 5; index++) {
      const type = await candidate.$eval('app-question-response', el => window.ng.getComponent(el).question.questionType);
      if (type === 'essay' || type === 'fill_blank') await fill(candidate, 'app-question-response textarea', type === 'essay' ? 'Water evaporates, condenses and falls as precipitation.' : 'Lagos');
      else if (type === 'matching') {
        for (const select of await candidate.$$('app-question-response select')) {
          const wanted = await select.evaluate(el => [...el.options].find(option => option.textContent.trim() === (el.closest('.row').textContent.includes('Nigeria') ? 'Abuja' : 'Jupiter')).value); await select.select(wanted);
        }
      } else {
        const choices = await candidate.$$('app-question-response .option-row');
        for (const choice of choices) if (type === 'multiple_answer' || (await choice.evaluate(el => el.textContent.includes('One')))) { const letter = await choice.$('.option-letter'); await letter.evaluate(el => el.scrollIntoView({ block: 'center' })); await letter.click(); }
      }
      await candidate.waitForFunction(expected => Number(document.querySelector('.nav-summary strong').textContent) === expected, {}, index + 1);
      if (index < 4) { await click(candidate, '.question-actions button', 'Next →'); await candidate.waitForFunction(expected => document.querySelector('.question-number')?.textContent.includes(expected), {}, `Question ${index + 2} of 5`); }
    }
    await candidate.screenshot({ path: path.join(output, 'rich-exam.png'), fullPage: true });
    await click(candidate, '.submit-bar button', 'Submit all subjects'); await click(candidate, '.confirm-dialog button', 'Submit now'); await candidate.waitForSelector('.submission-card');
    const result = (await root.collection('results').get()).docs[0]; assert.equal(result.data().pendingManual, 1); assert.equal(result.data().score, 4);
    console.log('Browser practice, reminders and all five response controls with submission passed.');
    await go(page, '/admin/result-workflow'); await click(page, 'button', 'Review / mark / release'); await page.waitForSelector('input[aria-label^="Marks for"]');
    await fill(page, 'input[aria-label^="Marks for"]', '0.5'); await fill(page, 'textarea[aria-label^="Feedback for"]', 'Partially correct.'); await click(page, 'button', 'Save essay mark'); await contains(page, 'Essay mark saved.');
    await page.waitForFunction(() => [...document.querySelectorAll('button')].some(el => el.textContent.trim() === 'Release now' && !el.disabled));
    await click(page, 'button', 'Release now'); await contains(page, 'Result release updated.');
    await go(candidate, '/student/assessments'); await click(candidate, 'button', 'Appeal result'); await fill(candidate, '#appeal-reason', 'Please review the partial essay mark.'); await click(candidate, 'button', 'Submit appeal'); await contains(candidate, 'Appeal submitted.');
    await go(page, '/admin/result-workflow'); await page.waitForSelector('textarea[id^="appeal-response-"]'); await fill(page, 'textarea[id^="appeal-response-"]', 'Reviewed and confirmed against the rubric.'); await click(page, 'button', 'Resolve appeal'); await contains(page, 'Appeal resolved.');
    await page.screenshot({ path: path.join(output, 'results-and-appeals.png'), fullPage: true });
    await go(page, '/admin/readiness'); await contains(page, 'Registered candidates'); await click(page, 'button', 'Check this browser and question images'); await contains(page, 'images loaded; 0 failed.');
    await go(page, '/admin/backups'); await click(page, 'button', 'Create backup now'); await contains(page, 'Backup created.'); await page.waitForFunction(() => [...document.querySelectorAll('button')].some(el => el.textContent.trim() === 'Preview restore'));
    await essay.ref.delete(); await click(page, 'button', 'Preview restore'); await contains(page, '1 missing');
    const confirmations = await page.$$('app-backups section:last-child input[type=checkbox]'); await confirmations[1].click(); await click(page, 'button', 'Restore backup'); await contains(page, 'Restore complete: 1 records restored.'); assert.ok((await essay.ref.get()).exists);
    console.log('Browser marking, result publication, appeals, readiness and backup restoration passed.');

    await page.keyboard.down('Alt'); await page.keyboard.press('a'); await page.keyboard.up('Alt'); await page.waitForSelector('#reading-scale');
    const scale = await page.$eval('#reading-scale', el => [...el.options].find(option => option.textContent === '130%').value); await page.select('#reading-scale', scale);
    await page.click('#accessibility-panel input[type=checkbox]'); await page.keyboard.press('Escape'); assert.equal(await page.$eval('html', el => el.hasAttribute('data-high-contrast')), true);
    await go(page, '/admin/security'); assert.equal(await page.$eval('html', el => el.style.getPropertyValue('--cbt-text-scale')), '1.3');
    await click(page, 'button', 'Set up two-factor authentication'); await page.waitForSelector('.setup-key'); const secret = await page.$eval('.setup-key', el => el.textContent.trim());
    await fill(page, '#enroll-code', totp(secret)); await click(page, 'button', 'Confirm enrollment'); await contains(page, 'Two-factor authentication enabled.');
    const recovery = await page.$eval('.alert-warning code', el => el.textContent.trim());
    const sessions = await db.collection('secondFactorSessions').where('uid', '==', owner.uid).get(); for (const session of sessions.docs) await session.ref.delete();
    await go(page, '/admin/readiness'); await page.waitForSelector('#security-code'); await fill(page, '#security-code', recovery); await click(page, 'button', 'Verify and continue'); await page.waitForFunction(() => location.pathname.startsWith('/admin/'));
    await go(page, '/admin/security'); await contains(page, '7 recovery codes remaining.');
    assert.equal(await page.$eval('.app-workspace', el => getComputedStyle(el).backgroundColor), 'rgb(0, 0, 0)');
    assert.equal(await page.$eval('h1', el => getComputedStyle(el).color), 'rgb(255, 255, 255)');
    await page.screenshot({ path: path.join(output, 'account-security.png'), fullPage: true });
    console.log('Browser accessibility persistence, authenticator enrollment and recovery-code challenge passed.');
  } catch (error) {
    console.error('Browser check failed:', error.message);
    if (browser) for (const [index, page] of (await browser.pages()).entries()) { fs.writeFileSync(path.join(output, `failure-${index}.txt`), await page.$eval('body', el => el.innerText).catch(() => '')); await Promise.race([page.screenshot({ path: path.join(output, `failure-${index}.png`), fullPage: true }).catch(() => {}), new Promise(resolve => setTimeout(resolve, 3000))]); }
    throw error;
  } finally {
    clearTimeout(watchdog); if (browser) await browser.close();
    for (const row of (await db.collection('resultChecks').where('tenantId', '==', tenantId).get()).docs) await row.ref.delete();
    const bucket = admin.storage().bucket(); for (const file of (await bucket.getFiles({ prefix: `tenants/${tenantId}/` }))[0]) await file.delete();
    await db.recursiveDelete(root);
    for (const uid of users) { await db.doc('accountSecurity/' + uid).delete(); for (const row of (await db.collection('secondFactorSessions').where('uid', '==', uid).get()).docs) await row.ref.delete(); await db.recursiveDelete(db.doc('userTenancies/' + uid)); await admin.auth().deleteUser(uid); }
    await admin.app().delete();
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
