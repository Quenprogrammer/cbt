const assert=require('node:assert/strict');
const admin=require('../functions/node_modules/firebase-admin');
process.env.FIRESTORE_EMULATOR_HOST='127.0.0.1:8980';
process.env.FIREBASE_AUTH_EMULATOR_HOST='127.0.0.1:9099';
const app=admin.initializeApp({projectId:'cbt-sass'},'onboarding-verification');
const db=app.firestore(),auth=app.auth(),suffix=Date.now().toString(36),users=[],tenants=[];
const password='OnboardingTest123!';
async function identity(label,verified=true){
 const email='onboarding-'+label+'-'+suffix+'@cbt.test';
 const user=await auth.createUser({email,password,emailVerified:verified,displayName:'QA '+label});users.push(user.uid);
 return{uid:user.uid,email,token:await token(email)};
}
async function token(email){
 const response=await fetch('http://127.0.0.1:9099/identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=emulator',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password,returnSecureToken:true})});
 const data=await response.json();assert.ok(data.idToken,'Emulator sign in failed');return data.idToken;
}
async function call(group,name,data={},who){
 const response=await fetch('http://127.0.0.1:5001/cbt-sass/us-central1/'+group+'-'+name,{method:'POST',headers:{'Content-Type':'application/json',...(who?{Authorization:'Bearer '+who.token}:{})},body:JSON.stringify({data})});
 return response.json();
}
async function ok(group,name,data,who){const result=await call(group,name,data,who);assert.ok(!result.error,name+': '+JSON.stringify(result.error));return result.result;}
async function denied(group,name,data,status,who){const result=await call(group,name,data,who);assert.equal(result.error?.status,status,name+': '+JSON.stringify(result));}
const group='institution_onboarding';
function institution(code){return{code,name:'QA institution',shortName:'QA',address:'Local testing address',phone:'08000000000',contactEmail:'qa@cbt.test',timezone:'Africa/Lagos',limits:{students:999999},role:'platform-owner',planId:'enterprise'};}
function profile(admission){return{admissionNumber:admission,firstname:'Test',lastname:'Student',gender:'Other',dateOfBirth:'2006-01-01',department:'SS 2',subjectIds:['onboarding-first-subject']};}
async function main(){
 try{
  const owner=await identity('owner',false);
  await denied(group,'checkInstitutionCode',{code:'qa-'+suffix},'UNAUTHENTICATED');
  await denied(group,'provisionInstitution',institution('qa-'+suffix),'FAILED_PRECONDITION',owner);
  await auth.updateUser(owner.uid,{emailVerified:true});owner.token=await token(owner.email);
  const firstCode='qa-'+suffix;
  const created=await ok(group,'provisionInstitution',institution(firstCode),owner);tenants.push(created.tenantId);
  const root=db.doc('tenants/'+created.tenantId);
  assert.equal((await root.get()).data().planId,'starter');
  assert.notEqual((await root.get()).data().limits.students,999999);
  assert.equal((await auth.getUser(owner.uid)).customClaims.role,'admin');
  assert.equal((await ok(group,'provisionInstitution',institution(firstCode),owner)).tenantId,created.tenantId);
  await denied(group,'provisionInstitution',institution(firstCode+'-other'),'ALREADY_EXISTS',owner);
  const second=await identity('other-owner');
  await denied(group,'provisionInstitution',institution(firstCode),'ALREADY_EXISTS',second);
  const other=await ok(group,'provisionInstitution',institution('qa-other-'+suffix),second);tenants.push(other.tenantId);
  await auth.setCustomUserClaims(owner.uid,{});
  const repaired=await ok(group,'registrationState',{},owner);assert.equal(repaired.role,'admin');owner.token=await token(owner.email);
  const forged=await fetch('http://127.0.0.1:8980/v1/projects/cbt-sass/databases/(default)/documents/tenants/'+created.tenantId+'/settings/onboarding',{method:'PATCH',headers:{'Content-Type':'application/json',Authorization:'Bearer '+owner.token},body:JSON.stringify({fields:{status:{stringValue:'completed'}}})});
  assert.equal(forged.status,403,'Onboarding progress must only be written through validated Functions.');
  let state=await ok(group,'getInstitutionOnboardingState',{},owner);
  assert.equal(state.progress.revision,0);
  async function save(step,data={},action='continue'){
   const result=await ok(group,'saveInstitutionOnboardingStep',{step,expectedRevision:state.progress.revision,data,action},owner);
   state=await ok(group,'getInstitutionOnboardingState',{},owner);return result;
  }
  await save('welcome');
  await denied(group,'saveInstitutionOnboardingStep',{step:'profile',expectedRevision:0,data:{}},'ABORTED',owner);
  await denied(group,'saveInstitutionOnboardingStep',{step:'profile',expectedRevision:state.progress.revision,data:{}},'INVALID_ARGUMENT',owner);
  await save('profile',{name:'Updated QA institution',shortName:'QA',email:owner.email,address:'Updated local address',phone:'08000000000',timezone:'Africa/Lagos'});
  await save('academic',{className:'SS 2',department:'Science'});
  await save('exam',{createSubject:true,name:'English Language',description:'QA draft',className:'SS 2',timeLimit:30,questionLimit:20},'pause');
  assert.equal(state.progress.paused,true);assert.equal(state.progress.currentStep,'exam');
  const subject=root.collection('subjects').doc('onboarding-first-subject');assert.equal((await subject.get()).data().active,false);
  assert.equal((await root.collection('subjects').get()).size,1);
  await save('exam',{createSubject:false});
  await save('registration',{},'back');assert.equal(state.progress.currentStep,'exam');
  await save('exam',{createSubject:false});
  await save('registration');await save('review');
  assert.equal(state.progress.status,'completed');
  assert.equal((await root.get()).data().name,'Updated QA institution');
  const anonSubjects=await ok('student_accounts','listRegistrationSubjects',{tenantCode:firstCode});assert.equal(anonSubjects.subjects.length,0);
  await denied(group,'setSubjectAvailability',{subjectId:subject.id,active:true},'FAILED_PRECONDITION',owner);
  await subject.collection('exams').doc('qa-question').set({question:'Sample question?',options:[{id:'a',text:'A'},{id:'b',text:'B'}],correctAnswerId:'a'});
  await ok(group,'setSubjectAvailability',{subjectId:subject.id,active:true},owner);
  await root.update({'limits.students':1,'limits.users':3});
  const studentA=await identity('student-a',false),studentB=await identity('student-b');
  await denied('student_accounts','registerStudent',{...profile('A-1'),tenantCode:firstCode},'FAILED_PRECONDITION',studentA);
  await auth.updateUser(studentA.uid,{emailVerified:true});studentA.token=await token(studentA.email);
  await ok(group,'setRegistrationIntent',{intent:'student',tenantCode:firstCode},studentA);
  assert.equal((await ok(group,'registrationState',{},studentA)).intent,'student');
  const attempts=await Promise.all([call('student_accounts','registerStudent',{...profile('A-1'),tenantCode:firstCode},studentA),call('student_accounts','registerStudent',{...profile('B-1'),tenantCode:firstCode},studentB)]);
  assert.equal(attempts.filter(result=>!result.error).length,1,'Only one registration should fit the available capacity.');
  assert.equal(attempts.find(result=>result.error)?.error.status,'RESOURCE_EXHAUSTED');
  assert.equal((await root.collection('student').get()).size,1);
  const winner=attempts[0].error?studentB:studentA,admission=attempts[0].error?'B-1':'A-1';
  winner.token=await token(winner.email);
  await ok('student_accounts','registerStudent',{...profile(admission),tenantCode:firstCode},winner);
  await denied('student_accounts','registerStudent',{...profile(admission),tenantCode:'qa-other-'+suffix},'PERMISSION_DENIED',winner);
  await denied('student_accounts','listRegistrationSubjects',{tenantCode:'qa-other-'+suffix},'PERMISSION_DENIED',winner);
  await denied(group,'getInstitutionOnboardingState',{},'PERMISSION_DENIED',winner);
  await denied(group,'setSubjectAvailability',{subjectId:subject.id,active:false},'PERMISSION_DENIED',winner);
  await root.update({locked:true,statusReason:'QA restriction'});
  await denied(group,'getInstitutionOnboardingState',{},'PERMISSION_DENIED',owner);
  await denied('student_accounts','resolveRegistrationTenant',{tenantCode:firstCode},'PERMISSION_DENIED');
  console.log('PASS: verified signup, server-owned defaults, code collision/idempotency, claim recovery, step validation/revisions, pause/resume/back/completion, inactive draft, student verification, concurrent capacity, retry and tenant/role restrictions.');
 }finally{
  for(const tenantId of tenants){
   const records=await db.collection('platformAuditLogs').where('tenantId','==',tenantId).get();for(const record of records.docs)await record.ref.delete();
   await db.recursiveDelete(db.doc('tenants/'+tenantId));
  }
  for(const uid of users){
   for(const name of ['institutionSignups','registrationIntents','studentAccountBindings'])await db.doc(name+'/'+uid).delete();
   await db.recursiveDelete(db.doc('userTenancies/'+uid));
   const limits=await db.collection('signupRateLimits').where(admin.firestore.FieldPath.documentId(),'>=',uid+'-').where(admin.firestore.FieldPath.documentId(),'<',uid+'.').get();for(const item of limits.docs)await item.ref.delete();
   await auth.deleteUser(uid).catch(()=>{});
  }
  await app.delete();
 }
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});

