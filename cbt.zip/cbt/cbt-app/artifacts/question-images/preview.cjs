const fs = require('node:fs');
const path = require('node:path');
const puppeteer = require('../../functions/node_modules/puppeteer');
(async () => {
  const browser = await puppeteer.launch({ headless: true });
  const page = await browser.newPage();
  await page.setViewport({ width: 1500, height: 1400 });
  const dir = path.resolve('public/question-images');
  await page.setContent('<style>body{font-family:Arial;background:#edf1f5;display:grid;grid-template-columns:repeat(3,1fr);gap:12px;padding:16px}article{background:white;border-radius:12px;padding:8px}img{width:100%}</style>' + fs.readdirSync(dir).map(f => '<article><img src="data:image/svg+xml;base64,' + fs.readFileSync(path.join(dir, f)).toString('base64') + '"></article>').join(''));
  await page.waitForFunction(() => [...document.images].every(img => img.complete && img.naturalWidth > 0));
  await page.screenshot({ path: 'artifacts/question-images/diagrams.png', fullPage: true });
  await browser.close();
})();
