const assert = require('node:assert/strict');
const fs = require('node:fs');
const puppeteer = require('../../functions/node_modules/puppeteer');
const { ad: admin } = require('../../functions/lib/seed/firebase');
const db = admin.firestore();
const suffix = Date.now().toString(36);
const id = 'qa-image-ui-' + suffix;
const email = id + '@cbt.test';
const root = db.doc('tenants/' + id);
let browser, user;
(async () => {
 try {
  user = await admin.auth().createUser({email, password:'ImageTest123!', emailVerified:true});
  await admin.auth().setCustomUserClaims(user.uid, {role:'admin', tenantId:id});
  await root.set({name:'Image questions QA',shortName:'QA',tenantCode:id,status:'active',accessStatus:'enabled',locked:false,modules:{subjects:true,exams:true},limits:{subjects:20},usage:{subjects:1},address:'QA',email,phone:'08000000000',timezone:'Africa/Lagos',currency:'NGN'});
  await root.collection('users').doc(user.uid).set({role:'admin',email});
  const subject = root.collection('subjects').doc('math');
  await subject.set({name:'Math QA',active:true,timeLimit:1,questionLimit:1});
  browser = await puppeteer.launch({headless:true});
  const page = await browser.newPage();
  await page.setViewport({width:1440,height:1100});
  const dialogs=[];
  page.on('dialog', async dialog=>{dialogs.push(dialog.message());await dialog.accept();});
  await page.goto('http://127.0.0.1:4200/authentication');
  await page.waitForSelector('#signinSrEmail');
  await page.type('#signinSrEmail',email);
  await page.type('#signupSrPassword','ImageTest123!');
  await page.click('button[type=submit]');
  await page.waitForFunction(()=>location.pathname.startsWith('/admin'),{timeout:30000});
  await page.goto('http://127.0.0.1:4200/admin/adding-exam-question?id=math');
  await page.waitForSelector('#question-text');
  await page.type('#question-text','Image upload browser verification');
  const png='artifacts/question-images/test-upload.png';
  fs.writeFileSync(png,Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII=','base64'));
  const fileInput=await page.$('#question-image-file');
  await fileInput.uploadFile(png);
  await page.waitForFunction(()=>document.querySelector('#question-image-url').value.startsWith('http://localhost:9199'),{timeout:15000});
  await page.type('#question-image-alt','An uploaded test diagram');
  const options=await page.$$('input[formcontrolname=text]');
  for(let i=0;i<options.length;i++) await options[i].type('Option '+i);
  await page.select('#correct-answer','A');
  await page.click('button[type=submit]');
  await page.waitForFunction(()=>document.querySelector('#question-text').value==='');
  const saved=await subject.collection('exams').get();
  assert.equal(saved.size,1);
  const q=saved.docs[0];
  assert.ok(q.data().imageUrl.includes('question-images%2F'));
  assert.equal(q.data().imageAlt,'An uploaded test diagram');
  assert.ok(dialogs.includes('Question added successfully.'));
  await page.goto('http://127.0.0.1:4200/admin/updating-exams/math/'+q.id);
  await page.waitForFunction(()=>document.querySelector('#question-image-alt')?.value==='An uploaded test diagram');
  await page.screenshot({path:'artifacts/question-images/edit-question.png',fullPage:true});
  const buttons=await page.$$('button');
  for(const button of buttons){if((await button.evaluate(el=>el.textContent)).includes('Remove image')){await button.click();break;}}
  await page.click('button[type=submit]');
  await page.waitForFunction(()=>!document.querySelector('button[type=submit]').disabled);
  assert.equal((await q.ref.get()).data().imageUrl,'');
  assert.equal((await q.ref.get()).data().imageAlt,'');
  console.log('Browser checks passed: upload, create, reload/edit, remove and save image.');
 } finally {
  if(browser)await browser.close();
  const [files]=await admin.storage().bucket().getFiles({prefix:'tenants/'+id+'/question-images/'});
  for(const file of files)await file.delete();
  await db.recursiveDelete(root);
  if(user)await admin.auth().deleteUser(user.uid);
  await admin.app().delete();
 }
})().catch(e=>{console.error(e);process.exitCode=1});

