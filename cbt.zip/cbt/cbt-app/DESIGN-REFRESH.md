# Responsive UI refresh

This build removes the previous Front Dashboard SCSS/theme bundle and replaces it with one new responsive design system.

## What changed

- Removed the old `src/scss/` Front Dashboard/theme tree.
- `angular.json` now loads only `src/styles.scss`.
- Rebuilt global tokens, typography, buttons, forms, cards, tables, navigation, badges and responsive utilities.
- Rebuilt the administration shell/sidebar for desktop, tablet and mobile.
- Rebuilt the sidebar navigation and search UI.
- Rebuilt login, sign-up and password-reset screens.
- Rebuilt dashboard header/stat cards/chart containers.
- Rebuilt student home and exam views.
- Removed inline `style="..."` attributes from application templates.
- Added responsive adapters for the existing student/staff/exam forms and data tables.
- Kept Bootstrap as the grid/layout foundation so existing templates continue to work while using the new visual system.

## Responsive breakpoints

- Desktop: sidebar navigation and multi-column dashboard/cards.
- Tablet: two-column metric/subject layouts and mobile navigation drawer.
- Mobile: single-column cards/forms, horizontally scrollable data tables, full-width actions and navigation drawer.

## Run

```bash
npm install
npm run dev
```

Or UI only:

```bash
npm start
```
