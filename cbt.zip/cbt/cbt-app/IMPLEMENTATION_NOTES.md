# CBT/JAMB Workflow Upgrade

## Current behavior

- Students can only start a **new** examination after an administrator grants permission from **Admin → Exam Control**.
- Exam permission is enforced by the callable backend, not only by the UI.
- A submitted attempt consumes the permission by changing the candidate exam status to `Completed`; an administrator can grant access again for a retake.
- Existing in-progress assignments are resumed instead of creating duplicate attempts.
- The student dashboard shows the linked candidate profile, exam-access state, active subjects and quick tools.
- After submission, the candidate sees **only the result PIN and submission confirmation**. Score, grade, subject performance and pass/fail are not returned by the submission API.
- Candidate attempt history shows session metadata and result PINs only.
- Candidate reads of private `results` and `examAttempts` are blocked by Firestore rules.
- Official candidate results are available through `/result-check` with an exact PIN lookup.
- Administrators retain access to Result Management and detailed attempt analysis.

## Exam workflow features

- Secure callable exam delivery (`getExamPackage`) so student clients never receive `correctAnswerId`.
- Randomized question selection and option order per candidate.
- MCQ and True/False question management.
- One multi-subject examination submission for all active subjects.
- Continuous countdown timer and automatic submission at expiry.
- Pre-exam instructions and acknowledgement.
- Automatic answer saving to localStorage + Firestore `examDrafts`.
- Question navigator with answered/unanswered indicators.
- Submit confirmation dialog.
- Server-side grading with per-subject score, percentage, grade, pass/fail, correct/incorrect/unanswered and time tracking.
- Private `examAttempts` / `results` collections and public exact-PIN `resultChecks/{PIN}` documents.
- Public `/result-check` page accessible without login.
- Student `/student/history` attempt-history page without score leakage.

## Administration

- Redesigned advanced admin dashboard with live exam status, quick actions, real statistics, gender and department charts, exam-readiness overview and recent audit activity.
- Redesigned **Exam Control** with bulk grant/block, individual grant/block, candidate login-link status, access metrics and search.
- Admin `/admin/results`, `/admin/attempt-monitoring`, `/admin/notifications`, `/admin/activity-logs` pages.
- Candidate CSV import/export on student list.
- User & Roles navigation.
- Audit entries for candidate/staff/subject/question creation and imports; exam starts/submissions are logged server-side.

## Student portal

- Redesigned student dashboard with complete linked-profile summary.
- Clear exam permission state: Access granted / Waiting / Blocked / Completed.
- Start Exam button is disabled unless access has been granted.
- Result Checker and Attempt History remain available from the candidate dashboard.

## Firestore collections

- `examAssignments`
- `examDrafts`
- `examAttempts`
- `results`
- `resultChecks`
- `activityLogs`
- `notifications`

## Security changes

- Students may read only their own linked `student` profile.
- Students may read their own `examAssignments` and drafts.
- Detailed `examAttempts` and `results` are admin-only.
- `resultChecks/{PIN}` allows exact document `get` but not collection listing.
- Question answer keys remain admin/server-only.

## Validation

Changed TypeScript sources were syntax-checked successfully. A complete Angular/npm build could not be completed in the generation environment because package installation stalled while fetching dependencies. On your development machine run:

```powershell
npm install
npm run verify
npm run emulators
```

If you changed Firestore rules while the emulators were already running, restart the emulator suite before testing the new permissions.
