export const environment = {
  production: false,
  useEmulator: true,
  studentAccountLink: 'http://localhost:4200/home', // Ensure this is correct
  cbtAccountLink: 'http://localhost:4200/',

  firebaseApp: {
    apiKey: "AIzaSyDPWXB4j38pUbGOUfx97aa8KcKk5pNNq3Q",
    authDomain: "cbt-sass.firebaseapp.com",
    projectId: "cbt-sass",
    storageBucket: "cbt-sass.firebasestorage.app",
    messagingSenderId: "775641539345",
    appId: "1:775641539345:web:a3841a50da85199542a2b0",
    measurementId: "G-7GE0FSTSB8"
  }
};
