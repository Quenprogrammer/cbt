import {Routes} from "@angular/router";
import { administratorSetupGuard } from '../guards/onboarding.guard';
import { staffPermissionGuard } from '../guards/role.guard';

export const routes: Routes = ([
  { path:'question-review',loadComponent:()=>import('../features/assessment/question-review.component').then(m=>m.QuestionReviewComponent) },
  { path:'result-workflow',loadComponent:()=>import('../features/assessment/result-workflow.component').then(m=>m.ResultWorkflowComponent) },
  { path:'scheduling',loadComponent:()=>import('../features/assessment/scheduling.component').then(m=>m.SchedulingComponent) },
  { path:'readiness',loadComponent:()=>import('../features/assessment/readiness.component').then(m=>m.ReadinessComponent) },
  { path:'backups',loadComponent:()=>import('../features/assessment/backups.component').then(m=>m.BackupsComponent) },
  { path:'staff-access',loadComponent:()=>import('../features/assessment/staff-access.component').then(m=>m.StaffAccessComponent) },
  { path:'security',loadComponent:()=>import('../features/security/security.component').then(m=>m.SecurityComponent) },
/*  {path: '', redirectTo: '', pathMatch: 'full'},*/
  {
    path: 'dashboard',
    canActivate: [administratorSetupGuard],
    loadComponent: () => import('../features/dashboard/dashboard.component').then(_ => _.DashboardComponent)
  },
  {

    path: 'users',
    loadComponent: () => import('../features/users/users.component').then(_ => _.UsersComponent)
  },
  {

    path: 'student-list',
    loadComponent: () => import('../features/student/student-list/student-list.component').then(_ => _.StudentListComponent)
  },

 {

    path: 'add-student',
    loadComponent: () => import('../features/student/add-student/add-student.component').then(_ => _.AddStudentComponent)
  },
 {

    path: 'add-staff',
    loadComponent: () => import('../features/staff/add-staff/add-staff.component').then(_ => _.AddStaffComponent)
  },
  {

    path: 'edit-student/:id',
    loadComponent: () => import('../features/student/edit-student/edit-student.component').then(_ => _.EditStudentComponent)
  },
  {

    path: 'edit-staff/:id',
    loadComponent: () => import('../features/staff/edit-staff/edit-staff.component').then(_ => _.EditStaffComponent)
  },
  {

    path: 'staff-list',
    loadComponent: () => import('../features/staff/staff-list/staff-list.component').then(_ => _.StaffListComponent)
  },
  {

    path: 'exam-list',
    loadComponent: () => import('../features/exams/exam-list/exam-list.component').then(_ => _.ExamListComponent)
  },
  {

    path: 'add-exams',
    loadComponent: () => import('../features/exams/add-exams/add-exams.component').then(_ => _.AddExamsComponent)
  },
  {

    path: 'debug',
    loadComponent: () => import('../features/debug/debug.component').then(_ => _.DebugComponent)
  },
  {

    path: 'waiting-exams',
    loadComponent: () => import('../features/exams/waiting-exams/waiting-exams.component').then(_ => _.WaitingExamsComponent)
  },
  {
    path: 'exam-control',
    loadComponent: () => import('../features/exams/exam-instruction/exam-instruction.component').then(_ => _.ExamInstructionComponent)
  },
  { path: 'exam-instruction', redirectTo: 'exam-control', pathMatch: 'full' },

  {

    path: 'adding-exam-question',
    loadComponent: () => import('../features/exams/adding-exam-question/adding-exam-question.component').then(_ => _.AddingExamQuestionComponent)
  },
  { path: 'view-exam/:id',
    loadComponent: () => import("../features/exams/view-exam/view-exam.component").then(m => m.ViewExamComponent) },
  { path: 'view-score/:id',
    loadComponent: () => import("../features/exams/view-score/view-score.component").then(m => m.ViewScoreComponent) },
  { path: 'updating-exams/:subjectId/:examsId',
    loadComponent: () => import("../features/exams/updating-exams/updating-exams.component").then(m => m.UpdatingExamsComponent) },

  { path: 'results', loadComponent: () => import('../features/admin-results/admin-results.component').then(m => m.AdminResultsComponent) },
  { path: 'performance', loadComponent: () => import('../features/performance/performance.component').then(m => m.PerformanceComponent) },
  { path: 'attempt-monitoring', loadComponent: () => import('../features/admin-attempts/admin-attempts.component').then(m => m.AdminAttemptsComponent) },
  { path: 'notifications', loadComponent: () => import('../features/admin-notifications/admin-notifications.component').then(m => m.AdminNotificationsComponent) },
  { path: 'activity-logs', loadComponent: () => import('../features/admin-activity/admin-activity.component').then(m => m.AdminActivityComponent) },

] as Routes).map(route=>route.redirectTo!==undefined?route:({...route,canActivate:[...(route.canActivate||[]),staffPermissionGuard]}));
