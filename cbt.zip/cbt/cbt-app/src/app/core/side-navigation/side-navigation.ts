export interface NavigationType {
  label: string;
  icon?: string;
  matches: string,
  disabled?: boolean;
  badge?: {
    tone: string,
    text: string
  },
  secondaryAction?: {
    accessibilityLabel?: string,
    icon: string,
    tooltip: {
      content: string,
    },
  },
  subNavigationItems?: NavigationType[],
  collapsedSubNavigationItems?: boolean,
  onClick?: () => void,

}

export const mainNavigationList: NavigationType[] = [
  {
    label: 'Dashboard',
    icon: 'HomeMajor',
    matches: 'dashboard',
  },
 /* {
    label: 'Students',
    icon: 'CustomersFilledMinor',
    onClick: () => {

    },
    matches: 'student-list',
    subNavigationItems: [
      {
        label: 'Students List',
        onClick: () => {
        },
        matches: 'student-list',
      },
      {
        label: 'Add Student',
        onClick: () => {
        },
        matches: 'add-student',
      },
    /!*  {
        label: 'Extension Agents',
        onClick: () => {
        },
        matches: 'extension-agents',
      },
      {
        label: 'M&E Staff',
        onClick: () => {
        },
        matches: 'm-and-e-staff',
      }*!/
    ],
  },
  {
    label: 'Teachers',
    icon: 'CustomersMajor',
    onClick: () => {

    },
    matches: 'students',
    subNavigationItems: [
      {
        label: 'Teachers List',
        onClick: () => {
        },
        matches: 'teachers-list',
      },
      {
        label: 'Add Teachers ',
        onClick: () => {
        },
        matches: 'add-teacher',
      },
    /!*  {
        label: 'Extension Agents',
        onClick: () => {
        },
        matches: 'extension-agents',
      },
      {
        label: 'M&E Staff',
        onClick: () => {
        },
        matches: 'm-and-e-staff',
      }*!/
    ],
  },
  {
    label: 'Subjects',
    icon: 'VocabularyMajor',
    onClick: () => {

    },
    matches: 'subjects-list',
    subNavigationItems: [
      {
        label: 'subject-List',
        onClick: () => {
        },
        matches: 'teachers-list',
      },
      {
        label: 'Add exams ',
        onClick: () => {
        },
        matches: 'add-teacher',
      },
      {
        label: 'Exam-list',
        onClick: () => {
        },
        matches: 'extension-agents',
      },
      {
        label: 'M&E Staff',
        onClick: () => {
        },
        matches: 'm-and-e-staff',
      }
    ],
  },
*/
  {
    label: 'Student',
    icon: 'CustomersFilledMinor',
    badge: {
      tone: 'attention',
      text: 'New'
    },
    onClick: () => {

    },
    matches: 'student-list',
  },
  {
    label: 'Staff',
    icon: 'CustomersMajor',
    badge: {
      tone: 'attention',
      text: 'New'
    },
    onClick: () => {

    },
    matches: 'staff-list',
  },

  { label: 'Users & Invigilation', icon: 'CustomersMajor', matches: 'users' },
  {
    label: 'Exam',
    disabled: true,
    icon: 'BlogMajor',
    onClick: () => {

    },
    matches: 'exam-list',
  },
/*  {
    label: 'Early warning alert',
    disabled: true,
    icon: 'StoreStatusMajor',
    onClick: () => {
    },
    matches: 'early-warning-system',
  },*/
  { label: 'Results', icon: 'AnalyticsMajor', matches: 'results' },
  { label: 'Performance Analytics', icon: 'AnalyticsMajor', matches: 'performance' },
  { label:'Question Review',icon:'ViewMajor',matches:'question-review' },
  { label:'Marking and Release',icon:'AnalyticsMajor',matches:'result-workflow' },
  { label:'Exam Scheduling',icon:'CalendarMajor',matches:'scheduling' },
  { label:'Exam Readiness',icon:'ViewMajor',matches:'readiness' },
  { label:'Backup and Recovery',icon:'FolderMajor',matches:'backups' },
  { label:'Staff Access',icon:'CustomersMajor',matches:'staff-access' },
  { label:'Account Security',icon:'LockMajor',matches:'security' },
  { label: 'Attempt Monitoring', icon: 'ViewMajor', matches: 'attempt-monitoring' },
  { label: 'Notifications', icon: 'NotificationMajor', matches: 'notifications' },
  { label: 'Activity Logs', icon: 'ListMajor', matches: 'activity-logs' },
  {
    label: 'Exam Control',
    icon: 'PlayCircleMajor',
    onClick: () => {
    },
    matches: 'exam-control',
  },
 /* {
    label: 'farmers',
    disabled: true,
    icon: 'PlayCircleMajor',
    onClick: () => {
    },
    matches: 'farmers',
  },
  {
    label: 'Bulk SMS',
    disabled: true,
    icon: 'ComposeMajor',
    onClick: () => {
    },
    matches: 'bulk-sms',
  },
  {
    label: 'Crop prices',
    icon: 'TransactionFeeDollarMajor',
    onClick: () => {
    },
    matches: 'crop-prices',
  }*/]

export const integrations: NavigationType[] = [
  {
    label: 'YieldEx website',
    icon: 'GlobeMajor',
    onClick: () => {
      window.open('https://www.yieldex.org', '_blank', 'noreferrer')
    },
    secondaryAction: {
      icon: 'ExternalMinor',
      tooltip: {
        content: 'Open YieldEx public website',
      },
    },
    matches: 'website',

  },
  {
    label: 'Zoho mail',
    icon: 'EmailMajor',
    onClick: () => {
      window.open('https://mail.zoho.com', '_blank', 'noreferrer')
    },
    matches: 'zoho',
    secondaryAction: {
      accessibilityLabel: 'OLp',
      icon: 'ExternalMinor',
      tooltip: {
        content: 'Open Zoho mail to check your emails',
      },
    },
  },
  {
    label: 'Google drive',
    icon: 'FolderUpMajor ',
    onClick: () => {
      window.open('https://drive.google.com/drive/folders/1-1HQpf7u4ujvLsvTUaMFuU0cQG0Lc5qB', '_blank', 'noreferrer')
    },
    matches: 'gdrive',
    secondaryAction: {
      accessibilityLabel: 'radio',
      icon: 'ExternalMinor',
      tooltip: {
        content: 'Open Google drive to view shared files',
      },
    },
  },
]
