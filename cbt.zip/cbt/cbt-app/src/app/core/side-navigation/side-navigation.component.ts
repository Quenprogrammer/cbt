import {Component, inject} from '@angular/core';
import {integrations, mainNavigationList} from './side-navigation';
import {Router, RouterLink, RouterLinkActive} from '@angular/router';
import {NgClass} from '@angular/common';
import {SearchComponent} from '../layout/search/search.component';
import {Auth, signOut, User, user} from '@angular/fire/auth';
import {GoogleAuthProvider} from 'firebase/auth';
import {Subscription} from 'rxjs';
import {main} from "@popperjs/core";
import {environment} from '../../../environments/environment';
import { TenantContextService } from '../../services/tenant-context.service';
import { routePermissions } from '../route-permissions';
@Component({
  selector: 'app-side-navigation',
  standalone: true,
  imports: [
    RouterLinkActive,
    NgClass,
    RouterLink,
    SearchComponent
  ],
  templateUrl: './side-navigation.component.html',
  styleUrl: './side-navigation.component.scss'
})
export class SideNavigationComponent {



 protected env = environment;
  private readonly tenant=inject(TenantContextService);
  get mainNavigation(){if(this.tenant.state()?.role==='admin')return mainNavigationList;return mainNavigationList.filter(item=>{const required=routePermissions[item.matches];return required&&(required.length===0||required.some(permission=>this.tenant.can(permission)));});}
  integrationNavigation = integrations;

  protected readonly main = main;

  router = inject(Router);
  private auth = inject(Auth);
  provider = new GoogleAuthProvider();
  user$ = user(this.auth);
  userSubscription: Subscription;
  userX: User | null = null;

  constructor() {


    this.userSubscription = this.user$.subscribe((aUser: User | null) => {
      //handle user state changes here. Note, that user will be null if there is no currently logged in user.
      this.userX = aUser;
    })

    let actionCodeSettings = {
      // URL you want to redirect back to. The domain (www.example.com) for this
      // URL must be in the authorized domains list in the Firebase Console.
      url: 'https://www.example.com/finishSignUp?cartId=1234',
      // This must be true.
      handleCodeInApp: true,
      iOS: {
        bundleId: 'com.example.ios'
      },
      android: {
        packageName: 'com.example.android',
        installApp: true,
        minimumVersion: '12'
      },
      dynamicLinkDomain: 'example.page.link'
    };

  }


  logOut() {
    signOut(this.auth).then(() => {
      // Sign-out successful.
      this.router.navigate(['/authentication']);


    }).catch((error) => {
      alert(error);
      // An error happened.

    });
  }

}
