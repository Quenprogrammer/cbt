import { Component } from '@angular/core';
import {NgClass} from '@angular/common';
import {SideNavigationComponent} from '../side-navigation/side-navigation.component';
import {RouterOutlet} from '@angular/router';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [
    NgClass,
    SideNavigationComponent,
    RouterOutlet
  ],
  templateUrl: './layout.component.html',
  styleUrl: './layout.component.scss'
})
export class LayoutComponent {
  private environment = true;
  env = this.environment;
  dp: any;
  closeResult: any
  showAside: boolean = typeof window === 'undefined' ? true : window.innerWidth >= 992;
  protected readonly open = open;

  toggleAside() {
    this.showAside = !this.showAside;
  }
}
