export const routePermissions: Record<string, string[]> = {
  'exam-list': ['questions.write', 'questions.review', 'exams.manage'],
  'view-exam/:id': ['questions.write', 'questions.review'],
  'adding-exam-question': ['questions.write'], 'updating-exams/:subjectId/:examsId': ['questions.write'],
  'student-list': ['students.manage', 'exams.manage'],
  performance: ['reports.read'], results: ['results.manage'], 'result-workflow': ['results.manage'],
  scheduling: ['exams.manage'], readiness: ['exams.manage'], 'exam-control': ['exams.manage'],
  backups: ['backups.manage'], 'question-review': ['questions.review'], security: [],
};
