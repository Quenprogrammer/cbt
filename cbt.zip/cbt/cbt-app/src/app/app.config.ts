import {ApplicationConfig, provideZoneChangeDetection} from '@angular/core';
import {provideRouter, withComponentInputBinding} from '@angular/router';

import {routes} from './app.routes';
import {getApp, initializeApp, provideFirebaseApp} from '@angular/fire/app';
import {connectAuthEmulator, getAuth, provideAuth} from '@angular/fire/auth';
import {connectFunctionsEmulator, getFunctions, provideFunctions} from '@angular/fire/functions';
import {connectStorageEmulator, getStorage, provideStorage} from '@angular/fire/storage';
import {
  connectFirestoreEmulator,
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  provideFirestore
} from '@angular/fire/firestore';
import {environment} from '../environments/environment';

export const appConfig: ApplicationConfig = {
  providers: [provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes,withComponentInputBinding()),

    provideFirebaseApp(() => initializeApp(environment.firebaseApp)),
    provideAuth(() => {


      if(environment.useEmulator){
        const auth = getAuth();
        connectAuthEmulator(auth, "http://localhost:9099", {
          disableWarnings: false,
        });

        return auth;
      }else{
        return getAuth();
      }

    }),
    provideFirestore(() => {

      if(environment.useEmulator){
        const firestore = initializeFirestore(getApp(), {
          localCache: persistentLocalCache({
            tabManager: persistentMultipleTabManager(),
          }),
        });

        connectFirestoreEmulator(firestore, "localhost", 8980);

        return firestore;
      }else{
        return initializeFirestore(getApp(), {
          localCache: persistentLocalCache({
            tabManager: persistentMultipleTabManager(),
          }),
        });
      }


    }),
    provideFunctions(() => {

      if(environment.useEmulator) {
        const functions = getFunctions(getApp());
        //functions.region = "us-central1";

        connectFunctionsEmulator(functions, "localhost", 5001);

        return functions;
      }else{
        return getFunctions(getApp());
      }
    }),
    provideStorage(() => {
      const storage = getStorage();
      if (environment.useEmulator) {
        connectStorageEmulator(storage, 'localhost', 9199);
      }
      return storage;
    }),

  ]


};
