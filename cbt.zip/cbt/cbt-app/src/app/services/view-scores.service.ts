import { Injector, Injectable, inject, runInInjectionContext } from '@angular/core';
import { collection, collectionData, Firestore } from '@angular/fire/firestore';
import { BehaviorSubject, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import { TenantContextService } from './tenant-context.service';

export interface Score {
  id: string;
  sn: number;
  exam: string;
  examId: string;
  grade: string;
  score: number;
  scorePercentage: number;
  student: string;
  studentId: string;
  totalQuestion: number;
  date: string;
}

@Injectable({ providedIn: 'root' })
export class ViewScoresService {
  private readonly firestore = inject(Firestore);
  private readonly tenant = inject(TenantContextService);
  private readonly injector = inject(Injector);
  private unsub: Subscription | null = null;

  private readonly isLoadingSubject = new BehaviorSubject<boolean>(false);
  readonly isLoading$ = this.isLoadingSubject.asObservable();

  private readonly viewScoreSubject = new BehaviorSubject<Score[]>([]);
  readonly viewscores$ = this.viewScoreSubject.asObservable();

  loadExams(subjectId: string): void {
    this.isLoadingSubject.next(true);
    this.unsub?.unsubscribe();

    const scores$ = runInInjectionContext(this.injector, () => {
      const viewSubjectCollection = collection(this.firestore, this.tenant.path(`subjects/${subjectId}/score`));
      return collectionData(viewSubjectCollection, { idField: 'id' }).pipe(
        map((data) => data as Score[])
      );
    });

    this.unsub = scores$.subscribe({
      next: (scores) => {
        this.viewScoreSubject.next(scores);
        this.isLoadingSubject.next(false);
      },
      error: (error) => {
        console.error('Error fetching scores:', error);
        this.viewScoreSubject.next([]);
        this.isLoadingSubject.next(false);
      },
    });
  }

  ngOnDestroy(): void {
    this.unsub?.unsubscribe();
  }
}
