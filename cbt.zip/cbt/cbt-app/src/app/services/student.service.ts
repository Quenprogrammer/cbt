import {
  Injector,
  Injectable,
  inject,
  runInInjectionContext,
} from '@angular/core';
import {
  Auth,
  getIdTokenResult,
  user,
} from '@angular/fire/auth';
import {
  Firestore,
  collection,
  collectionData,
  query,
  where,
} from '@angular/fire/firestore';
import { Functions, httpsCallable } from '@angular/fire/functions';
import {
  BehaviorSubject,
  combineLatest,
  from,
  Observable,
  of,
  Subscription,
  switchMap,
} from 'rxjs';
import { map } from 'rxjs/operators';

export interface Student {
  id: string;
  sn: number;
  firstname: string;
  middlename?: string;
  lastname: string;
  admissionNumber: string;
  department: string;
  classLevel?: string;
  email: string;
  phone?: string;
  gender: string;
  dateOfBirth: string;
  address?: string;
  stateOfOrigin?: string;
  lga?: string;
  guardianName?: string;
  guardianPhone?: string;
  guardianEmail?: string;
  enrollmentDate?: string;
  status?: 'Active' | 'Inactive' | 'Graduated' | 'Suspended';
  bloodGroup?: string;
  genotype?: string;
  emergencyContact?: string;
  authUid?: string;
  notes?: string;
  photoURL?: string;
  examStatus: string;
  registeredSubjectIds?: string[];
  registeredSubjects?: string[];
  loginEmail?: string;
}

interface ExamAccessResponse {
  updated: number;
  status: string;
}

@Injectable({ providedIn: 'root' })
export class StudentService {
  private readonly firestore = inject(Firestore);
  private readonly auth = inject(Auth);
  private readonly functions = inject(Functions);
  private readonly injector = inject(Injector);
  private readonly subscription: Subscription;

  private readonly studentSubject = new BehaviorSubject<Student[]>([]);
  readonly students$ = this.studentSubject.asObservable();

  private readonly examStartedSubject = new BehaviorSubject<boolean>(false);
  readonly examStarted$ = this.examStartedSubject.asObservable();

  constructor() {
    this.subscription = user(this.auth)
      .pipe(
        switchMap((currentUser) => {
          if (!currentUser) return of([] as Student[]);

          const tokenPromise = runInInjectionContext(this.injector, () =>
            getIdTokenResult(currentUser, true)
          );

          return from(tokenPromise).pipe(
            switchMap((tokenResult) => {
              const role = tokenResult.claims['role'];
              const tenantId = String(tokenResult.claims['tenantId'] ?? '');
              if (!tenantId) return of([] as Student[]);

              return runInInjectionContext(this.injector, () => {
                const studentsCollection = collection(this.firestore, `tenants/${tenantId}/student`);

                if (role === 'admin' || role === 'staff') {
                  return collectionData(studentsCollection, { idField: 'id' });
                }

                if (role === 'student') {
                  const ownStudentQuery = query(
                    studentsCollection,
                    where('authUid', '==', currentUser.uid)
                  );
                  return collectionData(ownStudentQuery, { idField: 'id' });
                }

                return of([]);
              });
            })
          );
        }),
        map((students: any[]) =>
          students.map((student, index) => ({
            ...student,
            sn: index + 1,
            examStatus: student.examStatus || 'Not Started',
          })) as Student[]
        )
      )
      .subscribe({
        next: (students) => {
          this.studentSubject.next(students);
          this.examStartedSubject.next(
            students.some((student) => student.examStatus === 'Started')
          );
        },
        error: (error) => {
          console.error('Error fetching students:', error);
          this.studentSubject.next([]);
          this.examStartedSubject.next(false);
        },
      });
  }

  fetchStudents(): void {
    // Kept for compatibility. The authenticated realtime listener in the
    // constructor owns fetching and automatically refreshes after sign-in.
  }

  async updateAllStudentsExamStatus(status: string): Promise<void> {
    try {
      const fn = runInInjectionContext(this.injector, () =>
        httpsCallable<{ status: string; all: true }, ExamAccessResponse>(
          this.functions,
          'exam_attempts-setStudentExamStatus'
        )
      );
      await fn({ status, all: true });

      const updatedStudents = this.studentSubject.getValue().map((student) => ({
        ...student,
        examStatus: status,
      }));
      this.studentSubject.next(updatedStudents);
      this.examStartedSubject.next(status === 'Started');
    } catch (error) {
      console.error('Error updating all students exam status:', error);
      throw error;
    }
  }

  async updateStudentExamStatus(studentId: string, status: string): Promise<void> {
    try {
      const fn = runInInjectionContext(this.injector, () =>
        httpsCallable<
          { studentId: string; status: string },
          ExamAccessResponse
        >(this.functions, 'exam_attempts-setStudentExamStatus')
      );
      await fn({ studentId, status });

      const updatedStudents = this.studentSubject.getValue().map((student) =>
        student.id === studentId ? { ...student, examStatus: status } : student
      );
      this.studentSubject.next(updatedStudents);
      this.examStartedSubject.next(
        updatedStudents.some((student) => student.examStatus === 'Started')
      );
    } catch (error) {
      console.error('Error updating student exam status:', error);
      throw error;
    }
  }

  getStudentCount(): Observable<number> {
    return this.students$.pipe(map((students) => students.length));
  }

  getStudentThatTakeExamCount(): Observable<number> {
    return this.students$.pipe(
      map((students) =>
        students.filter((student) => student.examStatus === 'Started').length
      )
    );
  }

  getStudentTakingExamPercentage(): Observable<number> {
    return combineLatest([
      this.getStudentCount(),
      this.getStudentThatTakeExamCount(),
    ]).pipe(
      map(([totalStudents, studentsTakingExam]) =>
        totalStudents === 0 ? 0 : (studentsTakingExam / totalStudents) * 100
      )
    );
  }

  getStudentsByDepartment(): Observable<{ [key: string]: number }> {
    return this.students$.pipe(
      map((students) => {
        const departmentCounts: { [key: string]: number } = {};
        students.forEach((student) => {
          const department = student.department || 'Unassigned';
          departmentCounts[department] = (departmentCounts[department] || 0) + 1;
        });
        return departmentCounts;
      })
    );
  }

  getStudentsByGender(): Observable<{ males: number; females: number }> {
    return this.students$.pipe(
      map((students) => {
        const genderCounts = { males: 0, females: 0 };
        students.forEach((student) => {
          const gender = String(student.gender || '').toLowerCase();
          if (gender === 'male') genderCounts.males += 1;
          if (gender === 'female') genderCounts.females += 1;
        });
        return genderCounts;
      })
    );
  }

  getStudentScoresOverTime(): Observable<number[]> {
    return of([40, 75, 61, 85, 94, 82, 86]);
  }

  getStudentsAttemptedOverTime(): Observable<number[]> {
    return of([120, 140, 135, 160, 155, 150, 165]);
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
