import { TestBed } from '@angular/core/testing';
import { Auth } from '@angular/fire/auth';
import { ExamAttemptService, ExamPackage } from './exam-attempt.service';
import { ExamRecoveryService } from './exam-recovery.service';
import { TenantContextService } from './tenant-context.service';

describe('Exam connection recovery', () => {
  let service: ExamRecoveryService;
  let api: { saveDraft: jasmine.Spy };
  const auth = { currentUser: { uid: 'qa-recovery' } };
  const pkg: ExamPackage = { assignmentId: 'qa-assignment', durationMinutes: 1, expiresAtMs: Date.now() + 60000, subjects: [], questions: [{ subjectId: 'math', subjectName: 'Math', questionId: 'q', question: 'Test?', questionType: 'mcq', options: [{ id: 'A', text: 'One' }, { id: 'B', text: 'Two' }] }] };
  const key = 'cbt.exam.v2.qa-tenant.qa-recovery';
  beforeEach(() => {
    localStorage.removeItem(key);
    auth.currentUser = { uid: 'qa-recovery' };
    api = { saveDraft: jasmine.createSpy('saveDraft').and.resolveTo({ saved: true, revision: 1 }) };
    TestBed.configureTestingModule({ providers: [{ provide: Auth, useValue: auth }, { provide: TenantContextService, useValue: { tenantId: () => 'qa-tenant' } }, { provide: ExamAttemptService, useValue: api }] });
    service = TestBed.inject(ExamRecoveryService);
    service.online.set(false);
  });
  afterEach(() => { localStorage.removeItem(key); });

  it('persists offline answers and submission intent, scoped to the signed-in candidate', () => {
    service.begin(pkg); service.update({ q: 'B' }, { q: 12 }, 0); service.queueSubmission();
    expect(service.cached()?.answers['q']).toBe('B');
    expect(service.cached()?.pendingSubmission).toBeTrue();
    expect(api.saveDraft).not.toHaveBeenCalled();
    auth.currentUser = { uid: 'another-student' };
    expect(service.cached()).toBeNull();
  });
  it('restores a cloud draft on a second device and ignores invalid option IDs', () => {
    const restored = service.begin({ ...pkg, draft: { answers: { q: 'B', other: 'A' }, timePerQuestion: { q: 8 }, currentQuestionIndex: 0, clientId: 'other-device', revision: 3, updatedAtMs: Date.now() } });
    expect(restored.answers).toEqual({ q: 'B' });
    expect(restored.timePerQuestion['q']).toBe(8);
    expect(service.begin({ ...pkg, draft: { ...restored, updatedAtMs: Number(restored.updatedAtMs) + 1000, answers: { q: 'missing-option' } } }).answers).toEqual({});
  });
  it('keeps newer local answers when an older cloud draft is returned', () => {
    service.begin(pkg); service.update({ q: 'B' }, { q: 5 }, 0);
    const restored = service.begin({ ...pkg, draft: { answers: { q: 'A' }, timePerQuestion: {}, currentQuestionIndex: 0, clientId: 'cloud-device', revision: 5, updatedAtMs: Date.now() + 1000 } });
    expect(restored.answers['q']).toBe('B');
  });
  it('does not mark a newer answer saved when an older request is acknowledged', async () => {
    const acknowledgments: Array<(value: any) => void> = [];
    api.saveDraft.and.callFake(() => new Promise(resolve => acknowledgments.push(resolve)));
    service.begin(pkg); service.online.set(true); service.update({ q: 'A' }, {}, 0); service.update({ q: 'B' }, {}, 0);
    acknowledgments[0]({ saved: true });
    await new Promise(resolve => setTimeout(resolve, 0));
    expect(api.saveDraft.calls.count()).toBe(2);
    expect(api.saveDraft.calls.mostRecent().args[1].answers.q).toBe('B');
    expect(service.status()).toBe('saving');
    acknowledgments[1]({ saved: true });
    await new Promise(resolve => setTimeout(resolve, 0));
    expect(service.status()).toBe('saved');
    expect(service.cached()?.dirty).toBeFalse();
  });
  it('keeps failed saves queued and removes the local copy only after submission confirmation', async () => {
    service.begin(pkg); service.update({ q: 'B' }, {}, 0);
    api.saveDraft.and.rejectWith(new Error('Connection lost')); service.online.set(true);
    await service.flush();
    expect(service.status()).toBe('pending');
    expect(service.cached()?.dirty).toBeTrue();
    service.complete('different-assignment'); expect(service.cached()).not.toBeNull();
    service.complete(pkg.assignmentId); expect(service.cached()).toBeNull();
  });
  it('shows a local storage failure while preserving answers in memory for cloud retry', async () => {
    service.begin(pkg);
    spyOn(Storage.prototype, 'setItem').and.throwError('Storage full');
    service.update({ q: 'B' }, {}, 0);
    expect(service.storageError()).toContain('cannot save a local backup');
    service.online.set(true); await service.flush();
    expect(api.saveDraft.calls.mostRecent().args[1].answers.q).toBe('B');
  });
});
