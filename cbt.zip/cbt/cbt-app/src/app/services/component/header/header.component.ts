import {Component, input} from '@angular/core';
import {NgIf} from "@angular/common";

@Component({
  selector: 'ims-header',
  standalone: true,
    imports: [
        NgIf
    ],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent {
  title = input<any>('My Union');
  subtitle = input<any>('View official Union details and maintain permitted contact information.');
}
