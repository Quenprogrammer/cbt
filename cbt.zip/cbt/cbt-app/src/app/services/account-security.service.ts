import { Injectable, inject, signal } from '@angular/core';
import { AssessmentApiService } from './assessment-api.service';
export interface SecurityState { enrolled: boolean; verified: boolean; revoked: boolean; recoveryCodesRemaining: number; }
@Injectable({ providedIn: 'root' })
export class AccountSecurityService {
  private readonly api = inject(AssessmentApiService);
  readonly current = signal<SecurityState | null>(null);
  async refresh(): Promise<SecurityState> { const state = await this.api.call<SecurityState>('account_security', 'state'); this.current.set(state); return state; }
}
