import {
  Injector,
  Injectable,
  OnDestroy,
  inject,
  runInInjectionContext,
} from '@angular/core';
import { Auth, getIdTokenResult, user } from '@angular/fire/auth';
import { collection, collectionData, Firestore } from '@angular/fire/firestore';
import {
  BehaviorSubject,
  from,
  Observable,
  of,
  Subscription,
  switchMap,
} from 'rxjs';
import { map } from 'rxjs/operators';

export interface Staff {
  id: string;
  employeeId?: string;
  firstname: string;
  middlename?: string;
  lastname: string;
  email: string;
  phone?: string;
  department: string;
  role: string;
  dateOfBirth: string;
  gender: string;
  address?: string;
  qualification?: string;
  specialization?: string;
  employmentDate?: string;
  employmentType?: string;
  status?: 'Active' | 'Inactive' | 'On Leave';
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  nextOfKin?: string;
  nextOfKinPhone?: string;
  notes?: string;
}

@Injectable({ providedIn: 'root' })
export class StaffService implements OnDestroy {
  private readonly firestore = inject(Firestore);
  private readonly auth = inject(Auth);
  private readonly injector = inject(Injector);
  private unsub: Subscription | null = null;

  private readonly isLoadingSubject = new BehaviorSubject<boolean>(false);
  readonly isLoading$ = this.isLoadingSubject.asObservable();

  private readonly staffSubject = new BehaviorSubject<Staff[]>([]);
  readonly staffs$ = this.staffSubject.asObservable();

  constructor() {
    this.isLoadingSubject.next(true);

    this.unsub = user(this.auth)
      .pipe(
        switchMap((currentUser) => {
          if (!currentUser) return of([] as Staff[]);

          const tokenPromise = runInInjectionContext(this.injector, () =>
            getIdTokenResult(currentUser, true)
          );

          return from(tokenPromise).pipe(
            switchMap((tokenResult) => {
              if (tokenResult.claims['role'] !== 'admin') return of([] as Staff[]);
              const tenantId = String(tokenResult.claims['tenantId'] ?? '');
              if (!tenantId) return of([] as Staff[]);

              return runInInjectionContext(this.injector, () =>
                collectionData(collection(this.firestore, `tenants/${tenantId}/staffs`), {
                  idField: 'id',
                }).pipe(map((data) => data as Staff[]))
              );
            })
          );
        })
      )
      .subscribe({
        next: (staff) => {
          this.staffSubject.next(staff);
          this.isLoadingSubject.next(false);
        },
        error: (error) => {
          console.error('Error fetching staff:', error);
          this.staffSubject.next([]);
          this.isLoadingSubject.next(false);
        },
      });
  }

  getStaffCount(): Observable<number> {
    return this.staffs$.pipe(map((staff) => staff.length));
  }

  ngOnDestroy(): void {
    this.unsub?.unsubscribe();
  }
}
