import {
  Injector,
  Injectable,
  OnDestroy,
  inject,
  runInInjectionContext,
} from '@angular/core';
import { Auth, getIdTokenResult, user } from '@angular/fire/auth';
import { collection, collectionData, Firestore } from '@angular/fire/firestore';
import { BehaviorSubject, catchError, from, of, Subscription, switchMap } from 'rxjs';
import { map } from 'rxjs/operators';
import { QuestionMetadata } from '../shared/questions/question-metadata';

export interface Option {
  id: string;
  text: string;
}

export interface Question extends QuestionMetadata {
  id: string;
  question: string;
  imageUrl?: string;
  imageAlt?: string;
  options: Option[];
  correctAnswerId: string;
  subject: string;
  selectedAnswer?: string;
  visited?: boolean;
}

export interface Subject {
  name: string;
  id: string;
  description: string;
  questions: Question[];
  timeLimit?: number;
  questionLimit?: number;
  active?: boolean;
  class?: string;
}

@Injectable({ providedIn: 'root' })
export class ExamsListService implements OnDestroy {
  private readonly firestore = inject(Firestore);
  private readonly auth = inject(Auth);
  private readonly injector = inject(Injector);
  private unsub: Subscription | null = null;

  private readonly isLoadingSubject = new BehaviorSubject<boolean>(false);
  readonly isLoading$ = this.isLoadingSubject.asObservable();

  private readonly examSubject = new BehaviorSubject<Subject[]>([]);
  readonly examlist$ = this.examSubject.asObservable();

  constructor() {
    this.isLoadingSubject.next(true);

    this.unsub = user(this.auth)
      .pipe(
        switchMap((currentUser) => {
          if (!currentUser) return of([] as Subject[]);

          return from(runInInjectionContext(this.injector,()=>getIdTokenResult(currentUser))).pipe(
            switchMap(token=>{
              const tenantId=String(token.claims['tenantId']??'');
              if(!tenantId || !['admin','staff','student'].includes(String(token.claims['role'])))return of([] as Subject[]);
              return runInInjectionContext(this.injector,()=>collectionData(collection(this.firestore,`tenants/${tenantId}/subjects`),{idField:'id'}).pipe(map(data=>data as Subject[])));
            }),
            // A sign-out/claim transition can invalidate an existing listener.
            // Keep listening to future auth changes instead of terminating the service.
            catchError(()=>of([] as Subject[]))
          );
        })
      )
      .subscribe({
        next: (subjects) => {
          this.examSubject.next(subjects);
          this.isLoadingSubject.next(false);
        },
        error: (error) => {
          console.error('Error fetching exams:', error);
          this.examSubject.next([]);
          this.isLoadingSubject.next(false);
        },
      });
  }

  ngOnDestroy(): void {
    this.unsub?.unsubscribe();
  }
}
