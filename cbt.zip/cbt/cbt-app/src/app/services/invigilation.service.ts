import {
  Injectable,
  Injector,
  inject,
  runInInjectionContext,
} from '@angular/core';
import { Auth, getIdTokenResult, user } from '@angular/fire/auth';
import {
  Firestore,
  addDoc,
  collection,
  collectionData,
  deleteDoc,
  doc,
  serverTimestamp,
  updateDoc,
} from '@angular/fire/firestore';
import { Observable, from, of, switchMap } from 'rxjs';
import { map } from 'rxjs/operators';
import { TenantContextService } from './tenant-context.service';

export interface InvigilationStudentSnapshot {
  id: string;
  name: string;
  admissionNumber: string;
  department: string;
}

export interface InvigilationSchedule {
  id: string;
  examTitle: string;
  subjectName?: string;
  examDate: string;
  startTime: string;
  endTime: string;
  venue: string;
  staffId: string;
  staffName: string;
  staffEmployeeId?: string;
  staffDepartment?: string;
  studentIds: string[];
  students: InvigilationStudentSnapshot[];
  studentCount: number;
  status: 'Scheduled' | 'Completed' | 'Cancelled';
  notes?: string;
}

export interface CreateInvigilationSchedule {
  examTitle: string;
  subjectName: string;
  examDate: string;
  startTime: string;
  endTime: string;
  venue: string;
  staffId: string;
  staffName: string;
  staffEmployeeId: string;
  staffDepartment: string;
  studentIds: string[];
  students: InvigilationStudentSnapshot[];
  studentCount: number;
  status: 'Scheduled';
  notes: string;
}

@Injectable({ providedIn: 'root' })
export class InvigilationService {
  private readonly firestore = inject(Firestore);
  private readonly auth = inject(Auth);
  private readonly injector = inject(Injector);
  private readonly tenant = inject(TenantContextService);

  readonly schedules$: Observable<InvigilationSchedule[]> = runInInjectionContext(
    this.injector,
    () => user(this.auth)
  ).pipe(
    switchMap((currentUser) => {
      if (!currentUser) return of([] as InvigilationSchedule[]);

      const tokenPromise = runInInjectionContext(this.injector, () =>
        getIdTokenResult(currentUser, true)
      );

      return from(tokenPromise).pipe(
        switchMap((tokenResult) => {
          if (tokenResult.claims['role'] !== 'admin') {
            return of([] as InvigilationSchedule[]);
          }

          return runInInjectionContext(this.injector, () =>
            collectionData(collection(this.firestore, this.tenant.path('invigilationSchedules')), {
              idField: 'id',
            }).pipe(map((items) => items as InvigilationSchedule[]))
          );
        })
      );
    })
  );

  async createSchedule(data: CreateInvigilationSchedule): Promise<string> {
    return runInInjectionContext(this.injector, async () => {
      const ref = await addDoc(collection(this.firestore, this.tenant.path('invigilationSchedules')), {
        ...data,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      return ref.id;
    });
  }

  async updateStatus(
    scheduleId: string,
    status: InvigilationSchedule['status']
  ): Promise<void> {
    await runInInjectionContext(this.injector, () =>
      updateDoc(doc(this.firestore, this.tenant.path(`invigilationSchedules/${scheduleId}`)), {
        status,
        updatedAt: serverTimestamp(),
      })
    );
  }

  async deleteSchedule(scheduleId: string): Promise<void> {
    await runInInjectionContext(this.injector, () =>
      deleteDoc(doc(this.firestore, this.tenant.path(`invigilationSchedules/${scheduleId}`)))
    );
  }
}
