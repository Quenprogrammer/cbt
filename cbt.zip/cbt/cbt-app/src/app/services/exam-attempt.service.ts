import {
  Injectable,
  Injector,
  inject,
  signal,
  runInInjectionContext,
} from '@angular/core';
import { Auth, getIdTokenResult, user } from '@angular/fire/auth';
import { Functions, httpsCallable } from '@angular/fire/functions';
import {
  Firestore,
  collection,
  collectionData,
  doc,
  getDoc,
  query,
  where,
} from '@angular/fire/firestore';
import { from, Observable, of, switchMap } from 'rxjs';
import { TenantContextService } from './tenant-context.service';
import { ExamDraft } from './exam-draft.model';
import { AssessmentApiService } from './assessment-api.service';
import { ExamResponse, QuestionType, RichQuestion } from '../shared/questions/question-content.model';

export interface ExamPackageQuestion extends RichQuestion {
  subjectId: string;
  subjectName: string;
  questionId: string;
  question: string;
  imageUrl?: string;
  imageAlt?: string;
  questionType: QuestionType;
  options: Array<{ id: string; text: string; imageUrl?:string; imageAlt?:string }>;
}

export interface ExamPackage {
  assignmentId: string;
  durationMinutes: number;
  expiresAtMs: number;
  subjects: Array<{
    subjectId: string;
    subjectName: string;
    description?: string;
    timeLimit: number;
    questionCount: number;
  }>;
  questions: ExamPackageQuestion[];
  resumed?: boolean;
  draft?: ExamDraft | null;
}

export interface ResultSummary {
  pin: string;
  resultId: string;
  candidate: { name: string; admissionNumber?: string; department?: string };
  subjectResults: Array<any>;
  score: number;
  totalQuestions: number;
  answered: number;
  unanswered: number;
  incorrect: number;
  percentage: number;
  grade: string;
  status: string;
  submittedAtIso: string;
}

export interface SubmitExamResponse {
  submitted: boolean;
  pin: string;
  resultId: string;
  submittedAtIso?: string;
}

@Injectable({ providedIn: 'root' })
export class ExamAttemptService {
  private readonly assessmentApi=inject(AssessmentApiService);
  readonly resultMessage=signal('');
  private readonly functions = inject(Functions);
  private readonly firestore = inject(Firestore);
  private readonly auth = inject(Auth);
  private readonly injector = inject(Injector);
  private readonly tenant = inject(TenantContextService);

  async startExam(): Promise<ExamPackage> {
    return runInInjectionContext(this.injector, async () => {
      const fn = httpsCallable<unknown, ExamPackage>(
        this.functions,
        'exam_attempts-getExamPackage',
        { timeout: 12000 }
      );
      const result = await fn({});
      return result.data;
    });
  }

  async submitExam(
    assignmentId: string,
    answers: Array<{
      questionId: string;
      selectedAnswerId?: string | null;
      response?: ExamResponse;
      timeSpentSeconds?: number;
    }>
  ): Promise<SubmitExamResponse> {
    return runInInjectionContext(this.injector, async () => {
      const fn = httpsCallable<any, SubmitExamResponse>(
        this.functions,
        'exam_attempts-submitExamAttempt',
        { timeout: 15000 }
      );
      const result = await fn({ assignmentId, answers });
      return result.data;
    });
  }

  async getPublicResult(pin: string): Promise<ResultSummary | null> {
    const normalized = pin.trim().toUpperCase();
    if (!normalized) return null;

    const checked=await this.assessmentApi.call('result_workflow','checkResult',{pin:normalized});this.resultMessage.set(checked.message||'');return checked.result;
  }

  async saveDraft(assignmentId: string, draft: ExamDraft): Promise<{ saved?: boolean; submitted?: boolean; revision: number }> {
    const fn = runInInjectionContext(this.injector, () => httpsCallable<object, { saved?: boolean; submitted?: boolean; revision: number }>(this.functions, 'exam_drafts-saveDraft', { timeout: 12000 }));
    return (await fn({ assignmentId, ...draft })).data;
  }

  studentAssignments(studentId: string): Observable<any[]> {
    const authUser$ = runInInjectionContext(this.injector, () => user(this.auth));
    return authUser$.pipe(
      switchMap((currentUser) => {
        if (!currentUser || currentUser.uid !== studentId) return of([]);

        return runInInjectionContext(this.injector, () => {
          const q = query(
            collection(this.firestore, this.tenant.path('examAssignments')),
            where('studentId', '==', currentUser.uid)
          );
          return collectionData(q, { idField: 'id' });
        });
      })
    );
  }

  allResults(): Observable<any[]> {
    return this.adminCollection('results');
  }

  allAssignments(): Observable<any[]> {
    return this.adminCollection('examAssignments');
  }

  activityLogs(): Observable<any[]> {
    return this.adminCollection('activityLogs');
  }

  notifications(): Observable<any[]> {
    return this.adminCollection('notifications');
  }

  private adminCollection(path: string): Observable<any[]> {
    const authUser$ = runInInjectionContext(this.injector, () => user(this.auth));
    return authUser$.pipe(
      switchMap((currentUser) => {
        if (!currentUser) return of([]);

        const tokenPromise = runInInjectionContext(this.injector, () =>
          getIdTokenResult(currentUser, true)
        );

        return from(tokenPromise).pipe(
          switchMap((tokenResult) => {
            const tenantId=String(tokenResult.claims['tenantId']??'');
            if (!['admin','staff'].includes(String(tokenResult.claims['role'])) || !tenantId) return of([]);

            return runInInjectionContext(this.injector, () =>
              collectionData(collection(this.firestore, `tenants/${tenantId}/${path}`), { idField: 'id' })
            );
          })
        );
      })
    );
  }
}
