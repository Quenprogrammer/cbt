import { Injector, Injectable, inject, runInInjectionContext } from '@angular/core';
import { collection, collectionData, Firestore } from '@angular/fire/firestore';
import { BehaviorSubject, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import { TenantContextService } from './tenant-context.service';
import { QuestionMetadata } from '../shared/questions/question-metadata';

export interface Option {
  id: string;
  text: string;
}

export interface Question extends QuestionMetadata {
  id: string;
  question: string;
  imageUrl?: string;
  imageAlt?: string;
  questionType?: 'mcq' | 'true_false' | 'multiple_answer' | 'fill_blank' | 'matching' | 'essay';
  publicationStatus?: string;
  archived?: boolean;
  version?: number;
  options: Option[];
  correctAnswerId: string;
  subject?: string;
  selectedAnswer?: string;
  visited?: boolean;
}

@Injectable({ providedIn: 'root' })
export class ViewExamsService {
  private readonly firestore = inject(Firestore);
  private readonly injector = inject(Injector);
  private readonly tenant = inject(TenantContextService);
  private unsub: Subscription | null = null;

  private readonly isLoadingSubject = new BehaviorSubject<boolean>(false);
  readonly isLoading$ = this.isLoadingSubject.asObservable();

  private readonly viewExamSubject = new BehaviorSubject<Question[]>([]);
  readonly viewexam$ = this.viewExamSubject.asObservable();

  loadExams(subjectId: string): void {
    this.isLoadingSubject.next(true);
    this.unsub?.unsubscribe();

    const exams$ = runInInjectionContext(this.injector, () => {
      const examCollection = collection(this.firestore, this.tenant.path(`subjects/${subjectId}/exams`));
      return collectionData(examCollection, { idField: 'id' }).pipe(
        map((data) => data as Question[])
      );
    });

    this.unsub = exams$.subscribe({
      next: (exams) => {
        this.viewExamSubject.next(exams);
        this.isLoadingSubject.next(false);
      },
      error: (error) => {
        console.error('Error fetching exams:', error);
        this.viewExamSubject.next([]);
        this.isLoadingSubject.next(false);
      },
    });
  }

  ngOnDestroy(): void {
    this.unsub?.unsubscribe();
  }
}
