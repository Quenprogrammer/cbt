import { Injectable, Injector, inject, runInInjectionContext } from '@angular/core';
import { Auth, getIdTokenResult, signOut } from '@angular/fire/auth';
import { Functions, httpsCallable } from '@angular/fire/functions';
import { TenantContextService } from './tenant-context.service';
import { AccountSecurityService } from './account-security.service';

export const setupSteps=['welcome','profile','academic','exam','registration','review'] as const;
export type SetupStep=typeof setupSteps[number];
export interface SetupProgress {status:string;currentStep:SetupStep;completedSteps:string[];deferredSteps:string[];revision:number;paused:boolean;setupSubjectId?:string;}
export interface InstitutionProfile {name:string;shortName:string;address:string;email:string;phone:string;timezone:string;currency:string;}
export interface InstitutionSetupState {tenantId:string;profile:InstitutionProfile;progress:SetupProgress|null;academic:{className:string;department:string};checks:{subjects:boolean;candidates:boolean;staff:boolean};modules:Record<string,boolean>;setupSubjectId:string;registrationCode:string;signupPolicy:string;}
export interface RegistrationState {role:string;tenantId:string;emailVerified:boolean;intent:'institution'|'student';tenantCode:string;}

@Injectable({providedIn:'root'})
export class InstitutionOnboardingService {
  private readonly security=inject(AccountSecurityService);
  readonly auth=inject(Auth);
  private readonly functions=inject(Functions); private readonly injector=inject(Injector); private readonly tenant=inject(TenantContextService);
  private async call<T>(name:string,data:object={}):Promise<T> {
    const fn=runInInjectionContext(this.injector,()=>httpsCallable<object,T>(this.functions,'institution_onboarding-'+name));
    return (await fn(data)).data;
  }
  state():Promise<RegistrationState> { return this.call('registrationState'); }
  intent(intent:'institution'|'student',tenantCode=''):Promise<unknown> {return this.call('setRegistrationIntent',{intent,tenantCode});}
  checkCode(code:string):Promise<{available:boolean}> {return this.call('checkInstitutionCode',{code});}
  async provision(data:object):Promise<void> {await this.call('provisionInstitution',data);await this.refreshIdentity();}
  load():Promise<InstitutionSetupState> {return this.call('getInstitutionOnboardingState');}
  setSubjectAvailability(subjectId:string,active:boolean):Promise<unknown> {return this.call('setSubjectAvailability',{subjectId,active});}
  save(step:SetupStep,expectedRevision:number,data:object={},action='continue'):Promise<{status:string;currentStep:SetupStep;revision:number}> {return this.call('saveInstitutionOnboardingStep',{step,expectedRevision,data,action});}
  async refreshIdentity():Promise<void> {if(this.auth.currentUser)await runInInjectionContext(this.injector,()=>getIdTokenResult(this.auth.currentUser!,true));}
  async destination():Promise<string> {
    await this.auth.authStateReady();
    if(!this.auth.currentUser)return '/authentication';
    const security=await this.security.refresh();if(security.revoked){await this.logout();return '/authentication';}if(!security.verified)return '/security/verify';
    const state=await this.state();await this.refreshIdentity();
    if(state.role==='admin'||state.role==='student'||state.role==='staff') {
      const access=await this.tenant.initializeFromToken();
      if(!access.accessible)return '/tenant-access';
      if(state.role==='student')return '/home';
      if(state.role==='staff')return this.tenant.can('questions.write')||this.tenant.can('questions.review')||this.tenant.can('exams.manage')?'/admin/exam-list':'/admin/security';
      const setup=await this.load();
      return setup.progress && setup.progress.status!=='completed' && !setup.progress.paused ? '/onboarding' : '/admin/dashboard';
    }
    if(!state.emailVerified)return '/verify-email';
    return state.intent==='student' ? '/sign-up' : '/create-institution';
  }
  async logout():Promise<void> {await runInInjectionContext(this.injector,()=>signOut(this.auth));this.tenant.clear();}
}
