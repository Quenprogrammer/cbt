import { Injectable, OnDestroy, computed, inject, signal } from '@angular/core';
import { Auth } from '@angular/fire/auth';
import { ExamAttemptService, ExamPackage } from './exam-attempt.service';
import { ExamDraft } from './exam-draft.model';
import { TenantContextService } from './tenant-context.service';
import { ExamResponse, hasExamResponse, localResponse } from '../shared/questions/question-content.model';

export interface CachedExam extends ExamDraft {
  schema: 2;
  tenantId: string;
  studentId: string;
  pkg: ExamPackage;
  dirty: boolean;
  pendingSubmission: boolean;
}

@Injectable({ providedIn: 'root' })
export class ExamRecoveryService implements OnDestroy {
  private readonly api = inject(ExamAttemptService);
  private readonly auth = inject(Auth);
  private readonly tenant = inject(TenantContextService);
  private readonly active = signal<CachedExam | null>(null);
  readonly online = signal(navigator.onLine);
  readonly status = signal<'idle' | 'saving' | 'saved' | 'pending'>('idle');
  readonly storageError = signal('');
  readonly lastSyncedAt = signal<number | null>(null);
  readonly pendingSubmission = computed(() => this.active()?.pendingSubmission ?? false);
  private flushing = false;
  private readonly connected = () => { this.online.set(true); void this.flush(); };
  private readonly disconnected = () => { this.online.set(false); if (this.active()?.dirty) this.status.set('pending'); };

  constructor() { window.addEventListener('online', this.connected); window.addEventListener('offline', this.disconnected); }
  private key(): string { return `cbt.exam.v2.${this.tenant.tenantId()}.${this.auth.currentUser?.uid ?? ''}`; }
  cached(): CachedExam | null {
    try {
      const raw = localStorage.getItem(this.key());
      if (!raw) return null;
      const value = JSON.parse(raw) as CachedExam;
      return value.schema === 2 && value.tenantId === this.tenant.tenantId() && value.studentId === this.auth.currentUser?.uid &&
        typeof value.pkg?.assignmentId === 'string' && Array.isArray(value.pkg.questions) && Number.isFinite(value.pkg.expiresAtMs) ? value : null;
    } catch { return null; }
  }

  begin(pkg: ExamPackage): ExamDraft {
    const stored = this.cached();
    const local = stored?.pkg.assignmentId === pkg.assignmentId ? stored : null;
    const cloud = pkg.draft;
    const source = local && (local.dirty || local.pendingSubmission || !cloud || Number(local.updatedAtMs) >= Number(cloud.updatedAtMs)) ? local : cloud;
    const answers: Record<string, ExamResponse> = {}, timePerQuestion: Record<string, number> = {};
    for (const question of pkg.questions) {
      const answer = localResponse(question, source?.answers?.[question.questionId]);
      if (hasExamResponse(answer)) answers[question.questionId] = answer;
      const seconds = Number(source?.timePerQuestion?.[question.questionId] ?? 0);
      timePerQuestion[question.questionId] = Number.isFinite(seconds) ? Math.max(0, Math.min(seconds, 86400)) : 0;
    }
    const { draft: _draft, ...publicPackage } = pkg;
    const state: CachedExam = {
      schema: 2, tenantId: this.tenant.tenantId(), studentId: this.auth.currentUser?.uid ?? '', pkg: publicPackage,
      answers, timePerQuestion, currentQuestionIndex: Math.max(0, Math.min(Number(source?.currentQuestionIndex) || 0, pkg.questions.length - 1)),
      clientId: local?.clientId || crypto.randomUUID(), revision: Math.max(1, Number(local?.revision) || 1, source?.clientId === local?.clientId ? Number(source?.revision) || 1 : 1),
      updatedAtMs: Number(source?.updatedAtMs) || Date.now(), dirty: local?.dirty ?? false, pendingSubmission: local?.pendingSubmission ?? false,
    };
    this.active.set(state); this.persist(); this.status.set(state.dirty ? 'pending' : 'saved');
    this.lastSyncedAt.set(cloud && !state.dirty ? cloud.updatedAtMs ?? null : null);
    return state;
  }

  update(answers: Record<string, ExamResponse>, timePerQuestion: Record<string, number>, currentQuestionIndex: number): void {
    const current = this.active();
    if (!current || current.pendingSubmission) return;
    this.active.set({ ...current, answers: { ...answers }, timePerQuestion: { ...timePerQuestion }, currentQuestionIndex, revision: current.revision + 1, updatedAtMs: Date.now(), dirty: true });
    this.persist(); this.status.set('pending'); void this.flush();
  }
  queueSubmission(): void {
    const current = this.active(); if (!current) return;
    this.active.set({ ...current, pendingSubmission: true }); this.persist();
  }
  private persist(): void {
    const current = this.active(); if (!current) return;
    try { localStorage.setItem(`cbt.exam.v2.${current.tenantId}.${current.studentId}`, JSON.stringify(current)); this.storageError.set(''); }
    catch { this.storageError.set('This browser cannot save a local backup. Keep this page open and reconnect so your answers can reach the server.'); }
  }
  async flush(): Promise<void> {
    if (this.flushing || !this.online()) return;
    this.flushing = true;
    try {
      while (this.active()?.dirty && this.online()) {
        const snapshot = this.active()!;
        if (snapshot.studentId !== this.auth.currentUser?.uid || snapshot.tenantId !== this.tenant.tenantId()) return;
        this.status.set('saving');
        try {
          await this.api.saveDraft(snapshot.pkg.assignmentId, { answers: snapshot.answers, timePerQuestion: snapshot.timePerQuestion, currentQuestionIndex: snapshot.currentQuestionIndex, clientId: snapshot.clientId, revision: snapshot.revision });
          const current = this.active();
          if (!current || current.pkg.assignmentId !== snapshot.pkg.assignmentId) return;
          this.lastSyncedAt.set(Date.now());
          if (current.revision === snapshot.revision) { this.active.set({ ...current, dirty: false }); this.persist(); this.status.set('saved'); }
        } catch { this.status.set('pending'); break; }
      }
    } finally { this.flushing = false; }
  }
  complete(assignmentId: string): void {
    const current = this.active(); if (!current || current.pkg.assignmentId !== assignmentId) return;
    try { localStorage.removeItem(`cbt.exam.v2.${current.tenantId}.${current.studentId}`); } catch { /* Submission is already confirmed by the server. */ }
    this.active.set(null); this.status.set('idle');
  }
  ngOnDestroy(): void { window.removeEventListener('online', this.connected); window.removeEventListener('offline', this.disconnected); }
}
