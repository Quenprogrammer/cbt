import { TestBed } from '@angular/core/testing';

import { ViewExamsService } from './view-exams.service';

describe('ViewExamsService', () => {
  let service: ViewExamsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ViewExamsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
