import { Injectable, Injector, inject, runInInjectionContext, signal } from '@angular/core';
import { Auth, getIdTokenResult } from '@angular/fire/auth';
import { Functions, httpsCallable } from '@angular/fire/functions';

export interface TenantAccessState{tenantId:string;tenantName:string;tenantCode:string;role:string;status:string;accessStatus:string;locked:boolean;reason:string;changedAt:string|null;accessible:boolean;modules:Record<string,boolean>;limits:Record<string,number>;usage:Record<string,number|string>;permissions?:string[]}
@Injectable({providedIn:'root'})
export class TenantContextService{
  private readonly auth=inject(Auth);private readonly functions=inject(Functions);private readonly injector=inject(Injector);
  readonly tenantId=signal<string>('');readonly state=signal<TenantAccessState|null>(null);readonly loading=signal(false);
  async refresh():Promise<TenantAccessState>{if(!this.auth.currentUser)throw new Error('Sign in is required.');this.loading.set(true);try{const fn=runInInjectionContext(this.injector,()=>httpsCallable<Record<string,never>,TenantAccessState>(this.functions,'tenant_access-getAccessState'));const response=await fn({});this.state.set(response.data);this.tenantId.set(response.data.tenantId);return response.data;}finally{this.loading.set(false);}}
  async initializeFromToken():Promise<TenantAccessState>{if(!this.auth.currentUser)throw new Error('Sign in is required.');const token=await runInInjectionContext(this.injector,()=>getIdTokenResult(this.auth.currentUser!,true));const claim=String(token.claims['tenantId']??'');if(claim)this.tenantId.set(claim);return this.refresh();}
  path(relative:string):string{const id=this.tenantId();if(!id)throw new Error('Tenant context is not initialized.');return `tenants/${id}/${relative.replace(/^\/+/, '')}`;}
  storagePath(relative:string):string{const id=this.tenantId();if(!id)throw new Error('Tenant context is not initialized.');return `tenants/${id}/${relative.replace(/^\/+/, '')}`;}
  clear(){this.tenantId.set('');this.state.set(null);}
  can(permission:string):boolean{return this.state()?.role==='admin'||Boolean(this.state()?.permissions?.includes(permission));}
}
