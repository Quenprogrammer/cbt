import { ExamResponse } from '../shared/questions/question-content.model';
export interface ExamDraft {
  answers: Record<string, ExamResponse>;
  timePerQuestion: Record<string, number>;
  currentQuestionIndex: number;
  clientId: string;
  revision: number;
  updatedAtMs?: number;
}
