import { TestBed } from '@angular/core/testing';

import { ViewScoresService } from './view-scores.service';

describe('ViewScoresService', () => {
  let service: ViewScoresService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ViewScoresService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
