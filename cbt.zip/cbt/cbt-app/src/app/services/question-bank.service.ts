import { Injectable, Injector, inject, runInInjectionContext } from '@angular/core';
import { Functions, httpsCallable } from '@angular/fire/functions';

export interface ImportRow { rowNumber: number; values: Record<string, string>; errors: string[]; duplicate: boolean; }
export interface BlueprintRow { topic: string; difficulty: 'any' | 'easy' | 'medium' | 'hard'; count: number; }

@Injectable({ providedIn: 'root' })
export class QuestionBankService {
  private readonly functions = inject(Functions);
  private readonly injector = inject(Injector);
  private async call<T>(name: string, data: object): Promise<T> {
    const fn = runInInjectionContext(this.injector, () => httpsCallable<object, T>(this.functions, `question_bank-${name}`, { timeout: 30000 }));
    return (await fn(data)).data;
  }
  preview(subjectId: string, fileName: string, base64: string): Promise<{ rows: ImportRow[] }> { return this.call('previewImport', { subjectId, fileName, base64 }); }
  validate(subjectId: string, rows: ImportRow[]): Promise<{ rows: ImportRow[] }> { return this.call('previewImport', { subjectId, rows }); }
  import(subjectId: string, rows: ImportRow[], importId: string): Promise<{ added: number; skipped: number }> { return this.call('importQuestions', { subjectId, rows, importId }); }
  saveBlueprint(subjectId: string, questionLimit: number, enabled: boolean, rows: BlueprintRow[]): Promise<{ saved: boolean }> { return this.call('saveBlueprint', { subjectId, questionLimit, blueprint: { enabled, rows } }); }
}
