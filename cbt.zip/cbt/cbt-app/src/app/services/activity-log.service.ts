import { Injectable, inject } from '@angular/core';
import { Auth } from '@angular/fire/auth';
import { Firestore, addDoc, collection, serverTimestamp } from '@angular/fire/firestore';
import { TenantContextService } from './tenant-context.service';
@Injectable({providedIn:'root'})
export class ActivityLogService{
  private auth=inject(Auth);private db=inject(Firestore);private tenant=inject(TenantContextService);
  async log(action:string,entityType:string,entityId:string,metadata:Record<string,unknown>={}):Promise<void>{
    const user=this.auth.currentUser;if(!user)return;
    try{await addDoc(collection(this.db,this.tenant.path('activityLogs')),{action,entityType,entityId,actorId:user.uid,actorEmail:user.email??'',metadata,createdAt:serverTimestamp()});}catch(error){console.warn('Audit log write failed:',error);}
  }
}
