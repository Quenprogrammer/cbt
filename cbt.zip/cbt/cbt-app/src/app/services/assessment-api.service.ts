import { Injectable, Injector, inject, runInInjectionContext } from '@angular/core';
import { Functions, httpsCallable } from '@angular/fire/functions';

@Injectable({ providedIn: 'root' })
export class AssessmentApiService {
  private readonly functions = inject(Functions);
  private readonly injector = inject(Injector);
  async call<T = any>(group: string, name: string, data: object = {}): Promise<T> {
    const fn = runInInjectionContext(this.injector, () => httpsCallable<object, T>(this.functions, `${group}-${name}`, { timeout: group === 'tenant_backups' ? 540000 : 30000 }));
    return (await fn(data)).data;
  }
  async upload(file: File): Promise<string> {
    if (file.size >= 5 * 1024 * 1024) throw new Error('Choose media under 5 MB.');
    const base64 = await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result).split(',')[1]); reader.onerror = () => reject(new Error('Unable to read the file.')); reader.readAsDataURL(file); });
    return (await this.call('question_lifecycle', 'uploadMedia', { base64, contentType: file.type })).url;
  }
}
