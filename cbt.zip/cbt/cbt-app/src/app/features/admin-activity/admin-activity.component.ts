import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ExamAttemptService } from '../../services/exam-attempt.service';
import { HeaderComponent } from '../../services/component/header/header.component';

@Component({
  selector: 'app-admin-activity',
  standalone: true,
  imports: [CommonModule, HeaderComponent],
  templateUrl: './admin-activity.component.html',
})
export class AdminActivityComponent {
  private readonly service = inject(ExamAttemptService);

  readonly logs = toSignal(this.service.activityLogs(), {
    initialValue: [] as any[],
  });

  actor(log: any): string {
    return String(log?.actorEmail || log?.actorId || 'System');
  }

  activityDetails(log: any): string {
    const metadata = log?.metadata;
    if (!metadata || metadata.percentage === undefined || metadata.percentage === null) {
      return '-';
    }

    const parts = [`${metadata.percentage}%`];
    if (metadata.grade) parts.push(String(metadata.grade));
    if (metadata.status) parts.push(String(metadata.status));
    return parts.join(' · ');
  }
}
