import { Component, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Title, Meta } from '@angular/platform-browser';

@Component({standalone:true,imports:[RouterLink],templateUrl:'./landing.component.html',styleUrl:'./landing.component.scss'})
export class LandingComponent {
  readonly menuOpen=signal(false); readonly preview=signal(0);
  readonly tabs=['Exam setup','Candidate experience','Results'];
  readonly samples=[
    {title:'An exam, ready to take shape.',subtitle:'Build your question bank and keep subject settings together.',label:'EXAM WORKSPACE',name:'English Language',note:'SS 2 · Draft subject',metrics:[['Duration','45 min'],['Questions','30'],['Status','Draft']],rows:['Create a subject','Add questions & answers','Review settings before enabling']},
    {title:'A clear path for every candidate.',subtitle:'Candidates join their institution, select their subjects and view their assigned exams.',label:'CANDIDATE PORTAL',name:'Your next examination',note:'English Language · Example assignment',metrics:[['Duration','45 min'],['Questions','30'],['Progress','Not started']],rows:['Join with an institution code','Register examination subjects','Open your assigned examination']},
    {title:'Results that are easy to follow.',subtitle:'Review submitted attempts, candidate scores and examination outcomes in one place.',label:'RESULTS OVERVIEW',name:'English Language',note:'Sample result summary',metrics:[['Submitted','24'],['Average','72%'],['Highest','94%']],rows:['Review submitted attempts','Check candidate scores','Share approved result access']}
  ];
  readonly faqs=[
    ['How do I start a new institution?','Create an administrator account, verify your email, and choose a unique institution code. Guided setup helps you prepare your profile, subjects and candidate registration.'],
    ['How do students register?','Students choose Student registration and enter the code supplied by their institution. They create or sign in to their account, complete their profile and select the available subjects.'],
    ['Can I save setup and return later?','Yes. Institution setup is saved after each successful step. Save and exit lets you continue from the dashboard checklist when you are ready.'],
    ['Does creating a subject start an exam?','No. Guided setup creates an inactive draft subject. Administrators prepare questions and manage candidate access through the examination controls.'],
    ['What happens after institution registration?','Your institution starts with the platform’s Starter settings and trial status. Contact the platform administrator for activation, plan and billing arrangements.']
  ];
  constructor(title:Title,meta:Meta){title.setTitle('CBT Platform — Exams, organised.');meta.updateTag({name:'description',content:'Bring exam preparation, candidate registration and results together. Create a CBT institution or register as a student.'});}
  tabKey(event:KeyboardEvent):void{if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;event.preventDefault();const next=event.key==='Home'?0:event.key==='End'?2:(this.preview()+(event.key==='ArrowRight'?1:2))%3;this.preview.set(next);document.getElementById('preview-tab-'+next)?.focus();}
}

