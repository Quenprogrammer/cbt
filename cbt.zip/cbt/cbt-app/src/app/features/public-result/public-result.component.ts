import { CommonModule } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink,ActivatedRoute } from '@angular/router';
import { ExamAttemptService, ResultSummary } from '../../services/exam-attempt.service';
@Component({selector:'app-public-result',standalone:true,imports:[CommonModule,FormsModule,RouterLink],templateUrl:'./public-result.component.html',styleUrl:'./public-result.component.scss'})
export class PublicResultComponent{
  readonly service=inject(ExamAttemptService); pin=''; loading=signal(false); searched=signal(false); result=signal<ResultSummary|null>(null);error=signal('');
  constructor(){this.pin=inject(ActivatedRoute).snapshot.queryParamMap.get('pin')||'';if(this.pin)void this.check();}
  async check(){ const normalized=this.pin.trim().toUpperCase(); if(!normalized)return; this.loading.set(true); this.searched.set(false);this.error.set(''); try{this.result.set(await this.service.getPublicResult(normalized));this.searched.set(true);}catch(error){this.error.set((error as Error).message);}finally{this.loading.set(false);} }
}
