import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Auth, signOut } from '@angular/fire/auth';
import { AssessmentApiService } from '../../services/assessment-api.service';
import { AccountSecurityService } from '../../services/account-security.service';
import { InstitutionOnboardingService } from '../../services/institution-onboarding.service';

@Component({ selector: 'app-account-security', standalone: true, imports: [FormsModule, RouterLink], template: `
  <main id="content" class="main"><div class="content security-content">
    <h1>{{ challenge ? 'Verify your sign-in' : 'Account security' }}</h1>
    <p>Use a six-digit code from your authenticator app, or an unused recovery code.</p>
    @if (loading()) { <p role="status">Loading security settings…</p> }
    @if (error()) { <p role="alert" class="alert alert-danger">{{ error() }}</p> }
    @if (message()) { <p role="status" class="alert alert-success">{{ message() }}</p> }
    @if (challenge) {
      <form (ngSubmit)="verify()" class="card card-body"><label class="form-label" for="security-code">Authenticator or recovery code</label><input id="security-code" class="form-control" name="code" [(ngModel)]="code" autocomplete="one-time-code"><button class="btn btn-primary mt-3" [disabled]="busy()">Verify and continue</button><button type="button" class="btn btn-link" (click)="logout()">Sign out</button></form>
    } @else {
      <section class="card card-body mb-3"><h2 class="h5">Authenticator verification</h2><p>Status: <strong>{{ security.current()?.enrolled ? 'Enabled' : 'Disabled' }}</strong></p>
        @if (!security.current()?.enrolled && !enrollment()) { <button class="btn btn-primary" (click)="begin()" [disabled]="busy()">Set up two-factor authentication</button> }
        @if (enrollment(); as enrollment) { <p>Add an account in your authenticator app using this setup key. The key expires after 10 minutes.</p><code class="setup-key">{{ enrollment.secret }}</code><a [href]="enrollment.uri">Open authenticator setup link</a><label class="form-label mt-3" for="enroll-code">Code from the app</label><input id="enroll-code" class="form-control" [(ngModel)]="code" autocomplete="one-time-code"><button class="btn btn-primary mt-2" (click)="finish()" [disabled]="busy()">Confirm enrollment</button> }
        @if (recoveryCodes().length) { <div class="alert alert-warning mt-3"><strong>Save these recovery codes now.</strong><p>Each code works once. They will not be shown again.</p>@for (value of recoveryCodes(); track value) { <code class="d-block">{{ value }}</code> }<button class="btn btn-outline-secondary mt-2" (click)="downloadCodes()">Download recovery codes</button></div> }
        @if (security.current()?.enrolled) { <p>{{ security.current()?.recoveryCodesRemaining }} recovery codes remaining.</p><label class="form-label" for="disable-code">Fresh code to disable verification</label><input id="disable-code" class="form-control" [(ngModel)]="code" autocomplete="one-time-code"><button class="btn btn-outline-danger mt-2" (click)="disable()" [disabled]="busy()">Disable two-factor authentication</button> }
      </section>
      <section class="card card-body"><h2 class="h5">Sessions</h2><p>Sign out every device, including this one. Other devices must sign in again before accessing protected data.</p><button class="btn btn-outline-danger" (click)="revoke()" [disabled]="busy()">Revoke all sessions</button></section>
      <a routerLink="/admin/exam-list" class="btn btn-link mt-3">Return to question bank</a>
    }
  </div></main>
`, styles: ['.security-content { max-width: 720px; margin: 2rem auto; } .setup-key { overflow-wrap:anywhere; font-size:1.2rem; padding:1rem; background:#f1f4f9; margin-bottom:1rem; }'] })
export class SecurityComponent {
  readonly security = inject(AccountSecurityService);
  private readonly api = inject(AssessmentApiService);
  private readonly auth = inject(Auth);
  private readonly router = inject(Router);
  private readonly setup = inject(InstitutionOnboardingService);
  private readonly sanitizer = inject(DomSanitizer);
  readonly challenge = inject(ActivatedRoute).snapshot.routeConfig?.path === 'security/verify';
  readonly loading = signal(true); readonly busy = signal(false); readonly error = signal(''); readonly message = signal('');
  readonly enrollment = signal<{ secret: string; uri: SafeUrl } | null>(null); readonly recoveryCodes = signal<string[]>([]); code = '';
  constructor() { void this.load(); }
  private async load(): Promise<void> { try { await this.auth.authStateReady(); if (!this.auth.currentUser) { await this.router.navigateByUrl('/authentication'); return; } await this.security.refresh(); } catch (error) { this.error.set(String((error as Error).message)); } finally { this.loading.set(false); } }
  private async action(operation: () => Promise<void>): Promise<void> { if (this.busy()) return; this.busy.set(true); this.error.set(''); this.message.set(''); try { await operation(); } catch (error) { this.error.set(String((error as Error).message)); } finally { this.busy.set(false); } }
  begin(): void { void this.action(async () => { const result = await this.api.call<{secret:string;uri:string}>('account_security', 'beginEnrollment'); if (!result.uri.startsWith('otpauth://totp/CBT:')) throw new Error('Invalid authenticator setup link.'); this.enrollment.set({ secret: result.secret, uri: this.sanitizer.bypassSecurityTrustUrl(result.uri) }); }); }
  finish(): void { void this.action(async () => { const result = await this.api.call('account_security', 'finishEnrollment', { code: this.code }); this.recoveryCodes.set(result.recoveryCodes); this.enrollment.set(null); this.code = ''; await this.security.refresh(); this.message.set('Two-factor authentication enabled.'); }); }
  verify(): void { void this.action(async () => { await this.api.call('account_security', 'verify', { code: this.code }); await this.security.refresh(); await this.router.navigateByUrl(await this.setup.destination()); }); }
  disable(): void { void this.action(async () => { await this.api.call('account_security', 'disable', { code: this.code }); this.code = ''; this.recoveryCodes.set([]); await this.security.refresh(); this.message.set('Two-factor authentication disabled.'); }); }
  revoke(): void { void this.action(async () => { await this.api.call('account_security', 'revokeSessions'); await this.logout(); }); }
  async logout(): Promise<void> { await signOut(this.auth); await this.router.navigateByUrl('/authentication'); }
  downloadCodes(): void { const url = URL.createObjectURL(new Blob([this.recoveryCodes().join('\n')], { type: 'text/plain' })); const link = document.createElement('a'); link.href = url; link.download = 'cbt-recovery-codes.txt'; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); }
}
