import { AfterViewInit, Component, effect, ElementRef, inject, OnDestroy, ViewChild } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { Student, StudentService } from '../../../services/student.service';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { PaginationComponent } from '../pagination/pagination.component';
import { NgForOf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HeaderComponent } from '../../../services/component/header/header.component';
import { Chart, registerables } from 'chart.js';
import { Firestore, addDoc, collection, serverTimestamp } from '@angular/fire/firestore';
import { ActivityLogService } from '../../../services/activity-log.service';

import { TenantContextService } from '../../../services/tenant-context.service';
Chart.register(...registerables);

@Component({
  selector: 'app-student-list',
  standalone: true,
  imports: [
    RouterLink,
    RouterLinkActive,
    PaginationComponent,
    NgForOf,
    FormsModule,
    HeaderComponent
  ],
  templateUrl: './student-list.component.html',
  styleUrl: './student-list.component.scss'
})
export class StudentListComponent implements AfterViewInit, OnDestroy {
  private studentService = inject(StudentService);
  private firestore = inject(Firestore);
  private readonly tenant = inject(TenantContextService);
  private audit = inject(ActivityLogService);
  students = toSignal(this.studentService.students$, { initialValue: [] });

  @ViewChild('departmentChart') private departmentChartCanvas?: ElementRef<HTMLCanvasElement>;
  @ViewChild('studentGenderChart') private genderChartCanvas?: ElementRef<HTMLCanvasElement>;

  private departmentChart?: Chart<'bar', number[], string>;
  private genderChart?: Chart<'pie', number[], string>;
  private chartsReady = false;

  itemsPerPage = 10;
  currentPage = 1;
  searchTerm = '';

  constructor() {
    effect(() => {
      const students = this.students();

      if (!this.chartsReady) {
        return;
      }

      this.renderDepartmentChart(students);
      this.renderGenderChart(students);
    });
  }

  ngAfterViewInit(): void {
    this.chartsReady = true;
    const students = this.students();
    this.renderDepartmentChart(students);
    this.renderGenderChart(students);
  }

  get paginatedItems() {
    const filteredStudents = this.filterStudents();
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return filteredStudents.slice(startIndex, endIndex);
  }

  onPageChange(page: number): void {
    this.currentPage = page;
  }

  onSearch(): void {
    this.currentPage = 1; // Reset to the first page when searching
  }

  filterStudents() {
    if (!this.searchTerm) {
      return this.students();
    }
    return this.students().filter(student =>
      student.firstname.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      student.admissionNumber.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  private renderDepartmentChart(students: Student[]): void {
    const canvas = this.departmentChartCanvas?.nativeElement;
    if (!canvas) {
      return;
    }

    const departmentCounts = new Map<string, number>();

    students.forEach((student) => {
      const department = student.department?.trim() || 'Not specified';
      departmentCounts.set(department, (departmentCounts.get(department) ?? 0) + 1);
    });

    const departments = Array.from(departmentCounts.entries())
      .sort((a, b) => b[1] - a[1]);
    const labels = departments.map(([department]) => department);
    const data = departments.map(([, count]) => count);

    this.departmentChart?.destroy();
    this.departmentChart = new Chart(canvas, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            label: 'Students',
            data,
            backgroundColor: '#2563eb',
            borderColor: '#2563eb',
            borderWidth: 1,
            borderRadius: 6,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              precision: 0,
            },
          },
          x: {
            grid: {
              display: false,
            },
          },
        },
      },
    });
  }

  private renderGenderChart(students: Student[]): void {
    const canvas = this.genderChartCanvas?.nativeElement;
    if (!canvas) {
      return;
    }

    const genderCounts = this.countGenders(students.map((student) => student.gender));

    this.genderChart?.destroy();
    this.genderChart = new Chart(canvas, {
      type: 'pie',
      data: {
        labels: genderCounts.labels,
        datasets: [
          {
            label: 'Students',
            data: genderCounts.data,
            borderWidth: 0,
            backgroundColor: ['#2563eb', '#edcb50', ],
            hoverBackgroundColor: ['#2563eb', '#edcb50', ],
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              usePointStyle: true,
              padding: 18,
            },
          },
        },
      },
    });
  }

  private countGenders(genders: string[]): { labels: string[]; data: number[] } {
    const counts = new Map<string, number>([
      ['Male', 0],
      ['Female', 0],
    ]);

    genders.forEach((genderValue) => {
      const normalized = (genderValue ?? '').trim().toLowerCase();
      let label = 'Not specified';

      if (normalized === 'male' || normalized === 'm') {
        label = 'Male';
      } else if (normalized === 'female' || normalized === 'f') {
        label = 'Female';
      } else if (normalized) {
        label = 'Other';
      }

      counts.set(label, (counts.get(label) ?? 0) + 1);
    });

    const entries = Array.from(counts.entries()).filter(([, count]) => count > 0);
    return {
      labels: entries.map(([label]) => label),
      data: entries.map(([, count]) => count),
    };
  }

  exportCsv(): void {
    const rows = this.students();
    const headers = ['admissionNumber','firstname','middlename','lastname','email','phone','gender','dateOfBirth','department','classLevel','status','guardianName','guardianPhone'];
    const escape = (value: unknown) => `"${String(value ?? '').replace(/"/g, '""')}"`;
    const csv = [headers.join(','), ...rows.map(row => headers.map(key => escape((row as any)[key])).join(','))].join('\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = `students-${new Date().toISOString().slice(0,10)}.csv`; anchor.click(); URL.revokeObjectURL(url);
  }

  async importCsv(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement; const file = input.files?.[0]; if (!file) return;
    try {
      const text = await file.text(); const lines = text.split(/\r?\n/).filter(Boolean); if (lines.length < 2) return;
      const parse = (line: string) => { const values: string[] = []; let value=''; let quoted=false; for(let i=0;i<line.length;i++){const c=line[i]; if(c==='"'){if(quoted && line[i+1]==='"'){value+='"';i++;}else quoted=!quoted;}else if(c===','&&!quoted){values.push(value);value='';}else value+=c;} values.push(value); return values; };
      const headers = parse(lines[0]).map(h => h.trim()); let imported = 0;
      for (const line of lines.slice(1)) { const values=parse(line); const record:any={}; headers.forEach((h,i)=>record[h]=values[i] ?? ''); if(!record.firstname || !record.lastname || !record.admissionNumber) continue; record.examStatus=record.examStatus||'Not Started'; record.status=record.status||'Active'; record.createdAt=serverTimestamp(); await addDoc(collection(this.firestore,this.tenant.path('student')),record); imported++; }
      await this.audit.log('students_imported','student','bulk',{count:imported,fileName:file.name});
      alert(`${imported} student record(s) imported.`);
    } catch(error){console.error(error);alert('Unable to import CSV. Check the file format.');} finally { input.value=''; }
  }

  isLoading() {
    // Implement loading logic if needed
  }

  ngOnDestroy(): void {
    this.departmentChart?.destroy();
    this.genderChart?.destroy();
  }
}
