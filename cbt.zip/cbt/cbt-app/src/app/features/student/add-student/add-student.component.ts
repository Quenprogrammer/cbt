import { Component, Injector, inject, runInInjectionContext } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Firestore, collection, doc, serverTimestamp, setDoc } from '@angular/fire/firestore';
import { Storage, getDownloadURL, ref, uploadBytes } from '@angular/fire/storage';
import { RouterLink } from '@angular/router';
import { ActivityLogService } from '../../../services/activity-log.service';

import { TenantContextService } from '../../../services/tenant-context.service';
@Component({
  selector: 'app-add-student',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './add-student.component.html',
  styleUrl: './add-student.component.scss',
})
export class AddStudentComponent {
  private readonly firestore = inject(Firestore);
  private readonly tenant = inject(TenantContextService);
  private readonly storage = inject(Storage);
  private readonly injector = inject(Injector);
  private readonly audit = inject(ActivityLogService);
  saving = false;
  photoPreview = '';
  private selectedPhoto: File | null = null;

  profileForm = new FormGroup({
    admissionNumber: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    firstname: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    middlename: new FormControl('', { nonNullable: true }),
    lastname: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    email: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.email] }),
    phone: new FormControl('', { nonNullable: true }),
    gender: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    dateOfBirth: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    department: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    classLevel: new FormControl('', { nonNullable: true }),
    enrollmentDate: new FormControl('', { nonNullable: true }),
    status: new FormControl('Active', { nonNullable: true }),
    authUid: new FormControl('', { nonNullable: true }),
    address: new FormControl('', { nonNullable: true }),
    stateOfOrigin: new FormControl('', { nonNullable: true }),
    lga: new FormControl('', { nonNullable: true }),
    bloodGroup: new FormControl('', { nonNullable: true }),
    genotype: new FormControl('', { nonNullable: true }),
    guardianName: new FormControl('', { nonNullable: true }),
    guardianPhone: new FormControl('', { nonNullable: true }),
    guardianEmail: new FormControl('', { nonNullable: true, validators: [Validators.email] }),
    emergencyContact: new FormControl('', { nonNullable: true }),
    notes: new FormControl('', { nonNullable: true }),
  });

  onPhotoSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0] ?? null;
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      alert('Student photo must be an image file.');
      input.value = '';
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      alert('Student photo must be 5 MB or smaller.');
      input.value = '';
      return;
    }
    this.selectedPhoto = file;
    const reader = new FileReader();
    reader.onload = () => (this.photoPreview = String(reader.result ?? ''));
    reader.readAsDataURL(file);
  }

  private async uploadPhoto(ownerFolder: string): Promise<string> {
    if (!this.selectedPhoto) return '';
    const extension = this.selectedPhoto.name.split('.').pop()?.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() || 'jpg';
    return runInInjectionContext(this.injector, async () => {
      const storageRef = ref(this.storage, this.tenant.storagePath(`student-images/${ownerFolder}/profile-${Date.now()}.${extension}`));
      await uploadBytes(storageRef, this.selectedPhoto!, { contentType: this.selectedPhoto!.type });
      return getDownloadURL(storageRef);
    });
  }

  async handleSubmit(): Promise<void> {
    if (this.profileForm.invalid) {
      this.profileForm.markAllAsTouched();
      return;
    }

    const tenantState = this.tenant.state();
    if (tenantState?.modules['students'] === false) {
      alert('The Students module is disabled for this CBT tenant.');
      return;
    }
    const usedStudents = Number(tenantState?.usage['students'] ?? 0);
    const studentLimit = Number(tenantState?.limits['students'] ?? Number.MAX_SAFE_INTEGER);
    if (usedStudents >= studentLimit) {
      alert('This CBT tenant has reached its student limit. Increase the limit in Tenant Manager before adding another student.');
      return;
    }

    this.saving = true;
    try {
      const values = this.profileForm.getRawValue();
      const studentRef = doc(collection(this.firestore, this.tenant.path('student')));
      const photoFolder = values.authUid.trim() || `admin-${studentRef.id}`;
      const photoURL = await this.uploadPhoto(photoFolder);
      await setDoc(studentRef, {
        ...values,
        photoURL,
        examStatus: 'Not Started',
        registeredSubjectIds: [],
        registeredSubjects: [],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await this.audit.log('student_created', 'student', studentRef.id, {
        admissionNumber: values.admissionNumber,
      });
      alert('Student added successfully.');
      this.profileForm.reset({ status: 'Active' });
      this.selectedPhoto = null;
      this.photoPreview = '';
      await this.tenant.refresh().catch(() => undefined);
    } catch (error) {
      console.error(error);
      alert('Unable to add student.');
    } finally {
      this.saving = false;
    }
  }
}
