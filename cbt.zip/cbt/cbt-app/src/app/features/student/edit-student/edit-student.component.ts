import { Component, Injector, Input, inject, runInInjectionContext } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import {
  Firestore,
  deleteDoc,
  doc,
  getDoc,
  serverTimestamp,
  updateDoc,
} from '@angular/fire/firestore';
import { TenantContextService } from '../../../services/tenant-context.service';
import { Storage, getDownloadURL, ref, uploadBytes } from '@angular/fire/storage';
import { Router, RouterLink } from '@angular/router';
import { ActivityLogService } from '../../../services/activity-log.service';
import { Student } from '../../../services/student.service';

@Component({
  selector: 'app-edit-student',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './edit-student.component.html',
  styleUrl: './edit-student.component.scss',
})
export class EditStudentComponent {
  private readonly firestore = inject(Firestore);
  private readonly tenant = inject(TenantContextService);
  private readonly storage = inject(Storage);
  private readonly injector = inject(Injector);
  private readonly router = inject(Router);
  private readonly audit = inject(ActivityLogService);

  studentId: string | null = null;
  student: Partial<Student> | null = null;
  loading = true;
  saving = false;
  deleting = false;
  editing = false;
  examStatus = 'Not Started';
  photoURL = '';
  photoPreview = '';
  registeredSubjects: string[] = [];
  private selectedPhoto: File | null = null;

  readonly profileForm = new FormGroup({
    admissionNumber: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    firstname: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    middlename: new FormControl('', { nonNullable: true }),
    lastname: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    email: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.email] }),
    phone: new FormControl('', { nonNullable: true }),
    gender: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    dateOfBirth: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    department: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    classLevel: new FormControl('', { nonNullable: true }),
    enrollmentDate: new FormControl('', { nonNullable: true }),
    status: new FormControl('Active', { nonNullable: true }),
    authUid: new FormControl('', { nonNullable: true }),
    address: new FormControl('', { nonNullable: true }),
    stateOfOrigin: new FormControl('', { nonNullable: true }),
    lga: new FormControl('', { nonNullable: true }),
    bloodGroup: new FormControl('', { nonNullable: true }),
    genotype: new FormControl('', { nonNullable: true }),
    guardianName: new FormControl('', { nonNullable: true }),
    guardianPhone: new FormControl('', { nonNullable: true }),
    guardianEmail: new FormControl('', { nonNullable: true, validators: [Validators.email] }),
    emergencyContact: new FormControl('', { nonNullable: true }),
    notes: new FormControl('', { nonNullable: true }),
  });

  @Input()
  set id(studentId: string) {
    if (!studentId) {
      void this.router.navigate(['/admin/student-list']);
      return;
    }

    this.studentId = studentId;
    void this.getStudentDetail(studentId);
  }

  fullName(): string {
    const value = this.student;
    if (!value) return 'Student';
    return [value.firstname, value.middlename, value.lastname].filter(Boolean).join(' ');
  }

  startEditing(): void {
    this.editing = true;
  }

  async cancelEditing(): Promise<void> {
    this.selectedPhoto = null;
    this.photoPreview = '';
    this.editing = false;
    if (this.studentId) await this.getStudentDetail(this.studentId);
  }

  onPhotoSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0] ?? null;
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Student photo must be an image file.');
      input.value = '';
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      alert('Student photo must be 5 MB or smaller.');
      input.value = '';
      return;
    }

    this.selectedPhoto = file;
    const reader = new FileReader();
    reader.onload = () => (this.photoPreview = String(reader.result ?? ''));
    reader.readAsDataURL(file);
  }

  private async uploadPhoto(): Promise<string> {
    if (!this.selectedPhoto || !this.studentId) return this.photoURL;

    const ownerFolder = this.profileForm.controls.authUid.value.trim() || `admin-${this.studentId}`;
    const extension = this.selectedPhoto.name.split('.').pop()?.replace(/[^a-zA-Z0-9]/g, '').toLowerCase() || 'jpg';
    return runInInjectionContext(this.injector, async () => {
      const storageRef = ref(
        this.storage,
        this.tenant.storagePath(`student-images/${ownerFolder}/profile-${Date.now()}.${extension}`)
      );
      await uploadBytes(storageRef, this.selectedPhoto!, { contentType: this.selectedPhoto!.type });
      return getDownloadURL(storageRef);
    });
  }

  private async getStudentDetail(studentId: string): Promise<void> {
    this.loading = true;
    try {
      const snapshot = await getDoc(doc(this.firestore, this.tenant.path(`student/${studentId}`)));
      if (!snapshot.exists()) {
        alert('Student record was not found.');
        await this.router.navigate(['/admin/student-list']);
        return;
      }

      const student = { id: snapshot.id, ...snapshot.data() } as Partial<Student>;
      this.student = student;
      this.examStatus = String(student.examStatus || 'Not Started');
      this.photoURL = String(student.photoURL || '');
      this.registeredSubjects = Array.isArray(student.registeredSubjects)
        ? student.registeredSubjects.map((value) => String(value))
        : [];
      this.profileForm.patchValue({
        admissionNumber: student.admissionNumber ?? '',
        firstname: student.firstname ?? '',
        middlename: student.middlename ?? '',
        lastname: student.lastname ?? '',
        email: student.email ?? '',
        phone: student.phone ?? '',
        gender: student.gender ?? '',
        dateOfBirth: student.dateOfBirth ?? '',
        department: student.department ?? '',
        classLevel: student.classLevel ?? '',
        enrollmentDate: student.enrollmentDate ?? '',
        status: student.status ?? 'Active',
        authUid: student.authUid ?? '',
        address: student.address ?? '',
        stateOfOrigin: student.stateOfOrigin ?? '',
        lga: student.lga ?? '',
        bloodGroup: student.bloodGroup ?? '',
        genotype: student.genotype ?? '',
        guardianName: student.guardianName ?? '',
        guardianPhone: student.guardianPhone ?? '',
        guardianEmail: student.guardianEmail ?? '',
        emergencyContact: student.emergencyContact ?? '',
        notes: student.notes ?? '',
      });
    } catch (error) {
      console.error('Error loading student:', error);
      alert('Unable to load the student record.');
    } finally {
      this.loading = false;
    }
  }

  async handleSubmit(): Promise<void> {
    if (!this.studentId) return;
    if (this.profileForm.invalid) {
      this.profileForm.markAllAsTouched();
      alert('Please complete all required fields correctly.');
      return;
    }

    this.saving = true;
    try {
      const values = this.profileForm.getRawValue();
      const photoURL = await this.uploadPhoto();
      await updateDoc(doc(this.firestore, this.tenant.path(`student/${this.studentId}`)), {
        ...values,
        photoURL,
        updatedAt: serverTimestamp(),
      });
      await this.audit.log('student_updated', 'student', this.studentId, {
        admissionNumber: values.admissionNumber,
      });
      this.selectedPhoto = null;
      this.photoPreview = '';
      this.editing = false;
      await this.getStudentDetail(this.studentId);
      alert('Student data updated successfully.');
    } catch (error) {
      console.error('Error updating student:', error);
      alert('Unable to update student data. Please try again.');
    } finally {
      this.saving = false;
    }
  }

  async delete(): Promise<void> {
    if (!this.studentId || this.deleting) return;
    if (!confirm('Delete this student record permanently?')) return;

    this.deleting = true;
    try {
      const studentId = this.studentId;
      await deleteDoc(doc(this.firestore, this.tenant.path(`student/${studentId}`)));
      await this.audit.log('student_deleted', 'student', studentId, {
        admissionNumber: this.profileForm.controls.admissionNumber.value,
      });
      await this.router.navigate(['/admin/student-list']);
    } catch (error) {
      console.error('Error deleting student:', error);
      alert('Unable to delete the student record.');
    } finally {
      this.deleting = false;
    }
  }
}
