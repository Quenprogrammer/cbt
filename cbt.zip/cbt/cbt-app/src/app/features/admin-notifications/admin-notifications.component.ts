import { CommonModule } from '@angular/common';
import { Component, Injector, inject, runInInjectionContext } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { Firestore, doc, updateDoc } from '@angular/fire/firestore';
import { HeaderComponent } from '../../services/component/header/header.component';
import { ExamAttemptService } from '../../services/exam-attempt.service';

import { TenantContextService } from '../../services/tenant-context.service';
@Component({
  selector: 'app-admin-notifications',
  standalone: true,
  imports: [CommonModule, HeaderComponent],
  templateUrl: './admin-notifications.component.html',
})
export class AdminNotificationsComponent {
  private readonly db = inject(Firestore);
  private readonly tenant = inject(TenantContextService);
  private readonly injector = inject(Injector);
  private readonly examService = inject(ExamAttemptService);

  readonly notifications = toSignal(this.examService.notifications(), {
    initialValue: [] as any[],
  });

  async markRead(id: string): Promise<void> {
    if (!id) return;
    await runInInjectionContext(this.injector, () =>
      updateDoc(doc(this.db, this.tenant.path(`notifications/${id}`)), { read: true })
    );
  }
}
