import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddingExamQuestionComponent } from './adding-exam-question.component';

describe('AddingExamQuestionComponent', () => {
  let component: AddingExamQuestionComponent;
  let fixture: ComponentFixture<AddingExamQuestionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddingExamQuestionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddingExamQuestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
