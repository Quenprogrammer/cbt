import { Component, inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { QuestionEditorComponent } from '../question-editor/question-editor.component';
@Component({ selector:'app-adding-exam-question',standalone:true,imports:[QuestionEditorComponent],templateUrl:'./adding-exam-question.component.html',styleUrl:'./adding-exam-question.component.scss' })
export class AddingExamQuestionComponent { subjectId = inject(ActivatedRoute).snapshot.queryParamMap.get('id') || ''; }
