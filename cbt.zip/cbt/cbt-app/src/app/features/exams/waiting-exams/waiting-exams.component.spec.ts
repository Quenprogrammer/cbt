import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WaitingExamsComponent } from './waiting-exams.component';

describe('WaitingExamsComponent', () => {
  let component: WaitingExamsComponent;
  let fixture: ComponentFixture<WaitingExamsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WaitingExamsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WaitingExamsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
