import {Component, inject, OnInit} from '@angular/core';
import {StudentService} from '../../../services/student.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-waiting-exams',
  standalone: true,
  imports: [],
  templateUrl: './waiting-exams.component.html',
  styleUrl: './waiting-exams.component.scss'
})
export class WaitingExamsComponent implements OnInit {
  private studentService = inject(StudentService);
  private router = inject(Router);

  ngOnInit(): void {
    this.studentService.examStarted$.subscribe((isExamStarted) => {
      console.log('Exam started:', isExamStarted); // Debugging log
      if (isExamStarted) {
        this.router.navigate(['/admin/exam-list']); // Ensure this path matches your route
      }
    });
  }
}
