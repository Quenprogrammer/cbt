import {Component, inject, signal} from '@angular/core';
import { InstitutionOnboardingService } from '../../../services/institution-onboarding.service';
import {CommonModule} from '@angular/common';
import {PaginationComponent} from '../../student/pagination/pagination.component';
import {RouterLink, RouterLinkActive} from '@angular/router';
import {toSignal} from '@angular/core/rxjs-interop';
import {ExamsListService} from '../../../services/exams-list.service';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

@Component({
  selector: 'app-exam-list',
  standalone: true,
  imports: [
    CommonModule,
    PaginationComponent,
    RouterLink,
    RouterLinkActive,
    FormsModule,
    ReactiveFormsModule
  ],
  templateUrl: './exam-list.component.html',

  styleUrl: './exam-list.component.scss'
})
export class ExamListComponent {
  private readonly setup=inject(InstitutionOnboardingService);
  readonly saving=signal('');readonly message=signal('');readonly error=signal('');
  async setAvailability(id:string,active:boolean):Promise<void>{if(this.saving())return;this.saving.set(id);this.message.set('');this.error.set('');try{await this.setup.setSubjectAvailability(id,active);this.message.set(active?'Subject enabled for student registration.':'Subject disabled.');}catch(error){this.error.set(error instanceof Error?error.message:'Unable to update subject.');}finally{this.saving.set('');}}
  private examlist = inject(ExamsListService)
  examlists = toSignal(this.examlist.examlist$, { initialValue: [] });

  itemsPerPage = 5;
  currentPage = 1;
  searchTerm = '';
  get Examlist() {
    const filteredExamination = this.filterExams();
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return filteredExamination.slice(startIndex, endIndex);
  }

  onPageChange(page: number): void {
    this.currentPage = page;
  }

  onSearch(): void {
    this.currentPage = 1; // Reset to the first page when searching
  }

  filterExams() {
    if (!this.searchTerm) {
      return this.examlists();
    }
    return this.examlists().filter(exams =>
      exams.name.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      exams.description.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }
}
