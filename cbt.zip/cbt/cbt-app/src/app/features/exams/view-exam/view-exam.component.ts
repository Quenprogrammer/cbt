import {Component, inject, Input} from '@angular/core';
import {CommonModule} from '@angular/common';
import { QuestionImageComponent } from '../../../shared/question-image/question-image.component';
import { QuestionImportComponent } from '../question-import/question-import.component';
import { ExamBlueprintComponent } from '../exam-blueprint/exam-blueprint.component';
import { AssessmentApiService } from '../../../services/assessment-api.service';
import {PaginationComponent} from '../../student/pagination/pagination.component';
import {ActivatedRoute, Router, RouterLink, RouterLinkActive} from '@angular/router';
import {ViewExamsService} from '../../../services/view-exams.service';
import {deleteDoc, doc, Firestore} from '@angular/fire/firestore';
import {toSignal} from '@angular/core/rxjs-interop';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";

import { TenantContextService } from '../../../services/tenant-context.service';
@Component({
  selector: 'app-view-exam',
  standalone: true,
    imports: [
        CommonModule,
        QuestionImageComponent,
        QuestionImportComponent, ExamBlueprintComponent,
        PaginationComponent,
        RouterLink,
        RouterLinkActive,
        FormsModule,
        ReactiveFormsModule
    ],
  templateUrl: './view-exam.component.html',
  styleUrl: './view-exam.component.scss'
})
export class ViewExamComponent {
  private viewExamsService = inject(ViewExamsService);
  private router = inject(Router);
  private firestore=inject(Firestore);
  private api=inject(AssessmentApiService);
  readonly tenant = inject(TenantContextService);
  route: ActivatedRoute = inject(ActivatedRoute);
  subjectId: string | null = null;
  examId: string | null = null;

  @Input()
  set id(subjectId: string) {
    if (subjectId) {
      this.subjectId = subjectId;
      this.viewExamsService.loadExams(subjectId);
    } else {
      this.router.navigate(['/']);
    }
  }
/*
  constructor() {

    this.route.paramMap.subscribe((params)=>{

      const subjectId = params.get('subjectId');
      const examId =params.get('examsId');

      if (subjectId && examId) {
        this.subjectId = subjectId;
        this.examId = examId;
      } else {
        this.router.navigate(['/']);
      }
    });





  }*/

  viewExam = toSignal(this.viewExamsService.viewexam$, { initialValue: [] });
  itemsPerPage = 5;
  currentPage = 1;
  searchTerm = '';
  topicFilter = '';
  difficultyFilter = '';
  publicationFilter = '';
  classFilter = '';
  sessionFilter = '';
  curriculumFilter = '';
  topics(): string[] { return [...new Set(this.viewExam().map(q => q.topic || 'General'))].sort(); }
  classes(): string[] { return [...new Set(this.viewExam().map(q => q.className || '').filter(Boolean))].sort(); }
  sessions(): string[] { return [...new Set(this.viewExam().map(q => q.academicSession || '').filter(Boolean))].sort(); }
  curricula(): string[] { return [...new Set(this.viewExam().map(q => q.curriculum || '').filter(Boolean))].sort(); }


  get ViewExams() {
    const filteredExaminationQ = this.filterExams();
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return filteredExaminationQ.slice(startIndex, endIndex);
  }

  onPageChange(page: number): void {
    this.currentPage = page;
  }

  getOptionLetter(index: number): string {
    return String.fromCharCode(65 + index); // 65 is the ASCII code for 'A'
  }


  delete() {
    if (this.subjectId) {
      const subjectDocRef = doc(this.firestore, this.tenant.path(`subjects/${this.subjectId}`));
      console.log('Document reference:', subjectDocRef);

      // Delete the subject document from Firestore
      deleteDoc(subjectDocRef)
        .then(() => {
          alert('Subject deleted successfully!');
          //this.viewExam.reset(); // Reset the form view
          this.subjectId = ''; // Clear the subject ID
        })
        .catch((error: any) => {
          console.error('Error deleting document:', error);
          alert('Error deleting subject data. Please try again.');
        });
    } else {
      alert('No subject selected for deletion.');
    }
  }



  deleting(examId: string) {
    if (this.subjectId && examId) {
      // Construct the path to the specific exam document

      // Delete the specific exam document from Firestore
      this.api.call('question_lifecycle','archiveQuestion',{subjectId:this.subjectId,questionId:examId})
        .then(() => {
          alert('Question archived. Its version history has been preserved.');
        })
        .catch((error: any) => {
          console.error('Error deleting document:', error);
          alert('Error deleting exam document. Please try again.');
        });
    } else {
      alert('Subject ID or Exam ID is missing. Unable to delete.');
    }
  }

  onSearch(): void {
    this.currentPage = 1; // Reset to the first page when searching
  }

  filterExams() {
    const term = this.searchTerm.trim().toLowerCase();
    return this.viewExam().filter(q =>
      (!term || [q.question, q.topic, ...(q.tags || [])].some(value => value?.toLowerCase().includes(term))) &&
      (!this.topicFilter || (q.topic || 'General') === this.topicFilter) &&
      (!this.difficultyFilter || (q.difficulty || 'medium') === this.difficultyFilter) &&
      (this.publicationFilter === 'archived' ? Boolean(q.archived) : !q.archived && (!this.publicationFilter || (q.publicationStatus || 'approved') === this.publicationFilter)) &&
      (!this.classFilter || q.className === this.classFilter) &&
      (!this.sessionFilter || q.academicSession === this.sessionFilter) &&
      (!this.curriculumFilter || q.curriculum === this.curriculumFilter));
  }

}
