import {Component, inject, Input} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {NgForOf} from '@angular/common';
import {PaginationComponent} from '../../student/pagination/pagination.component';
import {ActivatedRoute, Router, RouterLink, RouterLinkActive} from '@angular/router';
import {StudentService} from '../../../services/student.service';
import {toSignal} from '@angular/core/rxjs-interop';
import {ViewScoresService} from '../../../services/view-scores.service';
import {ViewExamsService} from '../../../services/view-exams.service';
import {deleteDoc, doc, Firestore} from '@angular/fire/firestore';

@Component({
  selector: 'app-view-score',
  standalone: true,
  imports: [
    FormsModule,
    NgForOf,
    PaginationComponent,
    RouterLink,
    RouterLinkActive
  ],
  templateUrl: './view-score.component.html',

  styleUrl: './view-score.component.scss'
})
export class ViewScoreComponent {
  private viewScoreService = inject(ViewScoresService);
  private studentService = inject(StudentService);
  private router = inject(Router);
  private firestore=inject(Firestore);
  route: ActivatedRoute = inject(ActivatedRoute);
  subjectId: string | null = null;
  examId: string | null = null;
  @Input()
  set id(subjectId: string) {
    if (subjectId) {
      this.subjectId = subjectId;
      this.viewScoreService.loadExams(subjectId);
    } else {
      this.router.navigate(['/']);
    }
  }
  /*
    constructor() {

      this.route.paramMap.subscribe((params)=>{

        const subjectId = params.get('subjectId');
        const examId =params.get('examsId');

        if (subjectId && examId) {
          this.subjectId = subjectId;
          this.examId = examId;
        } else {
          this.router.navigate(['/']);
        }
      });





    }*/

  viewScore = toSignal(this.viewScoreService.viewscores$, { initialValue: [] });
  itemsPerPage = 5;
  currentPage = 1;
  searchTerm ='';


  get ViewExams() {
    const filteredStudentScore = this.filterStudents();
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return filteredStudentScore.slice(startIndex, endIndex);
  }

  onPageChange(page: number): void {
    this.currentPage = page;
  }

  getOptionLetter(index: number): string {
    return String.fromCharCode(65 + index); // 65 is the ASCII code for 'A'
  }


  onSearch(): void {
    this.currentPage = 1; // Reset to the first page when searching
  }

  filterStudents() {
    if (!this.searchTerm) {
      return this.viewScore();
    }
    return this.viewScore().filter(students =>
      students.student.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      students.grade.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }
}
