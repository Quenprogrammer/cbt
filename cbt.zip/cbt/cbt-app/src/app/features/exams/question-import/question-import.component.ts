import { Component, Input, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ImportRow, QuestionBankService } from '../../../services/question-bank.service';

@Component({
  selector: 'app-question-import', standalone: true, imports: [FormsModule],
  template: `
    <section class="card mb-4">
      <div class="card-body">
        <h2 class="h5">Bulk question import</h2>
        <p class="text-muted">Upload CSV or Excel (.xlsx), up to 200 questions and 2 MB. Preview and correct rows before importing. Existing questions with the same text are skipped.</p>
        <div class="d-flex flex-wrap gap-2 align-items-center">
          <button type="button" class="btn btn-outline-secondary" (click)="downloadTemplate()">Download CSV template</button>
          <label class="btn btn-outline-primary mb-0" [class.disabled]="busy()">Choose CSV or Excel<input type="file" class="visually-hidden" accept=".csv,.xlsx" [disabled]="busy()" (change)="readFile($event)"></label>
          <span>{{ fileName() }}</span>
        </div>
        @if (busy()) { <p class="mt-3" role="status">{{ operation() }}</p> }
        @if (error()) { <p class="text-danger mt-3" role="alert">{{ error() }}</p> }
        @if (message()) { <p class="text-success mt-3" role="status">{{ message() }}</p> }
        @if (rows().length) {
          <p class="mt-3">{{ rows().length }} rows · {{ invalidCount() }} invalid · {{ duplicateCount() }} duplicates</p>
          <div class="preview-list">
            @for (row of rows(); track $index) {
              <details class="border rounded p-3 mb-2" [open]="row.errors.length > 0">
                <summary>Row {{ row.rowNumber }} — {{ row.values['question'] || 'Missing question' }} @if (row.duplicate) { <span class="badge text-bg-secondary">Duplicate</span> }</summary>
                @for (issue of row.errors; track issue) { <p class="text-danger mb-1">{{ issue }}</p> }
                <fieldset [disabled]="busy()" class="row g-2 mt-2">
                  @for (column of columns; track column.key) {
                    <div [class]="column.key === 'question' ? 'col-12' : 'col-md-4'">
                      <label class="form-label" [for]="'import-' + row.rowNumber + '-' + column.key">{{ column.label }}</label>
                      <input class="form-control" [id]="'import-' + row.rowNumber + '-' + column.key" [(ngModel)]="row.values[column.key]" (ngModelChange)="edited()">
                    </div>
                  }
                </fieldset>
              </details>
            }
          </div>
          @if (needsValidation()) { <p class="text-warning mt-2">Validate your edited rows before importing.</p> }
          <div class="d-flex gap-2 mt-3">
            <button type="button" class="btn btn-outline-primary" (click)="validate()" [disabled]="busy()">Validate edited rows</button>
            <button type="button" class="btn btn-primary" (click)="commit()" [disabled]="busy() || needsValidation() || invalidCount() > 0">Import questions</button>
            <button type="button" class="btn btn-outline-secondary" (click)="rows.set([])" [disabled]="busy()">Clear preview</button>
          </div>
        }
      </div>
    </section>
  `,
  styles: [`.preview-list { max-height: 560px; overflow-y: auto; } summary { overflow-wrap: anywhere; cursor: pointer; }`],
})
export class QuestionImportComponent {
  @Input({ required: true }) subjectId!: string;
  private readonly api = inject(QuestionBankService);
  readonly rows = signal<ImportRow[]>([]);
  readonly busy = signal(false);
  readonly operation = signal('');
  readonly error = signal('');
  readonly message = signal('');
  readonly fileName = signal('');
  readonly needsValidation = signal(false);
  private importId = crypto.randomUUID();
  readonly columns = [
    { key: 'question', label: 'Question' }, { key: 'questionType', label: 'Type (mcq / true_false)' },
    ...['A', 'B', 'C', 'D', 'E', 'F'].map(id => ({ key: `option${id}`, label: `Option ${id}` })),
    { key: 'correctAnswerId', label: 'Correct answer ID' }, { key: 'imageUrl', label: 'Image URL' }, { key: 'imageAlt', label: 'Image description' },
    { key: 'topic', label: 'Topic' }, { key: 'difficulty', label: 'Difficulty' }, { key: 'className', label: 'Class' },
    { key: 'curriculum', label: 'Curriculum' }, { key: 'academicSession', label: 'Academic session' }, { key: 'tags', label: 'Tags (comma separated)' },
  ];
  invalidCount(): number { return this.rows().filter(row => row.errors.length > 0).length; }
  duplicateCount(): number { return this.rows().filter(row => row.duplicate).length; }
  edited(): void { this.needsValidation.set(true); this.message.set(''); this.importId = crypto.randomUUID(); }
  async readFile(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement, file = input.files?.[0]; input.value = '';
    if (!file || this.busy()) return;
    this.rows.set([]); this.error.set(''); this.message.set('');
    if (!/\.(csv|xlsx)$/i.test(file.name) || file.size > 2 * 1024 * 1024) { this.error.set('Choose a CSV or XLSX file under 2 MB.'); return; }
    this.busy.set(true); this.operation.set('Reading and validating questions…'); this.fileName.set(file.name);
    try {
      const base64 = await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onerror = () => reject(new Error('Unable to read this file.')); reader.onload = () => resolve(String(reader.result).split(',')[1]); reader.readAsDataURL(file); });
      this.rows.set((await this.api.preview(this.subjectId, file.name, base64)).rows);
      this.importId = crypto.randomUUID(); this.needsValidation.set(false);
    } catch (error) { this.error.set(error instanceof Error ? error.message : 'Unable to preview import.'); }
    finally { this.busy.set(false); }
  }
  async validate(): Promise<void> {
    if (this.busy()) return;
    this.busy.set(true); this.operation.set('Validating edited questions…'); this.error.set('');
    try { this.rows.set((await this.api.validate(this.subjectId, this.rows())).rows); this.needsValidation.set(false); }
    catch (error) { this.error.set(error instanceof Error ? error.message : 'Validation failed.'); }
    finally { this.busy.set(false); }
  }
  async commit(): Promise<void> {
    if (this.busy() || this.needsValidation() || this.invalidCount()) return;
    this.busy.set(true); this.operation.set('Importing questions…'); this.error.set('');
    try { const summary = await this.api.import(this.subjectId, this.rows(), this.importId); this.message.set(`Imported ${summary.added} questions. Skipped ${summary.skipped} duplicates.`); this.rows.set([]); }
    catch (error) { this.error.set(error instanceof Error ? error.message : 'Import failed. You can retry safely.'); }
    finally { this.busy.set(false); }
  }
  downloadTemplate(): void {
    const values = { question: 'What is 2 + 2?', questionType: 'mcq', optionA: '3', optionB: '4', optionC: '5', optionD: '6', correctAnswerId: 'B', topic: 'Arithmetic', difficulty: 'easy', className: 'JSS1', academicSession: '2026/2027' } as Record<string, string>;
    const csv = this.columns.map(column => column.key).join(',') + '\r\n' + this.columns.map(column => `"${(values[column.key] || '').replace(/"/g, '""')}"`).join(',') + '\r\n';
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement('a'); link.href = url; link.download = 'question-import-template.csv'; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
}
