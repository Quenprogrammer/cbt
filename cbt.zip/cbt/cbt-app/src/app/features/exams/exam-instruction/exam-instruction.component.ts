import { CommonModule } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { toSignal } from '@angular/core/rxjs-interop';
import { Student, StudentService } from '../../../services/student.service';
import { PaginationComponent } from '../../student/pagination/pagination.component';
import { HeaderComponent } from '../../../services/component/header/header.component';

@Component({
  selector: 'app-exam-instruction',
  standalone: true,
  imports: [CommonModule, FormsModule, PaginationComponent, HeaderComponent],
  templateUrl: './exam-instruction.component.html',
  styleUrl: './exam-instruction.component.scss',
})
export class ExamInstructionComponent {
  private studentService = inject(StudentService);

  readonly students = toSignal(this.studentService.students$, { initialValue: [] });
  readonly busyStudentId = signal('');
  readonly bulkBusy = signal(false);

  itemsPerPage = 10;
  currentPage = 1;
  searchTerm = '';

  filteredStudents(): Student[] {
    const term = this.searchTerm.trim().toLowerCase();
    if (!term) return this.students();

    return this.students().filter((student) =>
      [
        student.firstname,
        student.middlename,
        student.lastname,
        student.department,
        student.admissionNumber,
        student.email,
      ]
        .filter(Boolean)
        .some((value) => String(value).toLowerCase().includes(term))
    );
  }

  get paginatedItems(): Student[] {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    return this.filteredStudents().slice(startIndex, startIndex + this.itemsPerPage);
  }

  grantedCount(): number {
    return this.students().filter((student) => student.examStatus === 'Started').length;
  }

  completedCount(): number {
    return this.students().filter((student) => student.examStatus === 'Completed').length;
  }

  blockedCount(): number {
    return this.students().filter((student) =>
      student.examStatus !== 'Started' && student.examStatus !== 'Completed'
    ).length;
  }

  statusLabel(status: string): string {
    if (status === 'Started') return 'Access granted';
    if (status === 'Completed') return 'Completed';
    if (status === 'Ended') return 'Blocked';
    return 'Waiting';
  }

  statusClass(status: string): string {
    if (status === 'Started') return 'granted';
    if (status === 'Completed') return 'completed';
    if (status === 'Ended') return 'blocked';
    return 'waiting';
  }

  onPageChange(page: number): void {
    this.currentPage = page;
  }

  onSearch(): void {
    this.currentPage = 1;
  }

  async grantAll(): Promise<void> {
    if (this.bulkBusy()) return;
    if (!confirm('Grant exam access to all candidates?')) return;

    this.bulkBusy.set(true);
    try {
      await this.studentService.updateAllStudentsExamStatus('Started');
    } finally {
      this.bulkBusy.set(false);
    }
  }

  async blockAll(): Promise<void> {
    if (this.bulkBusy()) return;
    if (!confirm('Block new exam starts for all candidates?')) return;

    this.bulkBusy.set(true);
    try {
      await this.studentService.updateAllStudentsExamStatus('Ended');
    } finally {
      this.bulkBusy.set(false);
    }
  }

  async grantStudent(student: Student): Promise<void> {
    if (this.busyStudentId()) return;
    this.busyStudentId.set(student.id);

    try {
      await this.studentService.updateStudentExamStatus(student.id, 'Started');
    } finally {
      this.busyStudentId.set('');
    }
  }

  async blockStudent(student: Student): Promise<void> {
    if (this.busyStudentId()) return;
    this.busyStudentId.set(student.id);

    try {
      await this.studentService.updateStudentExamStatus(student.id, 'Ended');
    } finally {
      this.busyStudentId.set('');
    }
  }
}
