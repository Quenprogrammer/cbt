import { Component, Input, OnChanges, SimpleChanges, inject, Injector, runInInjectionContext } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Firestore, doc, getDoc } from '@angular/fire/firestore';
import { AssessmentApiService } from '../../../services/assessment-api.service';
import { TenantContextService } from '../../../services/tenant-context.service';
import { QuestionMetadataComponent } from '../../../shared/questions/question-metadata.component';
import { metadataForSave, questionMetadataControls } from '../../../shared/questions/question-metadata';
import { QuestionImageEditorComponent, questionImageUrlValidator } from '../../../shared/question-image/question-image-editor.component';
import { QuestionContentComponent } from '../../../shared/questions/question-content.component';
import { MathExpressionComponent } from '../../../shared/questions/math-expression.component';

@Component({ selector: 'app-question-editor', standalone: true, imports: [ReactiveFormsModule, QuestionMetadataComponent, QuestionImageEditorComponent, QuestionContentComponent, MathExpressionComponent], templateUrl: './question-editor.component.html' })
export class QuestionEditorComponent implements OnChanges {
  @Input({ required: true }) subjectId!: string;
  @Input() questionId: string | null = null;
  readonly tenant = inject(TenantContextService);
  private readonly db = inject(Firestore);
  private readonly injector = inject(Injector);
  private readonly api = inject(AssessmentApiService);
  private readonly fb = inject(FormBuilder);
  form: FormGroup = this.fb.group({ ...questionMetadataControls(), question: ['', Validators.required], questionType: ['mcq'], options: this.fb.array([]), correctAnswerId: [''], correctAnswerIds: [[]], acceptedAnswers: [''], matchingPairs: this.fb.array([]), rubric: [''], explanation: [''], passage: [''], formula: [''], tableText: [''], imageUrl: ['', questionImageUrlValidator], imageAlt: [''], audioUrl: ['', questionImageUrlValidator], videoUrl: ['', questionImageUrlValidator], practiceEnabled: [false], caseSensitive: [false] });
  currentId: string | null = null; version = 0; status = 'draft'; reviewComment = ''; busy = false; imageBusy = false; loading = false; error = ''; message = ''; versions: any[] = []; selectedVersion: any = null; showPreview = false;
  readonly types = [{ id: 'mcq', label: 'Multiple choice' }, { id: 'true_false', label: 'True / False' }, { id: 'multiple_answer', label: 'Multiple answers' }, { id: 'fill_blank', label: 'Fill in the blank' }, { id: 'matching', label: 'Matching' }, { id: 'essay', label: 'Essay (manual marking)' }];
  constructor() { for (let i = 0; i < 4; i++) this.addOption(); for (let i = 0; i < 2; i++) this.addPair(); }
  ngOnChanges(changes: SimpleChanges): void { if (changes['subjectId'] || changes['questionId']) { this.currentId = this.questionId; if (this.questionId) void this.load(); } }
  get options(): FormArray { return this.form.get('options') as FormArray; }
  get pairs(): FormArray { return this.form.get('matchingPairs') as FormArray; }
  choiceType(): boolean { return ['mcq', 'true_false', 'multiple_answer'].includes(this.form.value.questionType); }
  addOption(): void { if (this.options.length < 6) this.options.push(this.fb.group({ id: [String.fromCharCode(65 + this.options.length)], text: [''], imageUrl: ['', questionImageUrlValidator], imageAlt: [''] })); }
  removeOption(index: number): void { if (this.options.length <= 2) return; this.options.removeAt(index); this.options.controls.forEach((control, i) => control.get('id')?.setValue(String.fromCharCode(65 + i))); this.form.patchValue({ correctAnswerId: '', correctAnswerIds: [] }); }
  addPair(): void { if (this.pairs.length < 10) this.pairs.push(this.fb.group({ left: [''], right: [''] })); }
  typeChanged(): void { if (this.form.value.questionType === 'true_false') { this.options.clear(); this.addOption(); this.addOption(); this.options.at(0).patchValue({ text: 'True' }); this.options.at(1).patchValue({ text: 'False' }); this.form.patchValue({ correctAnswerId: 'A' }); } }
  toggleCorrect(id: string, checked: boolean): void { const values: string[] = this.form.value.correctAnswerIds || []; this.form.get('correctAnswerIds')?.setValue(checked ? [...new Set([...values, id])] : values.filter(value => value !== id)); }
  private async load(): Promise<void> {
    this.loading = true; this.error = '';
    try {
      const saved = await runInInjectionContext(this.injector, () => getDoc(doc(this.db, this.tenant.path(`subjects/${this.subjectId}/exams/${this.currentId}`)))); if (!saved.exists()) throw new Error('Question not found.');
      const data = saved.data(); this.version = Number(data['version'] || 0); this.status = data['publicationStatus'] || 'approved'; this.reviewComment = data['reviewComment'] || '';
      this.form.patchValue({ ...data, topic: data['topic'] || 'General', difficulty: data['difficulty'] || 'medium', questionType: data['questionType'] || 'mcq',correctAnswerIds:data['correctAnswerIds']||[], tags: (data['tags'] || []).join(', '), acceptedAnswers: (data['acceptedAnswers'] || []).join('\n'), tableText: (data['tableRows'] || []).map((row: any) => (Array.isArray(row)?row:row.cells).join('\t')).join('\n') });
      this.options.clear(); for (const option of data['options'] || []) { this.addOption(); this.options.at(this.options.length - 1).patchValue(option); }
      if (!this.options.length) for (let i = 0; i < 4; i++) this.addOption();
      this.pairs.clear(); for (const pair of data['matchingPairs'] || []) { this.addPair(); this.pairs.at(this.pairs.length - 1).patchValue(pair); } if (!this.pairs.length) { this.addPair(); this.addPair(); }
    } catch (error) { this.error = (error as Error).message; } finally { this.loading = false; }
  }
  payload(): any { const data = this.form.getRawValue(); return { ...data, ...metadataForSave(data), acceptedAnswers: data.acceptedAnswers.split('\n').map((value: string) => value.trim()).filter(Boolean), tableRows: data.tableText.trim() ? data.tableText.split('\n').slice(0, 20).map((row: string) => row.split(/\t|\|/).slice(0, 10).map(value => value.trim())) : [] }; }
  async save(action: string): Promise<void> {
    if (this.busy || this.imageBusy || this.loading) return; if (this.form.invalid) { this.form.markAllAsTouched(); this.error = 'Complete the required fields and correct invalid media URLs.'; return; }
    this.busy = true; this.error = ''; this.message = '';
    try { const result = await this.api.call('question_lifecycle', 'saveQuestion', { subjectId: this.subjectId, questionId: this.currentId || '', expectedVersion: this.version, action, question: this.payload() }); this.currentId = result.questionId; this.version = result.version; this.status = action === 'approve' ? 'approved' : action === 'submit' ? 'in_review' : 'draft'; this.message = `Version ${this.version} saved (${this.status.replace('_', ' ')}).`; this.versions = []; }
    catch (error) { this.error = (error as Error).message; } finally { this.busy = false; }
  }
  async uploadMedia(event: Event, field: 'audioUrl' | 'videoUrl'): Promise<void> { const input = event.target as HTMLInputElement, file = input.files?.[0]; input.value = ''; if (!file) return; this.imageBusy = true; this.error = ''; try { this.form.get(field)?.setValue(await this.api.upload(file)); } catch (error) { this.error = (error as Error).message; } finally { this.imageBusy = false; } }
  async history(): Promise<void> { if (!this.currentId) return; this.error = ''; try { this.versions = (await this.api.call('question_lifecycle', 'history', { subjectId: this.subjectId, questionId: this.currentId })).versions; } catch (error) { this.error = (error as Error).message; } }
  async restore(version: number): Promise<void> { if (this.busy) return; this.busy = true; this.error = ''; try { await this.api.call('question_lifecycle', 'restoreVersion', { subjectId: this.subjectId, questionId: this.currentId, version, expectedVersion: this.version }); await this.load(); this.message = 'Version restored as a new draft. Review it before publishing.'; this.selectedVersion = null; } catch (error) { this.error = (error as Error).message; } finally { this.busy = false; } }
}
