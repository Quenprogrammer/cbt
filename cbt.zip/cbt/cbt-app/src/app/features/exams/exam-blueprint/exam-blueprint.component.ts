import { Component, Input, OnChanges, SimpleChanges, inject, Injector, runInInjectionContext } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Firestore, doc, getDoc } from '@angular/fire/firestore';
import { TenantContextService } from '../../../services/tenant-context.service';
import { BlueprintRow, QuestionBankService } from '../../../services/question-bank.service';
import { Question } from '../../../services/view-exams.service';

@Component({
  selector: 'app-exam-blueprint', standalone: true, imports: [FormsModule],
  template: `
    <section class="card mb-4"><div class="card-body">
      <h2 class="h5">Exam blueprint</h2>
      <p class="text-muted">Choose the number of questions from each topic and difficulty. Questions and options remain randomized for each candidate. Existing sessions keep their assigned questions.</p>
      @if (loading) { <p role="status">Loading blueprint…</p> }
      <fieldset [disabled]="loading || saving">
        <div class="d-flex flex-wrap gap-3 align-items-end mb-3">
          <div><label for="blueprint-limit" class="form-label">Questions per candidate</label><input id="blueprint-limit" class="form-control" type="number" min="1" max="500" [(ngModel)]="questionLimit"></div>
          <label class="form-check-label mb-2"><input class="form-check-input me-2" type="checkbox" [(ngModel)]="enabled">Use topic and difficulty quotas</label>
        </div>
        @if (enabled) {
          @for (row of rows; track $index; let i = $index) {
            <div class="row g-2 mb-2 align-items-end">
              <div class="col-md-4"><label class="form-label" [for]="'blueprint-topic-' + i">Topic</label><select class="form-select" [(ngModel)]="row.topic" [id]="'blueprint-topic-' + i">@for (topic of topics(); track topic) { <option [value]="topic">{{ topic }}</option> }</select></div>
              <div class="col-md-3"><label class="form-label" [for]="'blueprint-level-' + i">Difficulty</label><select class="form-select" [(ngModel)]="row.difficulty" [id]="'blueprint-level-' + i"><option value="any">Any difficulty</option><option value="easy">Easy</option><option value="medium">Medium</option><option value="hard">Hard</option></select></div>
              <div class="col-md-2"><label class="form-label" [for]="'blueprint-count-' + i">Count ({{ available(row) }} available)</label><input class="form-control" type="number" min="1" max="500" [(ngModel)]="row.count" [id]="'blueprint-count-' + i" [class.is-invalid]="row.count > available(row)"></div>
              <div class="col-md-3"><button type="button" class="btn btn-outline-danger" (click)="rows.splice(i, 1)">Remove row</button></div>
            </div>
          }
          <button type="button" class="btn btn-outline-primary mt-2" (click)="addRow()" [disabled]="rows.length >= 50">Add quota</button>
          <p class="mt-3" [class.text-danger]="total() !== questionLimit">{{ total() }} of {{ questionLimit }} questions allocated.</p>
        }
        <button type="button" class="btn btn-primary mt-2" (click)="save()" [disabled]="loading || saving || (enabled && total() !== questionLimit)">{{ saving ? 'Saving…' : 'Save blueprint' }}</button>
      </fieldset>
      @if (error) { <p class="text-danger mt-3" role="alert">{{ error }}</p> }
      @if (message) { <p class="text-success mt-3" role="status">{{ message }}</p> }
      <p class="form-text mt-2">Questions without organization fields belong to General / Medium.</p>
    </div></section>
  `,
})
export class ExamBlueprintComponent implements OnChanges {
  @Input({ required: true }) subjectId!: string;
  @Input() questions: Question[] = [];
  private readonly db = inject(Firestore);
  private readonly tenant = inject(TenantContextService);
  private readonly api = inject(QuestionBankService);
  private readonly injector = inject(Injector);
  questionLimit = 20;
  enabled = false;
  rows: BlueprintRow[] = [];
  loading = true;
  saving = false;
  error = '';
  message = '';
  ngOnChanges(changes: SimpleChanges): void { if (changes['subjectId']) void this.load(); }
  private async load(): Promise<void> {
    this.loading = true; this.error = '';
    try {
      const subject = await runInInjectionContext(this.injector, () => getDoc(doc(this.db, this.tenant.path(`subjects/${this.subjectId}`))));
      const data = subject.data();
      this.questionLimit = Number(data?.['questionLimit']) || this.questions.length || 20;
      this.enabled = Boolean(data?.['blueprint']?.enabled);
      this.rows = (data?.['blueprint']?.rows ?? []).map((row: BlueprintRow) => ({ ...row }));
    } catch (error) { this.error = error instanceof Error ? error.message : 'Unable to load blueprint.'; }
    finally { this.loading = false; }
  }
  topics(): string[] { return [...new Set([...this.questions.map(q => q.topic?.trim() || 'General'), ...this.rows.map(row => row.topic)])].sort(); }
  available(row: BlueprintRow): number { return this.questions.filter(q => (q.topic?.trim() || 'General').toLowerCase() === row.topic.toLowerCase() && (row.difficulty === 'any' || (q.difficulty || 'medium') === row.difficulty)).length; }
  total(): number { return this.rows.reduce((sum, row) => sum + Number(row.count || 0), 0); }
  addRow(): void { this.rows.push({ topic: this.topics()[0] || 'General', difficulty: 'any', count: 1 }); }
  async save(): Promise<void> {
    if (this.saving || this.loading) return;
    this.saving = true; this.error = ''; this.message = '';
    try { await this.api.saveBlueprint(this.subjectId, this.questionLimit, this.enabled, this.rows); this.message = 'Blueprint saved. It will apply to new examination sessions.'; }
    catch (error) { this.error = error instanceof Error ? error.message : 'Unable to save blueprint.'; }
    finally { this.saving = false; }
  }
}
