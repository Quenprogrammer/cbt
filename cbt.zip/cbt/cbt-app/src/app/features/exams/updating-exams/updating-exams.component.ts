import { Component, inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { QuestionEditorComponent } from '../question-editor/question-editor.component';
@Component({ selector:'app-updating-exams',standalone:true,imports:[QuestionEditorComponent],templateUrl:'./updating-exams.component.html',styleUrl:'./updating-exams.component.scss' })
export class UpdatingExamsComponent { private route = inject(ActivatedRoute); subjectId = this.route.snapshot.paramMap.get('subjectId') || ''; questionId = this.route.snapshot.paramMap.get('examsId') || ''; }
