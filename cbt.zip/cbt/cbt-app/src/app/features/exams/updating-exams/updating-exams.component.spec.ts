import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatingExamsComponent } from './updating-exams.component';

describe('UpdatingExamsComponent', () => {
  let component: UpdatingExamsComponent;
  let fixture: ComponentFixture<UpdatingExamsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UpdatingExamsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdatingExamsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
