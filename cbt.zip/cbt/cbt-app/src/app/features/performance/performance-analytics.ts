export interface PerformanceFilters { from: string; to: string; className: string; subjectId: string; candidate: string; }
interface Breakdown { key: string; name: string; subject: string; attempts: number; correct: number; total: number; seconds: number; percentage: number; }
interface CandidateProgress { id: string; name: string; admission: string; className: string; attempts: number; latest: number; previous: number | null; change: number | null; lastDate: string; }

export function buildPerformance(results: any[], filters: PerformanceFilters) {
  const from = filters.from ? new Date(filters.from + 'T00:00:00').getTime() : -Infinity;
  const to = filters.to ? new Date(filters.to + 'T23:59:59.999').getTime() : Infinity;
  const candidates = new Map<string, CandidateProgress>();
  const subjects = new Map<string, Breakdown>(), topics = new Map<string, Breakdown>(), classes = new Map<string, Breakdown>(), questions = new Map<string, Breakdown>();
  const selected = results.filter(result => {
    if (result.pendingManual || result.status === 'Awaiting marking') return false;
    const date = Date.parse(result.submittedAtIso || ''), details = result.studentDetails || {};
    const className = result.className || details.department || 'Unassigned';
    const candidate = [details.firstname, details.lastname, details.admissionNumber, result.studentEmail].filter(Boolean).join(' ').toLowerCase();
    return (!filters.from && !filters.to || Number.isFinite(date) && date >= from && date <= to) &&
      (!filters.className || className === filters.className) && (!filters.candidate || candidate.includes(filters.candidate.toLowerCase().trim())) &&
      (!filters.subjectId || (result.subjectResults || []).some((subject: any) => subject.subjectId === filters.subjectId));
  }).sort((a, b) => Date.parse(a.submittedAtIso || '') - Date.parse(b.submittedAtIso || ''));
  let totalCorrect = 0, totalQuestions = 0, passed = 0, unanswered = 0, analyzed = 0;
  const add = (map: Map<string, Breakdown>, key: string, name: string, subject: string, correct: number, total: number, seconds = 0) => {
    const row = map.get(key) || { key, name, subject, attempts: 0, correct: 0, total: 0, seconds: 0, percentage: 0 };
    row.attempts++; row.correct += correct; row.total += total; row.seconds += seconds; row.percentage = row.total ? Math.round(row.correct / row.total * 100) : 0;
    map.set(key, row);
  };
  for (const result of selected) {
    const rows = (result.subjectResults || []).filter((subject: any) => !filters.subjectId || subject.subjectId === filters.subjectId);
    const correct = rows.length ? rows.reduce((sum: number, row: any) => sum + Number(row.score || 0), 0) : Number(result.score || 0);
    const total = rows.length ? rows.reduce((sum: number, row: any) => sum + Number(row.totalQuestions || 0), 0) : Number(result.totalQuestions || 0);
    const percentage = total ? Math.round(correct / total * 100) : 0;
    totalCorrect += correct; totalQuestions += total; if (percentage >= 50) passed++;
    unanswered += rows.length ? rows.reduce((sum: number, row: any) => sum + Number(row.unanswered || 0), 0) : Number(result.unanswered || 0);
    const details = result.studentDetails || {}, className = result.className || details.department || 'Unassigned';
    add(classes, className, className, '', correct, total);
    for (const row of rows) add(subjects, row.subjectId, row.subjectName || 'Subject', '', Number(row.score || 0), Number(row.totalQuestions || 0));
    const id = String(result.studentId || result.studentEmail || result.id);
    const previous = candidates.get(id);
    candidates.set(id, { id, name: [details.firstname, details.lastname].filter(Boolean).join(' ') || result.studentEmail || 'Candidate', admission: details.admissionNumber || '', className, attempts: (previous?.attempts || 0) + 1, latest: percentage, previous: previous?.latest ?? null, change: previous ? percentage - previous.latest : null, lastDate: result.submittedAtIso || '' });
    for (const question of result.questionAnalysis || []) {
      if (filters.subjectId && question.subjectId !== filters.subjectId) continue;
      analyzed++;
      const topic = question.topic || 'Unclassified (older attempt)', subject = question.subjectName || 'Subject';
      add(topics, `${question.subjectId}:${topic}`, topic, subject, question.isCorrect ? 1 : 0, 1, Number(question.timeSpentSeconds || 0));
      add(questions, `${question.subjectId}:${question.questionId}`, question.question || `Question ${question.questionId}`, subject, question.isCorrect ? 1 : 0, 1, Number(question.timeSpentSeconds || 0));
    }
  }
  return {
    attempts: selected.length, candidates: candidates.size,
    accuracy: totalQuestions ? Math.round(totalCorrect / totalQuestions * 100) : 0,
    passRate: selected.length ? Math.round(passed / selected.length * 100) : 0,
    unanswered, analyzed,
    subjects: [...subjects.values()].sort((a, b) => a.name.localeCompare(b.name)),
    classes: [...classes.values()].sort((a, b) => a.name.localeCompare(b.name)),
    topics: [...topics.values()].sort((a, b) => a.percentage - b.percentage),
    questions: [...questions.values()].filter(row => row.correct < row.total).sort((a, b) => a.percentage - b.percentage || b.total - a.total).slice(0, 20),
    students: [...candidates.values()].sort((a, b) => a.name.localeCompare(b.name)),
  };
}
