import { buildPerformance, PerformanceFilters } from './performance-analytics';

describe('Performance analytics', () => {
  const filters: PerformanceFilters = { from: '', to: '', className: '', subjectId: '', candidate: '' };
  const results = [
    { id: 'r1', studentId: 'one', studentDetails: { firstname: 'Ada', department: 'SS2', admissionNumber: 'A01' }, submittedAtIso: '2026-10-01T12:00:00Z', subjectResults: [{ subjectId: 'math', subjectName: 'Math', score: 1, totalQuestions: 2, unanswered: 1 }], questionAnalysis: [{ subjectId: 'math', subjectName: 'Math', questionId: 'q1', topic: 'Algebra', isCorrect: false, timeSpentSeconds: 10 }] },
    { id: 'r2', studentId: 'one', studentDetails: { firstname: 'Ada', department: 'SS2', admissionNumber: 'A01' }, submittedAtIso: '2026-10-02T12:00:00Z', subjectResults: [{ subjectId: 'math', subjectName: 'Math', score: 8, totalQuestions: 8, unanswered: 0 }], questionAnalysis: [{ subjectId: 'math', subjectName: 'Math', questionId: 'q1', topic: 'Algebra', isCorrect: true, timeSpentSeconds: 20 }] },
    { id: 'r3', studentId: 'two', studentDetails: { firstname: 'Bola', department: 'SS1' }, submittedAtIso: '2026-09-20T12:00:00Z', subjectResults: [{ subjectId: 'english', subjectName: 'English', score: 0, totalQuestions: 5, unanswered: 2 }] },
  ];
  it('weights accuracy by questions and reports chronological candidate progress', () => {
    const report = buildPerformance([results[1], results[0]], filters);
    expect(report.accuracy).toBe(90);
    expect(report.passRate).toBe(100);
    expect(report.students[0].previous).toBe(50);
    expect(report.students[0].latest).toBe(100);
    expect(report.students[0].change).toBe(50);
    expect(report.unanswered).toBe(1);
  });
  it('combines date, subject, class and candidate filters', () => {
    const report = buildPerformance(results, { ...filters, from: '2026-10-01', to: '2026-10-02', subjectId: 'math', className: 'SS2', candidate: 'a01' });
    expect(report.attempts).toBe(2);
    expect(report.candidates).toBe(1);
    expect(report.subjects.map(row => row.name)).toEqual(['Math']);
  });
  it('aggregates topic and question accuracy with response times', () => {
    const report = buildPerformance(results, filters);
    expect(report.topics[0].percentage).toBe(50);
    expect(report.topics[0].seconds / report.topics[0].total).toBe(15);
    expect(report.questions[0].total).toBe(2);
  });
  it('handles empty and older results without inventing topic data', () => {
    expect(buildPerformance([], filters).accuracy).toBe(0);
    const report = buildPerformance([{ id: 'old', studentId: 'old', score: 1, totalQuestions: 4, percentage: 25 }], filters);
    expect(report.accuracy).toBe(25);
    expect(report.topics.length).toBe(0);
  });
  it('excludes provisional results while essay marking is incomplete',()=>{
    const report=buildPerformance([...results,{...results[0],id:'pending',pendingManual:1,status:'Awaiting marking'}],filters);
    expect(report.attempts).toBe(3);
  });
});
