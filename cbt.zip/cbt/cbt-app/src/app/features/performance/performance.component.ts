import { CommonModule } from '@angular/common';
import { Component, computed, inject, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { catchError, of, tap } from 'rxjs';
import { ExamAttemptService } from '../../services/exam-attempt.service';
import { buildPerformance, PerformanceFilters } from './performance-analytics';

@Component({
  selector: 'app-performance', standalone: true, imports: [CommonModule, FormsModule],
  templateUrl: './performance.component.html',
  styles: [`table { min-width: 650px; } .metric { font-size: 2rem; font-weight: 700; } .accuracy-bar { height: .5rem; background: #e8edf4; border-radius: 8px; overflow: hidden; } .accuracy-bar span { display: block; height: 100%; background: #2455a4; }`],
})
export class PerformanceComponent {
  private readonly api = inject(ExamAttemptService);
  readonly error = signal('');
  readonly loading = signal(true);
  readonly results = toSignal(this.api.allResults().pipe(tap(() => this.loading.set(false)), catchError(() => { this.loading.set(false); this.error.set('Unable to load results. Check your connection and tenant access.'); return of([]); })), { initialValue: [] as any[] });
  readonly filters = signal<PerformanceFilters>({ from: '', to: '', className: '', subjectId: '', candidate: '' });
  readonly report = computed(() => buildPerformance(this.results(), this.filters()));
  readonly classes = computed(() => [...new Set<string>(this.results().map(result => result.className || result.studentDetails?.department || 'Unassigned'))].sort());
  readonly subjects = computed(() => [...new Map<string, string>(this.results().flatMap(result => (result.subjectResults || []).map((subject: any) => [String(subject.subjectId), String(subject.subjectName)] as [string, string]))).entries()].map(([id, name]) => ({ id, name })).sort((a, b) => a.name.localeCompare(b.name)));
  setFilter(key: keyof PerformanceFilters, value: string): void { this.filters.update(current => ({ ...current, [key]: value })); }
}
