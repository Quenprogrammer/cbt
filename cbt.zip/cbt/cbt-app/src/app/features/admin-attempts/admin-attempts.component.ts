import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { ExamAttemptService } from '../../services/exam-attempt.service';
import { HeaderComponent } from '../../services/component/header/header.component';
@Component({selector:'app-admin-attempts',standalone:true,imports:[CommonModule,HeaderComponent],templateUrl:'./admin-attempts.component.html'})
export class AdminAttemptsComponent{
  private s=inject(ExamAttemptService);
  attempts=toSignal(this.s.allAssignments(),{initialValue:[] as any[]});
  inProgressCount():number{return this.attempts().filter((attempt:any)=>attempt.status==='in-progress').length;}
  submittedCount():number{return this.attempts().filter((attempt:any)=>attempt.status==='submitted').length;}
}
