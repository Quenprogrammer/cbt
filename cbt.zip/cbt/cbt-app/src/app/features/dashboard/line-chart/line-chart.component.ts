import { Component, OnInit, OnDestroy } from '@angular/core';
import { Chart, registerables } from 'chart.js';
import 'chart.js/auto';
import {StudentService} from '../../../services/student.service';

@Component({
  selector: 'app-line-chart',
  standalone: true,
  template: `
    <div class="chart-container">
      <canvas id="multiAxisLineChart"></canvas>
    </div>
  `,
  styles: [`
    .chart-container {
      width: 100%;
      height: 400px;
      position: relative;
    }
  `],
})
export class LineChartComponent implements OnInit, OnDestroy {
  public chart: any;

  constructor(private studentService: StudentService) {}

  ngOnInit(): void {
    Chart.register(...registerables); // Register Chart.js controllers
    this.fetchDataAndCreateChart();
  }

  fetchDataAndCreateChart(): void {
    // Fetch data for average scores and students attempted
    this.studentService.getStudentScoresOverTime().subscribe({
      next: (scores) => {
        this.studentService.getStudentsAttemptedOverTime().subscribe({
          next: (studentsAttempted) => {
            this.createMultiAxisLineChart(scores, studentsAttempted);
          },
          error: (error) => {
            console.error('Error fetching students attempted data:', error);
          },
        });
      },
      error: (error) => {
        console.error('Error fetching student scores data:', error);
      },
    });
  }

  createMultiAxisLineChart(scores: number[], studentsAttempted: number[]): void {
    const ctx = document.getElementById('multiAxisLineChart') as HTMLCanvasElement;
    if (!ctx) {
      console.error('Canvas element not found!');
      return;
    }

    // Destroy existing chart if it exists
    if (this.chart) {
      this.chart.destroy();
    }

    this.chart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'], // Replace with dynamic labels if needed
        datasets: [
          {
            label: 'Average Score (%)',
            data: scores, // Dynamic data for average scores
            borderColor: '#448c74',
            backgroundColor: 'rgba(68, 140, 116, 0.2)',
            borderWidth: 2,
            fill: true,
            yAxisID: 'y',
          },
          {
            label: 'Students Attempted',
            data: studentsAttempted, // Dynamic data for students attempted
            borderColor: '#edcb50',
            backgroundColor: 'rgba(237, 203, 80, 0.2)',
            borderWidth: 2,
            fill: true,
            yAxisID: 'y1',
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
          mode: 'index',
          intersect: false,
        },
        plugins: {
          legend: {
            position: 'bottom',
          },
        },
        scales: {
          y: {
            type: 'linear',
            display: true,
            position: 'left',
            title: {
              display: true,
              text: 'Average Score (%)',
            },
            min: 0, // Adjust based on your data
            max: 100,
          },
          y1: {
            type: 'linear',
            display: true,
            position: 'right',
            title: {
              display: true,
              text: 'Students Attempted',
            },
            grid: {
              drawOnChartArea: false,
            },
          },
        },
      },
    });
  }

  ngOnDestroy(): void {
    // Destroy the chart when the component is destroyed to avoid memory leaks
    if (this.chart) {
      this.chart.destroy();
    }
  }
}
