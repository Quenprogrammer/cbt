import {Component, OnInit} from '@angular/core';
import {Chart, registerables} from 'chart.js';

@Component({
  selector: 'app-bar-chart',
  standalone: true,
  imports: [],
  template: ` <div class="chart-container">
    <canvas id="lineChart"></canvas>
  </div>`,

  styles:  [`
    .chart-container {
      width: 100%;
      height: 400px;
      position: relative;
    }
  `]
})
export class BarChartComponent implements OnInit {
  public chart: any;

  ngOnInit(): void {
    Chart.register(...registerables); // Register controllers
    this.createLineChart();
  }

  createLineChart() {
    const ctx = document.getElementById('lineChart') as HTMLCanvasElement;
    if (!ctx) {
      console.error('Canvas element not found!');
      return;
    }

    this.chart = new Chart(ctx, {
      type: 'line', // Line chart
      data: {
        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'November', 'December'],
        datasets: [
          {
            label: 'Students performances',
            data: [10, 35, 65, 40, 56, 55, 80,85, 90, 38, 56, 75 ],
            borderColor: '#4156eb',
            backgroundColor: 'rgba(68, 140, 116, 0.2)',
            borderWidth: 2,
            fill: true,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
          },
        },
        scales: {
          y: {
            beginAtZero: true,
          },
        },
      },
    });
  }
}
