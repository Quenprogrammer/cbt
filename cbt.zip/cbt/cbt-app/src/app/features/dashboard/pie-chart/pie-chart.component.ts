import { AfterViewInit, Component, ElementRef, OnDestroy, ViewChild } from '@angular/core';
import { Chart, registerables } from 'chart.js';
import { Subscription } from 'rxjs';
import { StudentService } from '../../../services/student.service';

Chart.register(...registerables);

@Component({
  selector: 'app-pie-chart',
  standalone: true,
  imports: [],
  template: `
    <div class="chart-container">
      <canvas #departmentCanvas aria-label="Students by department"></canvas>
    </div>
  `,
  styles: [`
    .chart-container {
      width: 100%;
      height: 400px;
      position: relative;
    }
  `],
})
export class PieChartComponent implements AfterViewInit, OnDestroy {
  @ViewChild('departmentCanvas') private canvasRef?: ElementRef<HTMLCanvasElement>;

  private chart?: Chart;
  private dataSubscription?: Subscription;

  constructor(private readonly studentService: StudentService) {}

  ngAfterViewInit(): void {
    this.dataSubscription = this.studentService.getStudentsByDepartment().subscribe({
      next: (departmentCounts) => {
        this.createChart(Object.keys(departmentCounts), Object.values(departmentCounts));
      },
      error: (error) => console.error('Error fetching department data:', error),
    });
  }

  private createChart(labels: string[], data: number[]): void {
    const canvas = this.canvasRef?.nativeElement;
    if (!canvas) return;

    this.chart?.destroy();
    this.chart = new Chart(canvas, {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: 'Students',
          data,
          backgroundColor: '#4156eb',
          borderColor: '#4156eb',
          borderWidth: 1,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { position: 'bottom' } },
        scales: { y: { beginAtZero: true } },
      },
    });
  }

  ngOnDestroy(): void {
    this.dataSubscription?.unsubscribe();
    this.chart?.destroy();
  }
}
