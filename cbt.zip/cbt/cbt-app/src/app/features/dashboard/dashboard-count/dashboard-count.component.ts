import { Component, OnDestroy, OnInit, inject } from '@angular/core';
import { Subscription } from 'rxjs';
import { StudentService } from '../../../services/student.service';
import { StaffService } from '../../../services/staff.service';
import { ExamsListService } from '../../../services/exams-list.service';
import { ExamAttemptService } from '../../../services/exam-attempt.service';

@Component({
  selector: 'app-dashboard-count',
  standalone: true,
  imports: [],
  templateUrl: './dashboard-count.component.html',
  styleUrl: './dashboard-count.component.scss',
})
export class DashboardCountComponent implements OnInit, OnDestroy {
  private readonly students = inject(StudentService);
  private readonly staff = inject(StaffService);
  private readonly exams = inject(ExamsListService);
  private readonly attempts = inject(ExamAttemptService);
  private readonly subscriptions = new Subscription();

  studentCount = 0;
  staffCount = 0;
  subjectCount = 0;
  activeAttempts = 0;
  submittedAttempts = 0;
  resultCount = 0;
  passRate = 0;

  ngOnInit(): void {
    this.subscriptions.add(
      this.students.getStudentCount().subscribe((value) => (this.studentCount = value))
    );
    this.subscriptions.add(
      this.staff.getStaffCount().subscribe((value) => (this.staffCount = value))
    );
    this.subscriptions.add(
      this.exams.examlist$.subscribe((rows) => (this.subjectCount = rows.length))
    );
    this.subscriptions.add(
      this.attempts.allAssignments().subscribe((rows) => {
        this.activeAttempts = rows.filter((row) => row?.status === 'in-progress').length;
        this.submittedAttempts = rows.filter((row) => row?.status === 'submitted').length;
      })
    );
    this.subscriptions.add(
      this.attempts.allResults().subscribe((rows) => {
        this.resultCount = rows.length;
        this.passRate = rows.length
          ? Math.round((rows.filter((row) => row?.status === 'Pass').length / rows.length) * 100)
          : 0;
      })
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }
}
