import { Component, OnInit } from '@angular/core';
import { Chart, registerables } from 'chart.js';

// Register Chart.js components
Chart.register(...registerables);

@Component({
  selector: 'app-chart',
  standalone: true,
  template: `
    <div class="card-header card-header-content-sm-between mb-lg-4 mb-xl-4 ">
      <h4 class="card-header-title mb-2 mb-sm-0">Student Performance Over Time</h4>

      <!-- Nav -->
      <ul class="nav nav-segment" id="expensesTabEg1" role="tablist">
        <li class="nav-item">
          <a class="nav-link active" href="javascript:;" (click)="updateChart('thisWeek')">This week</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="javascript:;" (click)="updateChart('lastWeek')">Last week</a>
        </li>
      </ul>
      <!-- End Nav -->
    </div>
    <!-- Bar Chart -->
    <div class="chartjs-custom mb-5 py-5">
      <canvas id="updatingBarChart" style="height: 20rem;"></canvas>
    </div>
    <!-- End Bar Chart -->
  `,
  styles: [``]
})
export class ChartComponent implements OnInit {
  private barChart: Chart<'bar'> | undefined;

  ngOnInit(): void {
    this.initializeChart();
  }

  initializeChart(): void {
    const ctx = document.getElementById('updatingBarChart') as HTMLCanvasElement;

    // @ts-ignore
    // @ts-ignore
    // @ts-ignore
    // @ts-ignore
    this.barChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ["January ", "February ", "march ", "April ", "May ", "June", "July ", "August ", "September", "October", "November", "December"],
        datasets: [
          {
            label: 'Students ',
            data: [200, 300, 290, 350, 150, 350, 300, 100, 125, 220],
            backgroundColor: '#3ea74e',
            hoverBackgroundColor: '#3ea74e',
            borderColor: '#3ea74e',
            maxBarThickness: 10
          },
          {
            label: 'performance ',
            data: [150, 230, 382, 204, 169, 290, 300, 100, 300, 225, 120],
            backgroundColor: '#dee0e7',
            borderColor: '#dee0e7',
            maxBarThickness: 10
          }
        ]
      },
      options: {
        scales: {
          y: {
            grid: {
              color: '#dee0e7',
            },
            ticks: {
             // beginAtZero: true,
              stepSize: 100,
              font: {
                size: 12,
                family: 'Open Sans, sans-serif'
              },
              color: '#97a4af',
              padding: 10,
              callback: (value) => `${value}`
            }
          },
          x: {
            grid: {
              display: false,
            },
            ticks: {
              font: {
                size: 12,
                family: 'Open Sans, sans-serif'
              },
              color: '#97a4af',
              padding: 5
            },
          }
        },
        plugins: {
          tooltip: {
            callbacks: {
              label: (context) => `$${context.raw}`
            }
          }
        },
        hover: {
          mode: 'nearest',
          intersect: true
        }
      }
    });
  }

  updateChart(datasetKey: 'thisWeek' | 'lastWeek'): void {
    if (!this.barChart) return;

    if (datasetKey === 'lastWeek') {
      this.barChart.data.labels = ["January ", "February ", "march ", "April ", "May ", "June", "July ", "August ", "September", "October", "November", "December"];
      this.barChart.data.datasets[0].data = [120, 250, 300, 200, 300, 290, 350, 100, 125, 320,200, 300, ];
      this.barChart.data.datasets[1].data = [250, 130, 322, 144, 129, 300, 260, 120, 260, 245, 110,200,];
    } else {
      this.barChart.data.labels = ["January ", "February ", "march ", "April ", "May ", "June", "July ", "August ", "September", "October", "November", "December"];
      this.barChart.data.datasets[0].data = [200, 300, 290, 350, 150, 350, 300, 100, 125, 220,200, 300,];
      this.barChart.data.datasets[1].data = [150, 230, 382, 204, 169, 290, 300, 100, 300, 225, 300,150,];
    }

    this.barChart.update();
  }
}
