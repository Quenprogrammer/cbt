import { CommonModule } from '@angular/common';
import { Component, computed, inject } from '@angular/core';
import { Auth, user } from '@angular/fire/auth';
import { toSignal } from '@angular/core/rxjs-interop';
import { RouterLink } from '@angular/router';
import { StudentService } from '../../services/student.service';
import { ExamAttemptService } from '../../services/exam-attempt.service';
import { GenderChartComponent } from './gender-chart/gender-chart.component';
import { PieChartComponent } from './pie-chart/pie-chart.component';
import { DashboardCountComponent } from './dashboard-count/dashboard-count.component';
import { HeaderComponent } from '../../services/component/header/header.component';
import {ExamsListService} from '../../services/exams-list.service';
import { SetupChecklistComponent } from '../onboarding/setup-checklist.component';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    GenderChartComponent,
    PieChartComponent,
    DashboardCountComponent,
    HeaderComponent,
    SetupChecklistComponent,
  ],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss',
})
export class DashboardComponent {
  private auth = inject(Auth);
  private studentsService = inject(StudentService);
  private examService = inject(ExamAttemptService);

  readonly currentUser = toSignal(user(this.auth), { initialValue: null });
  readonly students = toSignal(this.studentsService.students$, { initialValue: [] });
  readonly assignments = toSignal(this.examService.allAssignments(), { initialValue: [] as any[] });
  readonly results = toSignal(this.examService.allResults(), { initialValue: [] as any[] });
  readonly logs = toSignal(this.examService.activityLogs(), { initialValue: [] as any[] });

  grantedCount(): number {
    return this.students().filter((student) => student.examStatus === 'Started').length;
  }

  waitingCount(): number {
    return this.students().filter((student) =>
      student.examStatus !== 'Started' && student.examStatus !== 'Completed'
    ).length;
  }

  activeAttemptCount(): number {
    return this.assignments().filter((attempt) => attempt.status === 'in-progress').length;
  }

  completedTodayCount(): number {
    const today = new Date().toISOString().slice(0, 10);
    return this.results().filter((result) =>
      String(result.submittedAtIso ?? '').startsWith(today)
    ).length;
  }

  passRate(): number {
    const results = this.results();
    if (!results.length) return 0;
    return Math.round(
      (results.filter((result) => result.status === 'Pass').length / results.length) * 100
    );
  }

  recentActivity(): any[] {
    return [...this.logs()]
      .sort((a, b) => this.timestampMs(b.createdAt) - this.timestampMs(a.createdAt))
      .slice(0, 6);
  }

  activityLabel(action: string): string {
    const labels: Record<string, string> = {
      exam_started: 'Exam started',
      exam_submitted: 'Exam submitted',
      student_created: 'Student added',
      staff_created: 'Staff added',
      subject_created: 'Subject created',
      question_created: 'Question added',
      candidate_import: 'Candidates imported',
    };
    return labels[action] || action?.replaceAll('_', ' ') || 'System activity';
  }

  activityInitial(log: any): string {
    const value = String(log.actorEmail || log.action || 'A');
    return value.charAt(0).toUpperCase();
  }

  activityDate(log: any): Date | null {
    const ms = this.timestampMs(log?.createdAt);
    return ms ? new Date(ms) : null;
  }

  private timestampMs(value: any): number {
    if (!value) return 0;
    if (typeof value?.toMillis === 'function') return value.toMillis();
    if (typeof value?.seconds === 'number') return value.seconds * 1000;
    const parsed = new Date(value).getTime();
    return Number.isFinite(parsed) ? parsed : 0;
  }
  private readonly examsService = inject(ExamsListService);


  private readonly allSubjects = toSignal(this.examsService.examlist$, { initialValue: [] });
  readonly subjects = computed(() => this.allSubjects().filter(subject => subject.active !== false));
  readonly loading = toSignal(this.examsService.isLoading$, { initialValue: true });
// Add to your component
  onCardMove(e: MouseEvent) {
    const el = e.currentTarget as HTMLElement;
    const rect = el.getBoundingClientRect();
    el.style.setProperty('--mx', `${e.clientX - rect.left}px`);
    el.style.setProperty('--my', `${e.clientY - rect.top}px`);
  }
}
