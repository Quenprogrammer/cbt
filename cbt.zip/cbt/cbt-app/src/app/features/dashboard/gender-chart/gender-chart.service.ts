import { Injectable } from '@angular/core';

import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import {StudentService} from '../../../services/student.service';

@Injectable({
  providedIn: 'root',
})
export class GenderChartService {
  private metricsSubject = new BehaviorSubject<{ males: number; females: number }>({ males: 0, females: 0 });
  metrics$ = this.metricsSubject.asObservable();

  private isLoadingSubject = new BehaviorSubject<boolean>(true);
  isLoading$ = this.isLoadingSubject.asObservable();

  constructor(private studentService: StudentService) {
    this.fetchGenderData();
  }

  fetchGenderData(): void {
    this.studentService.getStudentsByGender().subscribe({
      next: (genderCounts) => {
        this.metricsSubject.next(genderCounts);
        this.isLoadingSubject.next(false);
      },
      error: (error) => {
        console.error('Error fetching gender data:', error);
        this.isLoadingSubject.next(false);
      },
    });
  }
}
