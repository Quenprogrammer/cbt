import { TestBed } from '@angular/core/testing';

import { GenderChartService } from './gender-chart.service';

describe('GenderChartService', () => {
  let service: GenderChartService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GenderChartService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
