import { AfterViewInit, Component, ElementRef, OnDestroy, ViewChild, effect, inject, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { Chart, registerables } from 'chart.js';
import { GenderChartService } from './gender-chart.service';

Chart.register(...registerables);

@Component({
  selector: 'app-gender-chart',
  standalone: true,
  imports: [],
  templateUrl: './gender-chart.component.html',
  styleUrl: './gender-chart.component.scss',
})
export class GenderChartComponent implements AfterViewInit, OnDestroy {
  private readonly genderChartService = inject(GenderChartService);

  @ViewChild('genderCanvas') private canvasRef?: ElementRef<HTMLCanvasElement>;

  private readonly viewReady = signal(false);
  private chart?: Chart;

  readonly isLoading = toSignal(this.genderChartService.isLoading$, { initialValue: true });
  readonly genderChart = toSignal(this.genderChartService.metrics$, {
    initialValue: { males: 0, females: 0 },
  });

  constructor() {
    effect(() => {
      const ready = this.viewReady();
      const metrics = this.genderChart();
      if (!ready) return;
      this.createChart(metrics.males, metrics.females);
    });
  }

  ngAfterViewInit(): void {
    this.viewReady.set(true);
  }

  private createChart(males: number, females: number): void {
    const canvas = this.canvasRef?.nativeElement;
    if (!canvas) return;

    this.chart?.destroy();
    this.chart = new Chart(canvas, {
      type: 'pie',
      data: {
        labels: ['Male', 'Female'],
        datasets: [{
          label: 'Students',
          data: [males, females],
          borderWidth: 0,
          backgroundColor: ['#4156eb', '#edcb50'],
          hoverBackgroundColor: ['#4156eb', '#edcb50'],
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              usePointStyle: true,
              boxWidth: 12,
              boxHeight: 10,
              useBorderRadius: true,
              borderRadius: 8,
              padding: 20,
              font: { size: 15 },
            },
          },
        },
      },
    });
  }

  ngOnDestroy(): void {
    this.chart?.destroy();
  }
}
