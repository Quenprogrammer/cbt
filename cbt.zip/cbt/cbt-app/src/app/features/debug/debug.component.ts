import {Component, inject, Input} from '@angular/core';
import {ViewExamsService} from '../../services/view-exams.service';
import {ActivatedRoute, Router, RouterLink, RouterLinkActive} from '@angular/router';
import {deleteDoc, doc, Firestore} from '@angular/fire/firestore';
import {toSignal} from '@angular/core/rxjs-interop';
import {NgForOf} from '@angular/common';
import {PaginationComponent} from '../student/pagination/pagination.component';
import {ViewScoresService} from '../../services/view-scores.service';

import { TenantContextService } from '../../services/tenant-context.service';
@Component({
  selector: 'app-debug',
  standalone: true,
  imports: [
    NgForOf,
    PaginationComponent,
    RouterLinkActive,
    RouterLink
  ],
  templateUrl: './debug.component.html',

  styleUrl: './debug.component.scss'
})
export class DebugComponent {

  private viewScoreService = inject(ViewScoresService);
  private router = inject(Router);
  private firestore=inject(Firestore);
  private readonly tenant = inject(TenantContextService);
  route: ActivatedRoute = inject(ActivatedRoute);
  subjectId: string | null = null;
  examId: string | null = null;

  @Input()
  set id(subjectId: string) {
    if (subjectId) {
      this.subjectId = subjectId;
      this.viewScoreService.loadExams(subjectId);
    } else {
      this.router.navigate(['/']);
    }
  }
  /*
    constructor() {

      this.route.paramMap.subscribe((params)=>{

        const subjectId = params.get('subjectId');
        const examId =params.get('examsId');

        if (subjectId && examId) {
          this.subjectId = subjectId;
          this.examId = examId;
        } else {
          this.router.navigate(['/']);
        }
      });





    }*/

  viewExam = toSignal(this.viewScoreService.viewscores$, { initialValue: [] });
  itemsPerPage = 5;
  currentPage = 1;



  get ViewExams() {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    return this.viewExam().slice(startIndex, startIndex + this.itemsPerPage);
  }

  onPageChange(page: number): void {
    this.currentPage = page;
  }

  getOptionLetter(index: number): string {
    return String.fromCharCode(65 + index); // 65 is the ASCII code for 'A'
  }


  delete() {
    if (this.subjectId) {
      const subjectDocRef = doc(this.firestore, this.tenant.path(`subjects/${this.subjectId}`));
      console.log('Document reference:', subjectDocRef);

      // Delete the subject document from Firestore
      deleteDoc(subjectDocRef)
        .then(() => {
          alert('Subject deleted successfully!');
          //this.viewExam.reset(); // Reset the form view
          this.subjectId = ''; // Clear the subject ID
        })
        .catch((error: any) => {
          console.error('Error deleting document:', error);
          alert('Error deleting subject data. Please try again.');
        });
    } else {
      alert('No subject selected for deletion.');
    }
  }



  deleting(examId: string) {
    if (this.subjectId && examId) {
      // Construct the path to the specific exam document
      const examDocRef = doc(this.firestore, this.tenant.path(`subjects/${this.subjectId}/exams/${examId}`));
      console.log('Deleting document:', examDocRef);

      // Delete the specific exam document from Firestore
      deleteDoc(examDocRef)
        .then(() => {
          alert('Exam document deleted successfully!');
        })
        .catch((error: any) => {
          console.error('Error deleting document:', error);
          alert('Error deleting exam document. Please try again.');
        });
    } else {
      alert('Subject ID or Exam ID is missing. Unable to delete.');
    }
  }

}
