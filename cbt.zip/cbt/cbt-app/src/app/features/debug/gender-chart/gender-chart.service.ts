import { Injectable } from '@angular/core';
import {of} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GenderChartService {
  getData() {
    // Simulate an API call
    return of({ males: 200, females: 150 });
  }
}
