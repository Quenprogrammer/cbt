import { Component, OnInit } from '@angular/core';
import {Chart, registerables,} from 'chart.js';
import 'chart.js/auto'; // Alternatively, use this to auto-register all controllers

@Component({
  selector: 'app-gender-chart',
  standalone: true,
  template: `
    <div class="chart-container">
      <canvas id="genderChart"></canvas>
    </div>
  `,

  styles: [`
    .chart-container {
      width: 100%;
      height: 400px;
      position: relative;
    }
  `]
})
export class GenderChartComponent implements OnInit {
  public chart: any;

  ngOnInit(): void {
    // Register all Chart.js controllers
    Chart.register(...registerables);
    this.createChart();
  }

  createChart() {
    const ctx = document.getElementById('genderChart') as HTMLCanvasElement;
    if (!ctx) {
      console.error('Canvas element not found!');
      return;
    }

    this.chart = new Chart(ctx, {
      type: 'pie', // Now "pie" is registered
      data: {
        labels: ['Male', 'Female'],
        datasets: [
          {
            label: 'Gender Distribution',
            data: [200, 150], // Static data for demonstration
            backgroundColor: ['#448c74', '#edcb50'],
            hoverBackgroundColor: ['#448c74', '#edcb50'],
            borderWidth: 0,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              usePointStyle: true,
              boxWidth: 12,
              boxHeight: 10,
              useBorderRadius: true,
              borderRadius: 8,
              padding: 20,
              font: {
                size: 15,
              },
            },
          },
        },
      },
    });
  }
}
