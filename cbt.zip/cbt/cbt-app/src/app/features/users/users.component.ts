import { CommonModule } from '@angular/common';
import { Component, OnDestroy, inject } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { ActivityLogService } from '../../services/activity-log.service';
import {
  CreateInvigilationSchedule,
  InvigilationSchedule,
  InvigilationService,
} from '../../services/invigilation.service';
import { Staff, StaffService } from '../../services/staff.service';
import { Student, StudentService } from '../../services/student.service';

@Component({
  selector: 'app-users',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './users.component.html',
  styleUrl: './users.component.scss',
})
export class UsersComponent implements OnDestroy {
  private readonly staffService = inject(StaffService);
  private readonly studentService = inject(StudentService);
  private readonly invigilationService = inject(InvigilationService);
  private readonly audit = inject(ActivityLogService);
  private readonly subscriptions = new Subscription();

  staffs: Staff[] = [];
  students: Student[] = [];
  schedules: InvigilationSchedule[] = [];
  selectedStudentIds = new Set<string>();
  saving = false;
  scheduleActionId = '';

  readonly staffSearch = new FormControl('', { nonNullable: true });
  readonly studentSearch = new FormControl('', { nonNullable: true });

  readonly scheduleForm = new FormGroup({
    examTitle: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    subjectName: new FormControl('', { nonNullable: true }),
    examDate: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    startTime: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    endTime: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    venue: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    staffId: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    notes: new FormControl('', { nonNullable: true }),
  });

  constructor() {
    this.subscriptions.add(
      this.staffService.staffs$.subscribe((staffs) => {
        this.staffs = staffs;
      })
    );
    this.subscriptions.add(
      this.studentService.students$.subscribe((students) => {
        this.students = students;
      })
    );
    this.subscriptions.add(
      this.invigilationService.schedules$.subscribe({
        next: (schedules) => {
          this.schedules = [...schedules].sort((a, b) =>
            `${a.examDate}T${a.startTime}`.localeCompare(`${b.examDate}T${b.startTime}`)
          );
        },
        error: (error) => console.error('Error fetching invigilation schedules:', error),
      })
    );
  }

  get activeStaff(): Staff[] {
    return this.staffs.filter((staff) => (staff.status || 'Active') === 'Active');
  }

  get filteredStaff(): Staff[] {
    const term = this.staffSearch.value.trim().toLowerCase();
    if (!term) return this.activeStaff;
    return this.activeStaff.filter((staff) =>
      [staff.firstname, staff.middlename, staff.lastname, staff.employeeId, staff.department, staff.role]
        .filter(Boolean)
        .some((value) => String(value).toLowerCase().includes(term))
    );
  }

  get filteredStudents(): Student[] {
    const term = this.studentSearch.value.trim().toLowerCase();
    const activeStudents = this.students.filter((student) => (student.status || 'Active') === 'Active');
    if (!term) return activeStudents;
    return activeStudents.filter((student) =>
      [student.firstname, student.middlename, student.lastname, student.admissionNumber, student.department, student.classLevel]
        .filter(Boolean)
        .some((value) => String(value).toLowerCase().includes(term))
    );
  }

  get upcomingSchedules(): InvigilationSchedule[] {
    return this.schedules.filter((schedule) => schedule.status === 'Scheduled');
  }

  get selectedStudentCount(): number {
    return this.selectedStudentIds.size;
  }

  get allFilteredStudentsSelected(): boolean {
    return this.filteredStudents.length > 0 && this.filteredStudents.every((student) => this.selectedStudentIds.has(student.id));
  }

  fullStaffName(staff: Staff): string {
    return [staff.firstname, staff.middlename, staff.lastname].filter(Boolean).join(' ');
  }

  fullStudentName(student: Student): string {
    return [student.firstname, student.middlename, student.lastname].filter(Boolean).join(' ');
  }

  isStudentSelected(studentId: string): boolean {
    return this.selectedStudentIds.has(studentId);
  }

  toggleStudent(studentId: string, checked: boolean): void {
    if (checked) this.selectedStudentIds.add(studentId);
    else this.selectedStudentIds.delete(studentId);
  }

  toggleAllFilteredStudents(): void {
    if (this.allFilteredStudentsSelected) {
      this.filteredStudents.forEach((student) => this.selectedStudentIds.delete(student.id));
      return;
    }
    this.filteredStudents.forEach((student) => this.selectedStudentIds.add(student.id));
  }

  isStaffAvailable(staffId: string): boolean {
    const date = this.scheduleForm.controls.examDate.value;
    const start = this.scheduleForm.controls.startTime.value;
    const end = this.scheduleForm.controls.endTime.value;
    if (!date || !start || !end) return true;

    return !this.schedules.some(
      (schedule) =>
        schedule.status !== 'Cancelled' &&
        schedule.staffId === staffId &&
        schedule.examDate === date &&
        this.timesOverlap(start, end, schedule.startTime, schedule.endTime)
    );
  }

  staffScheduleCount(staffId: string): number {
    return this.schedules.filter(
      (schedule) => schedule.staffId === staffId && schedule.status === 'Scheduled'
    ).length;
  }

  async scheduleInvigilation(): Promise<void> {
    if (this.scheduleForm.invalid) {
      this.scheduleForm.markAllAsTouched();
      alert('Complete the examination date, time, venue and invigilator.');
      return;
    }

    if (this.selectedStudentIds.size === 0) {
      alert('Select at least one student for this invigilator.');
      return;
    }

    const values = this.scheduleForm.getRawValue();
    if (this.toMinutes(values.endTime) <= this.toMinutes(values.startTime)) {
      alert('End time must be later than start time.');
      return;
    }

    const staff = this.staffs.find((item) => item.id === values.staffId);
    if (!staff) {
      alert('Select a valid staff member.');
      return;
    }
    if (!this.isStaffAvailable(staff.id)) {
      alert('This staff member already has an invigilation assignment during the selected time.');
      return;
    }

    const selectedStudents = this.students.filter((student) => this.selectedStudentIds.has(student.id));
    const conflictingStudentIds = this.findStudentConflicts(
      selectedStudents.map((student) => student.id),
      values.examDate,
      values.startTime,
      values.endTime
    );
    if (conflictingStudentIds.length > 0) {
      const names = selectedStudents
        .filter((student) => conflictingStudentIds.includes(student.id))
        .map((student) => this.fullStudentName(student))
        .slice(0, 5)
        .join(', ');
      alert(`Some selected students already have an invigilator for this time: ${names}`);
      return;
    }

    const payload: CreateInvigilationSchedule = {
      examTitle: values.examTitle.trim(),
      subjectName: values.subjectName.trim(),
      examDate: values.examDate,
      startTime: values.startTime,
      endTime: values.endTime,
      venue: values.venue.trim(),
      staffId: staff.id,
      staffName: this.fullStaffName(staff),
      staffEmployeeId: staff.employeeId ?? '',
      staffDepartment: staff.department ?? '',
      studentIds: selectedStudents.map((student) => student.id),
      students: selectedStudents.map((student) => ({
        id: student.id,
        name: this.fullStudentName(student),
        admissionNumber: student.admissionNumber,
        department: student.department,
      })),
      studentCount: selectedStudents.length,
      status: 'Scheduled',
      notes: values.notes.trim(),
    };

    this.saving = true;
    try {
      const scheduleId = await this.invigilationService.createSchedule(payload);
      await this.audit.log('invigilation_scheduled', 'invigilationSchedule', scheduleId, {
        staffId: staff.id,
        staffName: payload.staffName,
        examDate: payload.examDate,
        startTime: payload.startTime,
        studentCount: payload.studentCount,
      });
      this.selectedStudentIds.clear();
      this.scheduleForm.reset({
        examTitle: '',
        subjectName: '',
        examDate: '',
        startTime: '',
        endTime: '',
        venue: '',
        staffId: '',
        notes: '',
      });
      alert('Invigilation schedule created successfully.');
    } catch (error) {
      console.error('Error creating invigilation schedule:', error);
      alert('Unable to create the invigilation schedule.');
    } finally {
      this.saving = false;
    }
  }

  async setScheduleStatus(
    schedule: InvigilationSchedule,
    status: InvigilationSchedule['status']
  ): Promise<void> {
    this.scheduleActionId = schedule.id;
    try {
      await this.invigilationService.updateStatus(schedule.id, status);
      await this.audit.log('invigilation_status_changed', 'invigilationSchedule', schedule.id, {
        previousStatus: schedule.status,
        status,
      });
    } catch (error) {
      console.error('Error updating invigilation status:', error);
      alert('Unable to update the schedule status.');
    } finally {
      this.scheduleActionId = '';
    }
  }

  async deleteSchedule(schedule: InvigilationSchedule): Promise<void> {
    if (!confirm(`Delete the invigilation schedule for ${schedule.staffName}?`)) return;
    this.scheduleActionId = schedule.id;
    try {
      await this.invigilationService.deleteSchedule(schedule.id);
      await this.audit.log('invigilation_deleted', 'invigilationSchedule', schedule.id, {
        staffId: schedule.staffId,
        examDate: schedule.examDate,
      });
    } catch (error) {
      console.error('Error deleting invigilation schedule:', error);
      alert('Unable to delete the schedule.');
    } finally {
      this.scheduleActionId = '';
    }
  }

  private findStudentConflicts(
    studentIds: string[],
    examDate: string,
    startTime: string,
    endTime: string
  ): string[] {
    const conflicts = new Set<string>();
    this.schedules.forEach((schedule) => {
      if (
        schedule.status === 'Cancelled' ||
        schedule.examDate !== examDate ||
        !this.timesOverlap(startTime, endTime, schedule.startTime, schedule.endTime)
      ) {
        return;
      }
      (schedule.studentIds || []).forEach((studentId) => {
        if (studentIds.includes(studentId)) conflicts.add(studentId);
      });
    });
    return [...conflicts];
  }

  private timesOverlap(startA: string, endA: string, startB: string, endB: string): boolean {
    return this.toMinutes(startA) < this.toMinutes(endB) && this.toMinutes(startB) < this.toMinutes(endA);
  }

  private toMinutes(value: string): number {
    const [hours, minutes] = value.split(':').map(Number);
    return (Number.isFinite(hours) ? hours : 0) * 60 + (Number.isFinite(minutes) ? minutes : 0);
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }
}
