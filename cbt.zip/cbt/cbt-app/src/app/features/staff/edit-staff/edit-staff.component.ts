import { Component, Input, inject } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import {
  Firestore,
  deleteDoc,
  doc,
  getDoc,
  serverTimestamp,
  updateDoc,
} from '@angular/fire/firestore';
import { TenantContextService } from '../../../services/tenant-context.service';
import { Router, RouterLink } from '@angular/router';
import { ActivityLogService } from '../../../services/activity-log.service';
import { Staff } from '../../../services/staff.service';

@Component({
  selector: 'app-edit-staff',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './edit-staff.component.html',
  styleUrl: './edit-staff.component.scss',
})
export class EditStaffComponent {
  private readonly firestore = inject(Firestore);
  private readonly tenant = inject(TenantContextService);
  private readonly router = inject(Router);
  private readonly audit = inject(ActivityLogService);

  staffId: string | null = null;
  loading = true;
  saving = false;
  deleting = false;

  readonly profileForm = new FormGroup({
    employeeId: new FormControl('', { nonNullable: true }),
    firstname: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    middlename: new FormControl('', { nonNullable: true }),
    lastname: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    email: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.email] }),
    phone: new FormControl('', { nonNullable: true }),
    role: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    department: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    dateOfBirth: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    gender: new FormControl('', { nonNullable: true, validators: [Validators.required] }),
    address: new FormControl('', { nonNullable: true }),
    qualification: new FormControl('', { nonNullable: true }),
    specialization: new FormControl('', { nonNullable: true }),
    employmentDate: new FormControl('', { nonNullable: true }),
    employmentType: new FormControl('Full-time', { nonNullable: true }),
    status: new FormControl('Active', { nonNullable: true }),
    emergencyContactName: new FormControl('', { nonNullable: true }),
    emergencyContactPhone: new FormControl('', { nonNullable: true }),
    nextOfKin: new FormControl('', { nonNullable: true }),
    nextOfKinPhone: new FormControl('', { nonNullable: true }),
    notes: new FormControl('', { nonNullable: true }),
  });

  @Input()
  set id(staffId: string) {
    if (!staffId) {
      void this.router.navigate(['/admin/staff-list']);
      return;
    }

    this.staffId = staffId;
    void this.getStaffDetail(staffId);
  }

  private async getStaffDetail(staffId: string): Promise<void> {
    this.loading = true;
    try {
      const snapshot = await getDoc(doc(this.firestore, this.tenant.path(`staffs/${staffId}`)));
      if (!snapshot.exists()) {
        alert('Staff record was not found.');
        await this.router.navigate(['/admin/staff-list']);
        return;
      }

      const staff = snapshot.data() as Partial<Staff>;
      this.profileForm.patchValue({
        employeeId: staff.employeeId ?? '',
        firstname: staff.firstname ?? '',
        middlename: staff.middlename ?? '',
        lastname: staff.lastname ?? '',
        email: staff.email ?? '',
        phone: staff.phone ?? '',
        role: staff.role ?? '',
        department: staff.department ?? '',
        dateOfBirth: staff.dateOfBirth ?? '',
        gender: staff.gender ?? '',
        address: staff.address ?? '',
        qualification: staff.qualification ?? '',
        specialization: staff.specialization ?? '',
        employmentDate: staff.employmentDate ?? '',
        employmentType: staff.employmentType ?? 'Full-time',
        status: staff.status ?? 'Active',
        emergencyContactName: staff.emergencyContactName ?? '',
        emergencyContactPhone: staff.emergencyContactPhone ?? '',
        nextOfKin: staff.nextOfKin ?? '',
        nextOfKinPhone: staff.nextOfKinPhone ?? '',
        notes: staff.notes ?? '',
      });
    } catch (error) {
      console.error('Error loading staff:', error);
      alert('Unable to load the staff record.');
    } finally {
      this.loading = false;
    }
  }

  async handleSubmit(): Promise<void> {
    if (!this.staffId) return;
    if (this.profileForm.invalid) {
      this.profileForm.markAllAsTouched();
      alert('Please complete all required fields correctly.');
      return;
    }

    this.saving = true;
    try {
      const values = this.profileForm.getRawValue();
      await updateDoc(doc(this.firestore, this.tenant.path(`staffs/${this.staffId}`)), {
        ...values,
        updatedAt: serverTimestamp(),
      });
      await this.audit.log('staff_updated', 'staff', this.staffId, {
        employeeId: values.employeeId,
      });
      alert('Staff data updated successfully.');
    } catch (error) {
      console.error('Error updating staff:', error);
      alert('Unable to update staff data. Please try again.');
    } finally {
      this.saving = false;
    }
  }

  async delete(): Promise<void> {
    if (!this.staffId || this.deleting) return;
    if (!confirm('Delete this staff record permanently?')) return;

    this.deleting = true;
    try {
      const staffId = this.staffId;
      await deleteDoc(doc(this.firestore, this.tenant.path(`staffs/${staffId}`)));
      await this.audit.log('staff_deleted', 'staff', staffId, {
        employeeId: this.profileForm.controls.employeeId.value,
      });
      await this.router.navigate(['/admin/staff-list']);
    } catch (error) {
      console.error('Error deleting staff:', error);
      alert('Unable to delete the staff record.');
    } finally {
      this.deleting = false;
    }
  }
}
