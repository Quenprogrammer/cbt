import { AfterViewInit, Component, effect, ElementRef, inject, OnDestroy, ViewChild } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { PaginationComponent } from '../../student/pagination/pagination.component';
import { NgForOf } from '@angular/common';
import { Staff, StaffService } from '../../../services/staff.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HeaderComponent } from '../../../services/component/header/header.component';
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

@Component({
  selector: 'app-staff-list',
  standalone: true,
  imports: [
    RouterLink,
    RouterLinkActive,
    PaginationComponent,
    NgForOf,
    FormsModule,
    ReactiveFormsModule,
    HeaderComponent
  ],
  templateUrl: './staff-list.component.html',
  styleUrl: './staff-list.component.scss'
})
export class StaffListComponent  {
  private staffService = inject(StaffService);
  staffs = toSignal(this.staffService.staffs$, { initialValue: [] });

  @ViewChild('staffGenderChart') private genderChartCanvas?: ElementRef<HTMLCanvasElement>;



  itemsPerPage = 5;
  currentPage = 1;
  searchTerm = '';

  constructor() {
    effect(() => {
      const staffs = this.staffs();


      this.renderGenderChart(staffs);
    });
  }



  get staffsItems() {
    const filteredStaff = this.filterStaffs();
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return filteredStaff.slice(startIndex, endIndex);
  }

  onPageChange(page: number): void {
    this.currentPage = page;
  }

  onSearch(): void {
    this.currentPage = 1; // Reset to the first page when searching
  }

  filterStaffs() {
    if (!this.searchTerm) {
      return this.staffs();
    }
    return this.staffs().filter(staffs =>
      staffs.firstname.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      staffs.email.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      staffs.role.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      staffs.department.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      staffs.gender.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  private renderGenderChart(staffs: Staff[]): void {
    const canvas = this.genderChartCanvas?.nativeElement;
    if (!canvas) {
      return;
    }

    const counts = new Map<string, number>([
      ['Male', 0],
      ['Female', 0],
    ]);

    staffs.forEach((staff) => {
      const normalized = (staff.gender ?? '').trim().toLowerCase();
      let label = 'Not specified';

      if (normalized === 'male' || normalized === 'm') {
        label = 'Male';
      } else if (normalized === 'female' || normalized === 'f') {
        label = 'Female';
      } else if (normalized) {
        label = 'Other';
      }

      counts.set(label, (counts.get(label) ?? 0) + 1);
    });

    const entries = Array.from(counts.entries()).filter(([, count]) => count > 0);


  }

  isLoading() {
  }


}
