import { CommonModule } from '@angular/common';
import { Component, Injector, computed, inject, runInInjectionContext } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { Auth, signOut, user } from '@angular/fire/auth';
import { Firestore, collection, collectionData, query, where } from '@angular/fire/firestore';
import { toSignal } from '@angular/core/rxjs-interop';
import { map, of, switchMap } from 'rxjs';
import { ExamsListService } from '../../services/exams-list.service';
import { Student } from '../../services/student.service';

import { TenantContextService } from '../../services/tenant-context.service';
@Component({
  selector: 'app-student-home',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './student-home.component.html',
  styleUrl: './student-home.component.scss',
})
export class StudentHomeComponent {
  private readonly auth = inject(Auth);
  private readonly injector = inject(Injector);
  private readonly firestore = inject(Firestore);
  private readonly tenant = inject(TenantContextService);
  private readonly router = inject(Router);
  private readonly examsService = inject(ExamsListService);

  readonly currentUser = toSignal(user(this.auth), { initialValue: null });
  readonly subjects = toSignal(this.examsService.examlist$, { initialValue: [] });
  readonly loading = toSignal(this.examsService.isLoading$, { initialValue: true });

  private readonly profile$ = user(this.auth).pipe(
    switchMap((currentUser) => {
      if (!currentUser) return of(null);

      return runInInjectionContext(this.injector, () => {
        const profileQuery = query(
          collection(this.firestore, this.tenant.path('student')),
          where('authUid', '==', currentUser.uid)
        );

        return collectionData(profileQuery, { idField: 'id' }).pipe(
          map((rows) => (rows[0] as Student | undefined) ?? null)
        );
      });
    })
  );

  readonly student = toSignal(this.profile$, { initialValue: null });
  readonly registeredSubjects = computed(() => {
    const allSubjects = this.subjects().filter((subject) => subject.active !== false);
    const registeredIds = this.student()?.registeredSubjectIds ?? [];
    if (registeredIds.length === 0) return [];
    const allowed = new Set(registeredIds);
    return allSubjects.filter((subject) => allowed.has(subject.id));
  });

  fullName(): string {
    const profile = this.student();
    if (!profile) return this.currentUser()?.displayName || 'Student';
    return [profile.firstname, profile.middlename, profile.lastname]
      .filter(Boolean)
      .join(' ');
  }

  examAllowed(): boolean {
    return this.student()?.examStatus === 'Started';
  }

  permissionLabel(): string {
    const status = this.student()?.examStatus || 'Not Started';
    if (status === 'Started') return 'Access granted';
    if (status === 'Completed') return 'Attempt completed';
    if (status === 'Ended') return 'Access blocked';
    return 'Waiting for admin';
  }

  permissionTone(): string {
    const status = this.student()?.examStatus || '';
    if (status === 'Started') return 'allowed';
    if (status === 'Completed') return 'completed';
    return 'locked';
  }

  async logout(): Promise<void> {
    await signOut(this.auth);
    await this.router.navigate(['/authentication']);
  }
}
