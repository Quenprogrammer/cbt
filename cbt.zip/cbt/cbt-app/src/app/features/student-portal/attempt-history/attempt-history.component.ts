import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { Auth } from '@angular/fire/auth';
import { toSignal } from '@angular/core/rxjs-interop';
import { RouterLink } from '@angular/router';
import { of } from 'rxjs';
import { ExamAttemptService } from '../../../services/exam-attempt.service';

@Component({
  selector: 'app-attempt-history',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './attempt-history.component.html',
  styleUrl: './attempt-history.component.scss',
})
export class AttemptHistoryComponent {
  private auth = inject(Auth);
  private service = inject(ExamAttemptService);
  private uid = this.auth.currentUser?.uid || '';

  attempts = toSignal(
    this.uid ? this.service.studentAssignments(this.uid) : of([]),
    { initialValue: [] as any[] }
  );
}
