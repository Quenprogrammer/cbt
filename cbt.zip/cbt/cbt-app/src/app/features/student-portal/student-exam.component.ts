import { CommonModule } from '@angular/common';
import { QuestionContentComponent } from '../../shared/questions/question-content.component';
import { QuestionResponseComponent } from '../../shared/questions/question-response.component';
import { ExamResponse, hasExamResponse } from '../../shared/questions/question-content.model';
import {
  Component,
  OnDestroy,
  inject,
  signal,
} from '@angular/core';
import { ExamRecoveryService } from '../../services/exam-recovery.service';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import {
  ExamAttemptService,
  ExamPackage,
  ExamPackageQuestion,
  SubmitExamResponse,
} from '../../services/exam-attempt.service';

@Component({
  selector: 'app-student-exam',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, QuestionContentComponent, QuestionResponseComponent],
  templateUrl: './student-exam.component.html',
  styleUrl: './student-exam.component.scss',
})
export class StudentExamComponent implements OnDestroy {
  private examService = inject(ExamAttemptService);
  readonly recovery = inject(ExamRecoveryService);

  readonly loading = signal(false);
  readonly started = signal(false);
  readonly submitting = signal(false);
  readonly showSubmitConfirm = signal(false);
  readonly examPackage = signal<ExamPackage | null>(null);
  readonly submission = signal<SubmitExamResponse | null>(null);
  readonly remainingSeconds = signal(0);
  readonly currentQuestionIndex = signal(0);
  readonly answers = signal<Record<string, ExamResponse>>({});
  readonly timePerQuestion = signal<Record<string, number>>({});
  readonly acceptedInstructions = signal(false);
  readonly startError = signal('');
  readonly submissionError = signal('');
  readonly recoveryMessage = signal('');

  private timer?: ReturnType<typeof setInterval>;
  private retryTimer?: ReturnType<typeof setInterval>;
  private questionStartedAt = Date.now();

  instructions = [
    'Your examination can only start after an administrator grants access from Exam Control.',
    'All active subjects assigned to you are submitted together as one examination attempt.',
    'The timer starts immediately after you click Begin exam and cannot be paused.',
    'Questions and option order are randomized for each candidate.',
    'Respond using the controls for each question. Your progress is saved automatically.',
    'Unanswered questions are allowed, but they count as unanswered.',
    'The examination submits automatically when the timer reaches zero.',
    'Your score becomes available after marking and release. Keep your result PIN safe.',
  ];

  answeredCount(): number {
    return Object.values(this.answers()).filter(hasExamResponse).length;
  }

  unansweredCount(): number {
    return Math.max(
      (this.examPackage()?.questions.length ?? 0) - this.answeredCount(),
      0
    );
  }

  currentQuestion(): ExamPackageQuestion | null {
    return this.examPackage()?.questions[this.currentQuestionIndex()] ?? null;
  }

  formattedTime(): string {
    const value = Math.max(this.remainingSeconds(), 0);
    const h = Math.floor(value / 3600);
    const m = Math.floor((value % 3600) / 60);
    const s = value % 60;
    return `${h > 0 ? String(h).padStart(2, '0') + ':' : ''}${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }

  async beginExam(): Promise<void> {
    if (!this.acceptedInstructions() || this.loading()) return;

    this.loading.set(true);
    this.startError.set('');

    try {
      const cached = this.recovery.cached();
      let pkg: ExamPackage;
      if (cached?.pendingSubmission || (!this.recovery.online() && cached)) {
        pkg = cached.pkg;
      } else {
        try { pkg = await this.examService.startExam(); }
        catch (error) {
          const code = String((error as { code?: string })?.code ?? '');
          if (!cached || !['functions/unavailable', 'functions/deadline-exceeded', 'auth/network-request-failed'].includes(code)) throw error;
          pkg = cached.pkg;
          this.recoveryMessage.set('Your saved examination was restored from this device. Reconnect to synchronize answers.');
        }
      }
      this.examPackage.set(pkg);
      this.started.set(true);
      const draft = this.recovery.begin(pkg);
      this.answers.set(draft.answers);
      this.timePerQuestion.set(draft.timePerQuestion);
      this.currentQuestionIndex.set(draft.currentQuestionIndex);
      this.remainingSeconds.set(
        Math.max(0, Math.ceil((pkg.expiresAtMs - Date.now()) / 1000))
      );
      this.questionStartedAt = Date.now();
      this.startTimer(pkg);
      this.retryTimer = setInterval(() => {
        void this.recovery.flush();
        if (this.recovery.pendingSubmission() && this.recovery.online()) void this.submitExam(true);
      }, 10000);
      void this.recovery.flush();
      if (this.recovery.pendingSubmission() || this.remainingSeconds() === 0) void this.submitExam(true);
    } catch (error: any) {
      const message =
        error?.message ||
        'Unable to start exam. Ask an administrator to enable your exam from Exam Control.';
      this.startError.set(message);
    } finally {
      this.loading.set(false);
    }
  }

  hasAnswer(questionId:string):boolean{return hasExamResponse(this.answers()[questionId]);}
  async selectAnswer(questionId: string, answerId: ExamResponse): Promise<void> {
    if (!this.started() || this.remainingSeconds() <= 0 || this.recovery.pendingSubmission() || this.submitting()) return;
    this.captureQuestionTime();
    this.answers.update((value) => ({ ...value, [questionId]: answerId }));
    this.saveDraft();
  }

  goToQuestion(index: number): void {
    this.captureQuestionTime();
    const total = this.examPackage()?.questions.length ?? 0;

    if (index >= 0 && index < total) {
      this.currentQuestionIndex.set(index);
      this.questionStartedAt = Date.now();
      this.saveDraft();
    }
  }

  next(): void {
    this.goToQuestion(this.currentQuestionIndex() + 1);
  }

  previous(): void {
    this.goToQuestion(this.currentQuestionIndex() - 1);
  }

  requestSubmit(): void {
    if (this.recovery.pendingSubmission()) { void this.submitExam(true); return; }
    this.showSubmitConfirm.set(true);
  }

  async submitExam(auto = false): Promise<void> {
    const pkg = this.examPackage();
    if (!pkg || this.submitting() || this.submission()) return;
    if (!auto && !this.showSubmitConfirm() && !this.recovery.pendingSubmission()) return;

    if (!this.recovery.pendingSubmission()) { this.captureQuestionTime(); this.saveDraft(); this.recovery.queueSubmission(); }
    this.showSubmitConfirm.set(false);
    this.submitting.set(true);
    this.submissionError.set('');

    if (!this.recovery.online()) {
      this.submissionError.set('Submission is queued on this device. It will retry when your connection returns.');
      this.submitting.set(false);
      return;
    }

    try {
      const answerMap = this.answers();
      const timeMap = this.timePerQuestion();
      const payload = pkg.questions.map((question) => ({
        questionId: question.questionId,
        selectedAnswerId: typeof answerMap[question.questionId] === 'string' ? answerMap[question.questionId] as string : null,
        response: answerMap[question.questionId] || '',
        timeSpentSeconds: timeMap[question.questionId] || 0,
      }));

      const response = await this.examService.submitExam(pkg.assignmentId, payload);
      this.submission.set(response);
      this.started.set(false);

      if (this.timer) clearInterval(this.timer);
      if (this.retryTimer) clearInterval(this.retryTimer);
      this.recovery.complete(pkg.assignmentId);
    } catch (error: any) {
      this.submissionError.set((error?.message || 'Unable to submit exam.') + ' Your submission remains queued and will retry automatically.');
    } finally {
      this.submitting.set(false);
    }
  }

  private startTimer(pkg: ExamPackage): void {
    if (this.timer) clearInterval(this.timer);

    this.timer = setInterval(() => {
      const seconds = Math.max(
        0,
        Math.ceil((pkg.expiresAtMs - Date.now()) / 1000)
      );
      this.remainingSeconds.set(seconds);

      if (seconds <= 0) {
        if (this.timer) clearInterval(this.timer);
        void this.submitExam(true);
      }
    }, 1000);
  }

  private captureQuestionTime(): void {
    if (this.recovery.pendingSubmission()) return;
    const question = this.currentQuestion();
    if (!question) return;

    const elapsed = Math.max(
      0,
      Math.round((Math.min(Date.now(), this.examPackage()?.expiresAtMs ?? Date.now()) - this.questionStartedAt) / 1000)
    );

    this.timePerQuestion.update((value) => ({
      ...value,
      [question.questionId]:
        (value[question.questionId] || 0) + elapsed,
    }));
    this.questionStartedAt = Date.now();
  }

  private saveDraft(): void { this.recovery.update(this.answers(), this.timePerQuestion(), this.currentQuestionIndex()); }

  retrySync(): void { void this.recovery.flush(); if (this.recovery.pendingSubmission()) void this.submitExam(true); }

  ngOnDestroy(): void {
    this.captureQuestionTime();
    if (this.started() && !this.submission()) this.saveDraft();
    if (this.timer) clearInterval(this.timer);
    if (this.retryTimer) clearInterval(this.retryTimer);
  }
}
