import { Component, OnInit, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { InstitutionOnboardingService, InstitutionSetupState } from '../../services/institution-onboarding.service';

@Component({selector:'app-setup-checklist',standalone:true,imports:[RouterLink],template:`
@if(state();as state){@if(state.progress){<section class="checklist"><div><span class="tag">YOUR NEXT STEPS</span><h2>{{state.progress.status==='completed'?'Keep your institution moving.':'Continue setting up your institution.'}}</h2><p>{{state.progress.status==='completed'?'Your essentials are saved. Prepare your questions and candidates when you are ready.':'Pick up where you left off. Your saved setup is ready to resume.'}}</p></div><div class="checklist-links">
@if(state.progress.status!=='completed'){<a routerLink="/onboarding"><i aria-hidden="true" class="bi bi-arrow-right-circle"></i> Resume guided setup</a>}
@if(state.modules['subjects']){<a routerLink="/admin/exam-list"><i aria-hidden="true" class="bi" [class.bi-check-circle]="state.checks.subjects" [class.bi-circle]="!state.checks.subjects"></i> {{state.checks.subjects?'Review subjects':'Add a subject'}}</a>}
@if(state.setupSubjectId && state.modules['exams']){<a routerLink="/admin/adding-exam-question" [queryParams]="{id:state.setupSubjectId}"><i aria-hidden="true" class="bi bi-pencil-square"></i> Add questions to your draft</a>}
@if(state.modules['students']){<a routerLink="/admin/student-list"><i aria-hidden="true" class="bi" [class.bi-check-circle]="state.checks.candidates" [class.bi-circle]="!state.checks.candidates"></i> {{state.checks.candidates?'Review candidates':'Add candidates'}}</a>}
<a routerLink="/onboarding"><i aria-hidden="true" class="bi bi-building"></i> Review institution setup</a></div></section>}}
@if(error()){<div class="checklist"><p role="alert">Setup checklist could not load.</p><button (click)="load()">Retry</button><a routerLink="/onboarding">Open guided setup</a></div>}
`,styles:[`.checklist{border:1px solid #dad7f2;background:#f6f5ff;border-radius:16px;padding:24px;margin-bottom:28px;display:flex;justify-content:space-between;gap:30px;color:#14213d}.tag{font-size:10px;letter-spacing:.13em;color:#4338ca;font-weight:700}.checklist h2{font-size:21px;margin:10px 0}.checklist p{font-size:13px;color:#647087;max-width:500px;margin:0}.checklist-links{display:grid;gap:12px;min-width:240px}.checklist a{color:#4338ca;font-size:13px;text-decoration:none}.checklist i{margin-right:9px}.checklist button{border:0;padding:8px 14px;border-radius:7px;background:#e8e5fa;color:#4338ca}@media(max-width:800px){.checklist{flex-direction:column;gap:20px}}`]})
export class SetupChecklistComponent implements OnInit {
  private readonly setup=inject(InstitutionOnboardingService);readonly state=signal<InstitutionSetupState|null>(null);readonly error=signal(false);
  ngOnInit():void{void this.load();}async load():Promise<void>{this.error.set(false);try{this.state.set(await this.setup.load());}catch{this.error.set(true);}}
}

