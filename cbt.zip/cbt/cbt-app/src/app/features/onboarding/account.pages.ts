import { Component, DestroyRef, OnInit, inject, runInInjectionContext, Injector, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { createUserWithEmailAndPassword, updateProfile, sendEmailVerification, reload } from '@angular/fire/auth';
import { InstitutionOnboardingService } from '../../services/institution-onboarding.service';
import { environment } from '../../../environments/environment';

export function registrationError(error:unknown):string {
  const code=String((error as {code?:string})?.code ?? '');
  if(code.includes('email-already-in-use'))return 'An account already uses this email. Sign in to resume registration.';
  if(code.includes('weak-password'))return 'Use a stronger password with at least eight characters.';
  if(code.includes('network-request-failed'))return 'Check your connection and try again.';
  if(code.includes('too-many-requests'))return 'Too many attempts. Please wait and try again.';
  return error instanceof Error ? error.message : 'Unable to continue. Please try again.';
}
@Component({standalone:true,imports:[ReactiveFormsModule,RouterLink],styleUrl:'./public-journey.scss',template:`
<main class="public-page"><header class="public-bar"><a class="public-brand" routerLink="/"><span class="brand-box">C</span>CBT Platform</a><a routerLink="/authentication">Sign in ↗</a></header>
<section class="account-card"><span class="eyebrow">For schools & exam centres · 1 of 3</span><h1>Make room for better exams.</h1><p>Create your administrator account. Next, verify your email and set up your institution.</p>
@if(error()){<div class="notice error" role="alert">{{error()}}</div>}
<form [formGroup]="form" (ngSubmit)="submit()"><fieldset [disabled]="busy()">
<label>Full name<input formControlName="name" autocomplete="name" maxlength="80"></label>
<label>Email address<input type="email" formControlName="email" autocomplete="email"></label>
<label>Password<input type="password" formControlName="password" autocomplete="new-password" minlength="8" maxlength="128"></label>
<label>Confirm password<input type="password" formControlName="confirmPassword" autocomplete="new-password" minlength="8" maxlength="128"></label><p class="hint">Use at least eight characters. Your account will administer only your institution.</p>
<button class="action full" [disabled]="busy()">{{busy() ? 'Creating account…' : 'Create account →'}}</button>
</fieldset></form>
@if(accountCreated()){<a class="text-action" routerLink="/verify-email">Continue email verification →</a>}
<p class="footer-note">Joining an existing institution as a student? <a routerLink="/sign-up">Register here</a></p></section></main>`})
export class RegisterInstitutionPage implements OnInit {
  readonly setup=inject(InstitutionOnboardingService); private readonly router=inject(Router); private readonly injector=inject(Injector);
  readonly busy=signal(false);readonly error=signal('');readonly accountCreated=signal(false);
  readonly form=new FormGroup({name:new FormControl('',{nonNullable:true,validators:[Validators.required,Validators.minLength(2),Validators.maxLength(80)]}),email:new FormControl('',{nonNullable:true,validators:[Validators.required,Validators.email]}),password:new FormControl('',{nonNullable:true,validators:[Validators.required,Validators.minLength(8),Validators.maxLength(128)]}),confirmPassword:new FormControl('',{nonNullable:true,validators:[Validators.required]})});
  async ngOnInit():Promise<void>{await this.setup.auth.authStateReady();if(this.setup.auth.currentUser){try{await this.router.navigateByUrl(await this.setup.destination());}catch(e){this.error.set(registrationError(e));}}}
  async submit():Promise<void>{
    this.form.markAllAsTouched();this.error.set('');
    const raw=this.form.getRawValue();
    if(this.form.invalid||raw.name.trim().length<2){this.error.set('Enter your name, a valid email and a password of at least eight characters.');return;}
    if(raw.password!==raw.confirmPassword){this.error.set('Passwords do not match.');return;}
    if(this.busy())return;this.busy.set(true);
    try{
      if(this.setup.auth.currentUser){await this.router.navigateByUrl(await this.setup.destination());return;}
      const result=await runInInjectionContext(this.injector,()=>createUserWithEmailAndPassword(this.setup.auth,raw.email.trim(),raw.password));
      this.accountCreated.set(true);
      try{await runInInjectionContext(this.injector,()=>updateProfile(result.user,{displayName:raw.name.trim()}));}catch{}
      await this.setup.intent('institution');
      try{await runInInjectionContext(this.injector,()=>sendEmailVerification(result.user));}catch{}
      this.form.controls.password.reset();this.form.controls.confirmPassword.reset();
      await this.router.navigateByUrl('/verify-email');
    }catch(e){this.error.set(registrationError(e));}finally{this.busy.set(false);}
  }
}
@Component({standalone:true,imports:[RouterLink],styleUrl:'./public-journey.scss',template:`
<main class="public-page"><header class="public-bar"><a class="public-brand" routerLink="/"><span class="brand-box">C</span>CBT Platform</a><button class="text-action" (click)="logout()" [disabled]="busy()">Sign out</button></header>
<section class="account-card"><span class="verification-icon"><i class="bi bi-envelope-check"></i></span><span class="eyebrow">Confirm your email · 2 of 3</span><h1>Check your inbox.</h1><p>Use the verification link sent to <strong>{{setup.auth.currentUser?.email}}</strong>, then return here to continue.</p>
@if(error()){<div class="notice error" role="alert">{{error()}}</div>}@if(message()){<div class="notice success" role="status">{{message()}}</div>}
<button class="action full" [disabled]="busy()" (click)="check()">{{busy() ? 'Checking…' : 'I have verified my email →'}}</button>
<div class="actions between"><button class="text-action" (click)="resend()" [disabled]="busy() || cooldown()>0">{{cooldown()>0 ? 'Resend in '+cooldown()+'s' : 'Resend email'}}</button><button class="text-action" type="button" (click)="logout()" [disabled]="busy()">Use another account</button></div>
<p class="hint">Check your spam folder too. A verified address is required to create an institution or finish a new student registration.</p>
@if(localMode){<hr><span class="hint">Local development only</span><button class="soft-action" (click)="localVerification()" [disabled]="busy()">Show emulator verification email</button>@if(localLink()){<p class="footer-note"><a [href]="localLink()" target="_blank" rel="noopener">Open local verification link ↗</a></p>}}
</section></main>`})
export class VerifyEmailPage {
  readonly setup=inject(InstitutionOnboardingService);private readonly router=inject(Router);private readonly injector=inject(Injector);private readonly destroy=inject(DestroyRef);
  readonly busy=signal(false);readonly error=signal('');readonly message=signal('');readonly cooldown=signal(0);readonly localLink=signal('');readonly localMode=environment.useEmulator;
  private timer?:ReturnType<typeof setInterval>;
  constructor(){this.destroy.onDestroy(()=>{if(this.timer)clearInterval(this.timer);});}
  async check():Promise<void>{
    if(this.busy())return;this.busy.set(true);this.error.set('');
    try{const user=this.setup.auth.currentUser;if(!user){await this.router.navigateByUrl('/authentication');return;}
      await runInInjectionContext(this.injector,()=>reload(user));await this.setup.refreshIdentity();
      if(!user.emailVerified){this.error.set('Your email is not verified yet. Open the link in your email, then check again.');return;}
      await this.router.navigateByUrl(await this.setup.destination());
    }catch(e){this.error.set(registrationError(e));}finally{this.busy.set(false);}
  }
  async resend():Promise<void>{
    if(this.busy()||this.cooldown())return;this.busy.set(true);this.error.set('');
    try{const user=this.setup.auth.currentUser;if(!user)return;await runInInjectionContext(this.injector,()=>sendEmailVerification(user));this.message.set('Verification email sent.');this.cooldown.set(60);this.timer=setInterval(()=>{this.cooldown.update(v=>Math.max(0,v-1));if(!this.cooldown()&&this.timer)clearInterval(this.timer);},1000);}
    catch(e){this.error.set(registrationError(e));}finally{this.busy.set(false);}
  }
  async localVerification():Promise<void>{
    if(!this.localMode||this.busy())return;this.busy.set(true);this.error.set('');
    try{const response=await fetch('http://127.0.0.1:9099/emulator/v1/projects/'+environment.firebaseApp.projectId+'/oobCodes');if(!response.ok)throw new Error('Unable to load the local verification email.');
      const data=await response.json() as {oobCodes?:{email:string;requestType:string;oobLink:string}[]};const matches=data.oobCodes?.filter(c=>c.email===this.setup.auth.currentUser?.email&&c.requestType==='VERIFY_EMAIL') ?? [];const found=matches[matches.length-1];if(!found)throw new Error('No verification email found. Choose Resend email first.');
      const url=new URL(found.oobLink);if(url.protocol!=='http:'||!['localhost','127.0.0.1'].includes(url.hostname)||url.port!=='9099')throw new Error('Invalid local verification link.');this.localLink.set(url.href);
    }catch(e){this.error.set(registrationError(e));}finally{this.busy.set(false);}
  }
  async logout():Promise<void>{await this.setup.logout();await this.router.navigateByUrl('/authentication');}
}
@Component({standalone:true,imports:[ReactiveFormsModule,RouterLink],styleUrl:'./public-journey.scss',template:`
<main class="public-page"><header class="public-bar"><a class="public-brand" routerLink="/"><span class="brand-box">C</span>CBT Platform</a><button class="text-action" (click)="logout()" [disabled]="busy()">Sign out</button></header>
<section class="account-card"><span class="eyebrow">Your institution workspace · 3 of 3</span><h1>A place for your institution.</h1><p>Add the essentials. You will be its first administrator, with a guided setup to help you get ready.</p>
@if(error()){<div class="notice error" role="alert">{{error()}}</div>}
@if(loading()){<p role="status">Loading your account…</p>}
<form [formGroup]="form" (ngSubmit)="submit()"><fieldset [disabled]="busy() || loading()">
<label>Institution name<input formControlName="name" autocomplete="organization" maxlength="150"></label><label>Short name<input formControlName="shortName" maxlength="40"></label>
<label>Institution code<input formControlName="code" placeholder="e.g. bright-school" maxlength="40" (input)="availability.set('')"></label><p class="hint">3–40 letters, numbers and single hyphens, starting with a letter. Students use this code to join your institution.</p>
<button type="button" class="soft-action" (click)="checkCode()" [disabled]="checking() || form.controls.code.invalid">{{checking() ? 'Checking…' : 'Check availability'}}</button>@if(availability()){<div class="hint" role="status">{{availability()}}</div>}
<label style="margin-top:20px">Address<input formControlName="address" autocomplete="street-address" maxlength="250"></label><div class="form-grid"><label>Contact email<input formControlName="contactEmail" type="email" autocomplete="email"></label><label>Phone<input formControlName="phone" type="tel" autocomplete="tel" maxlength="40"></label></div><label>Timezone<input formControlName="timezone"></label>
<div class="notice">Your institution starts with the platform's Starter settings and trial status. Activation and billing are managed by the platform administrator.</div>
<button class="action full" [disabled]="busy() || loading()">{{busy() ? 'Creating workspace…' : 'Create institution & start setup →'}}</button>
</fieldset></form></section></main>`})
export class CreateInstitutionPage implements OnInit {
  readonly setup=inject(InstitutionOnboardingService);private readonly router=inject(Router);
  readonly loading=signal(true);readonly busy=signal(false);readonly checking=signal(false);readonly availability=signal('');readonly error=signal('');
  readonly form=new FormGroup({name:new FormControl('',{nonNullable:true,validators:[Validators.required,Validators.minLength(2)]}),shortName:new FormControl('',{nonNullable:true,validators:[Validators.required,Validators.minLength(2)]}),code:new FormControl('',{nonNullable:true,validators:[Validators.required,Validators.minLength(3),Validators.maxLength(40),Validators.pattern(/^[A-Za-z][A-Za-z0-9]*(?:-[A-Za-z0-9]+)*$/)]}),address:new FormControl('',{nonNullable:true,validators:[Validators.required,Validators.minLength(2)]}),contactEmail:new FormControl('',{nonNullable:true,validators:[Validators.required,Validators.email]}),phone:new FormControl('',{nonNullable:true,validators:[Validators.required,Validators.minLength(2)]}),timezone:new FormControl('Africa/Lagos',{nonNullable:true,validators:[Validators.required]})});
  async ngOnInit():Promise<void>{try{await this.setup.auth.authStateReady();this.form.controls.contactEmail.setValue(this.setup.auth.currentUser?.email ?? '');}finally{this.loading.set(false);}}
  async checkCode():Promise<void>{if(this.checking()||this.form.controls.code.invalid)return;this.checking.set(true);this.error.set('');const code=this.form.controls.code.value;try{const result=await this.setup.checkCode(code);if(this.form.controls.code.value===code)this.availability.set(result.available?'Available. Your code is reserved when the institution is created.':'This code is taken. Choose another.');}catch(e){this.error.set(registrationError(e));}finally{this.checking.set(false);}}
  async submit():Promise<void>{this.form.markAllAsTouched();if(this.busy())return;if(this.form.invalid){this.error.set('Complete all institution details and choose a valid code.');return;}this.busy.set(true);this.error.set('');try{await this.setup.provision(this.form.getRawValue());await this.router.navigateByUrl('/onboarding');}catch(e){this.error.set(registrationError(e));}finally{this.busy.set(false);}}
  async logout():Promise<void>{await this.setup.logout();await this.router.navigateByUrl('/authentication');}
}


