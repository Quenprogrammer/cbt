import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { InstitutionOnboardingService, InstitutionSetupState, setupSteps, SetupStep } from '../../services/institution-onboarding.service';
import { registrationError } from './account.pages';

@Component({standalone:true,imports:[FormsModule,RouterLink],styleUrl:'./public-journey.scss',template:`
<main class="public-page"><header class="public-bar"><a class="public-brand" routerLink="/"><span class="brand-box">C</span>CBT Platform</a><button class="text-action" (click)="logout()" [disabled]="busy()">Sign out</button></header>
<section class="setup-shell"><div class="setup-heading"><span class="eyebrow">YOUR INSTITUTION, READY FOR WHAT’S NEXT</span><h1>Let’s get the essentials in place.</h1><p>A guided start for your CBT workspace. Your progress is saved after each successful step.</p></div>
@if(error()){<div class="notice error" role="alert">{{error()}} <button class="text-action" (click)="load()" [disabled]="busy()">Reload saved progress</button></div>}
@if(loading()){<div class="setup-panel loading" role="status">Loading your saved setup…</div>}
@else { @if(state();as current){
@if(current.progress?.status==='completed'){<section class="setup-panel"><span class="verification-icon"><i class="bi bi-check2-all"></i></span><h2>Your essentials are in place.</h2><p>Continue from your dashboard checklist to add questions, register candidates and prepare your next examination.</p><a class="action" routerLink="/admin/dashboard">Open dashboard →</a></section>}
@else if(!current.progress){<section class="setup-panel"><h2>Set up at your own pace.</h2><p>Your existing institution can use this guide without losing any current subjects, candidates or results.</p><div class="actions"><button class="action" (click)="save('start')" [disabled]="busy()">Start guided setup →</button><a class="soft-action" routerLink="/admin/dashboard">Back to dashboard</a></div></section>}
@else{
<div class="setup-layout"><aside class="setup-rail"><ol aria-label="Setup steps">@for(item of steps;track item;let i=$index){<li [class.current]="step()===item" [class.done]="current.progress.completedSteps.includes(item)" [attr.aria-current]="step()===item?'step':null"><span class="step-number">{{current.progress.completedSteps.includes(item)?'✓':i+1}}</span>{{labels[item]}}</li>}</ol></aside>
<section class="setup-panel"><div class="step-meta">STEP {{index()+1}} OF {{steps.length}} · {{current.progress.paused?'Resuming saved setup':'Institution essentials'}}</div><progress [value]="index()+1" [max]="steps.length" aria-label="Current setup step"></progress>
<fieldset [disabled]="busy()">
@switch(step()){
@case('welcome'){<h2>Welcome to {{current.profile.name}}.</h2><p>Your workspace is created. Review the essentials now, then use your dashboard checklist for the rest.</p><div class="welcome-grid"><div><i class="bi bi-building"></i><strong>Make it yours</strong><small>Confirm institution details</small></div><div><i class="bi bi-journal-text"></i><strong>Prepare a subject</strong><small>Start with a draft</small></div><div><i class="bi bi-person-check"></i><strong>Bring students in</strong><small>Share your institution code</small></div></div>}
@case('profile'){<h2>Your institution profile.</h2><p>These details help your team identify the right workspace.</p><div class="form-grid"><label>Institution name<input [(ngModel)]="profile.name" maxlength="150"></label><label>Short name<input [(ngModel)]="profile.shortName" maxlength="40"></label><label class="wide">Address<input [(ngModel)]="profile.address" maxlength="250"></label><label>Contact email<input type="email" [(ngModel)]="profile.email"></label><label>Phone<input type="tel" [(ngModel)]="profile.phone" maxlength="40"></label><label>Timezone<input [(ngModel)]="profile.timezone"></label><label>Currency<input value="NGN" readonly></label></div>}
@case('academic'){<h2>A structure for your subjects.</h2><p>Choose the first class, level or department you want to prepare. You can add more subjects later.</p><label>First class or level<input [(ngModel)]="academic.className" maxlength="80" placeholder="e.g. SS 2"></label><label>Department (optional)<input [(ngModel)]="academic.department" maxlength="120" placeholder="e.g. Science"></label>}
@case('exam'){<h2>Your first exam subject.</h2><p>We will save an inactive draft subject. Add questions and enable it later from your examination workspace.</p>
@if(current.setupSubjectId){<div class="notice success">Your draft subject is saved. Continue setup, then add its questions from the dashboard checklist.</div>}
@else if(!current.modules['subjects'] || !current.modules['exams']){<div class="notice">Subjects or exams are not enabled on your current plan. You can defer this step.</div>}
@else{<label class="check-label"><input type="checkbox" [(ngModel)]="exam.createSubject">Create a draft subject now</label>@if(exam.createSubject){<label>Subject name<input [(ngModel)]="exam.name" maxlength="120" placeholder="e.g. English Language"></label><label>Description<input [(ngModel)]="exam.description" maxlength="240"></label><div class="form-grid"><label>Class or level<input [(ngModel)]="exam.className" maxlength="80"></label><label>Duration (minutes)<input type="number" min="1" max="480" step="1" [(ngModel)]="exam.timeLimit"></label><label>Question limit<input type="number" min="1" max="500" step="1" [(ngModel)]="exam.questionLimit"></label></div>}}}
@case('registration'){<h2>Give students the right starting point.</h2><p>Share this code with your candidates. They will use it to join this institution and choose from its enabled subjects.</p><div class="code-box">{{current.registrationCode}}</div><label>Student registration link<input [value]="registrationLink()" readonly></label><p class="hint">A draft subject will not appear for students until it is enabled. Creating a student account never grants administrator access.</p>}
@case('review'){<h2>Ready for your next step.</h2><p>Review your essentials. Questions, candidate imports and exam access stay in their dedicated workflows.</p><dl class="review-list"><div><dt>Institution</dt><dd>{{current.profile.name}}</dd></div><div><dt>Contact</dt><dd>{{current.profile.email}}</dd></div><div><dt>Institution code</dt><dd>{{current.registrationCode}}</dd></div><div><dt>Academic structure</dt><dd>{{current.academic.className}}</dd></div><div><dt>First subject</dt><dd>{{current.checks.subjects?'Saved':'Add later'}}</dd></div><div><dt>Candidate records</dt><dd>{{current.checks.candidates?'Started':'Add from the dashboard'}}</dd></div></dl><div class="notice" style="margin-top:24px">Finishing setup does not start or publish an examination.</div>}
}
<div class="actions between"><button class="soft-action" (click)="save('back')" [disabled]="busy() || index()===0">← Back</button><button class="text-action" (click)="save('pause')" [disabled]="busy()">Save and exit</button>@if(step()==='exam' || step()==='registration'){<button class="text-action" (click)="save('defer')" [disabled]="busy()">Do later</button>}<button class="action" (click)="save()" [disabled]="busy()">{{busy()?'Saving…':step()==='review'?'Finish setup →':step()==='welcome'?'Start setup →':'Save and continue →'}}</button></div>
</fieldset></section></div>}
} }
</section></main>`})
export class InstitutionOnboardingPage implements OnInit {
  readonly setup=inject(InstitutionOnboardingService);private readonly router=inject(Router);
  readonly state=signal<InstitutionSetupState|null>(null);readonly loading=signal(true);readonly busy=signal(false);readonly error=signal('');
  readonly steps=setupSteps;readonly labels:Record<SetupStep,string>={welcome:'Welcome',profile:'Institution',academic:'Academic structure',exam:'First exam subject',registration:'Candidate registration',review:'Review'};
  profile={name:'',shortName:'',email:'',phone:'',address:'',timezone:'Africa/Lagos',currency:'NGN'};
  academic={className:'',department:''};exam={createSubject:true,name:'',description:'',className:'',timeLimit:30,questionLimit:20};
  async ngOnInit():Promise<void>{await this.load();}
  step():SetupStep{return this.state()?.progress?.currentStep ?? 'welcome';}index():number{return this.steps.indexOf(this.step());}
  registrationLink():string{return location.origin+'/sign-up?tenant='+encodeURIComponent(this.state()?.registrationCode ?? '');}
  async load():Promise<void>{this.loading.set(true);this.error.set('');try{const state=await this.setup.load();this.state.set(state);this.profile={...state.profile};this.academic={...state.academic};this.exam.className=state.academic.className;}catch(e){this.error.set(registrationError(e));}finally{this.loading.set(false);}}
  async save(action='continue'):Promise<void>{
    if(this.busy())return;this.busy.set(true);this.error.set('');
    try{
      const step=this.step(),revision=this.state()?.progress?.revision ?? 0;
      const data=step==='profile'?this.profile:step==='academic'?this.academic:step==='exam'?(this.state()?.setupSubjectId?{createSubject:false}:this.exam):{};
      await this.setup.save(step,revision,data,action);
      if(action==='pause' || (step==='review'&&action==='continue')){await this.router.navigateByUrl('/admin/dashboard');return;}
      await this.load();
    }catch(e){this.error.set(registrationError(e));}finally{this.busy.set(false);}
  }
  async logout():Promise<void>{if(this.busy())return;await this.setup.logout();await this.router.navigateByUrl('/authentication');}
}

