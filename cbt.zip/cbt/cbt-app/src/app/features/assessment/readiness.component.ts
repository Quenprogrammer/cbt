import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { AssessmentPageState } from './assessment-page-state';

@Component({ selector: 'app-readiness', standalone: true, imports: [CommonModule], template: `
  <main id="content" class="main"><div class="content"><h1>Exam readiness</h1><p>Check approved questions, blueprints, candidate registration and configured attempt capacity before an examination.</p><div class="d-flex gap-2 mb-3"><button class="btn btn-primary" [disabled]="loading() || busy()" (click)="load()">Refresh server checks</button><button class="btn btn-outline-primary" [disabled]="loading() || busy() || !data()" (click)="browserChecks()">Check this browser and question images</button></div>
    @if (loading()) { <p role="status">Checking readiness…</p> } @if (busy()) { <p role="status">Checking browser image loading…</p> } @if (error()) { <p role="alert" class="alert alert-danger">{{ error() }}</p> }
    @if (data(); as report) {
      <div class="row g-3 mb-4"><div class="col-md-3"><div class="card card-body"><strong>{{ report.candidates }}</strong><span>Registered candidates</span></div></div><div class="col-md-3"><div class="card card-body"><strong>{{ report.activeSessions }}</strong><span>Active examinations</span></div></div><div class="col-md-3"><div class="card card-body"><strong>{{ report.usedAttempts }} / {{ report.attemptLimit || 'Unlimited' }}</strong><span>Monthly attempt capacity</span></div></div><div class="col-md-3"><div class="card card-body"><strong>{{ report.roundTripMs }} ms</strong><span>Server readiness scan</span></div></div></div>
      @if (report.attemptLimit && report.usedAttempts >= report.attemptLimit) { <p class="alert alert-danger">The monthly attempt limit has been reached.</p> }
      <section class="card card-body mb-4"><h2 class="h5">Subject checks</h2><div class="table-responsive"><table class="table"><thead><tr><th>Subject</th><th>Approved</th><th>Drafts / archived</th><th>Target</th><th>Readiness</th></tr></thead><tbody>@for (subject of report.subjects; track subject.id) { <tr><td>{{ subject.name }} {{ subject.active ? '' : '(inactive)' }}</td><td>{{ subject.approved }}</td><td>{{ subject.drafts }}</td><td>{{ subject.target }}</td><td>@for (issue of subject.issues; track issue) { <p class="text-danger mb-1">{{ issue }}</p> } @empty { <span class="text-success">Ready</span> }</td></tr> } @empty { <tr><td colspan="5">No subjects configured.</td></tr> }</tbody></table></div></section>
      <section class="card card-body mb-4"><h2 class="h5">Candidate attention required</h2>@for (candidate of report.candidateIssues; track candidate.id) { <p><strong>{{ candidate.name }}</strong> — {{ candidate.issues.join(' ') }}</p> } @empty { <p class="text-success">Every candidate has active registered subjects and exam access.</p> }</section>
    }
    @if (browserReport) { <section class="card card-body"><h2 class="h5">This browser</h2><p>Network: {{ browserReport.online ? 'Connected' : 'Offline' }} · Local answer backup: {{ browserReport.storage ? 'Available' : 'Unavailable' }}</p><p>{{ browserReport.loaded }} images loaded; {{ browserReport.failed.length }} failed.</p>@for (url of browserReport.failed; track url) { <p class="text-danger text-break">{{ url }}</p> }<p class="text-muted small">These checks describe this browser and the configured quota; they are not a concurrent-user load test.</p></section> }
  </div></main>
` })
export class ReadinessComponent extends AssessmentPageState {
  browserReport: any = null;
  constructor() { super(); void this.load(); }
  load(): Promise<void> { return this.fetch('exam_readiness', 'inspect'); }
  async browserChecks(): Promise<void> {
    await this.perform(async () => {
      let storage = false; const key = 'cbt.readiness.' + crypto.randomUUID();
      try { localStorage.setItem(key, 'ok'); storage = localStorage.getItem(key) === 'ok'; localStorage.removeItem(key); } catch { /* Report unavailable. */ }
      const urls = [...new Set<string>((this.data()?.subjects || []).flatMap((subject: any) => subject.imageUrls || []))].slice(0, 200), failed: string[] = [];
      const check = (url: string) => new Promise<void>(resolve => { const image = new Image(); let finished = false; const done = (ok: boolean) => { if (finished) return; finished = true; clearTimeout(timer); if (!ok) failed.push(url); image.onload = image.onerror = null; resolve(); }; const timer = setTimeout(() => done(false), 4000); image.onload = () => done(true); image.onerror = () => done(false); image.src = url; });
      for (let index = 0; index < urls.length; index += 6) await Promise.all(urls.slice(index, index + 6).map(check));
      this.browserReport = { online: navigator.onLine, storage, loaded: urls.length - failed.length, failed }; return true;
    });
  }
}
