import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AssessmentPageState } from './assessment-page-state';

@Component({ selector: 'app-staff-access', standalone: true, imports: [FormsModule], template: `
  <main id="content" class="main"><div class="content"><h1>Staff access and permissions</h1><p>Create staff sign-ins and grant only the tasks each staff member needs. Institution administrators retain full access.</p>
    @if (error()) { <p role="alert" class="alert alert-danger">{{ error() }}</p> } @if (message()) { <p role="status" class="alert alert-success">{{ message() }}</p> } @if (loading()) { <p role="status">Loading staff accounts…</p> }
    <section class="card card-body mb-4"><h2 class="h5">{{ editing ? 'Edit staff access' : 'Create staff account' }}</h2><div class="row g-3"><div class="col-md-6"><label class="form-label" for="staff-access-name">Name</label><input id="staff-access-name" class="form-control" [(ngModel)]="name" maxlength="150"></div><div class="col-md-6"><label class="form-label" for="staff-access-email">Email</label><input id="staff-access-email" type="email" class="form-control" [(ngModel)]="email" [readOnly]="editing"></div>@if (!editing) { <div class="col-12"><label class="form-label" for="staff-access-password">Initial password (at least 12 characters)</label><input id="staff-access-password" type="password" class="form-control" [(ngModel)]="password" minlength="12" autocomplete="new-password"><p class="form-text">Share credentials through your institution's usual secure process. This action does not send an email.</p></div> }</div>
      <div class="d-flex flex-wrap gap-2 my-3"><button class="btn btn-sm btn-outline-secondary" (click)="permissions = ['questions.write']">Question author preset</button><button class="btn btn-sm btn-outline-secondary" (click)="permissions = ['questions.write','questions.review']">Question reviewer preset</button><button class="btn btn-sm btn-outline-secondary" (click)="permissions = ['results.manage','reports.read']">Results officer preset</button></div>
      <div class="row g-2">@for (permission of data()?.permissions || []; track permission) { <label class="col-md-6"><input class="form-check-input me-2" type="checkbox" [checked]="permissions.includes(permission)" (change)="toggle(permission,$any($event.target).checked)">{{ labels[permission] || permission }}</label> }</div><label class="mt-3"><input type="checkbox" [(ngModel)]="disabled"> Disable this staff account's tenant access</label><div class="d-flex gap-2 mt-3"><button class="btn btn-primary" [disabled]="busy()" (click)="save()">Save staff access</button><button class="btn btn-outline-secondary" (click)="clear()">New account</button></div>
    </section>
    <section class="card card-body"><h2 class="h5">Staff accounts</h2>@for (user of data()?.users || []; track user.uid) { <div class="border-bottom py-3"><strong>{{ user.displayName }} — {{ user.status }}</strong><p>{{ user.email }}</p><p class="small">{{ user.permissions?.join(', ') || 'No permissions' }}</p><button class="btn btn-sm btn-outline-primary" (click)="edit(user)">Edit permissions</button></div> } @empty { <p>No staff sign-in accounts.</p> }</section>
  </div></main>
` })
export class StaffAccessComponent extends AssessmentPageState {
  editing = false; name = ''; email = ''; password = ''; permissions: string[] = []; disabled = false;
  readonly labels: Record<string, string> = { 'questions.write': 'Create and edit questions', 'questions.review': 'Review and approve questions', 'results.manage': 'Mark essays, release results and resolve appeals', 'exams.manage': 'Manage schedules and readiness', 'students.manage': 'View student records', 'reports.read': 'View performance reports', 'backups.manage': 'Create and restore backups' };
  constructor() { super(); void this.load(); }
  load(): Promise<void> { return this.fetch('staff_access', 'list'); }
  toggle(permission: string, checked: boolean): void { this.permissions = checked ? [...new Set([...this.permissions, permission])] : this.permissions.filter(value => value !== permission); }
  edit(user: any): void { this.editing = true; this.name = user.displayName; this.email = user.email; this.password = ''; this.permissions = [...(user.permissions || [])]; this.disabled = user.status === 'disabled'; }
  clear(): void { this.editing = false; this.name = ''; this.email = ''; this.password = ''; this.permissions = []; this.disabled = false; }
  async save(): Promise<void> { if (await this.perform(() => this.api.call('staff_access', 'save', { name: this.name, email: this.email, password: this.password, permissions: this.permissions, disabled: this.disabled }), 'Staff access saved.')) { this.clear(); await this.load(); } }
}
