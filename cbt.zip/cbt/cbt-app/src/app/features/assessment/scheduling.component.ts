import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { toSignal } from '@angular/core/rxjs-interop';
import { ExamsListService } from '../../services/exams-list.service';
import { AssessmentPageState } from './assessment-page-state';

@Component({ selector: 'app-exam-scheduling', standalone: true, imports: [CommonModule, FormsModule], template: `
  <main id="content" class="main"><div class="content"><h1>Exam scheduling and reminders</h1><p>Set the entry window for each subject. Times use your browser's time zone ({{ timezone }}). New attempts must enter within the late-entry allowance and finish before the window closes.</p>
    @if (error()) { <p role="alert" class="alert alert-danger">{{ error() }}</p> } @if (message()) { <p role="status" class="alert alert-success">{{ message() }}</p> }
    <section class="card card-body"><label class="form-label" for="schedule-subject">Subject</label><select id="schedule-subject" class="form-select mb-3" [(ngModel)]="subjectId" (ngModelChange)="select()"><option value="">Choose a subject</option>@for (subject of subjects(); track subject.id) { <option [value]="subject.id">{{ subject.name }}</option> }</select><label class="mb-3"><input type="checkbox" [(ngModel)]="enabled"> Use a scheduled examination window</label><div class="row g-3"><div class="col-md-4"><label class="form-label" for="exam-start">Starts at</label><input id="exam-start" type="datetime-local" class="form-control" [(ngModel)]="startsAt" [disabled]="!enabled"></div><div class="col-md-4"><label class="form-label" for="exam-end">Closes at</label><input id="exam-end" type="datetime-local" class="form-control" [(ngModel)]="endsAt" [disabled]="!enabled"></div><div class="col-md-4"><label class="form-label" for="exam-late">Late entry allowance (minutes)</label><input id="exam-late" type="number" min="0" max="480" class="form-control" [(ngModel)]="lateEntryMinutes" [disabled]="!enabled"></div></div><label class="mt-3"><input type="checkbox" [(ngModel)]="reminders"> Show an in-app reminder within 24 hours of the start</label><button class="btn btn-primary mt-3" (click)="save()" [disabled]="busy() || !subjectId">Save schedule</button></section>
    <section class="card card-body mt-4"><h2 class="h5">Candidate reminders</h2><p>Registered candidates receive one reminder per scheduled window in their Schedule and results page. The background sweep runs every 15 minutes when deployed.</p><button class="btn btn-outline-primary" (click)="remind()" [disabled]="busy()">Generate upcoming in-app reminders now</button></section>
  </div></main>
` })
export class SchedulingComponent extends AssessmentPageState {
  readonly subjects = toSignal(inject(ExamsListService).examlist$, { initialValue: [] });
  readonly timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  subjectId = ''; enabled = false; startsAt = ''; endsAt = ''; lateEntryMinutes = 15; reminders = true;
  private localDate(ms: number): string { return ms ? new Date(ms - new Date(ms).getTimezoneOffset() * 60000).toISOString().slice(0, 16) : ''; }
  select(): void { const value = (this.subjects().find(subject => subject.id === this.subjectId) as any)?.schedule || {}; this.enabled = Boolean(value.enabled); this.startsAt = this.localDate(value.startsAtMs); this.endsAt = this.localDate(value.endsAtMs); this.lateEntryMinutes = value.lateEntryMinutes ?? 15; this.reminders = value.reminders ?? true; }
  async save(): Promise<void> { await this.perform(() => this.api.call('exam_scheduling', 'save', { subjectId: this.subjectId, enabled: this.enabled, startsAt: this.startsAt ? new Date(this.startsAt).toISOString() : '', endsAt: this.endsAt ? new Date(this.endsAt).toISOString() : '', lateEntryMinutes: this.lateEntryMinutes, reminders: this.reminders }), 'Schedule saved. Existing examination sessions keep their current deadline.'); }
  async remind(): Promise<void> { const result = await this.perform(() => this.api.call('exam_scheduling', 'sendReminders')); if (result) this.message.set(`Created ${result.created} new reminders. Existing reminders were preserved.`); }
}
