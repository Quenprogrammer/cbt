import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { toSignal } from '@angular/core/rxjs-interop';
import { Firestore, collection, getDocs, query, where } from '@angular/fire/firestore';
import { ExamsListService } from '../../services/exams-list.service';
import { TenantContextService } from '../../services/tenant-context.service';
import { QuestionContentComponent } from '../../shared/questions/question-content.component';
import { AssessmentPageState } from './assessment-page-state';

@Component({ selector: 'app-question-review', standalone: true, imports: [FormsModule, QuestionContentComponent], template: `
  <main id="content" class="main"><div class="content"><h1>Question review queue</h1><p class="text-muted">Approve submitted questions or return them with feedback. Only approved questions are available in examinations and practice.</p><label class="form-label" for="review-subject">Subject</label><select id="review-subject" class="form-select mb-4" [(ngModel)]="subjectId" (ngModelChange)="load()"><option value="">Choose a subject</option>@for (subject of subjects(); track subject.id) { <option [value]="subject.id">{{ subject.name }}</option> }</select>
    @if (error()) { <p class="alert alert-danger" role="alert">{{ error() }}</p> } @if (message()) { <p class="alert alert-success" role="status">{{ message() }}</p> } @if (loading()) { <p role="status">Loading submitted drafts…</p> }
    @for (question of questions; track question.id) { <section class="card card-body mb-4"><p class="small text-muted">Version {{ question.version || 0 }} · Author {{ question.updatedBy || question.createdBy }}</p><app-question-content [question]="question"></app-question-content><details class="mb-3"><summary>Marking key and guidance</summary><pre class="text-wrap">{{ markingKey(question) }}</pre></details><label class="form-label" [for]="'review-comment-' + question.id">Reviewer feedback</label><textarea [id]="'review-comment-' + question.id" class="form-control mb-2" [(ngModel)]="question.comment" maxlength="3000"></textarea><div class="d-flex gap-2"><button class="btn btn-success" [disabled]="busy()" (click)="review(question,'approved')">Approve</button><button class="btn btn-outline-danger" [disabled]="busy() || !question.comment" (click)="review(question,'rejected')">Return for changes</button></div></section> } @empty { @if (subjectId && !loading()) { <p>No questions are waiting for review in this subject.</p> } }
  </div></main>
` })
export class QuestionReviewComponent extends AssessmentPageState {
  readonly subjects = toSignal(inject(ExamsListService).examlist$, { initialValue: [] });
  private readonly db = inject(Firestore);
  private readonly tenant = inject(TenantContextService);
  subjectId = ''; questions: any[] = [];
  async load(): Promise<void> { if (!this.subjectId) { this.questions = []; return; } this.loading.set(true); this.error.set(''); try { const rows = await getDocs(query(collection(this.db, this.tenant.path(`subjects/${this.subjectId}/exams`)), where('publicationStatus', '==', 'in_review'))); this.questions = rows.docs.filter(row => !row.data()['archived']).map(row => ({ id: row.id, ...row.data(), comment: '' })); } catch (error) { this.error.set((error as Error).message); } finally { this.loading.set(false); } }
  markingKey(question: any): string { return JSON.stringify({ type: question.questionType, options: question.options, correctAnswerId: question.correctAnswerId, correctAnswerIds: question.correctAnswerIds, acceptedAnswers: question.acceptedAnswers, matchingPairs: question.matchingPairs, rubric: question.rubric, explanation: question.explanation }, null, 2); }
  async review(question: any, decision: string): Promise<void> { if (await this.perform(() => this.api.call('question_lifecycle', 'reviewQuestion', { subjectId: this.subjectId, questionId: question.id, expectedVersion: question.version || 0, decision, comment: question.comment }), decision === 'approved' ? 'Question approved.' : 'Question returned for changes.')) await this.load(); }
}
