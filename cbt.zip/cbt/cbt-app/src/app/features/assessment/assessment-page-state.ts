import { inject, signal } from '@angular/core';
import { AssessmentApiService } from '../../services/assessment-api.service';
export class AssessmentPageState {
  readonly api = inject(AssessmentApiService);
  readonly data = signal<any>(null); readonly loading = signal(false); readonly busy = signal(false); readonly error = signal(''); readonly message = signal('');
  async fetch(group: string, name: string, data: object = {}): Promise<void> { this.loading.set(true); this.error.set(''); try { this.data.set(await this.api.call(group, name, data)); } catch (error) { this.error.set((error as Error).message); } finally { this.loading.set(false); } }
  async perform<T>(operation: () => Promise<T>, success = ''): Promise<T | null> { if (this.busy()) return null; this.busy.set(true); this.error.set(''); this.message.set(''); try { const value = await operation(); if (success) this.message.set(success); return value; } catch (error) { this.error.set((error as Error).message); return null; } finally { this.busy.set(false); } }
}
