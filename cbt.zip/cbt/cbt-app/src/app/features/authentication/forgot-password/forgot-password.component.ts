import { Component, inject, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { Auth, sendPasswordResetEmail } from '@angular/fire/auth';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './forgot-password.component.html',
})
export class ForgotPasswordComponent {
  private readonly auth = inject(Auth);
  readonly sending = signal(false);
  readonly sent = signal(false);
  readonly message = signal('');

  readonly form = new FormGroup({
    email: new FormControl('', { nonNullable: true, validators: [Validators.required, Validators.email] }),
  });

  async submit(): Promise<void> {
    if (this.form.invalid || this.sending()) return;
    this.sending.set(true);
    this.message.set('');
    try {
      await sendPasswordResetEmail(this.auth, this.form.controls.email.value);
      this.sent.set(true);
      this.message.set('Password reset request sent.');
    } catch (error: any) {
      this.message.set(error?.message ?? 'Unable to send reset request.');
    } finally {
      this.sending.set(false);
    }
  }
}
