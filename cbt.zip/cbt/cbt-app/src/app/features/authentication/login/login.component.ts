import { Component, Injector, inject, runInInjectionContext, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Auth, signInWithEmailAndPassword } from '@angular/fire/auth';
import { Router, RouterLink } from '@angular/router';
import { InstitutionOnboardingService } from '../../../services/institution-onboarding.service';

@Component({selector:'app-login',standalone:true,imports:[ReactiveFormsModule,RouterLink],templateUrl:'./login.component.html',styleUrl:'./login.component.scss'})
export class LoginComponent {
  readonly router=inject(Router);private readonly auth=inject(Auth);private readonly injector=inject(Injector);private readonly setup=inject(InstitutionOnboardingService);
  readonly showPassword=signal(false);readonly isSigningIn=signal(false);readonly errorMessage=signal('');
  readonly profileForm=new FormGroup({email:new FormControl('',[Validators.required,Validators.email]),password:new FormControl('',[Validators.required,Validators.minLength(4),Validators.maxLength(128)])});
  async handleSubmit():Promise<void>{
    if(this.isSigningIn()||this.profileForm.invalid)return;this.isSigningIn.set(true);this.errorMessage.set('');
    try{await runInInjectionContext(this.injector,()=>signInWithEmailAndPassword(this.auth,this.profileForm.controls.email.value!.trim(),this.profileForm.controls.password.value!));await this.router.navigateByUrl(await this.setup.destination());}
    catch(error){this.errorMessage.set(error instanceof Error?error.message:'Unable to sign in. Please try again.');}
    finally{this.isSigningIn.set(false);}
  }
  toggleShowPassword():void{this.showPassword.update(value=>!value);}
}
