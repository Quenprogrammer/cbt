import { Component, DestroyRef, Injector, OnInit, inject, runInInjectionContext, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Auth, createUserWithEmailAndPassword, getIdTokenResult, signInWithPopup, updateProfile, sendEmailVerification } from '@angular/fire/auth';
import { GoogleAuthProvider } from 'firebase/auth';
import { Functions, httpsCallable } from '@angular/fire/functions';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Storage, getDownloadURL, ref, uploadBytes } from '@angular/fire/storage';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { InstitutionOnboardingService } from '../../../services/institution-onboarding.service';
import { registrationError } from '../../onboarding/account.pages';

interface RegistrationSubject{id:string;name:string;description:string;class:string;timeLimit:number;questionLimit:number;}
interface SubjectListResponse{tenantId:string;subjects:RegistrationSubject[];}
@Component({selector:'app-sign-up',standalone:true,imports:[CommonModule,ReactiveFormsModule,RouterLink],templateUrl:'./sign-up.component.html',styleUrl:'./sign-up.component.scss'})
export class SignUpComponent implements OnInit {
  private readonly auth=inject(Auth);private readonly functions=inject(Functions);private readonly injector=inject(Injector);private readonly router=inject(Router);private readonly route=inject(ActivatedRoute);private readonly storage=inject(Storage);private readonly setup=inject(InstitutionOnboardingService);private readonly destroy=inject(DestroyRef);
  readonly subjects=signal<RegistrationSubject[]>([]);readonly selectedSubjectIds=signal<string[]>([]);readonly loadingSubjects=signal(false);readonly initializing=signal(true);readonly saving=signal(false);readonly errorMessage=signal('');readonly accountNotice=signal('');readonly photoPreview=signal('');readonly tenantName=signal('');readonly step=signal(0);readonly signedIn=signal(false);
  readonly maxSubjects=11;readonly steps=['Institution','Account','Student profile','Subjects','Review'];
  private selectedPhoto:File|null=null;private request=0;private resolvedCode='';
  readonly identityFields=[{key:'admissionNumber',label:'Admission number *',type:'text'},{key:'firstname',label:'First name *',type:'text'},{key:'middlename',label:'Middle name',type:'text'},{key:'lastname',label:'Last name *',type:'text'},{key:'dateOfBirth',label:'Date of birth *',type:'date'},{key:'department',label:'Department / class *',type:'text'},{key:'classLevel',label:'Class level',type:'text'},{key:'enrollmentDate',label:'Enrollment date',type:'date'}];
  readonly additionalFields=[{key:'phone',label:'Phone',type:'tel'},{key:'address',label:'Address',type:'text'},{key:'stateOfOrigin',label:'State of origin',type:'text'},{key:'lga',label:'LGA',type:'text'},{key:'guardianName',label:'Guardian name',type:'text'},{key:'guardianPhone',label:'Guardian phone',type:'tel'},{key:'guardianEmail',label:'Guardian email',type:'email'},{key:'emergencyContact',label:'Emergency contact',type:'text'},{key:'bloodGroup',label:'Blood group',type:'text'},{key:'genotype',label:'Genotype',type:'text'},{key:'notes',label:'Additional notes',type:'text'}];
  readonly profileForm=new FormGroup({
    tenantCode:new FormControl('',{nonNullable:true,validators:[Validators.required]}),
    admissionNumber:new FormControl('',{nonNullable:true,validators:[Validators.required]}),
    firstname:new FormControl('',{nonNullable:true,validators:[Validators.required]}),
    middlename:new FormControl('',{nonNullable:true}),lastname:new FormControl('',{nonNullable:true,validators:[Validators.required]}),
    gender:new FormControl('',{nonNullable:true,validators:[Validators.required]}),dateOfBirth:new FormControl('',{nonNullable:true,validators:[Validators.required]}),
    department:new FormControl('',{nonNullable:true,validators:[Validators.required]}),classLevel:new FormControl('',{nonNullable:true}),enrollmentDate:new FormControl('',{nonNullable:true}),
    email:new FormControl('',{nonNullable:true,validators:[Validators.required,Validators.email]}),phone:new FormControl('',{nonNullable:true}),address:new FormControl('',{nonNullable:true}),stateOfOrigin:new FormControl('',{nonNullable:true}),lga:new FormControl('',{nonNullable:true}),guardianName:new FormControl('',{nonNullable:true}),guardianPhone:new FormControl('',{nonNullable:true}),guardianEmail:new FormControl('',{nonNullable:true,validators:[Validators.email]}),emergencyContact:new FormControl('',{nonNullable:true}),bloodGroup:new FormControl('',{nonNullable:true}),genotype:new FormControl('',{nonNullable:true}),notes:new FormControl('',{nonNullable:true}),
    password:new FormControl('',{nonNullable:true,validators:[Validators.required,Validators.minLength(8),Validators.maxLength(128)]}),
    confirmPassword:new FormControl('',{nonNullable:true,validators:[Validators.required]}),acceptTerms:new FormControl(false,{nonNullable:true,validators:[Validators.requiredTrue]})
  });
  async ngOnInit():Promise<void>{
    this.profileForm.controls.tenantCode.valueChanges.pipe(takeUntilDestroyed(this.destroy)).subscribe(()=>{++this.request;this.subjects.set([]);this.selectedSubjectIds.set([]);this.tenantName.set('');this.resolvedCode='';this.loadingSubjects.set(false);});
    try{
      await this.auth.authStateReady();
      const user=this.auth.currentUser;
      if(user){
        const state=await this.setup.state();
        if(state.role==='admin'||state.role==='student'){await this.router.navigateByUrl(await this.setup.destination());return;}
        this.prepareSignedIn();
        this.profileForm.controls.tenantCode.setValue(this.route.snapshot.queryParamMap.get('tenant')||state.tenantCode||'');
        if(this.profileForm.controls.tenantCode.value){await this.loadSubjects();if(this.tenantName())this.step.set(user.emailVerified?2:1);}
      }else this.profileForm.controls.tenantCode.setValue(this.route.snapshot.queryParamMap.get('tenant')||'');
    }catch(e){this.errorMessage.set(registrationError(e));}finally{this.initializing.set(false);}
  }
  private prepareSignedIn():void{
    this.signedIn.set(!!this.auth.currentUser);if(!this.auth.currentUser)return;
    this.profileForm.controls.email.setValue(this.auth.currentUser.email||'');
    for(const key of ['password','confirmPassword'] as const){this.profileForm.controls[key].clearValidators();this.profileForm.controls[key].reset();this.profileForm.controls[key].updateValueAndValidity();}
  }
  private async call<T>(name:string,data:object):Promise<T>{const fn=runInInjectionContext(this.injector,()=>httpsCallable<object,T>(this.functions,'student_accounts-'+name));return(await fn(data)).data;}
  async loadSubjects():Promise<void>{
    const code=this.profileForm.controls.tenantCode.value.trim(),request=++this.request;
    if(!code){this.errorMessage.set('Enter the institution code supplied by your school or centre.');return;}
    this.loadingSubjects.set(true);this.errorMessage.set('');
    try{
      const institution=await this.call<{tenantId:string;name:string}>('resolveRegistrationTenant',{tenantCode:code});
      const response=await this.call<SubjectListResponse>('listRegistrationSubjects',{tenantCode:code});
      if(request!==this.request)return;
      if(response.tenantId!==institution.tenantId)throw new Error('The subject list does not match this institution.');
      this.tenantName.set(institution.name);this.resolvedCode=code.toLowerCase();this.subjects.set(response.subjects ?? []);
    }catch(e){if(request===this.request){this.tenantName.set('');this.subjects.set([]);this.selectedSubjectIds.set([]);this.errorMessage.set(registrationError(e));}}
    finally{if(request===this.request)this.loadingSubjects.set(false);}
  }
  async next():Promise<void>{
    this.errorMessage.set('');
    if(this.step()===0){await this.loadSubjects();if(this.tenantName())this.step.set(1);return;}
    if(this.step()===1){await this.accountStep();return;}
    if(this.step()===2){const required=['admissionNumber','firstname','lastname','gender','dateOfBirth','department','guardianEmail'];for(const key of required)this.profileForm.get(key)?.markAsTouched();if(required.some(key=>this.profileForm.get(key)?.invalid)){this.errorMessage.set('Complete the required identity and academic fields, and check any guardian email.');return;}this.step.set(3);return;}
    if(this.step()===3){if(!this.selectedSubjectIds().length){this.errorMessage.set('Select at least one subject. If none are available, contact your institution.');return;}this.step.set(4);}
  }
  back():void{if(this.saving())return;this.step.update(v=>Math.max(0,v-1));this.errorMessage.set('');}
  private async accountStep():Promise<void>{
    if(this.saving())return;
    const raw=this.profileForm.getRawValue();
    if(this.profileForm.controls.email.invalid){this.errorMessage.set('Enter a valid email address.');return;}
    if(!this.auth.currentUser && (this.profileForm.controls.password.invalid||raw.password!==raw.confirmPassword)){this.errorMessage.set('Use a password of at least eight characters and matching confirmation.');return;}
    this.saving.set(true);
    try{
      let user=this.auth.currentUser;
      if(!user)user=(await runInInjectionContext(this.injector,()=>createUserWithEmailAndPassword(this.auth,raw.email.trim(),raw.password))).user;
      if(user.email?.toLowerCase()!==raw.email.trim().toLowerCase())throw new Error('Sign out before using a different email.');
      await this.setup.intent('student',raw.tenantCode);
      this.prepareSignedIn();
      if(!user.emailVerified){
        try{await runInInjectionContext(this.injector,()=>sendEmailVerification(user!));}catch{}
        await this.router.navigateByUrl('/verify-email');return;
      }
      this.step.set(2);
    }catch(e){this.errorMessage.set(registrationError(e));}finally{this.saving.set(false);}
  }
  toggleSubject(id:string,checked:boolean):void{const selected=new Set(this.selectedSubjectIds());if(checked&&selected.size>=this.maxSubjects&&!selected.has(id)){this.errorMessage.set('Select no more than '+this.maxSubjects+' subjects.');return;}if(checked)selected.add(id);else selected.delete(id);this.selectedSubjectIds.set([...selected]);this.errorMessage.set('');}
  isSubjectSelected(id:string):boolean{return this.selectedSubjectIds().includes(id);}
  subjectSelectionDisabled(id:string):boolean{return !this.isSubjectSelected(id)&&this.selectedSubjectIds().length>=this.maxSubjects;}
  onPhotoSelected(event:Event):void{
    const input=event.target as HTMLInputElement,file=input.files?.[0];if(!file)return;
    if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>=5*1024*1024){this.errorMessage.set('Choose a JPEG, PNG or WebP image smaller than 5 MB.');input.value='';return;}
    this.selectedPhoto=file;const reader=new FileReader();reader.onload=()=>this.photoPreview.set(String(reader.result||''));reader.readAsDataURL(file);this.errorMessage.set('');
  }
  private async uploadStudentPhoto(uid:string):Promise<string>{
    if(!this.selectedPhoto)return this.auth.currentUser?.photoURL||'';
    const extension=({'image/jpeg':'jpg','image/png':'png','image/webp':'webp'} as Record<string,string>)[this.selectedPhoto.type];
    const code=this.profileForm.controls.tenantCode.value.trim().toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'');
    return runInInjectionContext(this.injector,async()=>{const file=ref(this.storage,'tenant-registration/'+code+'/'+uid+'/profile.'+extension);await uploadBytes(file,this.selectedPhoto!,{contentType:this.selectedPhoto!.type});return getDownloadURL(file);});
  }
  async createAccount():Promise<void>{
    if(this.saving())return;
    if(this.step()!==4){await this.next();return;}
    this.profileForm.markAllAsTouched();
    if(this.profileForm.invalid||!this.selectedSubjectIds().length||this.selectedSubjectIds().length>this.maxSubjects){this.errorMessage.set('Complete all required fields, select subjects and confirm your information.');return;}
    const user=this.auth.currentUser;if(!user){this.step.set(1);this.errorMessage.set('Create or sign in to your account first.');return;}
    if(!user.emailVerified){await this.router.navigateByUrl('/verify-email');return;}
    if(this.resolvedCode!==this.profileForm.controls.tenantCode.value.trim().toLowerCase()){this.step.set(0);this.errorMessage.set('Confirm your institution code again.');return;}
    this.saving.set(true);this.errorMessage.set('');
    try{
      await this.setup.refreshIdentity();const raw=this.profileForm.getRawValue();const photoURL=await this.uploadStudentPhoto(user.uid);
      try{await runInInjectionContext(this.injector,()=>updateProfile(user,{displayName:[raw.firstname,raw.middlename,raw.lastname].filter(Boolean).join(' '),...(photoURL?{photoURL}:{})}));}catch{}
      const {password,confirmPassword,acceptTerms,...profile}=raw;
      await this.call('registerStudent',{...profile,photoURL,subjectIds:this.selectedSubjectIds()});
      await runInInjectionContext(this.injector,()=>getIdTokenResult(user,true));await this.router.navigateByUrl('/home');
    }catch(e){this.errorMessage.set(registrationError(e));this.accountNotice.set('Your account is kept. Correct the issue and try again to finish registration.');}finally{this.saving.set(false);}
  }
  async googleSignIn():Promise<void>{
    if(this.saving())return;this.saving.set(true);this.errorMessage.set('');
    try{const result=await runInInjectionContext(this.injector,()=>signInWithPopup(this.auth,new GoogleAuthProvider()));const names=(result.user.displayName||'').split(/\s+/);this.profileForm.controls.firstname.setValue(names[0]||'');this.profileForm.controls.lastname.setValue(names.slice(1).join(' '));this.prepareSignedIn();const state=await this.setup.state();if(state.role){await this.router.navigateByUrl(await this.setup.destination());return;}await this.setup.intent('student',this.profileForm.controls.tenantCode.value);this.step.set(result.user.emailVerified?2:1);}
    catch(e){this.errorMessage.set(registrationError(e));}finally{this.saving.set(false);}
  }
  async logout():Promise<void>{await this.setup.logout();await this.router.navigateByUrl('/authentication');}
}
