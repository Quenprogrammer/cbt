import { Routes } from '@angular/router';
import { adminRoleGuard, guestOnlyGuard, studentRoleGuard } from './guards/role.guard';
import { pendingAccountGuard } from './guards/onboarding.guard';

export const routes: Routes = [
  { path:'security/verify',loadComponent:()=>import('./features/security/security.component').then(m=>m.SecurityComponent) },
  { path:'student/practice',canActivate:[studentRoleGuard],loadComponent:()=>import('./features/assessment/practice.component').then(m=>m.PracticeComponent) },
  { path:'student/assessments',canActivate:[studentRoleGuard],loadComponent:()=>import('./features/assessment/student-assessment-hub.component').then(m=>m.StudentAssessmentHubComponent) },
  {
    path: '',
    pathMatch: 'full',
    loadComponent: () => import('./features/landing/landing.component').then(m => m.LandingComponent),
  },
  {
    path: 'register/institution',
    loadComponent: () => import('./features/onboarding/account.pages').then(m => m.RegisterInstitutionPage),
  },
  {
    path: 'verify-email', canActivate: [pendingAccountGuard],
    loadComponent: () => import('./features/onboarding/account.pages').then(m => m.VerifyEmailPage),
  },
  {
    path: 'create-institution', canActivate: [pendingAccountGuard],
    loadComponent: () => import('./features/onboarding/account.pages').then(m => m.CreateInstitutionPage),
  },
  {
    path: 'onboarding', canActivate: [adminRoleGuard],
    loadComponent: () => import('./features/onboarding/institution-onboarding.page').then(m => m.InstitutionOnboardingPage),
  },
  {
    path: 'admin',
    loadComponent: () => import('./core/layout/layout.component').then((m) => m.LayoutComponent),
    loadChildren: () => import('./core/routes').then((m) => m.routes),
    canActivate: [adminRoleGuard],
  },
  {
    path: 'home',
    loadComponent: () => import('./features/student-portal/student-home.component').then((m) => m.StudentHomeComponent),
    canActivate: [studentRoleGuard],
  },
  {
    path: 'student/exam',
    loadComponent: () => import('./features/student-portal/student-exam.component').then((m) => m.StudentExamComponent),
    canActivate: [studentRoleGuard],
  },
  {
    path: 'student/exam/:id',
    loadComponent: () => import('./features/student-portal/student-exam.component').then((m) => m.StudentExamComponent),
    canActivate: [studentRoleGuard],
  },
  {
    path: 'student/history',
    loadComponent: () => import('./features/student-portal/attempt-history/attempt-history.component').then((m) => m.AttemptHistoryComponent),
    canActivate: [studentRoleGuard],
  },
  {
    path: 'tenant-access',
    loadComponent: () => import('./features/tenant-access/tenant-access.component').then((m) => m.TenantAccessComponent),
  },
  {
    path: 'result-check',
    loadComponent: () => import('./features/public-result/public-result.component').then((m) => m.PublicResultComponent),
  },
  {
    path: 'sign-up',
    loadComponent: () => import('./features/authentication/sign-up/sign-up.component').then((m) => m.SignUpComponent),
  },
  {
    path: 'forget-password',
    loadComponent: () => import('./features/authentication/forgot-password/forgot-password.component').then((m) => m.ForgotPasswordComponent),
  },
  {
    path: 'authentication',
    loadComponent: () => import('./features/authentication/login/login.component').then((m) => m.LoginComponent),
    canActivate: [guestOnlyGuard],
  },
  {
    path: '**',
    redirectTo: '',
  },
];
