import { CanActivateFn } from '@angular/router';

export const preventBackGuard: CanActivateFn = (route, state) => {
  return true;
};
