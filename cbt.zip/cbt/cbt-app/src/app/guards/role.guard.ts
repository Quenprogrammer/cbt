import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { Auth, signOut } from '@angular/fire/auth';
import { routePermissions } from '../core/route-permissions';
import { TenantContextService } from '../services/tenant-context.service';
import { InstitutionOnboardingService } from '../services/institution-onboarding.service';
import { AccountSecurityService } from '../services/account-security.service';

function roleGuard(expected:'admin'|'student'):CanActivateFn {
  return async()=>{
    const auth=inject(Auth),router=inject(Router),tenant=inject(TenantContextService),setup=inject(InstitutionOnboardingService),security=inject(AccountSecurityService);
    await auth.authStateReady();
    if(!auth.currentUser)return router.parseUrl('/authentication');
    try{
      const protection=await security.refresh();if(protection.revoked){await signOut(auth);return router.parseUrl('/authentication');}if(!protection.verified)return router.parseUrl('/security/verify');
      const token=await auth.currentUser.getIdTokenResult(true);
      const role=token.claims['role'];
      if(role!=='admin' && role!=='student' && role!=='staff')return router.parseUrl(await setup.destination());
      const access=await tenant.initializeFromToken();
      if(!access.accessible)return router.parseUrl('/tenant-access');
      return role===expected || expected==='admin'&&role==='staff' ? true : router.parseUrl(role==='admin'||role==='staff'?'/admin/dashboard':'/home');
    }catch{return router.parseUrl('/authentication');}
  };
}
export const adminRoleGuard=roleGuard('admin');
export const studentRoleGuard=roleGuard('student');
export const staffPermissionGuard:CanActivateFn=route=>{
  const tenant=inject(TenantContextService),router=inject(Router);if(tenant.state()?.role==='admin')return true;
  const path=route.routeConfig?.path||'';
  const required=routePermissions[path];return required&&(required.length===0||required.some(permission=>tenant.can(permission)))?true:router.parseUrl('/admin/security');
};
export const guestOnlyGuard:CanActivateFn=async()=>{
  const auth=inject(Auth),router=inject(Router),setup=inject(InstitutionOnboardingService);
  await auth.authStateReady();if(!auth.currentUser)return true;
  try{return router.parseUrl(await setup.destination());}catch{return true;}
};
