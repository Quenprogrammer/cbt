import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { InstitutionOnboardingService } from '../services/institution-onboarding.service';

export const pendingAccountGuard:CanActivateFn=async route=>{
  const setup=inject(InstitutionOnboardingService),router=inject(Router);
  await setup.auth.authStateReady();
  if(!setup.auth.currentUser)return router.parseUrl('/authentication');
  try {
    const destination=await setup.destination();
    return destination==='/'+route.routeConfig?.path ? true : router.parseUrl(destination);
  } catch {return true;}
};
export const administratorSetupGuard:CanActivateFn=async()=>{
  const setup=inject(InstitutionOnboardingService),router=inject(Router);
  try {const state=await setup.load();return !state.progress || state.progress.status==='completed' || state.progress.paused ? true : router.parseUrl('/onboarding');}
  catch{return router.parseUrl('/onboarding');}
};
