import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AccessibilityComponent } from './shared/accessibility/accessibility.component';
@Component({selector:'app-root',standalone:true,imports:[RouterOutlet,AccessibilityComponent],template:'<app-accessibility /><router-outlet />'})
export class AppComponent {}
