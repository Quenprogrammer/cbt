import { TestBed } from '@angular/core/testing';
import { FormControl } from '@angular/forms';
import { Storage } from '@angular/fire/storage';
import { TenantContextService } from '../../services/tenant-context.service';
import { QuestionImageComponent } from './question-image.component';
import { QuestionImageEditorComponent, questionImageUrlValidator } from './question-image-editor.component';

describe('Question images', () => {
  it('accepts uploaded URLs and bundled diagrams while rejecting executable URLs', () => {
    const control = new FormControl('', questionImageUrlValidator);
    for (const value of ['', '/question-images/math.svg', 'https://example.com/diagram.png', 'http://localhost:9199/image.png']) {
      control.setValue(value);
      expect(control.valid).withContext(value).toBeTrue();
    }
    for (const value of ['javascript:alert(1)', 'data:image/svg+xml,<svg/>', 'not a url', 'https://user:password@example.com/image.png']) {
      control.setValue(value);
      expect(control.valid).withContext(value).toBeFalse();
    }
  });

  it('displays descriptions, reports failed loads and recovers when the image changes', () => {
    const fixture = TestBed.createComponent(QuestionImageComponent);
    fixture.componentRef.setInput('imageUrl', '/question-images/math.svg');
    fixture.componentRef.setInput('imageAlt', 'Triangle with a base and a perpendicular height');
    fixture.detectChanges();
    const img = fixture.nativeElement.querySelector('img') as HTMLImageElement;
    expect(img.alt).toContain('Triangle');
    img.dispatchEvent(new Event('error'));
    fixture.detectChanges();
    expect(fixture.nativeElement.textContent).toContain('could not be loaded');
    fixture.componentRef.setInput('imageUrl', '/question-images/english.svg');
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('img')).not.toBeNull();
    fixture.componentRef.setInput('imageUrl', '');
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('figure')).toBeNull();
  });

  it('rejects unsupported and oversized uploads without replacing an existing image', async () => {
    TestBed.configureTestingModule({ providers: [{ provide: Storage, useValue: {} }, { provide: TenantContextService, useValue: {} }] });
    const fixture = TestBed.createComponent(QuestionImageEditorComponent);
    const component = fixture.componentInstance;
    const changed = jasmine.createSpy('imageUrlChange');
    component.imageUrlChange.subscribe(changed);
    for (const file of [new File(['<svg/>'], 'test.svg', { type: 'image/svg+xml' }), new File([new Uint8Array(5 * 1024 * 1024)], 'large.png', { type: 'image/png' })]) {
      await component.upload({ target: { files: [file], value: 'file' } } as unknown as Event);
      expect(component.error).toContain('under 5 MB');
      expect(component.busy).toBeFalse();
    }
    expect(changed).not.toHaveBeenCalled();
  });

  it('removes both the image and its description', () => {
    TestBed.configureTestingModule({ providers: [{ provide: Storage, useValue: {} }, { provide: TenantContextService, useValue: {} }] });
    const component = TestBed.createComponent(QuestionImageEditorComponent).componentInstance;
    const urls: string[] = [], descriptions: string[] = [];
    component.imageUrlChange.subscribe(value => urls.push(value));
    component.imageAltChange.subscribe(value => descriptions.push(value));
    component.remove();
    expect(urls).toEqual(['']);
    expect(descriptions).toEqual(['']);
  });
});
