import { Component, Input, OnChanges } from '@angular/core';

@Component({
  selector: 'app-question-image',
  standalone: true,
  template: `
    @if (imageUrl) {
      <figure>
        @if (failed) {
          <p role="alert">The question image could not be loaded.
            <button type="button" (click)="failed = false">Retry image</button>
          </p>
        } @else {
          <a [href]="imageUrl" target="_blank" rel="noopener noreferrer" aria-label="Open question image at full size">
            <img [src]="imageUrl" [alt]="imageAlt || 'Image accompanying this question'" (error)="failed = true">
          </a>
        }
      </figure>
    }
  `,
  styles: [`
    figure { margin: 1rem 0; }
    img { display: block; max-width: 100%; width: auto; height: auto; max-height: 420px; object-fit: contain; border: 1px solid #dbe2ea; border-radius: 8px; background: white; }
    p { color: #a12b20; }
    button { margin-left: .5rem; }
  `],
})
export class QuestionImageComponent implements OnChanges {
  @Input() imageUrl: string | null | undefined = '';
  @Input() imageAlt: string | null | undefined = '';
  failed = false;

  ngOnChanges(): void { this.failed = false; }
}
