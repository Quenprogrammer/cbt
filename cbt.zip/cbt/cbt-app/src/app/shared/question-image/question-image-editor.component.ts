import { Component, EventEmitter, inject, Injector, Input, OnDestroy, Output } from '@angular/core';
import { AbstractControl, ValidationErrors } from '@angular/forms';
import { AssessmentApiService } from '../../services/assessment-api.service';
import { QuestionImageComponent } from './question-image.component';

export function questionImageUrlValidator(control: AbstractControl): ValidationErrors | null {
  const value = String(control.value ?? '').trim();
  if (!value || /^\/question-images\/[\w.-]+\.svg$/.test(value)) return null;
  try {
    const url = new URL(value);
    return ['https:', 'http:'].includes(url.protocol) && !url.username && !url.password
      ? null : { imageUrl: true };
  } catch { return { imageUrl: true }; }
}

@Component({
  selector: 'app-question-image-editor',
  standalone: true,
  imports: [QuestionImageComponent],
  template: `
    <fieldset [disabled]="busy">
      <legend class="form-label fs-6">Question image (optional)</legend>
      <label class="form-label" for="question-image-file">Upload an image</label>
      <input id="question-image-file" type="file" class="form-control" accept="image/png,image/jpeg,image/webp,image/gif" (change)="upload($event)">
      <p class="form-text">PNG, JPEG, WebP or GIF, under 5 MB. You can also paste an image URL below.</p>
      <label class="form-label" for="question-image-url">Image URL</label>
      <input id="question-image-url" class="form-control" type="url" [value]="imageUrl" (input)="changeUrl($event)" placeholder="https://example.com/diagram.png">
      <label class="form-label mt-2" for="question-image-alt">Image description</label>
      <input id="question-image-alt" class="form-control" [value]="imageAlt" (input)="imageAltChange.emit($any($event.target).value)" placeholder="Describe the diagram without revealing the answer" maxlength="500">
      <app-question-image [imageUrl]="previewUrl || imageUrl" [imageAlt]="imageAlt"></app-question-image>
      @if (imageUrl) {
        <button type="button" class="btn btn-outline-danger btn-sm mt-2" (click)="remove()">Remove image</button>
      }
    </fieldset>
    @if (busy) { <p role="status" class="text-muted mt-2">Uploading image…</p> }
    @if (error) { <p role="alert" class="text-danger mt-2">{{ error }}</p> }
  `,
})
export class QuestionImageEditorComponent implements OnDestroy {
  @Input() imageUrl = '';
  @Input() imageAlt = '';
  @Output() imageUrlChange = new EventEmitter<string>();
  @Output() imageAltChange = new EventEmitter<string>();
  @Output() busyChange = new EventEmitter<boolean>();
  private readonly injector = inject(Injector);
  busy = false;
  error = '';
  previewUrl = '';

  changeUrl(event: Event): void {
    this.error = '';
    this.imageUrlChange.emit((event.target as HTMLInputElement).value.trim());
  }

  remove(): void {
    this.imageUrlChange.emit('');
    this.imageAltChange.emit('');
    this.error = '';
  }

  async upload(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    input.value = '';
    if (!file || this.busy) return;
    this.error = '';
    const extensions: Record<string, string> = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif' };
    if (!extensions[file.type] || file.size === 0 || file.size >= 5 * 1024 * 1024) {
      this.error = 'Choose a PNG, JPEG, WebP or GIF image under 5 MB.';
      return;
    }
    this.busy = true;
    this.busyChange.emit(true);
    this.previewUrl = URL.createObjectURL(file);
    try {
      const url = await this.injector.get(AssessmentApiService).upload(file);
      this.imageUrlChange.emit(url);
    } catch (error) {
      console.error('Question image upload failed:', error);
      this.error = 'Unable to upload the image. Please try again before saving.';
    } finally {
      URL.revokeObjectURL(this.previewUrl);
      this.previewUrl = '';
      this.busy = false;
      this.busyChange.emit(false);
    }
  }

  ngOnDestroy(): void { if (this.previewUrl) URL.revokeObjectURL(this.previewUrl); }
}
