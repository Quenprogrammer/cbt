import { Component, Input } from '@angular/core';
import { FormGroup, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-question-metadata', standalone: true, imports: [ReactiveFormsModule],
  template: `
    <fieldset [formGroup]="group" class="row g-3">
      <legend class="fs-6">Question organization</legend>
      <div class="col-md-6"><label class="form-label" for="metadata-topic">Topic</label><input id="metadata-topic" class="form-control" formControlName="topic" maxlength="120" placeholder="e.g. Algebra"></div>
      <div class="col-md-6"><label class="form-label" for="metadata-difficulty">Difficulty</label><select id="metadata-difficulty" class="form-select" formControlName="difficulty"><option value="easy">Easy</option><option value="medium">Medium</option><option value="hard">Hard</option></select></div>
      <div class="col-md-4"><label class="form-label" for="metadata-class">Class</label><input id="metadata-class" class="form-control" formControlName="className" maxlength="120" placeholder="e.g. SS2"></div>
      <div class="col-md-4"><label class="form-label" for="metadata-curriculum">Curriculum</label><input id="metadata-curriculum" class="form-control" formControlName="curriculum" maxlength="120" placeholder="e.g. National curriculum"></div>
      <div class="col-md-4"><label class="form-label" for="metadata-session">Academic session</label><input id="metadata-session" class="form-control" formControlName="academicSession" maxlength="120" placeholder="e.g. 2026/2027"></div>
      <div class="col-12"><label class="form-label" for="metadata-tags">Tags</label><input id="metadata-tags" class="form-control" formControlName="tags" maxlength="1000" placeholder="Up to 20 tags, separated by commas"></div>
    </fieldset>
  `,
})
export class QuestionMetadataComponent { @Input({ required: true }) group!: FormGroup; }
