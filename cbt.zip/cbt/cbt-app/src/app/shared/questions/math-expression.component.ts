import { AfterViewInit, Component, ElementRef, Input, OnChanges, ViewChild } from '@angular/core';

// Builds native MathML from a small, safe expression grammar; never inserts HTML.
export function createMathExpression(document: Document, source: string): Element {
  const ns = 'http://www.w3.org/1998/Math/MathML';
  const make = (name: string, text?: string) => { const node = document.createElementNS(ns, name); if (text) node.textContent = text; return node; };
  let index = 0;
  const input = source.slice(0, 2000), greek: Record<string, string> = { alpha: 'α', beta: 'β', gamma: 'γ', delta: 'δ', theta: 'θ', pi: 'π', sigma: 'σ', mu: 'μ', times: '×', div: '÷', le: '≤', ge: '≥' };
  function group(depth: number, single = false): Element {
    const row = make('mrow'); if (depth > 25) { row.append(make('mtext', input.slice(index))); index = input.length; return row; }
    const braced = input[index] === '{'; if (braced) index++;
    while (index < input.length) {
      const char = input[index++];
      if (char === '}') break;
      if (char === '^' || char === '_') { const base = row.lastChild || make('mi', ' '); row.append(base); const script = make(char === '^' ? 'msup' : 'msub'); script.append(base, group(depth + 1, true)); row.append(script); }
      else if (char === '\\') {
        const command = /^[a-z]+/i.exec(input.slice(index))?.[0] || ''; index += command.length;
        if (command === 'frac') { const fraction = make('mfrac'); fraction.append(group(depth + 1, true), group(depth + 1, true)); row.append(fraction); }
        else if (command === 'sqrt') { const root = make('msqrt'); root.append(group(depth + 1, true)); row.append(root); }
        else row.append(make('mi', greek[command] || '\\' + command));
      } else if (char === '{') { index--; row.append(group(depth + 1)); }
      else if (/\d/.test(char)) { const tail = /^[\d.]*/.exec(input.slice(index))?.[0] || ''; index += tail.length; row.append(make('mn', char + tail)); }
      else if (/\s/.test(char)) { const space = make('mspace'); space.setAttribute('width', '.25em'); row.append(space); }
      else row.append(make(/[+\-=×÷<>≤≥()]/.test(char) ? 'mo' : 'mi', char));
      if (single && !braced) break;
    }
    return row;
  }
  const math = make('math'); math.setAttribute('display', 'block'); math.setAttribute('aria-label', source); math.append(group(0)); return math;
}
@Component({ selector: 'app-math-expression', standalone: true, template: '<div #host class="math-expression"></div>', styles: ['.math-expression { overflow-x: auto; padding: .75rem; font-size: 1.4em; }'] })
export class MathExpressionComponent implements AfterViewInit, OnChanges {
  @Input() expression = '';
  @ViewChild('host') host?: ElementRef<HTMLElement>;
  ngAfterViewInit(): void { this.render(); }
  ngOnChanges(): void { this.render(); }
  private render(): void { if (this.host) this.host.nativeElement.replaceChildren(...(this.expression ? [createMathExpression(document, this.expression)] : [])); }
}
