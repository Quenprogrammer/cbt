export type QuestionType = 'mcq' | 'true_false' | 'multiple_answer' | 'fill_blank' | 'matching' | 'essay';
export type ExamResponse = string | string[] | { text: string } | { matches: Record<string, string> };
export interface RichQuestion {
  question: string;
  questionType: QuestionType;
  options: Array<{ id: string; text: string; imageUrl?: string; imageAlt?: string }>;
  passage?: string;
  formula?: string;
  tableRows?: Array<string[]|{cells:string[]}>;
  imageUrl?: string;
  imageAlt?: string;
  audioUrl?: string;
  videoUrl?: string;
  matchingItems?: Array<{ id: string; text: string }>;
  matchingChoices?: Array<{ id: string; text: string }>;
}
export function hasExamResponse(value: ExamResponse | undefined): boolean { return typeof value === 'string' ? Boolean(value.trim()) : Array.isArray(value) ? value.length > 0 : Boolean(value && ('text' in value ? value.text.trim() : Object.keys(value.matches).length)); }
export function localResponse(question: RichQuestion, value: any): ExamResponse {
  const ids = question.options.map(option => option.id);
  if (question.questionType === 'multiple_answer') return Array.isArray(value) ? value.filter(id => ids.includes(id)) : [];
  if (question.questionType === 'essay' || question.questionType === 'fill_blank') return { text: typeof value === 'string' ? value : String(value?.text || '') };
  if (question.questionType === 'matching') return { matches: Object.fromEntries((question.matchingItems || []).filter(item => question.matchingChoices?.some(choice => choice.id === value?.matches?.[item.id])).map(item => [item.id, value.matches[item.id]])) };
  return typeof value === 'string' && ids.includes(value) ? value : '';
}
