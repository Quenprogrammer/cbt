import { FormControl, Validators } from '@angular/forms';

export interface QuestionMetadata {
  topic?: string;
  difficulty?: 'easy' | 'medium' | 'hard';
  className?: string;
  curriculum?: string;
  academicSession?: string;
  tags?: string[];
}

export function questionMetadataControls() {
  return {
    topic: new FormControl('General', { nonNullable: true, validators: [Validators.maxLength(120)] }),
    difficulty: new FormControl('medium', { nonNullable: true, validators: [Validators.required] }),
    className: new FormControl('', { nonNullable: true, validators: [Validators.maxLength(120)] }),
    curriculum: new FormControl('', { nonNullable: true, validators: [Validators.maxLength(120)] }),
    academicSession: new FormControl('', { nonNullable: true, validators: [Validators.maxLength(120)] }),
    tags: new FormControl('', { nonNullable: true, validators: [Validators.maxLength(1000)] }),
  };
}

export function metadataForSave(value: any): QuestionMetadata {
  return {
    topic: String(value.topic ?? '').trim() || 'General',
    difficulty: ['easy', 'medium', 'hard'].includes(value.difficulty) ? value.difficulty : 'medium',
    className: String(value.className ?? '').trim(), curriculum: String(value.curriculum ?? '').trim(),
    academicSession: String(value.academicSession ?? '').trim(),
    tags: [...new Set<string>(String(value.tags ?? '').split(',').map(tag => tag.trim()).filter(Boolean))].slice(0, 20),
  };
}
