import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ExamResponse, RichQuestion } from './question-content.model';
import { QuestionImageComponent } from '../question-image/question-image.component';

@Component({ selector: 'app-question-response', standalone: true, imports: [FormsModule, QuestionImageComponent], template: `
  <fieldset [disabled]="disabled">
    <legend class="visually-hidden">Your answer</legend>
    @if (question.questionType === 'essay' || question.questionType === 'fill_blank') {
      <label class="form-label" [for]="'response-' + groupId">{{ question.questionType === 'essay' ? 'Write your answer' : 'Fill in the blank' }}</label>
      <textarea [id]="'response-' + groupId" class="form-control" [rows]="question.questionType === 'essay' ? 8 : 2" [maxlength]="question.questionType === 'essay' ? 20000 : 1000" [ngModel]="textValue()" (ngModelChange)="valueChange.emit({ text: $event })"></textarea>
      @if (question.questionType === 'essay') { <small class="text-muted">{{ textValue().length }} / 20000 characters · Marked by a teacher.</small> }
    } @else if (question.questionType === 'matching') {
      @for (item of question.matchingItems || []; track item.id) {
        <div class="row g-2 align-items-center mb-3"><label class="col-sm-6" [for]="groupId + '-' + item.id">{{ item.text }}</label><div class="col-sm-6"><select [id]="groupId + '-' + item.id" class="form-select" [ngModel]="matchValue(item.id)" (ngModelChange)="setMatch(item.id, $event)"><option value="">Select a match</option>@for (choice of question.matchingChoices || []; track choice.id) { <option [value]="choice.id">{{ choice.text }}</option> }</select></div></div>
      }
    } @else {
      @if (question.questionType === 'multiple_answer') { <p class="text-muted">Select all answers that apply.</p> }
      @for (option of question.options; track option.id; let i = $index) {
        <label class="option-row" [class.selected]="chosen(option.id)"><input [type]="question.questionType === 'multiple_answer' ? 'checkbox' : 'radio'" [name]="groupId" [checked]="chosen(option.id)" (change)="choose(option.id)"><span class="option-letter">{{ ['A','B','C','D','E','F'][i] }}</span><span>{{ option.text }}<app-question-image [imageUrl]="option.imageUrl" [imageAlt]="option.imageAlt"></app-question-image></span></label>
      }
    }
  </fieldset>
`, styles: [`.option-row { display:flex; align-items:center; gap:1rem; padding:1rem; border:1px solid #d8dfeb; border-radius:12px; margin:.65rem 0; cursor:pointer; } .option-row.selected { background:#edf3ff; border-color:#2455a4; } .option-letter { display:inline-grid; place-items:center; width:2rem; height:2rem; border-radius:50%; background:#eef2f8; flex-shrink:0; } fieldset:disabled .option-row { cursor:default; }`] })
export class QuestionResponseComponent {
  @Input({ required: true }) question!: RichQuestion;
  @Input() value: ExamResponse | undefined = '';
  @Input() groupId = 'question';
  @Input() disabled = false;
  @Output() valueChange = new EventEmitter<ExamResponse>();
  chosen(id: string): boolean { return Array.isArray(this.value) ? this.value.includes(id) : this.value === id; }
  choose(id: string): void { if (this.disabled) return; if (this.question.questionType === 'multiple_answer') { const current = Array.isArray(this.value) ? this.value : []; this.valueChange.emit(current.includes(id) ? current.filter(value => value !== id) : [...current, id]); } else this.valueChange.emit(id); }
  textValue(): string { return this.value && typeof this.value === 'object' && 'text' in this.value ? this.value.text : ''; }
  matchValue(id: string): string { return this.value && !Array.isArray(this.value) && typeof this.value === 'object' && 'matches' in this.value ? this.value.matches[id] || '' : ''; }
  setMatch(id: string, value: string): void { if (this.disabled) return; const previous = this.value && !Array.isArray(this.value) && typeof this.value === 'object' && 'matches' in this.value ? this.value.matches : {}; const matches = { ...previous }; if (value) matches[id] = value; else delete matches[id]; this.valueChange.emit({ matches }); }
}
