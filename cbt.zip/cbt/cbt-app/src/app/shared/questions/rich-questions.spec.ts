import { TestBed } from '@angular/core/testing';
import { createMathExpression } from './math-expression.component';
import { QuestionResponseComponent } from './question-response.component';
import { QuestionContentComponent } from './question-content.component';
import { hasExamResponse, localResponse, RichQuestion, ExamResponse } from './question-content.model';

describe('Rich assessment questions', () => {
  const base: RichQuestion = { question: 'Choose an answer', questionType: 'mcq', options: [{ id: 'A', text: 'One' }, { id: 'B', text: 'Two' }] };
  it('renders fractions, roots and powers as native MathML without accepting HTML', () => {
    const math = createMathExpression(document, '\\frac{1}{2}+x^2+\\sqrt{9}');
    expect(math.namespaceURI).toBe('http://www.w3.org/1998/Math/MathML');
    expect(math.querySelectorAll('mfrac').length).toBe(1);
    expect(math.querySelectorAll('msup').length).toBe(1);
    expect(math.querySelectorAll('msqrt').length).toBe(1);
    expect(createMathExpression(document, '<img src=x onerror=alert(1)>').querySelector('img')).toBeNull();
  });
  it('renders stored table rows and preserves passage text as text', () => {
    const fixture = TestBed.createComponent(QuestionContentComponent);
    fixture.componentRef.setInput('question', { ...base, passage: '<script>not executable</script>', tableRows: [{ cells: ['Item', 'Value'] }, { cells: ['A', '1'] }] });
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelectorAll('td').length).toBe(4);
    expect(fixture.nativeElement.querySelector('script')).toBeNull();
    expect(fixture.nativeElement.textContent).toContain('<script>not executable</script>');
  });
  it('allows multiple answers and preserves an explicit empty selection', () => {
    const fixture = TestBed.createComponent(QuestionResponseComponent), component = fixture.componentInstance;
    component.question = { ...base, questionType: 'multiple_answer' };
    let response: ExamResponse = '';
    component.valueChange.subscribe(value => { response = value; component.value = value; });
    fixture.detectChanges();
    const inputs = fixture.nativeElement.querySelectorAll('input');
    inputs[0].click(); fixture.detectChanges(); inputs[1].click(); fixture.detectChanges();
    expect<ExamResponse>(response).toEqual(['A', 'B']);
    inputs[0].click(); fixture.detectChanges(); inputs[1].click(); fixture.detectChanges();
    expect<ExamResponse>(response).toEqual([]); expect(hasExamResponse(response)).toBeFalse();
  });
  it('restores text and matching responses without carrying unrelated option IDs', () => {
    expect(localResponse({ ...base, questionType: 'essay' }, { text: 'A\n  structured response' })).toEqual({ text: 'A\n  structured response' });
    expect(localResponse({ ...base, questionType: 'multiple_answer' }, ['A', 'unknown'])).toEqual(['A']);
    expect(localResponse({ ...base, questionType: 'matching', matchingItems: [{ id: 'L1', text: 'Left' }], matchingChoices: [{ id: 'R1', text: 'Right' }] }, { matches: { L1: 'R1', unrelated: 'R1' } })).toEqual({ matches: { L1: 'R1' } });
  });
  it('does not change a locked response', () => {
    const component = TestBed.createComponent(QuestionResponseComponent).componentInstance;
    component.question = base; component.disabled = true; const changed = jasmine.createSpy('changed'); component.valueChange.subscribe(changed);
    component.choose('A'); expect(changed).not.toHaveBeenCalled();
  });
});
