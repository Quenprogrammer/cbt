import { Component, Input } from '@angular/core';
import { QuestionImageComponent } from '../question-image/question-image.component';
import { MathExpressionComponent } from './math-expression.component';
import { RichQuestion } from './question-content.model';

@Component({ selector: 'app-question-content', standalone: true, imports: [QuestionImageComponent, MathExpressionComponent], template: `
  @if (question.passage) { <blockquote class="passage">{{ question.passage }}</blockquote> }
  <h2 class="question-prompt">{{ question.question }}</h2>
  @if (question.formula) { <app-math-expression [expression]="question.formula"></app-math-expression> }
  @if (question.tableRows?.length) { <div class="table-responsive"><table class="table table-bordered"><caption>Question data</caption><tbody>@for (row of question.tableRows; track $index) { <tr>@for (cell of cells(row); track $index) { <td>{{ cell }}</td> }</tr> }</tbody></table></div> }
  <app-question-image [imageUrl]="question.imageUrl" [imageAlt]="question.imageAlt"></app-question-image>
  @if (question.audioUrl) { <audio controls preload="metadata" [src]="question.audioUrl" aria-label="Question audio">Your browser cannot play this audio.</audio> }
  @if (question.videoUrl) { <video controls preload="metadata" [src]="question.videoUrl" aria-label="Question video">Your browser cannot play this video.</video> }
`, styles: ['.passage { white-space: pre-wrap; padding: 1rem; border-left: 3px solid #2455a4; background: #f2f5fa; } .question-prompt { font-size: 1.35em; white-space: pre-wrap; } audio, video { display: block; width: 100%; max-height: 420px; margin: 1rem 0; }'] })
export class QuestionContentComponent { @Input({ required: true }) question!: RichQuestion; cells(row:string[]|{cells:string[]}):string[]{return Array.isArray(row)?row:row.cells;} }
