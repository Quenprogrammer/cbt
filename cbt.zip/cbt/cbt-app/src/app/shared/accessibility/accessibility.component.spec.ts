import { TestBed } from '@angular/core/testing';
import { AccessibilityComponent, AccessibilityService } from './accessibility.component';
describe('Accessibility preferences', () => {
  beforeEach(() => localStorage.removeItem('cbt.accessibility'));
  afterEach(() => { TestBed.inject(AccessibilityService).reset(); });
  it('applies and persists text size, contrast and motion preferences', () => {
    const service = TestBed.inject(AccessibilityService);
    service.update('scale', 130); service.update('contrast', true); service.update('reducedMotion', true);
    expect(document.documentElement.style.getPropertyValue('--cbt-text-scale')).toBe('1.3');
    expect(document.documentElement.hasAttribute('data-high-contrast')).toBeTrue();
    expect(JSON.parse(localStorage.getItem('cbt.accessibility')!).reducedMotion).toBeTrue();
    service.reset(); expect(document.documentElement.hasAttribute('data-high-contrast')).toBeFalse();
  });
  it('opens with Alt+A and closes with Escape', () => {
    const fixture = TestBed.createComponent(AccessibilityComponent); fixture.detectChanges();
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'a', altKey: true })); fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('#accessibility-panel')).not.toBeNull();
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' })); fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('#accessibility-panel')).toBeNull();
  });
});
