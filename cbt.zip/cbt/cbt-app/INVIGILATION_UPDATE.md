# Student/Staff Editing + Invigilation Scheduling Update

## Edit student
`/admin/edit-student/:id` now edits every field currently captured by Add Student:
- Admission number
- First/middle/last name
- Email and phone
- Gender and date of birth
- Department/class and class level
- Enrollment date and student status
- Firebase Auth UID
- Address, state of origin and LGA
- Blood group and genotype
- Guardian name, phone and email
- Emergency contact
- Notes

Exam access remains controlled by Exam Control rather than the profile form.

## Edit staff
`/admin/edit-staff/:id` now edits every field currently captured by Add Staff:
- Employee ID
- First/middle/last name
- Email and phone
- Gender and date of birth
- Address
- Role and department
- Employment date/type/status
- Qualification and specialization
- Emergency contact name/phone
- Next of kin and phone
- Notes

## Users & Invigilation
`/admin/users` is now an Invigilation Management workspace:
- Lists active staff and their current assignment counts
- Searches staff by name, employee ID, role and department
- Defines exam title, subject/paper, date, start/end time and venue
- Shows whether each staff member is available for the selected time
- Prevents overlapping staff schedules
- Lists/searches active students
- Supports selecting one or many students for an invigilator
- Prevents a student being assigned to overlapping invigilation sessions
- Saves assignments in `invigilationSchedules`
- Shows scheduled/completed/cancelled assignments
- Supports Complete, Cancel, Restore and Delete actions
- Writes audit log events for scheduling and schedule changes

## Firestore
Added admin-only rules for:
`invigilationSchedules/{scheduleId}`

The reset seed process now also clears `invigilationSchedules`.
