# Install Fix - 17 Sep 2026

## Functions build errors: missing dependencies (14 Oct 2026)

If `npm run emulators` reports missing `firebase-admin`, `firebase-functions`,
`nodemailer`, or `puppeteer` modules followed by many TypeScript errors, restore
the separate Functions dependencies from the existing lockfile first:

```powershell
npm --prefix functions ci --no-audit --no-fund
npm run functions:build
npm run emulators
```

Run these commands from the `cbt-app` directory. Installing only the Angular
dependencies does not install the packages in `functions/node_modules`.
The missing module types can also cause follow-on implicit `any`, unknown-type,
and missing `FirebaseFirestore` namespace errors. Keep strict TypeScript checks
enabled and rebuild after restoring dependencies before changing source types.

The previous package had a Functions dependency mismatch:

- `functions/package.json` requested Nodemailer 7.x
- `functions/package-lock.json` resolved Nodemailer 6.10.1
- the root `postinstall` runs `npm --prefix functions ci`, and `npm ci` refuses any package/lock mismatch

This package fixes the mismatch by pinning `nodemailer` to `6.10.1`, matching the existing lockfile and `@types/nodemailer` 6.x line.

## Install

From the project root:

```powershell
npm install
```

The root `postinstall` will automatically run the Functions clean install.

Then start the emulators:

```powershell
npm run emulators
```

In another terminal, start Angular:

```powershell
npm start
```

## If replacing files in an existing extracted copy

Replace these two files from this package:

- `functions/package.json`
- `functions/package-lock.json`

Then remove only the Functions install folder and reinstall:

```powershell
Remove-Item -Recurse -Force .\functions\node_modules -ErrorAction SilentlyContinue
npm install
```

The `deprecated` messages printed by npm are warnings from direct/transitive packages and are not the cause of this install failure.
