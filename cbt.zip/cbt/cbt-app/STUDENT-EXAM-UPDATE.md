# Student Registration & Exam Update

## Added
- Student self-registration with complete student, academic, contact, guardian and account data.
- Subject selection during registration.
- Secure callable registration function that creates/links the Firestore student profile, saves exam registrations, and assigns the `student` custom claim.
- Student dashboard now shows the candidate's registered subjects (legacy seeded students without registrations still keep the previous all-subject behavior).
- "Add question" action on the exam question-bank screen.
- Existing MCQ / True-False question creation remains under `subjects/{subjectId}/exams`.

## Fixed
- `NG0303 Can't bind to ngIf` in Exam List and View Exam by importing `CommonModule`.
- Chart `Canvas element not found` timing by using `ViewChild` + `AfterViewInit`.
- AngularFire `collectionData` outside injection context in the dynamic exam/score services.
- Repeated `_UserImpl` console logging from side navigation/login.
- Callable Functions now explicitly enable CORS.
- Restored the missing `functions/` project inside the Firebase root.
- Removed the accidental `functions -> cbt-web -> functions` npm dependency loop.
- Repaired the Functions lockfile metadata so `npm ci` can validate it.

## Local run
From the project root:

```powershell
npm ci
npm run emulators
```

In another terminal:

```powershell
npm start
```

Or use the existing combined helper:

```powershell
npm run dev
```

`npm run dev` runs the bundled emulator seed workflow, so use the separate `emulators` + `start` commands when you do not want the local emulator data reset.

## Console notes
- `Angular is running in development mode` is an Angular development-mode notice, not an application error. Production builds do not show it.
- `You are using the Auth Emulator` is an intentional local-development warning. It confirms the app is connected to the local Auth emulator.
