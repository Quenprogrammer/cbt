# Assessment features

These additions extend the question bank, official examinations and administration. The earlier import, blueprints, analytics and connection recovery features are described in [CBT-IMPROVEMENTS.md](CBT-IMPROVEMENTS.md).

## Authoring and question types

Open a subject's question bank and create or edit a question. The editor supports reading passages, formulas, tables, question images, images on answer options, audio and video. Enter table columns separated by tabs or `|`, with one row per line. Formula previews use native MathML and support fractions, square roots, powers, subscripts and common Greek symbols. They do not execute HTML or support the full LaTeX language.

Supported question types are multiple choice, true/false, multiple answers, fill in the blank, matching and essay. Multiple answers require the exact correct set. Matching requires all pairs to match. Fill-in answers support multiple accepted spellings, optional case sensitivity and normalized whitespace. Each question carries one mark; essay markers may award partial marks from 0 to 1. Unanswered essays receive zero; answered essays require manual marking before publication.

Upload supported image/audio/video files smaller than 5 MB or enter HTTP(S) media URLs. Click an answer letter or its radio/checkbox to select it; clicking its image opens a full-size preview. Audio and video use browser playback controls. The institution must use media formats playable on candidate devices. Media download URLs are bearer links; avoid distributing question-media links outside the examination process.

## Review and history

Authors can save drafts or submit questions for review. **Question Review** allows an authorized reviewer to approve or return a submitted question with feedback. Staff reviewers cannot approve their own submissions; institution administrators can approve directly. Only approved, non-archived questions enter new examinations and practice sessions. Older questions without a publication status retain their previously published behavior.

**Version history** records every save, review, archive and restoration. Restoring a version creates a new draft and preserves later history. Saves reject a stale version so simultaneous edits do not silently overwrite one another. The history panel displays the latest 50 revisions. Existing questions receive an original snapshot when first edited. Deleting an entire subject still uses the existing subject administration workflow; archive individual questions to preserve their history.

## Practice and candidate information

Authors explicitly enable **Allow this approved question in practice mode**. Students open **Practice** from their dashboard, select a subject/topic and check answers for immediate explanations. Practice reveals answers only for these opted-in questions and creates no official result or attempt charge. Essay practice uses the teacher's rubric for self-assessment.

Students open **Schedule and results** for exam windows, in-app notices, release status and appeals. They can download scheduled windows as `.ics` calendar events. This implementation sends no email or SMS reminders.

## Marking, release and appeals

Open **Marking and Release** to set the default publication policy for new attempts, mark essays, release results immediately, withhold them or schedule a future release. The default is immediate release after marking is complete, preserving existing behavior. The provisional score remains unavailable to public PIN checks and the candidate hub until marking and release conditions are satisfied.

Candidates may submit one appeal per released result. Results officers record a resolution and the candidate receives an in-app notification. Any score change is made through the marking controls, preserving the result revision.

## Accessibility

The global **Aa** control (Alt+A) opens preferences for text size, contrast, reduced motion, reading spacing and a simple font. Escape closes it. Preferences persist in the current browser. Questions use labelled inputs, keyboard-accessible response controls, text alternatives for images and native MathML. Media captions/transcripts are not generated automatically; authors can provide equivalent text in the passage or prompt.

## Scheduling and readiness

**Exam Scheduling** configures subject start/close times, a late-entry allowance, and in-app reminders. New attempts must fit all registered subjects' windows. The assignment deadline cannot extend beyond the earliest closing window. Existing assignments retain their original deadline if a schedule later changes.

The reminder sweep runs every 15 minutes after deployment. **Generate upcoming in-app reminders now** also runs it on demand; repeat runs preserve existing reminders for the same scheduled window.

**Exam Readiness** checks approved question counts, blueprint coverage, expired windows, candidate registration/access, active sessions and monthly attempt quota. Its browser check tests local storage, connectivity and up to 200 distinct question-image URLs. It is a configuration and device check, not a concurrent-user capacity benchmark.

## Account security and scoped staff

Institution administrators open **Staff Access** to create staff sign-ins or edit existing staff permissions. Presets support authors, reviewers and results officers. Server callables and Firestore rules enforce the selected permissions. Account creation respects user/staff limits; disabling a membership blocks tenant access. Staff credentials are not emailed automatically.

Administrators and staff can enable authenticator verification under **Account Security** after a recent sign-in. Add the supplied setup key to an authenticator app, confirm its code and save the eight single-use recovery codes. Codes follow [RFC 6238](https://www.rfc-editor.org/info/rfc6238/). Verification expires after eight hours for a sign-in session. The server rejects reused authenticator steps and recovery codes, and temporarily locks verification after repeated failed attempts.

Two-factor checks are enforced in protected tenant callables, Firestore rules and authenticated Storage access. **Revoke all sessions** invalidates existing protected sessions and signs out the caller. Public result PIN checks and published media download links remain public bearer access. This is application-level authenticator verification, separate from Firebase Authentication's native MFA enrollment.

## Backups and recovery

**Backup and Recovery** creates a tenant snapshot, downloads its compressed archive, previews a restore and restores missing records. Overwriting existing records requires selecting that option and creates a safety backup before changes. Restore is blocked during active examinations. Interrupted jobs retain their ID and progress for retry. A page reload starts a new job; missing-only restoration remains safe to repeat.

Snapshots include assessment settings, questions and their revisions, student/staff records, examination records and results. Authentication accounts, staff permissions, authenticator secrets, platform billing, and media file bytes are excluded. Media URLs are retained and require the original files to remain available. Restore validates the archive checksum, tenant identity and an explicit list of allowed document paths.

Current limits are 5,000 records, 15 MB of uncompressed JSON and 5 MB compressed per snapshot. Automatic backups run daily at 01:00 Africa/Lagos when enabled. Retention keeps the newest configured 1–30 snapshots after a successful daily run. Download important archives before they age out of retention.

## Local checks and rollout

With Firebase emulators running, use `npm run verify:features`. With the app also running on port 4200, use `npm run verify:features:browser`. Both scripts create and remove isolated QA tenants and accounts; neither resets the institution's data. Browser evidence is saved under `artifacts/remaining-features`.

Build with `npm run verify`. Deploy the application, functions, Firestore rules and Storage rules together. The scheduled reminder and backup functions require their deployed Cloud Scheduler jobs; they do not run automatically in the local emulator. Storage rules now consult account-security records in Firestore; deployment may request permission to connect the two services, as described in [Firebase's cross-service rules documentation](https://firebase.google.com/docs/storage/security/rules-conditions#enhance_with_firestore). No production deployment is performed by these local changes.
