# Questions with images

Question management supports an optional image on both multiple-choice and True/False questions.

- Upload PNG, JPEG, WebP or GIF files under 5 MB, or paste an HTTP/HTTPS image URL.
- Add a description so candidates using assistive technology can understand the image.
- Preview, replace or remove the image when creating or editing a question.
- Images appear in the administrator question bank and the student exam. Candidates can open an image at full size.
- Text-only questions continue to work. Correct answers are excluded from student exam packages.

Uploads are saved under `tenants/{tenantId}/question-images/`. Only that tenant's administrators can upload; authenticated users in that tenant can read them. Removing or replacing an image detaches it from the question; it does not delete the stored file, because an existing exam assignment may still reference it.

## Sample questions

The full development seed includes a diagram question for each of the 12 seeded subjects. Original SVG diagrams live in `public/question-images/`, with question definitions in `functions/src/seed/exams/image-questions.ts`.

To add these questions to existing local emulator data without resetting accounts or existing questions, start the Firebase emulators and run:

```sh
npm run seed:images
```

Repeating this command skips examples that are already present. It updates matching subjects in both the legacy collection and tenant collections. It never connects to production Firebase.

Regenerate the diagram assets with `node tools/generate-question-images.cjs`.

## Verification

Build the functions, start the local Auth, Firestore and Storage emulators, then run `node tools/verify-question-images.cjs`. The script creates and cleans up isolated fixtures, and checks storage permissions, image delivery across all subjects, text-only compatibility and resumed exams.

The focused Angular tests are in `src/app/shared/question-image/question-image.component.spec.ts`.
